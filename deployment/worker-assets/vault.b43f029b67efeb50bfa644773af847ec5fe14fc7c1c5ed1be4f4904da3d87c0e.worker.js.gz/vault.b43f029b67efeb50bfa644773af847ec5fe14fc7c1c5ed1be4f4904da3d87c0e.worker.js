var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod2) => function __require() {
  try {
    return mod2 || (0, cb[__getOwnPropNames(cb)[0]])((mod2 = { exports: {} }).exports, mod2), mod2.exports;
  } catch (e) {
    throw mod2 = 0, e;
  }
};

// (disabled):crypto
var require_crypto = __commonJS({
  "(disabled):crypto"() {
  }
});

// node_modules/@hpke/common/esm/src/errors.js
var HpkeError = class extends Error {
  constructor(e) {
    let message;
    if (e instanceof Error) {
      message = e.message;
    } else if (typeof e === "string") {
      message = e;
    } else {
      message = "";
    }
    super(message);
    this.name = this.constructor.name;
  }
};
var InvalidParamError = class extends HpkeError {
};
var SerializeError = class extends HpkeError {
};
var DeserializeError = class extends HpkeError {
};
var EncapError = class extends HpkeError {
};
var DecapError = class extends HpkeError {
};
var ExportError = class extends HpkeError {
};
var SealError = class extends HpkeError {
};
var OpenError = class extends HpkeError {
};
var MessageLimitReachedError = class extends HpkeError {
};
var DeriveKeyPairError = class extends HpkeError {
};
var NotSupportedError = class extends HpkeError {
};

// node_modules/@hpke/common/esm/_dnt.shims.js
var dntGlobals = {};
var dntGlobalThis = createMergeProxy(globalThis, dntGlobals);
function createMergeProxy(baseObj, extObj) {
  return new Proxy(baseObj, {
    get(_target, prop, _receiver) {
      if (prop in extObj) {
        return extObj[prop];
      } else {
        return baseObj[prop];
      }
    },
    set(_target, prop, value) {
      if (prop in extObj) {
        delete extObj[prop];
      }
      baseObj[prop] = value;
      return true;
    },
    deleteProperty(_target, prop) {
      let success = false;
      if (prop in extObj) {
        delete extObj[prop];
        success = true;
      }
      if (prop in baseObj) {
        delete baseObj[prop];
        success = true;
      }
      return success;
    },
    ownKeys(_target) {
      const baseKeys = Reflect.ownKeys(baseObj);
      const extKeys = Reflect.ownKeys(extObj);
      const extKeysSet = new Set(extKeys);
      return [...baseKeys.filter((k2) => !extKeysSet.has(k2)), ...extKeys];
    },
    defineProperty(_target, prop, desc) {
      if (prop in extObj) {
        delete extObj[prop];
      }
      Reflect.defineProperty(baseObj, prop, desc);
      return true;
    },
    getOwnPropertyDescriptor(_target, prop) {
      if (prop in extObj) {
        return Reflect.getOwnPropertyDescriptor(extObj, prop);
      } else {
        return Reflect.getOwnPropertyDescriptor(baseObj, prop);
      }
    },
    has(_target, prop) {
      return prop in extObj || prop in baseObj;
    }
  });
}

// node_modules/@hpke/common/esm/src/algorithm.js
async function loadSubtleCrypto() {
  if (dntGlobalThis !== void 0 && globalThis.crypto !== void 0) {
    return globalThis.crypto.subtle;
  }
  try {
    const { webcrypto } = await import("crypto");
    return webcrypto.subtle;
  } catch (e) {
    throw new NotSupportedError(e);
  }
}
var NativeAlgorithm = class {
  constructor() {
    Object.defineProperty(this, "_api", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
  }
  async _setup() {
    if (this._api !== void 0) {
      return;
    }
    this._api = await loadSubtleCrypto();
  }
};

// node_modules/@hpke/common/esm/src/identifiers.js
var Mode = {
  Base: 0,
  Psk: 1,
  Auth: 2,
  AuthPsk: 3
};
var KemId = {
  NotAssigned: 0,
  DhkemP256HkdfSha256: 16,
  DhkemP384HkdfSha384: 17,
  DhkemP521HkdfSha512: 18,
  DhkemSecp256k1HkdfSha256: 19,
  DhkemX25519HkdfSha256: 32,
  DhkemX448HkdfSha512: 33,
  HybridkemX25519Kyber768: 48,
  MlKem512: 64,
  MlKem768: 65,
  MlKem1024: 66,
  XWing: 25722
};
var KdfId = {
  HkdfSha256: 1,
  HkdfSha384: 2,
  HkdfSha512: 3,
  Sha3256: 4,
  Sha3384: 5,
  Sha3512: 6,
  Shake128: 16,
  Shake256: 17,
  TurboShake128: 18,
  TurboShake256: 19
};
var AeadId = {
  Aes128Gcm: 1,
  Aes256Gcm: 2,
  Chacha20Poly1305: 3,
  ExportOnly: 65535
};

// node_modules/@hpke/common/esm/src/consts.js
var INPUT_LENGTH_LIMIT = 8192;
var INFO_LENGTH_LIMIT = 268435456;
var MINIMUM_PSK_LENGTH = 32;
var EMPTY = /* @__PURE__ */ new Uint8Array(0);
var N_0 = 0n;
var N_1 = 1n;
var N_2 = 2n;

// node_modules/@hpke/common/esm/src/interfaces/kemInterface.js
var SUITE_ID_HEADER_KEM = /* @__PURE__ */ new Uint8Array([
  75,
  69,
  77,
  0,
  0
]);

// node_modules/@hpke/common/esm/src/kdfs/hkdf.js
var HPKE_VERSION = /* @__PURE__ */ new Uint8Array([
  72,
  80,
  75,
  69,
  45,
  118,
  49
]);
function toUint8Array(input) {
  return new Uint8Array(toArrayBuffer(input));
}
function toArrayBuffer(input) {
  if (input instanceof ArrayBuffer) {
    return input;
  }
  if (ArrayBuffer.isView(input)) {
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength).slice().buffer;
  }
  return new Uint8Array(input).slice().buffer;
}
var HkdfNative = class extends NativeAlgorithm {
  constructor() {
    super();
    Object.defineProperty(this, "id", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: KdfId.HkdfSha256
    });
    Object.defineProperty(this, "hashSize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "_suiteId", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: EMPTY
    });
    Object.defineProperty(this, "algHash", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: {
        name: "HMAC",
        hash: "SHA-256",
        length: 256
      }
    });
  }
  init(suiteId) {
    this._suiteId = suiteId;
  }
  buildLabeledIkm(label, ikm) {
    this._checkInit();
    const ret = new Uint8Array(7 + this._suiteId.byteLength + label.byteLength + ikm.byteLength);
    ret.set(HPKE_VERSION, 0);
    ret.set(this._suiteId, 7);
    ret.set(label, 7 + this._suiteId.byteLength);
    ret.set(ikm, 7 + this._suiteId.byteLength + label.byteLength);
    return ret;
  }
  buildLabeledInfo(label, info, len) {
    this._checkInit();
    const ret = new Uint8Array(9 + this._suiteId.byteLength + label.byteLength + info.byteLength);
    ret.set(new Uint8Array([0, len]), 0);
    ret.set(HPKE_VERSION, 2);
    ret.set(this._suiteId, 9);
    ret.set(label, 9 + this._suiteId.byteLength);
    ret.set(info, 9 + this._suiteId.byteLength + label.byteLength);
    return ret;
  }
  async extract(salt, ikm) {
    await this._setup();
    const saltBuf = salt.byteLength === 0 ? new ArrayBuffer(this.hashSize) : toArrayBuffer(salt);
    if (saltBuf.byteLength !== this.hashSize) {
      throw new InvalidParamError("The salt length must be the same as the hashSize");
    }
    const ikmBuf = toArrayBuffer(ikm);
    const key = await this._api.importKey("raw", saltBuf, this.algHash, false, [
      "sign"
    ]);
    return await this._api.sign("HMAC", key, ikmBuf);
  }
  async expand(prk, info, len) {
    await this._setup();
    const prkBuf = toArrayBuffer(prk);
    const key = await this._api.importKey("raw", prkBuf, this.algHash, false, [
      "sign"
    ]);
    const okm = new ArrayBuffer(len);
    const okmBytes = new Uint8Array(okm);
    let prev = EMPTY;
    const mid = toUint8Array(info);
    const tail = new Uint8Array(1);
    if (len > 255 * this.hashSize) {
      throw new Error("Entropy limit reached");
    }
    const tmp = new Uint8Array(this.hashSize + mid.length + 1);
    for (let i2 = 1, cur = 0; cur < okmBytes.length; i2++) {
      tail[0] = i2;
      tmp.set(prev, 0);
      tmp.set(mid, prev.length);
      tmp.set(tail, prev.length + mid.length);
      prev = new Uint8Array(await this._api.sign("HMAC", key, tmp.slice(0, prev.length + mid.length + 1)));
      if (okmBytes.length - cur >= prev.length) {
        okmBytes.set(prev, cur);
        cur += prev.length;
      } else {
        okmBytes.set(prev.slice(0, okmBytes.length - cur), cur);
        cur += okmBytes.length - cur;
      }
    }
    return okm;
  }
  async extractAndExpand(salt, ikm, info, len) {
    await this._setup();
    const ikmBuf = toArrayBuffer(ikm);
    const baseKey = await this._api.importKey("raw", ikmBuf, "HKDF", false, ["deriveBits"]);
    return await this._api.deriveBits({
      name: "HKDF",
      hash: this.algHash.hash,
      salt: toArrayBuffer(salt),
      info: toArrayBuffer(info)
    }, baseKey, len * 8);
  }
  async labeledExtract(salt, label, ikm) {
    return await this.extract(salt, this.buildLabeledIkm(label, ikm));
  }
  async labeledExpand(prk, label, info, len) {
    return await this.expand(prk, this.buildLabeledInfo(label, info, len), len);
  }
  _checkInit() {
    if (this._suiteId === EMPTY) {
      throw new Error("Not initialized. Call init()");
    }
  }
};
var HkdfSha256Native = class extends HkdfNative {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "id", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: KdfId.HkdfSha256
    });
    Object.defineProperty(this, "hashSize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 32
    });
    Object.defineProperty(this, "algHash", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: {
        name: "HMAC",
        hash: "SHA-256",
        length: 256
      }
    });
  }
};

// node_modules/@hpke/common/esm/src/utils/misc.js
var isCryptoKeyPair = (x2) => typeof x2 === "object" && x2 !== null && typeof x2.privateKey === "object" && typeof x2.publicKey === "object";
function i2Osp(n2, w2) {
  if (w2 <= 0) {
    throw new Error("i2Osp: too small size");
  }
  if (n2 >= 256 ** w2) {
    throw new Error("i2Osp: too large integer");
  }
  const ret = new Uint8Array(w2);
  for (let i2 = 0; i2 < w2 && n2; i2++) {
    ret[w2 - (i2 + 1)] = n2 % 256;
    n2 = Math.floor(n2 / 256);
  }
  return ret;
}
function concat(a2, b2) {
  const ret = new Uint8Array(a2.length + b2.length);
  ret.set(a2, 0);
  ret.set(b2, a2.length);
  return ret;
}
function base64UrlToBytes(v2) {
  const base64 = v2.replace(/-/g, "+").replace(/_/g, "/");
  const byteString = atob(base64);
  const ret = new Uint8Array(byteString.length);
  for (let i2 = 0; i2 < byteString.length; i2++) {
    ret[i2] = byteString.charCodeAt(i2);
  }
  return ret;
}
async function loadCrypto() {
  if (typeof dntGlobalThis !== "undefined" && globalThis.crypto !== void 0) {
    return globalThis.crypto;
  }
  try {
    const { webcrypto } = await import("crypto");
    return webcrypto;
  } catch (_e2) {
    throw new Error("failed to load Crypto");
  }
}
function xor(a2, b2) {
  if (a2.byteLength !== b2.byteLength) {
    throw new Error("xor: different length inputs");
  }
  const buf = new Uint8Array(a2.byteLength);
  for (let i2 = 0; i2 < a2.byteLength; i2++) {
    buf[i2] = a2[i2] ^ b2[i2];
  }
  return buf;
}

// node_modules/@hpke/common/esm/src/kems/dhkem.js
var LABEL_EAE_PRK = /* @__PURE__ */ new Uint8Array([
  101,
  97,
  101,
  95,
  112,
  114,
  107
]);
var LABEL_SHARED_SECRET = /* @__PURE__ */ new Uint8Array([
  115,
  104,
  97,
  114,
  101,
  100,
  95,
  115,
  101,
  99,
  114,
  101,
  116
]);
function concat3(a2, b2, c2) {
  const ret = new Uint8Array(a2.length + b2.length + c2.length);
  ret.set(a2, 0);
  ret.set(b2, a2.length);
  ret.set(c2, a2.length + b2.length);
  return ret;
}
var Dhkem = class {
  constructor(id, prim, kdf) {
    Object.defineProperty(this, "id", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "secretSize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "encSize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "publicKeySize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "privateKeySize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "_prim", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_kdf", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this.id = id;
    this._prim = prim;
    this._kdf = kdf;
    const suiteId = new Uint8Array(SUITE_ID_HEADER_KEM);
    suiteId.set(i2Osp(this.id, 2), 3);
    this._kdf.init(suiteId);
  }
  async serializePublicKey(key) {
    return await this._prim.serializePublicKey(key);
  }
  async deserializePublicKey(key) {
    return await this._prim.deserializePublicKey(toArrayBuffer(key));
  }
  async serializePrivateKey(key) {
    return await this._prim.serializePrivateKey(key);
  }
  async deserializePrivateKey(key) {
    return await this._prim.deserializePrivateKey(toArrayBuffer(key));
  }
  async importKey(format, key, isPublic = true) {
    return await this._prim.importKey(format, key, isPublic);
  }
  async generateKeyPair() {
    return await this._prim.generateKeyPair();
  }
  async deriveKeyPair(ikm) {
    const rawIkm = toArrayBuffer(ikm);
    if (rawIkm.byteLength > INPUT_LENGTH_LIMIT) {
      throw new InvalidParamError("Too long ikm");
    }
    return await this._prim.deriveKeyPair(rawIkm);
  }
  async encap(params) {
    let ke2;
    if (params.ekm === void 0) {
      ke2 = await this.generateKeyPair();
    } else if (isCryptoKeyPair(params.ekm)) {
      ke2 = params.ekm;
    } else {
      ke2 = await this.deriveKeyPair(params.ekm);
    }
    const enc = await this._prim.serializePublicKey(ke2.publicKey);
    const pkrm = await this._prim.serializePublicKey(params.recipientPublicKey);
    try {
      let dh;
      if (params.senderKey === void 0) {
        dh = new Uint8Array(await this._prim.dh(ke2.privateKey, params.recipientPublicKey));
      } else {
        const sks = isCryptoKeyPair(params.senderKey) ? params.senderKey.privateKey : params.senderKey;
        const dh1 = new Uint8Array(await this._prim.dh(ke2.privateKey, params.recipientPublicKey));
        const dh2 = new Uint8Array(await this._prim.dh(sks, params.recipientPublicKey));
        dh = concat(dh1, dh2);
      }
      let kemContext;
      if (params.senderKey === void 0) {
        kemContext = concat(new Uint8Array(enc), new Uint8Array(pkrm));
      } else {
        const pks = isCryptoKeyPair(params.senderKey) ? params.senderKey.publicKey : await this._prim.derivePublicKey(params.senderKey);
        const pksm = await this._prim.serializePublicKey(pks);
        kemContext = concat3(new Uint8Array(enc), new Uint8Array(pkrm), new Uint8Array(pksm));
      }
      const sharedSecret = await this._generateSharedSecret(dh, kemContext);
      return {
        enc,
        sharedSecret
      };
    } catch (e) {
      throw new EncapError(e);
    }
  }
  async decap(params) {
    const enc = toArrayBuffer(params.enc);
    const pke = await this._prim.deserializePublicKey(enc);
    const skr = isCryptoKeyPair(params.recipientKey) ? params.recipientKey.privateKey : params.recipientKey;
    const pkr = isCryptoKeyPair(params.recipientKey) ? params.recipientKey.publicKey : await this._prim.derivePublicKey(params.recipientKey);
    const pkrm = await this._prim.serializePublicKey(pkr);
    try {
      let dh;
      if (params.senderPublicKey === void 0) {
        dh = new Uint8Array(await this._prim.dh(skr, pke));
      } else {
        const dh1 = new Uint8Array(await this._prim.dh(skr, pke));
        const dh2 = new Uint8Array(await this._prim.dh(skr, params.senderPublicKey));
        dh = concat(dh1, dh2);
      }
      let kemContext;
      if (params.senderPublicKey === void 0) {
        kemContext = concat(new Uint8Array(enc), new Uint8Array(pkrm));
      } else {
        const pksm = await this._prim.serializePublicKey(params.senderPublicKey);
        kemContext = new Uint8Array(enc.byteLength + pkrm.byteLength + pksm.byteLength);
        kemContext.set(new Uint8Array(enc), 0);
        kemContext.set(new Uint8Array(pkrm), enc.byteLength);
        kemContext.set(new Uint8Array(pksm), enc.byteLength + pkrm.byteLength);
      }
      return await this._generateSharedSecret(dh, kemContext);
    } catch (e) {
      throw new DecapError(e);
    }
  }
  async _generateSharedSecret(dh, kemContext) {
    const labeledIkm = this._kdf.buildLabeledIkm(LABEL_EAE_PRK, dh);
    const labeledInfo = this._kdf.buildLabeledInfo(LABEL_SHARED_SECRET, kemContext, this.secretSize);
    return await this._kdf.extractAndExpand(EMPTY, labeledIkm, labeledInfo, this.secretSize);
  }
};

// node_modules/@hpke/common/esm/src/interfaces/dhkemPrimitives.js
var KEM_USAGES = ["deriveBits"];
var LABEL_DKP_PRK = /* @__PURE__ */ new Uint8Array([
  100,
  107,
  112,
  95,
  112,
  114,
  107
]);
var LABEL_SK = /* @__PURE__ */ new Uint8Array([115, 107]);

// node_modules/@hpke/common/esm/src/kems/dhkemPrimitives/ec.js
var EC_P_521_PARAMS = {
  p: (1n << 521n) - 1n,
  b: 0x0051953eb9618e1c9a1f929a21a0b68540eea2da725b99b315f3b8b489918ef109e156193951ec7e937b1652c0bd3bb1bf073573df883d2c34f1ef451fd46b503f00n,
  gx: 0x00c6858e06b70404e9cd9e3ecb662395b4429c648139053fb521f828af606b4d3dbaa14b5e77efe75928fe1dc127a2ffa8de3348b3c1856a429bf97e7e31c2e5bd66n,
  gy: 0x011839296a789a3bc0045c8a5fb42c7d1bd998f54449579b446817afbd17273e662c97ee72995ef42640c550b9013fad0761353c7086a272c24088be94769fd16650n,
  coordinateSize: 66
};

// node_modules/@hpke/common/esm/src/xCryptoKey.js
var XCryptoKey = class {
  constructor(name, key, type, usages = []) {
    Object.defineProperty(this, "key", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "type", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "extractable", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: true
    });
    Object.defineProperty(this, "algorithm", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "usages", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this.key = key;
    this.type = type;
    this.algorithm = { name };
    this.usages = usages;
    if (type === "public") {
      this.usages = [];
    }
  }
};

// node_modules/@hpke/common/esm/src/kems/dhkemPrimitives/xCurve.js
var XCurveDhkemPrimitives = class {
  constructor(algName, keySize, curve, hkdf) {
    Object.defineProperty(this, "_algName", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_curve", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_hkdf", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_nPk", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_nSk", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this._algName = algName;
    this._nPk = keySize;
    this._nSk = keySize;
    this._curve = curve;
    this._hkdf = hkdf;
  }
  serializePublicKey(key) {
    try {
      return Promise.resolve(key.key.buffer);
    } catch (e) {
      return Promise.reject(new SerializeError(e));
    }
  }
  async deserializePublicKey(key) {
    try {
      return await this._importRawKey(toArrayBuffer(key), true);
    } catch (e) {
      throw new DeserializeError(e);
    }
  }
  serializePrivateKey(key) {
    try {
      return Promise.resolve(key.key.buffer);
    } catch (e) {
      return Promise.reject(new SerializeError(e));
    }
  }
  async deserializePrivateKey(key) {
    try {
      return await this._importRawKey(toArrayBuffer(key), false);
    } catch (e) {
      throw new DeserializeError(e);
    }
  }
  async importKey(format, key, isPublic) {
    try {
      if (format === "raw") {
        return await this._importRawKey(key, isPublic);
      }
      if (key instanceof ArrayBuffer) {
        throw new Error("Invalid jwk key format");
      }
      return await this._importJWK(key, isPublic);
    } catch (e) {
      throw new DeserializeError(e);
    }
  }
  async generateKeyPair() {
    try {
      const rawSk = await this._curve.utils.randomSecretKey();
      const sk = new XCryptoKey(this._algName, rawSk, "private", KEM_USAGES);
      const pk = await this.derivePublicKey(sk);
      return { publicKey: pk, privateKey: sk };
    } catch (e) {
      throw new NotSupportedError(e);
    }
  }
  async deriveKeyPair(ikm) {
    try {
      const rawIkm = toArrayBuffer(ikm);
      const dkpPrk = await this._hkdf.labeledExtract(EMPTY.buffer, LABEL_DKP_PRK, new Uint8Array(rawIkm));
      const rawSk = await this._hkdf.labeledExpand(dkpPrk, LABEL_SK, EMPTY, this._nSk);
      const sk = new XCryptoKey(this._algName, new Uint8Array(rawSk), "private", KEM_USAGES);
      return {
        privateKey: sk,
        publicKey: await this.derivePublicKey(sk)
      };
    } catch (e) {
      throw new DeriveKeyPairError(e);
    }
  }
  derivePublicKey(key) {
    try {
      const pk = this._curve.getPublicKey(key.key);
      return Promise.resolve(new XCryptoKey(this._algName, pk, "public"));
    } catch (e) {
      return Promise.reject(new DeserializeError(e));
    }
  }
  dh(sk, pk) {
    try {
      return Promise.resolve(this._curve.getSharedSecret(sk.key, pk.key).buffer);
    } catch (e) {
      return Promise.reject(new SerializeError(e));
    }
  }
  _importRawKey(key, isPublic) {
    return new Promise((resolve, reject) => {
      if (isPublic && key.byteLength !== this._nPk) {
        reject(new Error("Invalid length of the key"));
      }
      if (!isPublic && key.byteLength !== this._nSk) {
        reject(new Error("Invalid length of the key"));
      }
      resolve(new XCryptoKey(this._algName, new Uint8Array(key), isPublic ? "public" : "private", isPublic ? [] : KEM_USAGES));
    });
  }
  _importJWK(key, isPublic) {
    return new Promise((resolve, reject) => {
      if (key.kty !== "OKP") {
        reject(new Error(`Invalid kty: ${key.kty}`));
      }
      if (key.crv !== this._algName) {
        reject(new Error(`Invalid crv: ${key.crv}`));
      }
      if (isPublic) {
        if (typeof key.d !== "undefined") {
          reject(new Error("Invalid key: `d` should not be set"));
        }
        if (typeof key.x !== "string") {
          reject(new Error("Invalid key: `x` not found"));
        }
        resolve(new XCryptoKey(this._algName, base64UrlToBytes(key.x), "public"));
      } else {
        if (typeof key.d !== "string") {
          reject(new Error("Invalid key: `d` not found"));
        }
        resolve(new XCryptoKey(this._algName, base64UrlToBytes(key.d), "private", KEM_USAGES));
      }
    });
  }
};

// node_modules/@hpke/common/esm/src/interfaces/aeadEncryptionContext.js
var AEAD_USAGES = ["encrypt", "decrypt"];

// node_modules/@hpke/common/esm/src/utils/noble.js
function isBytes(a2) {
  return a2 instanceof Uint8Array || ArrayBuffer.isView(a2) && a2.constructor.name === "Uint8Array";
}
function anumber(n2, title = "") {
  if (!Number.isSafeInteger(n2) || n2 < 0) {
    const prefix = title && `"${title}" `;
    throw new Error(`${prefix}expected integer >0, got ${n2}`);
  }
}
function abytes(value, length, title = "") {
  const bytes = isBytes(value);
  const len = value?.length;
  const needsLen = length !== void 0;
  if (!bytes || needsLen && len !== length) {
    const prefix = title && `"${title}" `;
    const ofLen = needsLen ? ` of length ${length}` : "";
    const got = bytes ? `length=${len}` : `type=${typeof value}`;
    throw new Error(prefix + "expected Uint8Array" + ofLen + ", got " + got);
  }
  return value;
}
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished) {
    throw new Error("Hash#digest() has already been called");
  }
}
function aoutput(out, instance) {
  abytes(out, void 0, "digestInto() output");
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error('"digestInto() output" expected to be of length >=' + min);
  }
}
function abignumer(n2) {
  if (typeof n2 === "bigint") {
    if (!isPosBig(n2))
      throw new Error("positive bigint expected, got " + n2);
  } else
    anumber(n2);
  return n2;
}
function clean(...arrays) {
  for (let i2 = 0; i2 < arrays.length; i2++) {
    arrays[i2].fill(0);
  }
}
var _endianTestBuffer = /* @__PURE__ */ new Uint32Array([287454020]);
var _endianTestBytes = /* @__PURE__ */ new Uint8Array(_endianTestBuffer.buffer);
var isLE = _endianTestBytes[0] === 68;
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr(word, shift) {
  return word << 32 - shift | word >>> shift;
}
var hasHexBuiltin = /* @__PURE__ */ (() => (
  // @ts-ignore: to use toHex
  typeof Uint8Array.from([]).toHex === "function" && // @ts-ignore: to use fromHex
  typeof Uint8Array.fromHex === "function"
))();
var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_2, i2) => i2.toString(16).padStart(2, "0"));
var HEX_TO_BIGINT = [
  0n,
  1n,
  2n,
  3n,
  4n,
  5n,
  6n,
  7n,
  8n,
  9n,
  10n,
  11n,
  12n,
  13n,
  14n,
  15n
];
function bytesToHex(bytes) {
  abytes(bytes);
  if (hasHexBuiltin)
    return bytes.toHex();
  let hex = "";
  for (let i2 = 0; i2 < bytes.length; i2++) {
    hex += hexes[bytes[i2]];
  }
  return hex;
}
var asciis = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 };
function asciiToBase16(ch) {
  if (ch >= asciis._0 && ch <= asciis._9)
    return ch - asciis._0;
  if (ch >= asciis.A && ch <= asciis.F)
    return ch - (asciis.A - 10);
  if (ch >= asciis.a && ch <= asciis.f)
    return ch - (asciis.a - 10);
  return;
}
function hexToBytes(hex) {
  if (typeof hex !== "string") {
    throw new Error("hex string expected, got " + typeof hex);
  }
  if (hasHexBuiltin)
    return Uint8Array.fromHex(hex);
  const hl = hex.length;
  const al = hl / 2;
  if (hl % 2) {
    throw new Error("hex string expected, got unpadded hex of length " + hl);
  }
  const array = new Uint8Array(al);
  for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
    const n1 = asciiToBase16(hex.charCodeAt(hi));
    const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
    if (n1 === void 0 || n2 === void 0) {
      const char = hex[hi] + hex[hi + 1];
      throw new Error('hex string expected, got non-hex character "' + char + '" at index ' + hi);
    }
    array[ai] = n1 * 16 + n2;
  }
  return array;
}
function hexToNumber(hex) {
  if (typeof hex !== "string") {
    throw new Error("hex string expected, got " + typeof hex);
  }
  let out = N_0;
  for (let i2 = 0; i2 < hex.length; i2++) {
    const n2 = asciiToBase16(hex.charCodeAt(i2));
    if (n2 === void 0) {
      throw new Error('hex string expected, got non-hex character "' + hex[i2] + '" at index ' + i2);
    }
    out = out << 4n | HEX_TO_BIGINT[n2];
  }
  return out;
}
function numberToBigint(num) {
  anumber(num, "numberToBigint");
  let n2 = num;
  let out = N_0;
  let bit = 1n;
  while (n2 > 0) {
    if (n2 % 2 === 1)
      out += bit;
    n2 = Math.floor(n2 / 2);
    bit <<= 1n;
  }
  return out;
}
function bytesToNumberLE(bytes) {
  return hexToNumber(bytesToHex(copyBytes(abytes(bytes)).reverse()));
}
function numberToBytesBE(n2, len) {
  anumber(len);
  n2 = abignumer(n2);
  const res = hexToBytes(n2.toString(16).padStart(len * 2, "0"));
  if (res.length !== len)
    throw new Error("number too large");
  return res;
}
function numberToBytesLE(n2, len) {
  return numberToBytesBE(n2, len).reverse();
}
function copyBytes(bytes) {
  return Uint8Array.from(bytes);
}
function isPosBig(n2) {
  return typeof n2 === "bigint" && N_0 <= n2;
}
function inRange(n2, min, max) {
  return isPosBig(n2) && isPosBig(min) && isPosBig(max) && min <= n2 && n2 < max;
}
function aInRange(title, n2, min, max) {
  if (!inRange(n2, min, max)) {
    throw new Error("expected valid " + title + ": " + min + " <= n < " + max + ", got " + n2);
  }
}
function validateObject(object, fields = {}, optFields = {}) {
  if (!object || typeof object !== "object") {
    throw new Error("expected valid options object");
  }
  function checkField(fieldName, expectedType, isOpt) {
    const val = object[fieldName];
    if (isOpt && val === void 0)
      return;
    const current = typeof val;
    if (current !== expectedType || val === null) {
      throw new Error(`param "${fieldName}" is invalid: expected ${expectedType}, got ${current}`);
    }
  }
  const iter = (f2, isOpt) => Object.entries(f2).forEach(([k2, v2]) => checkField(k2, v2, isOpt));
  iter(fields, false);
  iter(optFields, true);
}
async function randomBytesAsync(bytesLength = 32) {
  const api = await loadCrypto();
  const rnd = new Uint8Array(bytesLength);
  api.getRandomValues(rnd);
  return rnd;
}
function oidNist(suffix) {
  return {
    oid: Uint8Array.from([
      6,
      9,
      96,
      134,
      72,
      1,
      101,
      3,
      4,
      2,
      suffix
    ])
  };
}

// node_modules/@hpke/common/esm/src/hash/hash.js
function ahash(h2) {
  if (typeof h2 !== "function" || typeof h2.create !== "function") {
    throw new Error("Hash must wrapped by utils.createHasher");
  }
  anumber(h2.outputLen);
  anumber(h2.blockLen);
}
function createHasher(hashCons, info = {}) {
  const hashFn = (msg, opts) => hashCons(opts).update(msg).digest();
  const tmp = hashCons(void 0);
  const hashC = Object.assign(hashFn, {
    outputLen: tmp.outputLen,
    blockLen: tmp.blockLen,
    create: (opts) => hashCons(opts),
    ...info
  });
  return Object.freeze(hashC);
}

// node_modules/@hpke/common/esm/src/hash/hmac.js
var _HMAC = class {
  constructor(hash, key) {
    Object.defineProperty(this, "oHash", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "iHash", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "blockLen", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "outputLen", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "finished", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: false
    });
    Object.defineProperty(this, "destroyed", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: false
    });
    ahash(hash);
    abytes(key, void 0, "key");
    this.iHash = hash.create();
    if (typeof this.iHash.update !== "function") {
      throw new Error("Expected instance of class which extends utils.Hash");
    }
    this.blockLen = this.iHash.blockLen;
    this.outputLen = this.iHash.outputLen;
    const blockLen = this.blockLen;
    const pad = new Uint8Array(blockLen);
    pad.set(key.length > blockLen ? hash.create().update(key).digest() : key);
    for (let i2 = 0; i2 < pad.length; i2++)
      pad[i2] ^= 54;
    this.iHash.update(pad);
    this.oHash = hash.create();
    for (let i2 = 0; i2 < pad.length; i2++)
      pad[i2] ^= 54 ^ 92;
    this.oHash.update(pad);
    clean(pad);
  }
  update(buf) {
    aexists(this);
    this.iHash.update(buf);
    return this;
  }
  digestInto(out) {
    aexists(this);
    abytes(out, this.outputLen, "output");
    this.finished = true;
    this.iHash.digestInto(out);
    this.oHash.update(out);
    this.oHash.digestInto(out);
    this.destroy();
  }
  digest() {
    const out = new Uint8Array(this.oHash.outputLen);
    this.digestInto(out);
    return out;
  }
  _cloneInto(to) {
    to ||= Object.create(Object.getPrototypeOf(this), {});
    const { oHash, iHash, finished, destroyed, blockLen, outputLen } = this;
    to = to;
    to.finished = finished;
    to.destroyed = destroyed;
    to.blockLen = blockLen;
    to.outputLen = outputLen;
    to.oHash = oHash._cloneInto(to.oHash);
    to.iHash = iHash._cloneInto(to.iHash);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
  destroy() {
    this.destroyed = true;
    this.oHash.destroy();
    this.iHash.destroy();
  }
};
var hmac = (hash, key, message) => new _HMAC(hash, key).update(message).digest();
hmac.create = (hash, key) => new _HMAC(hash, key);

// node_modules/@hpke/common/esm/src/hash/md.js
function Chi(a2, b2, c2) {
  return a2 & b2 ^ ~a2 & c2;
}
function Maj(a2, b2, c2) {
  return a2 & b2 ^ a2 & c2 ^ b2 & c2;
}
var HashMD = class {
  constructor(blockLen, outputLen, padOffset, isLE2) {
    Object.defineProperty(this, "blockLen", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "outputLen", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "padOffset", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "isLE", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "buffer", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "view", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "finished", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: false
    });
    Object.defineProperty(this, "length", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "pos", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "destroyed", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: false
    });
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE2;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView(this.buffer);
  }
  update(data) {
    aexists(this);
    abytes(data);
    const { view, buffer, blockLen } = this;
    const len = data.length;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView(data);
        for (; blockLen <= len - pos; pos += blockLen) {
          this.process(dataView, pos);
        }
        continue;
      }
      buffer.set(data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
      }
    }
    this.length += data.length;
    this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists(this);
    aoutput(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE: isLE2 } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    clean(this.buffer.subarray(pos));
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      pos = 0;
    }
    for (let i2 = pos; i2 < blockLen; i2++)
      buffer[i2] = 0;
    view.setBigUint64(blockLen - 8, numberToBigint(this.length * 8), isLE2);
    this.process(view, 0);
    const oview = createView(out);
    const len = this.outputLen;
    if (len % 4)
      throw new Error("_sha2: outputLen must be aligned to 32bit");
    const outLen = len / 4;
    const state = this.get();
    if (outLen > state.length) {
      throw new Error("_sha2: outputLen bigger than state");
    }
    for (let i2 = 0; i2 < outLen; i2++)
      oview.setUint32(4 * i2, state[i2], isLE2);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneInto(to) {
    to ||= new this.constructor();
    to.set(...this.get());
    const { blockLen, buffer, length, finished, destroyed, pos } = this;
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    if (length % blockLen)
      to.buffer.set(buffer);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};
var SHA256_IV = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);

// node_modules/@hpke/common/esm/src/hash/u64.js
var U32_MASK64 = 0xffffffffn;
var _32n = 32n;
function fromBig(n2, le2 = false) {
  if (le2) {
    return { h: Number(n2 & U32_MASK64), l: Number(n2 >> _32n & U32_MASK64) };
  }
  return {
    h: Number(n2 >> _32n & U32_MASK64) | 0,
    l: Number(n2 & U32_MASK64) | 0
  };
}
function split(lst, le2 = false) {
  const len = lst.length;
  const Ah = new Uint32Array(len);
  const Al = new Uint32Array(len);
  for (let i2 = 0; i2 < len; i2++) {
    const { h: h2, l: l2 } = fromBig(lst[i2], le2);
    [Ah[i2], Al[i2]] = [h2, l2];
  }
  return [Ah, Al];
}

// node_modules/@hpke/common/esm/src/hash/sha2.js
var SHA256_K = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
var SHA2_32B = class extends HashMD {
  constructor(outputLen) {
    super(64, outputLen, 8, false);
  }
  get() {
    const { A: A3, B: B2, C: C2, D: D2, E: E2, F: F2, G: G2, H: H2 } = this;
    return [A3, B2, C2, D2, E2, F2, G2, H2];
  }
  set(A3, B2, C2, D2, E2, F2, G2, H2) {
    this.A = A3 | 0;
    this.B = B2 | 0;
    this.C = C2 | 0;
    this.D = D2 | 0;
    this.E = E2 | 0;
    this.F = F2 | 0;
    this.G = G2 | 0;
    this.H = H2 | 0;
  }
  process(view, offset) {
    for (let i2 = 0; i2 < 16; i2++, offset += 4) {
      SHA256_W[i2] = view.getUint32(offset, false);
    }
    for (let i2 = 16; i2 < 64; i2++) {
      const W15 = SHA256_W[i2 - 15];
      const W2 = SHA256_W[i2 - 2];
      const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
      const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
      SHA256_W[i2] = s1 + SHA256_W[i2 - 7] + s0 + SHA256_W[i2 - 16] | 0;
    }
    let { A: A3, B: B2, C: C2, D: D2, E: E2, F: F2, G: G2, H: H2 } = this;
    for (let i2 = 0; i2 < 64; i2++) {
      const sigma1 = rotr(E2, 6) ^ rotr(E2, 11) ^ rotr(E2, 25);
      const T1 = H2 + sigma1 + Chi(E2, F2, G2) + SHA256_K[i2] + SHA256_W[i2] | 0;
      const sigma0 = rotr(A3, 2) ^ rotr(A3, 13) ^ rotr(A3, 22);
      const T2 = sigma0 + Maj(A3, B2, C2) | 0;
      H2 = G2;
      G2 = F2;
      F2 = E2;
      E2 = D2 + T1 | 0;
      D2 = C2;
      C2 = B2;
      B2 = A3;
      A3 = T1 + T2 | 0;
    }
    A3 = A3 + this.A | 0;
    B2 = B2 + this.B | 0;
    C2 = C2 + this.C | 0;
    D2 = D2 + this.D | 0;
    E2 = E2 + this.E | 0;
    F2 = F2 + this.F | 0;
    G2 = G2 + this.G | 0;
    H2 = H2 + this.H | 0;
    this.set(A3, B2, C2, D2, E2, F2, G2, H2);
  }
  roundClean() {
    clean(SHA256_W);
  }
  destroy() {
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    clean(this.buffer);
  }
};
var _SHA256 = class extends SHA2_32B {
  constructor() {
    super(32);
    Object.defineProperty(this, "A", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: SHA256_IV[0] | 0
    });
    Object.defineProperty(this, "B", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: SHA256_IV[1] | 0
    });
    Object.defineProperty(this, "C", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: SHA256_IV[2] | 0
    });
    Object.defineProperty(this, "D", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: SHA256_IV[3] | 0
    });
    Object.defineProperty(this, "E", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: SHA256_IV[4] | 0
    });
    Object.defineProperty(this, "F", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: SHA256_IV[5] | 0
    });
    Object.defineProperty(this, "G", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: SHA256_IV[6] | 0
    });
    Object.defineProperty(this, "H", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: SHA256_IV[7] | 0
    });
  }
};
var sha256 = /* @__PURE__ */ createHasher(
  () => new _SHA256(),
  /* @__PURE__ */ oidNist(1)
);

// node_modules/@hpke/common/esm/src/hash/sha3.js
var _0n = 0n;
var _1n = 1n;
var _2n = 2n;
var _7n = 7n;
var _256n = 256n;
var _0x71n = 0x71n;
var SHA3_PI = [];
var SHA3_ROTL = [];
var _SHA3_IOTA = [];
for (let round = 0, R2 = _1n, x2 = 1, y2 = 0; round < 24; round++) {
  [x2, y2] = [y2, (2 * x2 + 3 * y2) % 5];
  SHA3_PI.push(2 * (5 * y2 + x2));
  SHA3_ROTL.push((round + 1) * (round + 2) / 2 % 64);
  let t2 = _0n;
  for (let j2 = 0; j2 < 7; j2++) {
    R2 = (R2 << _1n ^ (R2 >> _7n) * _0x71n) % _256n;
    if (R2 & _2n)
      t2 ^= _1n << (_1n << BigInt(j2)) - _1n;
  }
  _SHA3_IOTA.push(t2);
}
var IOTAS = split(_SHA3_IOTA, true);
var SHA3_IOTA_H = IOTAS[0];
var SHA3_IOTA_L = IOTAS[1];

// node_modules/@hpke/common/esm/src/curve/modular.js
function mod(a2, b2) {
  const result = a2 % b2;
  return result >= N_0 ? result : b2 + result;
}
function pow2(x2, power, modulo) {
  let res = x2;
  while (power-- > N_0) {
    res *= res;
    res %= modulo;
  }
  return res;
}

// node_modules/@hpke/common/esm/src/curve/curve.js
function createKeygen(randomSecretKey, getPublicKey) {
  return function keygen(seed) {
    const secretKey = randomSecretKey(seed);
    return { secretKey, publicKey: getPublicKey(secretKey) };
  };
}

// node_modules/@hpke/common/esm/src/curve/montgomery.js
function validateOpts(curve) {
  validateObject(curve, {
    adjustScalarBytes: "function",
    powPminus2: "function"
  });
  return Object.freeze({ ...curve });
}
function montgomery(curveDef) {
  const CURVE = validateOpts(curveDef);
  const { P: P2, type, adjustScalarBytes: adjustScalarBytes2, powPminus2, randomBytes: rand } = CURVE;
  const is25519 = type === "x25519";
  if (!is25519 && type !== "x448")
    throw new Error("invalid type");
  const randomBytes_ = rand || randomBytesAsync;
  const montgomeryBits = is25519 ? 255n : 448n;
  const fieldLen = is25519 ? 32 : 56;
  const Gu = is25519 ? 9n : 5n;
  const a24 = is25519 ? 121665n : 39081n;
  const minScalar = is25519 ? N_2 ** 254n : N_2 ** 447n;
  const maxAdded = is25519 ? 8n * N_2 ** 251n - N_1 : 4n * N_2 ** 445n - N_1;
  const maxScalar = minScalar + maxAdded + N_1;
  const modP = (n2) => mod(n2, P2);
  const GuBytes = encodeU(Gu);
  function encodeU(u2) {
    return numberToBytesLE(modP(u2), fieldLen);
  }
  function decodeU(u2) {
    const _u = copyBytes(abytes(u2, fieldLen, "uCoordinate"));
    if (is25519)
      _u[31] &= 127;
    return modP(bytesToNumberLE(_u));
  }
  function decodeScalar(scalar) {
    return bytesToNumberLE(adjustScalarBytes2(copyBytes(abytes(scalar, fieldLen, "scalar"))));
  }
  function scalarMult(scalar, u2) {
    const pu = montgomeryLadder(decodeU(u2), decodeScalar(scalar));
    if (pu === N_0)
      throw new Error("invalid private or public key received");
    return encodeU(pu);
  }
  function scalarMultBase(scalar) {
    return scalarMult(scalar, GuBytes);
  }
  const getPublicKey = scalarMultBase;
  const getSharedSecret = scalarMult;
  function cswap(swap, x_2, x_3) {
    const dummy = modP(swap * (x_2 - x_3));
    x_2 = modP(x_2 - dummy);
    x_3 = modP(x_3 + dummy);
    return { x_2, x_3 };
  }
  function montgomeryLadder(u2, scalar) {
    aInRange("u", u2, N_0, P2);
    aInRange("scalar", scalar, minScalar, maxScalar);
    const k2 = scalar;
    const x_1 = u2;
    let x_2 = N_1;
    let z_2 = N_0;
    let x_3 = u2;
    let z_3 = N_1;
    let swap = N_0;
    for (let t2 = montgomeryBits - 1n; t2 >= N_0; t2--) {
      const k_t = k2 >> t2 & N_1;
      swap ^= k_t;
      ({ x_2, x_3 } = cswap(swap, x_2, x_3));
      ({ x_2: z_2, x_3: z_3 } = cswap(swap, z_2, z_3));
      swap = k_t;
      const A3 = x_2 + z_2;
      const AA = modP(A3 * A3);
      const B2 = x_2 - z_2;
      const BB = modP(B2 * B2);
      const E2 = AA - BB;
      const C2 = x_3 + z_3;
      const D2 = x_3 - z_3;
      const DA = modP(D2 * A3);
      const CB = modP(C2 * B2);
      const dacb = DA + CB;
      const da_cb = DA - CB;
      x_3 = modP(dacb * dacb);
      z_3 = modP(x_1 * modP(da_cb * da_cb));
      x_2 = modP(AA * BB);
      z_2 = modP(E2 * (AA + modP(a24 * E2)));
    }
    ({ x_2, x_3 } = cswap(swap, x_2, x_3));
    ({ x_2: z_2, x_3: z_3 } = cswap(swap, z_2, z_3));
    const z2 = powPminus2(z_2);
    return modP(x_2 * z2);
  }
  const lengths = {
    secretKey: fieldLen,
    publicKey: fieldLen,
    seed: fieldLen
  };
  const randomSecretKey = async (seed) => {
    if (seed === void 0) {
      seed = await randomBytes_(fieldLen);
    }
    abytes(seed, lengths.seed, "seed");
    return seed;
  };
  const utils = { randomSecretKey };
  return Object.freeze({
    keygen: createKeygen(randomSecretKey, getPublicKey),
    getSharedSecret,
    getPublicKey,
    scalarMult,
    scalarMultBase,
    utils,
    GuBytes: GuBytes.slice(),
    lengths
  });
}

// node_modules/@hpke/core/esm/src/aeads/aesGcm.js
var AesGcmContext = class extends NativeAlgorithm {
  constructor(key) {
    super();
    Object.defineProperty(this, "_rawKey", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_key", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this._rawKey = toArrayBuffer(key);
  }
  async seal(iv, data, aad) {
    await this._setupKey();
    const alg = {
      name: "AES-GCM",
      iv: toArrayBuffer(iv),
      additionalData: toArrayBuffer(aad)
    };
    const ct2 = await this._api.encrypt(alg, this._key, toArrayBuffer(data));
    return ct2;
  }
  async open(iv, data, aad) {
    await this._setupKey();
    const alg = {
      name: "AES-GCM",
      iv: toArrayBuffer(iv),
      additionalData: toArrayBuffer(aad)
    };
    const pt2 = await this._api.decrypt(alg, this._key, toArrayBuffer(data));
    return pt2;
  }
  async _setupKey() {
    if (this._key !== void 0) {
      return;
    }
    await this._setup();
    const key = await this._importKey(this._rawKey);
    new Uint8Array(this._rawKey).fill(0);
    this._key = key;
    return;
  }
  async _importKey(key) {
    return await this._api.importKey("raw", key, { name: "AES-GCM" }, true, AEAD_USAGES);
  }
};
var Aes128Gcm = class {
  constructor() {
    Object.defineProperty(this, "id", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: AeadId.Aes128Gcm
    });
    Object.defineProperty(this, "keySize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 16
    });
    Object.defineProperty(this, "nonceSize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 12
    });
    Object.defineProperty(this, "tagSize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 16
    });
  }
  createEncryptionContext(key) {
    return new AesGcmContext(key);
  }
};
var Aes256Gcm = class extends Aes128Gcm {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "id", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: AeadId.Aes256Gcm
    });
    Object.defineProperty(this, "keySize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 32
    });
    Object.defineProperty(this, "nonceSize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 12
    });
    Object.defineProperty(this, "tagSize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 16
    });
  }
};

// node_modules/@hpke/core/esm/src/utils/emitNotSupported.js
function emitNotSupported() {
  return new Promise((_resolve, reject) => {
    reject(new NotSupportedError("Not supported"));
  });
}

// node_modules/@hpke/core/esm/src/exporterContext.js
var LABEL_SEC = new Uint8Array([115, 101, 99]);
var ExporterContextImpl = class {
  constructor(api, kdf, exporterSecret) {
    Object.defineProperty(this, "_api", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "exporterSecret", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_kdf", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this._api = api;
    this._kdf = kdf;
    this.exporterSecret = exporterSecret;
  }
  async seal(_data, _aad) {
    return await emitNotSupported();
  }
  async open(_data, _aad) {
    return await emitNotSupported();
  }
  async export(exporterContext, len) {
    const rawExporterContext = toArrayBuffer(exporterContext);
    if (rawExporterContext.byteLength > INPUT_LENGTH_LIMIT) {
      throw new InvalidParamError("Too long exporter context");
    }
    try {
      return await this._kdf.labeledExpand(this.exporterSecret, LABEL_SEC, new Uint8Array(rawExporterContext), len);
    } catch (e) {
      throw new ExportError(e);
    }
  }
};
var RecipientExporterContextImpl = class extends ExporterContextImpl {
};
var SenderExporterContextImpl = class extends ExporterContextImpl {
  constructor(api, kdf, exporterSecret, enc) {
    super(api, kdf, exporterSecret);
    Object.defineProperty(this, "enc", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this.enc = enc;
    return;
  }
};

// node_modules/@hpke/core/esm/src/encryptionContext.js
var EncryptionContextImpl = class extends ExporterContextImpl {
  constructor(api, kdf, params) {
    super(api, kdf, params.exporterSecret);
    Object.defineProperty(this, "_aead", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_nK", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_nN", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_nT", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_ctx", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    if (params.key === void 0 || params.baseNonce === void 0 || params.seq === void 0) {
      throw new Error("Required parameters are missing");
    }
    this._aead = params.aead;
    this._nK = this._aead.keySize;
    this._nN = this._aead.nonceSize;
    this._nT = this._aead.tagSize;
    const key = this._aead.createEncryptionContext(params.key);
    this._ctx = {
      key,
      baseNonce: params.baseNonce,
      seq: params.seq
    };
  }
  computeNonce(k2) {
    const seqBytes = i2Osp(k2.seq, k2.baseNonce.byteLength);
    return xor(k2.baseNonce, seqBytes).buffer;
  }
  incrementSeq(k2) {
    if (k2.seq > Number.MAX_SAFE_INTEGER) {
      throw new MessageLimitReachedError("Message limit reached");
    }
    k2.seq += 1;
    return;
  }
};

// node_modules/@hpke/core/esm/src/mutex.js
var __classPrivateFieldGet = function(receiver, state, kind, f2) {
  if (kind === "a" && !f2) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f2 : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f2 : kind === "a" ? f2.call(receiver) : f2 ? f2.value : state.get(receiver);
};
var __classPrivateFieldSet = function(receiver, state, value, kind, f2) {
  if (kind === "m") throw new TypeError("Private method is not writable");
  if (kind === "a" && !f2) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f2 : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind === "a" ? f2.call(receiver, value) : f2 ? f2.value = value : state.set(receiver, value), value;
};
var _Mutex_locked;
var Mutex = class {
  constructor() {
    _Mutex_locked.set(this, Promise.resolve());
  }
  async lock() {
    let releaseLock;
    const nextLock = new Promise((resolve) => {
      releaseLock = resolve;
    });
    const previousLock = __classPrivateFieldGet(this, _Mutex_locked, "f");
    __classPrivateFieldSet(this, _Mutex_locked, nextLock, "f");
    await previousLock;
    return releaseLock;
  }
};
_Mutex_locked = /* @__PURE__ */ new WeakMap();

// node_modules/@hpke/core/esm/src/recipientContext.js
var __classPrivateFieldGet2 = function(receiver, state, kind, f2) {
  if (kind === "a" && !f2) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f2 : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f2 : kind === "a" ? f2.call(receiver) : f2 ? f2.value : state.get(receiver);
};
var __classPrivateFieldSet2 = function(receiver, state, value, kind, f2) {
  if (kind === "m") throw new TypeError("Private method is not writable");
  if (kind === "a" && !f2) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f2 : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind === "a" ? f2.call(receiver, value) : f2 ? f2.value = value : state.set(receiver, value), value;
};
var _RecipientContextImpl_mutex;
var RecipientContextImpl = class extends EncryptionContextImpl {
  constructor() {
    super(...arguments);
    _RecipientContextImpl_mutex.set(this, void 0);
  }
  async open(data, aad = EMPTY.buffer) {
    __classPrivateFieldSet2(this, _RecipientContextImpl_mutex, __classPrivateFieldGet2(this, _RecipientContextImpl_mutex, "f") ?? new Mutex(), "f");
    const release = await __classPrivateFieldGet2(this, _RecipientContextImpl_mutex, "f").lock();
    let pt2;
    try {
      pt2 = await this._ctx.key.open(this.computeNonce(this._ctx), toArrayBuffer(data), toArrayBuffer(aad));
    } catch (e) {
      throw new OpenError(e);
    } finally {
      release();
    }
    this.incrementSeq(this._ctx);
    return pt2;
  }
};
_RecipientContextImpl_mutex = /* @__PURE__ */ new WeakMap();

// node_modules/@hpke/core/esm/src/senderContext.js
var __classPrivateFieldGet3 = function(receiver, state, kind, f2) {
  if (kind === "a" && !f2) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f2 : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f2 : kind === "a" ? f2.call(receiver) : f2 ? f2.value : state.get(receiver);
};
var __classPrivateFieldSet3 = function(receiver, state, value, kind, f2) {
  if (kind === "m") throw new TypeError("Private method is not writable");
  if (kind === "a" && !f2) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f2 : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind === "a" ? f2.call(receiver, value) : f2 ? f2.value = value : state.set(receiver, value), value;
};
var _SenderContextImpl_mutex;
var SenderContextImpl = class extends EncryptionContextImpl {
  constructor(api, kdf, params, enc) {
    super(api, kdf, params);
    Object.defineProperty(this, "enc", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    _SenderContextImpl_mutex.set(this, void 0);
    this.enc = enc;
  }
  async seal(data, aad = EMPTY.buffer) {
    __classPrivateFieldSet3(this, _SenderContextImpl_mutex, __classPrivateFieldGet3(this, _SenderContextImpl_mutex, "f") ?? new Mutex(), "f");
    const release = await __classPrivateFieldGet3(this, _SenderContextImpl_mutex, "f").lock();
    let ct2;
    try {
      ct2 = await this._ctx.key.seal(this.computeNonce(this._ctx), toArrayBuffer(data), toArrayBuffer(aad));
    } catch (e) {
      throw new SealError(e);
    } finally {
      release();
    }
    this.incrementSeq(this._ctx);
    return ct2;
  }
};
_SenderContextImpl_mutex = /* @__PURE__ */ new WeakMap();

// node_modules/@hpke/core/esm/src/cipherSuiteNative.js
var LABEL_BASE_NONCE = new Uint8Array([
  98,
  97,
  115,
  101,
  95,
  110,
  111,
  110,
  99,
  101
]);
var LABEL_EXP = new Uint8Array([101, 120, 112]);
var LABEL_INFO_HASH = new Uint8Array([
  105,
  110,
  102,
  111,
  95,
  104,
  97,
  115,
  104
]);
var LABEL_KEY = new Uint8Array([107, 101, 121]);
var LABEL_PSK_ID_HASH = new Uint8Array([
  112,
  115,
  107,
  95,
  105,
  100,
  95,
  104,
  97,
  115,
  104
]);
var LABEL_SECRET = new Uint8Array([115, 101, 99, 114, 101, 116]);
var SUITE_ID_HEADER_HPKE = new Uint8Array([
  72,
  80,
  75,
  69,
  0,
  0,
  0,
  0,
  0,
  0
]);
var CipherSuiteNative = class extends NativeAlgorithm {
  /**
   * @param params A set of parameters for building a cipher suite.
   *
   * If the error occurred, throws {@link InvalidParamError}.
   *
   * @throws {@link InvalidParamError}
   */
  constructor(params) {
    super();
    Object.defineProperty(this, "_kem", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_kdf", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_aead", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_suiteId", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    if (typeof params.kem === "number") {
      throw new InvalidParamError("KemId cannot be used");
    }
    this._kem = params.kem;
    if (typeof params.kdf === "number") {
      throw new InvalidParamError("KdfId cannot be used");
    }
    this._kdf = params.kdf;
    if (typeof params.aead === "number") {
      throw new InvalidParamError("AeadId cannot be used");
    }
    this._aead = params.aead;
    this._suiteId = new Uint8Array(SUITE_ID_HEADER_HPKE);
    this._suiteId.set(i2Osp(this._kem.id, 2), 4);
    this._suiteId.set(i2Osp(this._kdf.id, 2), 6);
    this._suiteId.set(i2Osp(this._aead.id, 2), 8);
    this._kdf.init(this._suiteId);
  }
  /**
   * Gets the KEM context of the ciphersuite.
   */
  get kem() {
    return this._kem;
  }
  /**
   * Gets the KDF context of the ciphersuite.
   */
  get kdf() {
    return this._kdf;
  }
  /**
   * Gets the AEAD context of the ciphersuite.
   */
  get aead() {
    return this._aead;
  }
  /**
   * Creates an encryption context for a sender.
   *
   * If the error occurred, throws {@link DecapError} | {@link ValidationError}.
   *
   * @param params A set of parameters for the sender encryption context.
   * @returns A sender encryption context.
   * @throws {@link EncapError}, {@link ValidationError}
   */
  async createSenderContext(params) {
    this._validateInputLength(params);
    await this._setup();
    const dh = await this._kem.encap(params);
    let mode;
    if (params.psk !== void 0) {
      mode = params.senderKey !== void 0 ? Mode.AuthPsk : Mode.Psk;
    } else {
      mode = params.senderKey !== void 0 ? Mode.Auth : Mode.Base;
    }
    return await this._keyScheduleS(mode, dh.sharedSecret, dh.enc, params);
  }
  /**
   * Creates an encryption context for a recipient.
   *
   * If the error occurred, throws {@link DecapError}
   * | {@link DeserializeError} | {@link ValidationError}.
   *
   * @param params A set of parameters for the recipient encryption context.
   * @returns A recipient encryption context.
   * @throws {@link DecapError}, {@link DeserializeError}, {@link ValidationError}
   */
  async createRecipientContext(params) {
    this._validateInputLength(params);
    await this._setup();
    const sharedSecret = await this._kem.decap(params);
    let mode;
    if (params.psk !== void 0) {
      mode = params.senderPublicKey !== void 0 ? Mode.AuthPsk : Mode.Psk;
    } else {
      mode = params.senderPublicKey !== void 0 ? Mode.Auth : Mode.Base;
    }
    return await this._keyScheduleR(mode, sharedSecret, params);
  }
  /**
   * Encrypts a message to a recipient.
   *
   * If the error occurred, throws `EncapError` | `MessageLimitReachedError` | `SealError` | `ValidationError`.
   *
   * @param params A set of parameters for building a sender encryption context.
   * @param pt A plain text as bytes to be encrypted.
   * @param aad Additional authenticated data as bytes fed by an application.
   * @returns A cipher text and an encapsulated key as bytes.
   * @throws {@link EncapError}, {@link MessageLimitReachedError}, {@link SealError}, {@link ValidationError}
   */
  async seal(params, pt2, aad = EMPTY.buffer) {
    const ctx = await this.createSenderContext(params);
    return {
      ct: await ctx.seal(pt2, aad),
      enc: ctx.enc
    };
  }
  /**
   * Decrypts a message from a sender.
   *
   * If the error occurred, throws `DecapError` | `DeserializeError` | `OpenError` | `ValidationError`.
   *
   * @param params A set of parameters for building a recipient encryption context.
   * @param ct An encrypted text as bytes to be decrypted.
   * @param aad Additional authenticated data as bytes fed by an application.
   * @returns A decrypted plain text as bytes.
   * @throws {@link DecapError}, {@link DeserializeError}, {@link OpenError}, {@link ValidationError}
   */
  async open(params, ct2, aad = EMPTY.buffer) {
    const ctx = await this.createRecipientContext(params);
    return await ctx.open(ct2, aad);
  }
  // private verifyPskInputs(mode: Mode, params: KeyScheduleParams) {
  //   const gotPsk = (params.psk !== undefined);
  //   const gotPskId = (params.psk !== undefined && params.psk.id.byteLength > 0);
  //   if (gotPsk !== gotPskId) {
  //     throw new Error('Inconsistent PSK inputs');
  //   }
  //   if (gotPsk && (mode === Mode.Base || mode === Mode.Auth)) {
  //     throw new Error('PSK input provided when not needed');
  //   }
  //   if (!gotPsk && (mode === Mode.Psk || mode === Mode.AuthPsk)) {
  //     throw new Error('Missing required PSK input');
  //   }
  //   return;
  // }
  async _keySchedule(mode, sharedSecret, params) {
    const pskId = params.psk === void 0 ? EMPTY : toUint8Array(params.psk.id);
    const pskIdHash = await this._kdf.labeledExtract(EMPTY, LABEL_PSK_ID_HASH, pskId);
    const info = params.info === void 0 ? EMPTY : toUint8Array(params.info);
    const infoHash = await this._kdf.labeledExtract(EMPTY, LABEL_INFO_HASH, info);
    const keyScheduleContext = new Uint8Array(1 + pskIdHash.byteLength + infoHash.byteLength);
    keyScheduleContext.set(new Uint8Array([mode]), 0);
    keyScheduleContext.set(new Uint8Array(pskIdHash), 1);
    keyScheduleContext.set(new Uint8Array(infoHash), 1 + pskIdHash.byteLength);
    const psk = params.psk === void 0 ? EMPTY : toUint8Array(params.psk.key);
    const ikm = this._kdf.buildLabeledIkm(LABEL_SECRET, psk);
    const exporterSecretInfo = this._kdf.buildLabeledInfo(LABEL_EXP, keyScheduleContext, this._kdf.hashSize);
    const exporterSecret = await this._kdf.extractAndExpand(sharedSecret, ikm, exporterSecretInfo, this._kdf.hashSize);
    if (this._aead.id === AeadId.ExportOnly) {
      return { aead: this._aead, exporterSecret };
    }
    const keyInfo = this._kdf.buildLabeledInfo(LABEL_KEY, keyScheduleContext, this._aead.keySize);
    const key = await this._kdf.extractAndExpand(sharedSecret, ikm, keyInfo, this._aead.keySize);
    const baseNonceInfo = this._kdf.buildLabeledInfo(LABEL_BASE_NONCE, keyScheduleContext, this._aead.nonceSize);
    const baseNonce = await this._kdf.extractAndExpand(sharedSecret, ikm, baseNonceInfo, this._aead.nonceSize);
    return {
      aead: this._aead,
      exporterSecret,
      key,
      baseNonce: new Uint8Array(baseNonce),
      seq: 0
    };
  }
  async _keyScheduleS(mode, sharedSecret, enc, params) {
    const res = await this._keySchedule(mode, sharedSecret, params);
    if (res.key === void 0) {
      return new SenderExporterContextImpl(this._api, this._kdf, res.exporterSecret, enc);
    }
    return new SenderContextImpl(this._api, this._kdf, res, enc);
  }
  async _keyScheduleR(mode, sharedSecret, params) {
    const res = await this._keySchedule(mode, sharedSecret, params);
    if (res.key === void 0) {
      return new RecipientExporterContextImpl(this._api, this._kdf, res.exporterSecret);
    }
    return new RecipientContextImpl(this._api, this._kdf, res);
  }
  _validateInputLength(params) {
    if (params.info !== void 0 && params.info.byteLength > INFO_LENGTH_LIMIT) {
      throw new InvalidParamError("Too long info");
    }
    if (params.psk !== void 0) {
      if (params.psk.key.byteLength < MINIMUM_PSK_LENGTH) {
        throw new InvalidParamError(`PSK must have at least ${MINIMUM_PSK_LENGTH} bytes`);
      }
      if (params.psk.key.byteLength > INPUT_LENGTH_LIMIT) {
        throw new InvalidParamError("Too long psk.key");
      }
      if (params.psk.id.byteLength > INPUT_LENGTH_LIMIT) {
        throw new InvalidParamError("Too long psk.id");
      }
    }
    return;
  }
};

// node_modules/@hpke/core/esm/src/native.js
var CipherSuite = class extends CipherSuiteNative {
};
var HkdfSha256 = class extends HkdfSha256Native {
};

// node_modules/@hpke/core/esm/src/kems/dhkemPrimitives/x25519.js
var PKCS8_ALG_ID_X25519 = new Uint8Array([
  48,
  46,
  2,
  1,
  0,
  48,
  5,
  6,
  3,
  43,
  101,
  110,
  4,
  34,
  4,
  32
]);

// node_modules/@hpke/core/esm/src/kems/dhkemPrimitives/x448.js
var PKCS8_ALG_ID_X448 = new Uint8Array([
  48,
  70,
  2,
  1,
  0,
  48,
  5,
  6,
  3,
  43,
  101,
  111,
  4,
  58,
  4,
  56
]);

// node_modules/@hpke/dhkem-x25519/esm/src/primitives/x25519.js
var _1n2 = 1n;
var _2n2 = 2n;
var _3n = 3n;
var _5n = 5n;
var ed25519_CURVE_p = 0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffedn;
function ed25519_pow_2_252_3(x2) {
  const _10n = 10n;
  const _20n = 20n;
  const _40n = 40n;
  const _80n = 80n;
  const P2 = ed25519_CURVE_p;
  const x22 = x2 * x2 % P2;
  const b2 = x22 * x2 % P2;
  const b4 = pow2(b2, _2n2, P2) * b2 % P2;
  const b5 = pow2(b4, _1n2, P2) * x2 % P2;
  const b10 = pow2(b5, _5n, P2) * b5 % P2;
  const b20 = pow2(b10, _10n, P2) * b10 % P2;
  const b40 = pow2(b20, _20n, P2) * b20 % P2;
  const b80 = pow2(b40, _40n, P2) * b40 % P2;
  const b160 = pow2(b80, _80n, P2) * b80 % P2;
  const b240 = pow2(b160, _80n, P2) * b80 % P2;
  const b250 = pow2(b240, _10n, P2) * b10 % P2;
  const pow_p_5_8 = pow2(b250, _2n2, P2) * x2 % P2;
  return { pow_p_5_8, b2 };
}
function adjustScalarBytes(bytes) {
  bytes[0] &= 248;
  bytes[31] &= 127;
  bytes[31] |= 64;
  return bytes;
}
var x25519 = /* @__PURE__ */ (() => {
  const P2 = ed25519_CURVE_p;
  return montgomery({
    P: P2,
    type: "x25519",
    powPminus2: (x2) => {
      const { pow_p_5_8, b2 } = ed25519_pow_2_252_3(x2);
      return mod(pow2(pow_p_5_8, _3n, P2) * b2, P2);
    },
    adjustScalarBytes
  });
})();

// node_modules/@hpke/dhkem-x25519/esm/src/hkdfSha256.js
var HkdfSha2562 = class extends HkdfSha256Native {
  async extract(salt, ikm) {
    await this._setup();
    const saltBuf = salt.byteLength === 0 ? new ArrayBuffer(this.hashSize) : toArrayBuffer(salt);
    const ikmBuf = toArrayBuffer(ikm);
    if (saltBuf.byteLength !== this.hashSize) {
      return hmac(sha256, new Uint8Array(saltBuf), new Uint8Array(ikmBuf)).buffer;
    }
    const key = await this._api.importKey("raw", saltBuf, this.algHash, false, [
      "sign"
    ]);
    return await this._api.sign("HMAC", key, ikmBuf);
  }
};

// node_modules/@hpke/dhkem-x25519/esm/src/dhkemX25519.js
var X255192 = class extends XCurveDhkemPrimitives {
  constructor(hkdf) {
    super("X25519", 32, x25519, hkdf);
  }
  derive(sk, pk) {
    try {
      return Promise.resolve(this._curve.getSharedSecret(sk, pk));
    } catch (e) {
      return Promise.reject(new SerializeError(e));
    }
  }
};
var DhkemX25519HkdfSha2562 = class extends Dhkem {
  constructor() {
    const kdf = new HkdfSha2562();
    super(KemId.DhkemX25519HkdfSha256, new X255192(kdf), kdf);
    Object.defineProperty(this, "id", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: KemId.DhkemX25519HkdfSha256
    });
    Object.defineProperty(this, "secretSize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 32
    });
    Object.defineProperty(this, "encSize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 32
    });
    Object.defineProperty(this, "publicKeySize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 32
    });
    Object.defineProperty(this, "privateKeySize", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 32
    });
  }
};

// node_modules/bs58check/node_modules/@noble/hashes/esm/utils.js
function isBytes2(a2) {
  return a2 instanceof Uint8Array || ArrayBuffer.isView(a2) && a2.constructor.name === "Uint8Array";
}
function abytes2(b2, ...lengths) {
  if (!isBytes2(b2))
    throw new Error("Uint8Array expected");
  if (lengths.length > 0 && !lengths.includes(b2.length))
    throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b2.length);
}
function aexists2(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput2(out, instance) {
  abytes2(out);
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error("digestInto() expects output buffer of length at least " + min);
  }
}
function clean2(...arrays) {
  for (let i2 = 0; i2 < arrays.length; i2++) {
    arrays[i2].fill(0);
  }
}
function createView2(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr2(word, shift) {
  return word << 32 - shift | word >>> shift;
}
function utf8ToBytes(str) {
  if (typeof str !== "string")
    throw new Error("string expected");
  return new Uint8Array(new TextEncoder().encode(str));
}
function toBytes(data) {
  if (typeof data === "string")
    data = utf8ToBytes(data);
  abytes2(data);
  return data;
}
var Hash = class {
};
function createHasher2(hashCons) {
  const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
  const tmp = hashCons();
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = () => hashCons();
  return hashC;
}

// node_modules/bs58check/node_modules/@noble/hashes/esm/_md.js
function setBigUint64(view, byteOffset, value, isLE2) {
  if (typeof view.setBigUint64 === "function")
    return view.setBigUint64(byteOffset, value, isLE2);
  const _32n2 = BigInt(32);
  const _u32_max = BigInt(4294967295);
  const wh = Number(value >> _32n2 & _u32_max);
  const wl = Number(value & _u32_max);
  const h2 = isLE2 ? 4 : 0;
  const l2 = isLE2 ? 0 : 4;
  view.setUint32(byteOffset + h2, wh, isLE2);
  view.setUint32(byteOffset + l2, wl, isLE2);
}
function Chi2(a2, b2, c2) {
  return a2 & b2 ^ ~a2 & c2;
}
function Maj2(a2, b2, c2) {
  return a2 & b2 ^ a2 & c2 ^ b2 & c2;
}
var HashMD2 = class extends Hash {
  constructor(blockLen, outputLen, padOffset, isLE2) {
    super();
    this.finished = false;
    this.length = 0;
    this.pos = 0;
    this.destroyed = false;
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE2;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView2(this.buffer);
  }
  update(data) {
    aexists2(this);
    data = toBytes(data);
    abytes2(data);
    const { view, buffer, blockLen } = this;
    const len = data.length;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView2(data);
        for (; blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        continue;
      }
      buffer.set(data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
      }
    }
    this.length += data.length;
    this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists2(this);
    aoutput2(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE: isLE2 } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    clean2(this.buffer.subarray(pos));
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      pos = 0;
    }
    for (let i2 = pos; i2 < blockLen; i2++)
      buffer[i2] = 0;
    setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE2);
    this.process(view, 0);
    const oview = createView2(out);
    const len = this.outputLen;
    if (len % 4)
      throw new Error("_sha2: outputLen should be aligned to 32bit");
    const outLen = len / 4;
    const state = this.get();
    if (outLen > state.length)
      throw new Error("_sha2: outputLen bigger than state");
    for (let i2 = 0; i2 < outLen; i2++)
      oview.setUint32(4 * i2, state[i2], isLE2);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneInto(to) {
    to || (to = new this.constructor());
    to.set(...this.get());
    const { blockLen, buffer, length, finished, destroyed, pos } = this;
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    if (length % blockLen)
      to.buffer.set(buffer);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};
var SHA256_IV2 = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);

// node_modules/bs58check/node_modules/@noble/hashes/esm/sha2.js
var SHA256_K2 = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var SHA256_W2 = /* @__PURE__ */ new Uint32Array(64);
var SHA256 = class extends HashMD2 {
  constructor(outputLen = 32) {
    super(64, outputLen, 8, false);
    this.A = SHA256_IV2[0] | 0;
    this.B = SHA256_IV2[1] | 0;
    this.C = SHA256_IV2[2] | 0;
    this.D = SHA256_IV2[3] | 0;
    this.E = SHA256_IV2[4] | 0;
    this.F = SHA256_IV2[5] | 0;
    this.G = SHA256_IV2[6] | 0;
    this.H = SHA256_IV2[7] | 0;
  }
  get() {
    const { A: A3, B: B2, C: C2, D: D2, E: E2, F: F2, G: G2, H: H2 } = this;
    return [A3, B2, C2, D2, E2, F2, G2, H2];
  }
  // prettier-ignore
  set(A3, B2, C2, D2, E2, F2, G2, H2) {
    this.A = A3 | 0;
    this.B = B2 | 0;
    this.C = C2 | 0;
    this.D = D2 | 0;
    this.E = E2 | 0;
    this.F = F2 | 0;
    this.G = G2 | 0;
    this.H = H2 | 0;
  }
  process(view, offset) {
    for (let i2 = 0; i2 < 16; i2++, offset += 4)
      SHA256_W2[i2] = view.getUint32(offset, false);
    for (let i2 = 16; i2 < 64; i2++) {
      const W15 = SHA256_W2[i2 - 15];
      const W2 = SHA256_W2[i2 - 2];
      const s0 = rotr2(W15, 7) ^ rotr2(W15, 18) ^ W15 >>> 3;
      const s1 = rotr2(W2, 17) ^ rotr2(W2, 19) ^ W2 >>> 10;
      SHA256_W2[i2] = s1 + SHA256_W2[i2 - 7] + s0 + SHA256_W2[i2 - 16] | 0;
    }
    let { A: A3, B: B2, C: C2, D: D2, E: E2, F: F2, G: G2, H: H2 } = this;
    for (let i2 = 0; i2 < 64; i2++) {
      const sigma1 = rotr2(E2, 6) ^ rotr2(E2, 11) ^ rotr2(E2, 25);
      const T1 = H2 + sigma1 + Chi2(E2, F2, G2) + SHA256_K2[i2] + SHA256_W2[i2] | 0;
      const sigma0 = rotr2(A3, 2) ^ rotr2(A3, 13) ^ rotr2(A3, 22);
      const T2 = sigma0 + Maj2(A3, B2, C2) | 0;
      H2 = G2;
      G2 = F2;
      F2 = E2;
      E2 = D2 + T1 | 0;
      D2 = C2;
      C2 = B2;
      B2 = A3;
      A3 = T1 + T2 | 0;
    }
    A3 = A3 + this.A | 0;
    B2 = B2 + this.B | 0;
    C2 = C2 + this.C | 0;
    D2 = D2 + this.D | 0;
    E2 = E2 + this.E | 0;
    F2 = F2 + this.F | 0;
    G2 = G2 + this.G | 0;
    H2 = H2 + this.H | 0;
    this.set(A3, B2, C2, D2, E2, F2, G2, H2);
  }
  roundClean() {
    clean2(SHA256_W2);
  }
  destroy() {
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    clean2(this.buffer);
  }
};
var sha2562 = /* @__PURE__ */ createHasher2(() => new SHA256());

// node_modules/bs58check/node_modules/@noble/hashes/esm/sha256.js
var sha2563 = sha2562;

// node_modules/base-x/src/esm/index.js
function base(ALPHABET2) {
  if (ALPHABET2.length >= 255) {
    throw new TypeError("Alphabet too long");
  }
  const BASE_MAP = new Uint8Array(256);
  for (let j2 = 0; j2 < BASE_MAP.length; j2++) {
    BASE_MAP[j2] = 255;
  }
  for (let i2 = 0; i2 < ALPHABET2.length; i2++) {
    const x2 = ALPHABET2.charAt(i2);
    const xc = x2.charCodeAt(0);
    if (BASE_MAP[xc] !== 255) {
      throw new TypeError(x2 + " is ambiguous");
    }
    BASE_MAP[xc] = i2;
  }
  const BASE = ALPHABET2.length;
  const LEADER = ALPHABET2.charAt(0);
  const FACTOR = Math.log(BASE) / Math.log(256);
  const iFACTOR = Math.log(256) / Math.log(BASE);
  function encode(source) {
    if (source instanceof Uint8Array) {
    } else if (ArrayBuffer.isView(source)) {
      source = new Uint8Array(source.buffer, source.byteOffset, source.byteLength);
    } else if (Array.isArray(source)) {
      source = Uint8Array.from(source);
    }
    if (!(source instanceof Uint8Array)) {
      throw new TypeError("Expected Uint8Array");
    }
    if (source.length === 0) {
      return "";
    }
    let zeroes = 0;
    let length = 0;
    let pbegin = 0;
    const pend = source.length;
    while (pbegin !== pend && source[pbegin] === 0) {
      pbegin++;
      zeroes++;
    }
    const size = (pend - pbegin) * iFACTOR + 1 >>> 0;
    const b58 = new Uint8Array(size);
    while (pbegin !== pend) {
      let carry = source[pbegin];
      let i2 = 0;
      for (let it1 = size - 1; (carry !== 0 || i2 < length) && it1 !== -1; it1--, i2++) {
        carry += 256 * b58[it1] >>> 0;
        b58[it1] = carry % BASE >>> 0;
        carry = carry / BASE >>> 0;
      }
      if (carry !== 0) {
        throw new Error("Non-zero carry");
      }
      length = i2;
      pbegin++;
    }
    let it2 = size - length;
    while (it2 !== size && b58[it2] === 0) {
      it2++;
    }
    let str = LEADER.repeat(zeroes);
    for (; it2 < size; ++it2) {
      str += ALPHABET2.charAt(b58[it2]);
    }
    return str;
  }
  function decodeUnsafe(source) {
    if (typeof source !== "string") {
      throw new TypeError("Expected String");
    }
    if (source.length === 0) {
      return new Uint8Array();
    }
    let psz = 0;
    let zeroes = 0;
    let length = 0;
    while (source[psz] === LEADER) {
      zeroes++;
      psz++;
    }
    const size = (source.length - psz) * FACTOR + 1 >>> 0;
    const b256 = new Uint8Array(size);
    while (psz < source.length) {
      const charCode = source.charCodeAt(psz);
      if (charCode > 255) {
        return;
      }
      let carry = BASE_MAP[charCode];
      if (carry === 255) {
        return;
      }
      let i2 = 0;
      for (let it3 = size - 1; (carry !== 0 || i2 < length) && it3 !== -1; it3--, i2++) {
        carry += BASE * b256[it3] >>> 0;
        b256[it3] = carry % 256 >>> 0;
        carry = carry / 256 >>> 0;
      }
      if (carry !== 0) {
        throw new Error("Non-zero carry");
      }
      length = i2;
      psz++;
    }
    let it4 = size - length;
    while (it4 !== size && b256[it4] === 0) {
      it4++;
    }
    const vch = new Uint8Array(zeroes + (size - it4));
    let j2 = zeroes;
    while (it4 !== size) {
      vch[j2++] = b256[it4++];
    }
    return vch;
  }
  function decode(string) {
    const buffer = decodeUnsafe(string);
    if (buffer) {
      return buffer;
    }
    throw new Error("Non-base" + BASE + " character");
  }
  return {
    encode,
    decodeUnsafe,
    decode
  };
}
var esm_default = base;

// node_modules/bs58/src/esm/index.js
var ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
var esm_default2 = esm_default(ALPHABET);

// node_modules/bs58check/src/esm/base.js
function base_default(checksumFn) {
  function encode(payload) {
    var payloadU8 = Uint8Array.from(payload);
    var checksum = checksumFn(payloadU8);
    var length = payloadU8.length + 4;
    var both = new Uint8Array(length);
    both.set(payloadU8, 0);
    both.set(checksum.subarray(0, 4), payloadU8.length);
    return esm_default2.encode(both);
  }
  function decodeRaw(buffer) {
    var payload = buffer.slice(0, -4);
    var checksum = buffer.slice(-4);
    var newChecksum = checksumFn(payload);
    if (checksum[0] ^ newChecksum[0] | checksum[1] ^ newChecksum[1] | checksum[2] ^ newChecksum[2] | checksum[3] ^ newChecksum[3])
      return;
    return payload;
  }
  function decodeUnsafe(str) {
    var buffer = esm_default2.decodeUnsafe(str);
    if (buffer == null)
      return;
    return decodeRaw(buffer);
  }
  function decode(str) {
    var buffer = esm_default2.decode(str);
    var payload = decodeRaw(buffer);
    if (payload == null)
      throw new Error("Invalid checksum");
    return payload;
  }
  return {
    encode,
    decode,
    decodeUnsafe
  };
}

// node_modules/bs58check/src/esm/index.js
function sha256x2(buffer) {
  return sha2563(sha2563(buffer));
}
var esm_default3 = base_default(sha256x2);

// node_modules/libsodium-sumo/dist/modules-sumo-esm/libsodium-sumo.mjs
async function A(A3 = {}) {
  var I2, g2 = A3, C2 = !!globalThis.window, B2 = !!globalThis.WorkerGlobalScope, Q2 = (globalThis.process?.versions?.node && globalThis.process, import.meta.url);
  if (C2 || B2) {
    try {
      new URL(".", Q2).href;
    } catch {
    }
    B2 && (I2 = (A4) => {
      var I3 = new XMLHttpRequest();
      return I3.open("GET", A4, false), I3.responseType = "arraybuffer", I3.send(null), new Uint8Array(I3.response);
    });
  }
  (function() {
  }).bind();
  var E2, i2, D2, o2, y2, h2, w2, F2, c2, S2, a2, k2 = function() {
  }.bind(), M2 = false, G2 = false;
  function N2() {
    var A4 = e.buffer;
    w2 = new Int8Array(A4), y2 = new Int16Array(A4), g2.HEAPU8 = a2 = new Uint8Array(A4), new Uint16Array(A4), h2 = new Int32Array(A4), S2 = new Uint32Array(A4), F2 = new Float32Array(A4), c2 = new Float64Array(A4);
  }
  function J2(A4) {
    g2.onAbort?.(A4), k2(A4 = `Aborted(${A4})`), M2 = true, A4 += ". Build with -sASSERTIONS for more info.";
    var I3 = new WebAssembly.RuntimeError(A4);
    throw D2?.(I3), I3;
  }
  for (var U2 = (A4) => {
    for (; A4.length > 0; ) A4.shift()(g2);
  }, Y2 = [], K2 = (A4) => Y2.push(A4), H2 = [], s2 = (A4) => H2.push(A4), f2 = globalThis.TextDecoder && new TextDecoder(), t2 = (A4, I3, g3) => A4 ? ((A5, I4 = 0, g4, C3) => {
    var B3 = ((A6, I5, g5, C4) => {
      var B4 = I5 + g5;
      if (C4) return B4;
      for (; A6[I5] && !(I5 >= B4); ) ++I5;
      return I5;
    })(A5, I4, g4, C3);
    if (B3 - I4 > 16 && A5.buffer && f2) return f2.decode(A5.subarray(I4, B3));
    for (var Q3 = ""; I4 < B3; ) {
      var E3 = A5[I4++];
      if (128 & E3) {
        var i3 = 63 & A5[I4++];
        if (192 != (224 & E3)) {
          var D3 = 63 & A5[I4++];
          if ((E3 = 224 == (240 & E3) ? (15 & E3) << 12 | i3 << 6 | D3 : (7 & E3) << 18 | i3 << 12 | D3 << 6 | 63 & A5[I4++]) < 65536) Q3 += String.fromCharCode(E3);
          else {
            var o3 = E3 - 65536;
            Q3 += String.fromCharCode(55296 | o3 >> 10, 56320 | 1023 & o3);
          }
        } else Q3 += String.fromCharCode((31 & E3) << 6 | i3);
      } else Q3 += String.fromCharCode(E3);
    }
    return Q3;
  })(a2, A4, I3, g3) : "", p2 = [], L2 = (A4, I3) => Math.ceil(A4 / I3) * I3, r2 = (A4) => {
    var I3 = (A4 - e.buffer.byteLength + 65535) / 65536 | 0;
    try {
      return e.grow(I3), N2(), 1;
    } catch (A5) {
    }
  }, R2 = new Uint8Array(123), n2 = 25; n2 >= 0; --n2) R2[48 + n2] = 52 + n2, R2[65 + n2] = n2, R2[97 + n2] = 26 + n2;
  if (R2[43] = 62, R2[47] = 63, g2.noExitRuntime && g2.noExitRuntime, g2.print && g2.print, g2.printErr && (k2 = g2.printErr), g2.wasmBinary && (E2 = g2.wasmBinary), g2.arguments && g2.arguments, g2.thisProgram && g2.thisProgram, g2.preInit) for ("function" == typeof g2.preInit && (g2.preInit = [g2.preInit]); g2.preInit.length > 0; ) g2.preInit.shift()();
  g2.setValue = function(A4, I3, g3 = "i8") {
    switch (g3.endsWith("*") && (g3 = "*"), g3) {
      case "i1":
      case "i8":
        w2[A4] = I3;
        break;
      case "i16":
        y2[A4 >> 1] = I3;
        break;
      case "i32":
        h2[A4 >> 2] = I3;
        break;
      case "i64":
        J2("to do setValue(i64) use WASM_BIGINT");
      case "float":
        F2[A4 >> 2] = I3;
        break;
      case "double":
        c2[A4 >> 3] = I3;
        break;
      case "*":
        S2[A4 >> 2] = I3;
        break;
      default:
        J2(`invalid type for setValue: ${g3}`);
    }
  }, g2.getValue = function(A4, I3 = "i8") {
    switch (I3.endsWith("*") && (I3 = "*"), I3) {
      case "i1":
      case "i8":
        return w2[A4];
      case "i16":
        return y2[A4 >> 1];
      case "i32":
        return h2[A4 >> 2];
      case "i64":
        J2("to do getValue(i64) use WASM_BIGINT");
      case "float":
        return F2[A4 >> 2];
      case "double":
        return c2[A4 >> 3];
      case "*":
        return S2[A4 >> 2];
      default:
        J2(`invalid type for getValue: ${I3}`);
    }
  }, g2.UTF8ToString = t2;
  var e, _2, d2 = { 40712: () => g2.getRandomValue(), 40748: () => {
    if (void 0 === g2.getRandomValue) try {
      var A4 = "object" == typeof window ? window : self, I3 = void 0 !== A4.crypto ? A4.crypto : A4.msCrypto;
      I3 = void 0 === I3 ? B3 : I3;
      var C3 = function() {
        var A5 = new Uint32Array(1);
        return I3.getRandomValues(A5), A5[0] >>> 0;
      };
      C3(), g2.getRandomValue = C3;
    } catch (A5) {
      try {
        var B3 = require_crypto(), Q3 = function() {
          var A6 = B3.randomBytes(4);
          return (A6[0] << 24 | A6[1] << 16 | A6[2] << 8 | A6[3]) >>> 0;
        };
        Q3(), g2.getRandomValue = Q3;
      } catch (A6) {
        throw "No secure random number generator found";
      }
    }
  } }, q2 = { a: (A4, I3, g3, C3) => J2(`Assertion failed: ${t2(A4)}, at: ` + [I3 ? t2(I3) : "unknown filename", g3, C3 ? t2(C3) : "unknown function"]), c: () => J2(""), b: (A4, I3, g3) => ((A5, I4, g4) => {
    var C3 = ((A6, I5) => {
      var g5;
      for (p2.length = 0; g5 = a2[A6++]; ) {
        var C4 = 105 != g5;
        I5 += (C4 &= 112 != g5) && I5 % 8 ? 4 : 0, p2.push(112 == g5 ? S2[I5 >> 2] : 105 == g5 ? h2[I5 >> 2] : c2[I5 >> 3]), I5 += C4 ? 8 : 4;
      }
      return p2;
    })(I4, g4);
    return d2[A5](...C3);
  })(A4, I3, g3), d: (A4) => {
    var I3 = a2.length, g3 = 2147483648;
    if ((A4 >>>= 0) > g3) return false;
    for (var C3 = 1; C3 <= 4; C3 *= 2) {
      var B3 = I3 * (1 + 0.2 / C3);
      B3 = Math.min(B3, A4 + 100663296);
      var Q3 = Math.min(g3, L2(Math.max(A4, B3), 65536));
      if (r2(Q3)) return true;
    }
    return false;
  } };
  return _2 = await (async function() {
    function A4(A5, I3) {
      return (function(A6) {
        g2._crypto_aead_aegis128l_keybytes = A6.f, g2._crypto_aead_aegis128l_nsecbytes = A6.g, g2._crypto_aead_aegis128l_npubbytes = A6.h, g2._crypto_aead_aegis128l_abytes = A6.i, g2._crypto_aead_aegis128l_messagebytes_max = A6.j, g2._crypto_aead_aegis128l_keygen = A6.k, g2._crypto_aead_aegis128l_encrypt = A6.l, g2._crypto_aead_aegis128l_encrypt_detached = A6.m, g2._crypto_aead_aegis128l_decrypt = A6.n, g2._crypto_aead_aegis128l_decrypt_detached = A6.o, g2._crypto_aead_aegis256_keybytes = A6.p, g2._crypto_aead_aegis256_nsecbytes = A6.q, g2._crypto_aead_aegis256_npubbytes = A6.r, g2._crypto_aead_aegis256_abytes = A6.s, g2._crypto_aead_aegis256_messagebytes_max = A6.t, g2._crypto_aead_aegis256_keygen = A6.u, g2._crypto_aead_aegis256_encrypt = A6.v, g2._crypto_aead_aegis256_encrypt_detached = A6.w, g2._crypto_aead_aegis256_decrypt = A6.x, g2._crypto_aead_aegis256_decrypt_detached = A6.y, g2._crypto_aead_aes256gcm_is_available = A6.z, g2._crypto_aead_chacha20poly1305_encrypt_detached = A6.A, g2._crypto_aead_chacha20poly1305_encrypt = A6.B, g2._crypto_aead_chacha20poly1305_ietf_encrypt_detached = A6.C, g2._crypto_aead_chacha20poly1305_ietf_encrypt = A6.D, g2._crypto_aead_chacha20poly1305_decrypt_detached = A6.E, g2._crypto_aead_chacha20poly1305_decrypt = A6.F, g2._crypto_aead_chacha20poly1305_ietf_decrypt_detached = A6.G, g2._crypto_aead_chacha20poly1305_ietf_decrypt = A6.H, g2._crypto_aead_chacha20poly1305_ietf_keybytes = A6.I, g2._crypto_aead_chacha20poly1305_ietf_npubbytes = A6.J, g2._crypto_aead_chacha20poly1305_ietf_nsecbytes = A6.K, g2._crypto_aead_chacha20poly1305_ietf_abytes = A6.L, g2._crypto_aead_chacha20poly1305_ietf_messagebytes_max = A6.M, g2._crypto_aead_chacha20poly1305_ietf_keygen = A6.N, g2._crypto_aead_chacha20poly1305_keybytes = A6.O, g2._crypto_aead_chacha20poly1305_npubbytes = A6.P, g2._crypto_aead_chacha20poly1305_nsecbytes = A6.Q, g2._crypto_aead_chacha20poly1305_abytes = A6.R, g2._crypto_aead_chacha20poly1305_messagebytes_max = A6.S, g2._crypto_aead_chacha20poly1305_keygen = A6.T, g2._crypto_aead_xchacha20poly1305_ietf_encrypt_detached = A6.U, g2._crypto_aead_xchacha20poly1305_ietf_encrypt = A6.V, g2._crypto_aead_xchacha20poly1305_ietf_decrypt_detached = A6.W, g2._crypto_aead_xchacha20poly1305_ietf_decrypt = A6.X, g2._crypto_aead_xchacha20poly1305_ietf_keybytes = A6.Y, g2._crypto_aead_xchacha20poly1305_ietf_npubbytes = A6.Z, g2._crypto_aead_xchacha20poly1305_ietf_nsecbytes = A6._, g2._crypto_aead_xchacha20poly1305_ietf_abytes = A6.$, g2._crypto_aead_xchacha20poly1305_ietf_messagebytes_max = A6.aa, g2._crypto_aead_xchacha20poly1305_ietf_keygen = A6.ba, g2._crypto_auth_bytes = A6.ca, g2._crypto_auth_keybytes = A6.da, g2._crypto_auth_primitive = A6.ea, g2._crypto_auth = A6.fa, g2._crypto_auth_verify = A6.ga, g2._crypto_auth_keygen = A6.ha, g2._crypto_auth_hmacsha256_bytes = A6.ia, g2._crypto_auth_hmacsha256_keybytes = A6.ja, g2._crypto_auth_hmacsha256_statebytes = A6.ka, g2._crypto_auth_hmacsha256_keygen = A6.la, g2._crypto_auth_hmacsha256_init = A6.ma, g2._crypto_auth_hmacsha256_update = A6.na, g2._crypto_auth_hmacsha256_final = A6.oa, g2._crypto_auth_hmacsha256 = A6.pa, g2._crypto_auth_hmacsha256_verify = A6.qa, g2._crypto_auth_hmacsha512_bytes = A6.ra, g2._crypto_auth_hmacsha512_keybytes = A6.sa, g2._crypto_auth_hmacsha512_statebytes = A6.ta, g2._crypto_auth_hmacsha512_keygen = A6.ua, g2._crypto_auth_hmacsha512_init = A6.va, g2._crypto_auth_hmacsha512_update = A6.wa, g2._crypto_auth_hmacsha512_final = A6.xa, g2._crypto_auth_hmacsha512 = A6.ya, g2._crypto_auth_hmacsha512_verify = A6.za, g2._crypto_auth_hmacsha512256_bytes = A6.Aa, g2._crypto_auth_hmacsha512256_keybytes = A6.Ba, g2._crypto_auth_hmacsha512256_statebytes = A6.Ca, g2._crypto_auth_hmacsha512256_keygen = A6.Da, g2._crypto_auth_hmacsha512256_init = A6.Ea, g2._crypto_auth_hmacsha512256_update = A6.Fa, g2._crypto_auth_hmacsha512256_final = A6.Ga, g2._crypto_auth_hmacsha512256 = A6.Ha, g2._crypto_auth_hmacsha512256_verify = A6.Ia, g2._crypto_box_seedbytes = A6.Ja, g2._crypto_box_publickeybytes = A6.Ka, g2._crypto_box_secretkeybytes = A6.La, g2._crypto_box_beforenmbytes = A6.Ma, g2._crypto_box_noncebytes = A6.Na, g2._crypto_box_zerobytes = A6.Oa, g2._crypto_box_boxzerobytes = A6.Pa, g2._crypto_box_macbytes = A6.Qa, g2._crypto_box_messagebytes_max = A6.Ra, g2._crypto_box_primitive = A6.Sa, g2._crypto_box_seed_keypair = A6.Ta, g2._crypto_box_keypair = A6.Ua, g2._crypto_box_beforenm = A6.Va, g2._crypto_box_afternm = A6.Wa, g2._crypto_box_open_afternm = A6.Xa, g2._crypto_box = A6.Ya, g2._crypto_box_open = A6.Za, g2._crypto_box_detached_afternm = A6._a, g2._crypto_box_detached = A6.$a, g2._crypto_box_easy_afternm = A6.ab, g2._crypto_box_easy = A6.bb, g2._crypto_box_open_detached_afternm = A6.cb, g2._crypto_box_open_detached = A6.db, g2._crypto_box_open_easy_afternm = A6.eb, g2._crypto_box_open_easy = A6.fb, g2._crypto_box_seal = A6.gb, g2._crypto_box_seal_open = A6.hb, g2._crypto_box_sealbytes = A6.ib, g2._crypto_box_curve25519xsalsa20poly1305_seed_keypair = A6.jb, g2._crypto_box_curve25519xsalsa20poly1305_keypair = A6.kb, g2._crypto_box_curve25519xsalsa20poly1305_beforenm = A6.lb, g2._crypto_box_curve25519xsalsa20poly1305_afternm = A6.mb, g2._crypto_box_curve25519xsalsa20poly1305_open_afternm = A6.nb, g2._crypto_box_curve25519xsalsa20poly1305 = A6.ob, g2._crypto_box_curve25519xsalsa20poly1305_open = A6.pb, g2._crypto_box_curve25519xsalsa20poly1305_seedbytes = A6.qb, g2._crypto_box_curve25519xsalsa20poly1305_publickeybytes = A6.rb, g2._crypto_box_curve25519xsalsa20poly1305_secretkeybytes = A6.sb, g2._crypto_box_curve25519xsalsa20poly1305_beforenmbytes = A6.tb, g2._crypto_box_curve25519xsalsa20poly1305_noncebytes = A6.ub, g2._crypto_box_curve25519xsalsa20poly1305_zerobytes = A6.vb, g2._crypto_box_curve25519xsalsa20poly1305_boxzerobytes = A6.wb, g2._crypto_box_curve25519xsalsa20poly1305_macbytes = A6.xb, g2._crypto_box_curve25519xsalsa20poly1305_messagebytes_max = A6.yb, g2._crypto_core_hchacha20 = A6.zb, g2._crypto_core_hchacha20_outputbytes = A6.Ab, g2._crypto_core_hchacha20_inputbytes = A6.Bb, g2._crypto_core_hchacha20_keybytes = A6.Cb, g2._crypto_core_hchacha20_constbytes = A6.Db, g2._crypto_core_hsalsa20 = A6.Eb, g2._crypto_core_hsalsa20_outputbytes = A6.Fb, g2._crypto_core_hsalsa20_inputbytes = A6.Gb, g2._crypto_core_hsalsa20_keybytes = A6.Hb, g2._crypto_core_hsalsa20_constbytes = A6.Ib, g2._crypto_core_keccak1600_statebytes = A6.Jb, g2._crypto_core_keccak1600_init = A6.Kb, g2._crypto_core_keccak1600_xor_bytes = A6.Lb, g2._crypto_core_keccak1600_extract_bytes = A6.Mb, g2._crypto_core_keccak1600_permute_24 = A6.Nb, g2._crypto_core_keccak1600_permute_12 = A6.Ob, g2._crypto_core_salsa20 = A6.Pb, g2._crypto_core_salsa20_outputbytes = A6.Qb, g2._crypto_core_salsa20_inputbytes = A6.Rb, g2._crypto_core_salsa20_keybytes = A6.Sb, g2._crypto_core_salsa20_constbytes = A6.Tb, g2._crypto_core_salsa2012 = A6.Ub, g2._crypto_core_salsa2012_outputbytes = A6.Vb, g2._crypto_core_salsa2012_inputbytes = A6.Wb, g2._crypto_core_salsa2012_keybytes = A6.Xb, g2._crypto_core_salsa2012_constbytes = A6.Yb, g2._crypto_core_salsa208 = A6.Zb, g2._crypto_core_salsa208_outputbytes = A6._b, g2._crypto_core_salsa208_inputbytes = A6.$b, g2._crypto_core_salsa208_keybytes = A6.ac, g2._crypto_core_salsa208_constbytes = A6.bc, g2._crypto_generichash_bytes_min = A6.cc, g2._crypto_generichash_bytes_max = A6.dc, g2._crypto_generichash_bytes = A6.ec, g2._crypto_generichash_keybytes_min = A6.fc, g2._crypto_generichash_keybytes_max = A6.gc, g2._crypto_generichash_keybytes = A6.hc, g2._crypto_generichash_primitive = A6.ic, g2._crypto_generichash_statebytes = A6.jc, g2._crypto_generichash = A6.kc, g2._crypto_generichash_init = A6.lc, g2._crypto_generichash_update = A6.mc, g2._crypto_generichash_final = A6.nc, g2._crypto_generichash_keygen = A6.oc, g2._crypto_generichash_blake2b_bytes_min = A6.pc, g2._crypto_generichash_blake2b_bytes_max = A6.qc, g2._crypto_generichash_blake2b_bytes = A6.rc, g2._crypto_generichash_blake2b_keybytes_min = A6.sc, g2._crypto_generichash_blake2b_keybytes_max = A6.tc, g2._crypto_generichash_blake2b_keybytes = A6.uc, g2._crypto_generichash_blake2b_saltbytes = A6.vc, g2._crypto_generichash_blake2b_personalbytes = A6.wc, g2._crypto_generichash_blake2b_statebytes = A6.xc, g2._crypto_generichash_blake2b_keygen = A6.yc, g2._crypto_generichash_blake2b = A6.zc, g2._crypto_generichash_blake2b_salt_personal = A6.Ac, g2._crypto_generichash_blake2b_init = A6.Bc, g2._crypto_generichash_blake2b_init_salt_personal = A6.Cc, g2._crypto_generichash_blake2b_update = A6.Dc, g2._crypto_generichash_blake2b_final = A6.Ec, g2._crypto_hash_bytes = A6.Fc, g2._crypto_hash = A6.Gc, g2._crypto_hash_primitive = A6.Hc, g2._crypto_hash_sha256_bytes = A6.Ic, g2._crypto_hash_sha256_statebytes = A6.Jc, g2._crypto_hash_sha256_init = A6.Kc, g2._crypto_hash_sha256_update = A6.Lc, g2._crypto_hash_sha256_final = A6.Mc, g2._crypto_hash_sha256 = A6.Nc, g2._crypto_hash_sha512_bytes = A6.Oc, g2._crypto_hash_sha512_statebytes = A6.Pc, g2._crypto_hash_sha512_init = A6.Qc, g2._crypto_hash_sha512_update = A6.Rc, g2._crypto_hash_sha512_final = A6.Sc, g2._crypto_hash_sha512 = A6.Tc, g2._crypto_hash_sha3256_bytes = A6.Uc, g2._crypto_hash_sha3256_statebytes = A6.Vc, g2._crypto_hash_sha3256_init = A6.Wc, g2._crypto_hash_sha3256_update = A6.Xc, g2._crypto_hash_sha3256_final = A6.Yc, g2._crypto_hash_sha3256 = A6.Zc, g2._crypto_hash_sha3512_bytes = A6._c, g2._crypto_hash_sha3512_statebytes = A6.$c, g2._crypto_hash_sha3512_init = A6.ad, g2._crypto_hash_sha3512_update = A6.bd, g2._crypto_hash_sha3512_final = A6.cd, g2._crypto_hash_sha3512 = A6.dd, g2._crypto_ipcrypt_bytes = A6.ed, g2._crypto_ipcrypt_keybytes = A6.fd, g2._crypto_ipcrypt_nd_keybytes = A6.gd, g2._crypto_ipcrypt_nd_tweakbytes = A6.hd, g2._crypto_ipcrypt_nd_inputbytes = A6.id, g2._crypto_ipcrypt_nd_outputbytes = A6.jd, g2._crypto_ipcrypt_ndx_keybytes = A6.kd, g2._crypto_ipcrypt_ndx_tweakbytes = A6.ld, g2._crypto_ipcrypt_ndx_inputbytes = A6.md, g2._crypto_ipcrypt_ndx_outputbytes = A6.nd, g2._crypto_ipcrypt_pfx_keybytes = A6.od, g2._crypto_ipcrypt_pfx_bytes = A6.pd, g2._crypto_ipcrypt_keygen = A6.qd, g2._crypto_ipcrypt_nd_keygen = A6.rd, g2._crypto_ipcrypt_ndx_keygen = A6.sd, g2._crypto_ipcrypt_pfx_keygen = A6.td, g2._crypto_ipcrypt_encrypt = A6.ud, g2._crypto_ipcrypt_decrypt = A6.vd, g2._crypto_ipcrypt_nd_encrypt = A6.wd, g2._crypto_ipcrypt_nd_decrypt = A6.xd, g2._crypto_ipcrypt_ndx_encrypt = A6.yd, g2._crypto_ipcrypt_ndx_decrypt = A6.zd, g2._crypto_ipcrypt_pfx_encrypt = A6.Ad, g2._crypto_ipcrypt_pfx_decrypt = A6.Bd, g2._crypto_kdf_blake2b_bytes_min = A6.Cd, g2._crypto_kdf_blake2b_bytes_max = A6.Dd, g2._crypto_kdf_blake2b_contextbytes = A6.Ed, g2._crypto_kdf_blake2b_keybytes = A6.Fd, g2._crypto_kdf_blake2b_derive_from_key = A6.Gd, g2._crypto_kdf_primitive = A6.Hd, g2._crypto_kdf_bytes_min = A6.Id, g2._crypto_kdf_bytes_max = A6.Jd, g2._crypto_kdf_contextbytes = A6.Kd, g2._crypto_kdf_keybytes = A6.Ld, g2._crypto_kdf_derive_from_key = A6.Md, g2._crypto_kdf_keygen = A6.Nd, g2._crypto_kdf_hkdf_sha256_extract_init = A6.Od, g2._crypto_kdf_hkdf_sha256_extract_update = A6.Pd, g2._crypto_kdf_hkdf_sha256_extract_final = A6.Qd, g2._crypto_kdf_hkdf_sha256_extract = A6.Rd, g2._crypto_kdf_hkdf_sha256_keygen = A6.Sd, g2._crypto_kdf_hkdf_sha256_expand = A6.Td, g2._crypto_kdf_hkdf_sha256_keybytes = A6.Ud, g2._crypto_kdf_hkdf_sha256_bytes_min = A6.Vd, g2._crypto_kdf_hkdf_sha256_bytes_max = A6.Wd, g2._crypto_kdf_hkdf_sha256_statebytes = A6.Xd, g2._crypto_kdf_hkdf_sha512_extract_init = A6.Yd, g2._crypto_kdf_hkdf_sha512_extract_update = A6.Zd, g2._crypto_kdf_hkdf_sha512_extract_final = A6._d, g2._crypto_kdf_hkdf_sha512_extract = A6.$d, g2._crypto_kdf_hkdf_sha512_keygen = A6.ae, g2._crypto_kdf_hkdf_sha512_expand = A6.be, g2._crypto_kdf_hkdf_sha512_keybytes = A6.ce, g2._crypto_kdf_hkdf_sha512_bytes_min = A6.de, g2._crypto_kdf_hkdf_sha512_bytes_max = A6.ee, g2._crypto_kdf_hkdf_sha512_statebytes = A6.fe, g2._crypto_kem_publickeybytes = A6.ge, g2._crypto_kem_secretkeybytes = A6.he, g2._crypto_kem_ciphertextbytes = A6.ie, g2._crypto_kem_sharedsecretbytes = A6.je, g2._crypto_kem_seedbytes = A6.ke, g2._crypto_kem_primitive = A6.le, g2._crypto_kem_seed_keypair = A6.me, g2._crypto_kem_keypair = A6.ne, g2._crypto_kem_enc = A6.oe, g2._crypto_kem_dec = A6.pe, g2._crypto_kem_mlkem768_publickeybytes = A6.qe, g2._crypto_kem_mlkem768_secretkeybytes = A6.re, g2._crypto_kem_mlkem768_ciphertextbytes = A6.se, g2._crypto_kem_mlkem768_sharedsecretbytes = A6.te, g2._crypto_kem_mlkem768_seedbytes = A6.ue, g2._crypto_kem_mlkem768_seed_keypair = A6.ve, g2._crypto_kem_mlkem768_keypair = A6.we, g2._crypto_kem_mlkem768_enc = A6.xe, g2._crypto_kem_mlkem768_enc_deterministic = A6.ye, g2._crypto_kem_mlkem768_dec = A6.ze, g2._crypto_kem_xwing_publickeybytes = A6.Ae, g2._crypto_kem_xwing_secretkeybytes = A6.Be, g2._crypto_kem_xwing_ciphertextbytes = A6.Ce, g2._crypto_kem_xwing_sharedsecretbytes = A6.De, g2._crypto_kem_xwing_seedbytes = A6.Ee, g2._crypto_kem_xwing_seed_keypair = A6.Fe, g2._crypto_kem_xwing_keypair = A6.Ge, g2._crypto_kem_xwing_enc_deterministic = A6.He, g2._crypto_kem_xwing_enc = A6.Ie, g2._crypto_kem_xwing_dec = A6.Je, g2._crypto_kx_seed_keypair = A6.Ke, g2._crypto_kx_keypair = A6.Le, g2._crypto_kx_client_session_keys = A6.Me, g2._crypto_kx_server_session_keys = A6.Ne, g2._crypto_kx_publickeybytes = A6.Oe, g2._crypto_kx_secretkeybytes = A6.Pe, g2._crypto_kx_seedbytes = A6.Qe, g2._crypto_kx_sessionkeybytes = A6.Re, g2._crypto_kx_primitive = A6.Se, g2._crypto_onetimeauth_statebytes = A6.Te, g2._crypto_onetimeauth_bytes = A6.Ue, g2._crypto_onetimeauth_keybytes = A6.Ve, g2._crypto_onetimeauth = A6.We, g2._crypto_onetimeauth_verify = A6.Xe, g2._crypto_onetimeauth_init = A6.Ye, g2._crypto_onetimeauth_update = A6.Ze, g2._crypto_onetimeauth_final = A6._e, g2._crypto_onetimeauth_primitive = A6.$e, g2._crypto_onetimeauth_keygen = A6.af, g2._crypto_onetimeauth_poly1305 = A6.bf, g2._crypto_onetimeauth_poly1305_verify = A6.cf, g2._crypto_onetimeauth_poly1305_init = A6.df, g2._crypto_onetimeauth_poly1305_update = A6.ef, g2._crypto_onetimeauth_poly1305_final = A6.ff, g2._crypto_onetimeauth_poly1305_bytes = A6.gf, g2._crypto_onetimeauth_poly1305_keybytes = A6.hf, g2._crypto_onetimeauth_poly1305_statebytes = A6.jf, g2._crypto_onetimeauth_poly1305_keygen = A6.kf, g2._crypto_pwhash_argon2i_alg_argon2i13 = A6.lf, g2._crypto_pwhash_argon2i_bytes_min = A6.mf, g2._crypto_pwhash_argon2i_bytes_max = A6.nf, g2._crypto_pwhash_argon2i_passwd_min = A6.of, g2._crypto_pwhash_argon2i_passwd_max = A6.pf, g2._crypto_pwhash_argon2i_saltbytes = A6.qf, g2._crypto_pwhash_argon2i_strbytes = A6.rf, g2._crypto_pwhash_argon2i_strprefix = A6.sf, g2._crypto_pwhash_argon2i_opslimit_min = A6.tf, g2._crypto_pwhash_argon2i_opslimit_max = A6.uf, g2._crypto_pwhash_argon2i_memlimit_min = A6.vf, g2._crypto_pwhash_argon2i_memlimit_max = A6.wf, g2._crypto_pwhash_argon2i_opslimit_interactive = A6.xf, g2._crypto_pwhash_argon2i_memlimit_interactive = A6.yf, g2._crypto_pwhash_argon2i_opslimit_moderate = A6.zf, g2._crypto_pwhash_argon2i_memlimit_moderate = A6.Af, g2._crypto_pwhash_argon2i_opslimit_sensitive = A6.Bf, g2._crypto_pwhash_argon2i_memlimit_sensitive = A6.Cf, g2._crypto_pwhash_argon2i = A6.Df, g2._crypto_pwhash_argon2i_str = A6.Ef, g2._crypto_pwhash_argon2i_str_verify = A6.Ff, g2._crypto_pwhash_argon2i_str_needs_rehash = A6.Gf, g2._crypto_pwhash_argon2id_str_needs_rehash = A6.Hf, g2._crypto_pwhash_argon2id_alg_argon2id13 = A6.If, g2._crypto_pwhash_argon2id_bytes_min = A6.Jf, g2._crypto_pwhash_argon2id_bytes_max = A6.Kf, g2._crypto_pwhash_argon2id_passwd_min = A6.Lf, g2._crypto_pwhash_argon2id_passwd_max = A6.Mf, g2._crypto_pwhash_argon2id_saltbytes = A6.Nf, g2._crypto_pwhash_argon2id_strbytes = A6.Of, g2._crypto_pwhash_argon2id_strprefix = A6.Pf, g2._crypto_pwhash_argon2id_opslimit_min = A6.Qf, g2._crypto_pwhash_argon2id_opslimit_max = A6.Rf, g2._crypto_pwhash_argon2id_memlimit_min = A6.Sf, g2._crypto_pwhash_argon2id_memlimit_max = A6.Tf, g2._crypto_pwhash_argon2id_opslimit_interactive = A6.Uf, g2._crypto_pwhash_argon2id_memlimit_interactive = A6.Vf, g2._crypto_pwhash_argon2id_opslimit_moderate = A6.Wf, g2._crypto_pwhash_argon2id_memlimit_moderate = A6.Xf, g2._crypto_pwhash_argon2id_opslimit_sensitive = A6.Yf, g2._crypto_pwhash_argon2id_memlimit_sensitive = A6.Zf, g2._crypto_pwhash_argon2id = A6._f, g2._crypto_pwhash_argon2id_str = A6.$f, g2._crypto_pwhash_argon2id_str_verify = A6.ag, g2._crypto_pwhash_alg_argon2i13 = A6.bg, g2._crypto_pwhash_alg_argon2id13 = A6.cg, g2._crypto_pwhash_alg_default = A6.dg, g2._crypto_pwhash_bytes_min = A6.eg, g2._crypto_pwhash_bytes_max = A6.fg, g2._crypto_pwhash_passwd_min = A6.gg, g2._crypto_pwhash_passwd_max = A6.hg, g2._crypto_pwhash_saltbytes = A6.ig, g2._crypto_pwhash_strbytes = A6.jg, g2._crypto_pwhash_strprefix = A6.kg, g2._crypto_pwhash_opslimit_min = A6.lg, g2._crypto_pwhash_opslimit_max = A6.mg, g2._crypto_pwhash_memlimit_min = A6.ng, g2._crypto_pwhash_memlimit_max = A6.og, g2._crypto_pwhash_opslimit_interactive = A6.pg, g2._crypto_pwhash_memlimit_interactive = A6.qg, g2._crypto_pwhash_opslimit_moderate = A6.rg, g2._crypto_pwhash_memlimit_moderate = A6.sg, g2._crypto_pwhash_opslimit_sensitive = A6.tg, g2._crypto_pwhash_memlimit_sensitive = A6.ug, g2._crypto_pwhash = A6.vg, g2._crypto_pwhash_str = A6.wg, g2._crypto_pwhash_str_alg = A6.xg, g2._crypto_pwhash_str_verify = A6.yg, g2._crypto_pwhash_str_needs_rehash = A6.zg, g2._crypto_pwhash_primitive = A6.Ag, g2._crypto_scalarmult_primitive = A6.Bg, g2._crypto_scalarmult_base = A6.Cg, g2._crypto_scalarmult = A6.Dg, g2._crypto_scalarmult_bytes = A6.Eg, g2._crypto_scalarmult_scalarbytes = A6.Fg, g2._crypto_scalarmult_curve25519 = A6.Gg, g2._crypto_scalarmult_curve25519_base = A6.Hg, g2._crypto_scalarmult_curve25519_bytes = A6.Ig, g2._crypto_scalarmult_curve25519_scalarbytes = A6.Jg, g2._crypto_secretbox_keybytes = A6.Kg, g2._crypto_secretbox_noncebytes = A6.Lg, g2._crypto_secretbox_zerobytes = A6.Mg, g2._crypto_secretbox_boxzerobytes = A6.Ng, g2._crypto_secretbox_macbytes = A6.Og, g2._crypto_secretbox_messagebytes_max = A6.Pg, g2._crypto_secretbox_primitive = A6.Qg, g2._crypto_secretbox = A6.Rg, g2._crypto_secretbox_open = A6.Sg, g2._crypto_secretbox_keygen = A6.Tg, g2._crypto_secretbox_detached = A6.Ug, g2._crypto_secretbox_easy = A6.Vg, g2._crypto_secretbox_open_detached = A6.Wg, g2._crypto_secretbox_open_easy = A6.Xg, g2._crypto_secretbox_xsalsa20poly1305 = A6.Yg, g2._crypto_secretbox_xsalsa20poly1305_open = A6.Zg, g2._crypto_secretbox_xsalsa20poly1305_keybytes = A6._g, g2._crypto_secretbox_xsalsa20poly1305_noncebytes = A6.$g, g2._crypto_secretbox_xsalsa20poly1305_zerobytes = A6.ah, g2._crypto_secretbox_xsalsa20poly1305_boxzerobytes = A6.bh, g2._crypto_secretbox_xsalsa20poly1305_macbytes = A6.ch, g2._crypto_secretbox_xsalsa20poly1305_messagebytes_max = A6.dh, g2._crypto_secretbox_xsalsa20poly1305_keygen = A6.eh, g2._crypto_secretstream_xchacha20poly1305_keygen = A6.fh, g2._crypto_secretstream_xchacha20poly1305_init_push = A6.gh, g2._crypto_secretstream_xchacha20poly1305_init_pull = A6.hh, g2._crypto_secretstream_xchacha20poly1305_rekey = A6.ih, g2._crypto_secretstream_xchacha20poly1305_push = A6.jh, g2._crypto_secretstream_xchacha20poly1305_pull = A6.kh, g2._crypto_secretstream_xchacha20poly1305_statebytes = A6.lh, g2._crypto_secretstream_xchacha20poly1305_abytes = A6.mh, g2._crypto_secretstream_xchacha20poly1305_headerbytes = A6.nh, g2._crypto_secretstream_xchacha20poly1305_keybytes = A6.oh, g2._crypto_secretstream_xchacha20poly1305_messagebytes_max = A6.ph, g2._crypto_secretstream_xchacha20poly1305_tag_message = A6.qh, g2._crypto_secretstream_xchacha20poly1305_tag_push = A6.rh, g2._crypto_secretstream_xchacha20poly1305_tag_rekey = A6.sh, g2._crypto_secretstream_xchacha20poly1305_tag_final = A6.th, g2._crypto_shorthash_bytes = A6.uh, g2._crypto_shorthash_keybytes = A6.vh, g2._crypto_shorthash_primitive = A6.wh, g2._crypto_shorthash = A6.xh, g2._crypto_shorthash_keygen = A6.yh, g2._crypto_shorthash_siphash24_bytes = A6.zh, g2._crypto_shorthash_siphash24_keybytes = A6.Ah, g2._crypto_shorthash_siphash24 = A6.Bh, g2._crypto_sign_statebytes = A6.Ch, g2._crypto_sign_bytes = A6.Dh, g2._crypto_sign_seedbytes = A6.Eh, g2._crypto_sign_publickeybytes = A6.Fh, g2._crypto_sign_secretkeybytes = A6.Gh, g2._crypto_sign_messagebytes_max = A6.Hh, g2._crypto_sign_primitive = A6.Ih, g2._crypto_sign_seed_keypair = A6.Jh, g2._crypto_sign_keypair = A6.Kh, g2._crypto_sign = A6.Lh, g2._crypto_sign_open = A6.Mh, g2._crypto_sign_detached = A6.Nh, g2._crypto_sign_verify_detached = A6.Oh, g2._crypto_sign_init = A6.Ph, g2._crypto_sign_update = A6.Qh, g2._crypto_sign_final_create = A6.Rh, g2._crypto_sign_final_verify = A6.Sh, g2._crypto_sign_ed25519ph_statebytes = A6.Th, g2._crypto_sign_ed25519_bytes = A6.Uh, g2._crypto_sign_ed25519_seedbytes = A6.Vh, g2._crypto_sign_ed25519_publickeybytes = A6.Wh, g2._crypto_sign_ed25519_secretkeybytes = A6.Xh, g2._crypto_sign_ed25519_messagebytes_max = A6.Yh, g2._crypto_sign_ed25519_sk_to_seed = A6.Zh, g2._crypto_sign_ed25519_sk_to_pk = A6._h, g2._crypto_sign_ed25519ph_init = A6.$h, g2._crypto_sign_ed25519ph_update = A6.ai, g2._crypto_sign_ed25519ph_final_create = A6.bi, g2._crypto_sign_ed25519ph_final_verify = A6.ci, g2._crypto_sign_ed25519_seed_keypair = A6.di, g2._crypto_sign_ed25519_keypair = A6.ei, g2._crypto_sign_ed25519_pk_to_curve25519 = A6.fi, g2._crypto_sign_ed25519_sk_to_curve25519 = A6.gi, g2._crypto_sign_ed25519_verify_detached = A6.hi, g2._crypto_sign_ed25519_open = A6.ii, g2._crypto_sign_ed25519_detached = A6.ji, g2._crypto_sign_ed25519 = A6.ki, g2._crypto_stream_chacha20_keybytes = A6.li, g2._crypto_stream_chacha20_noncebytes = A6.mi, g2._crypto_stream_chacha20_messagebytes_max = A6.ni, g2._crypto_stream_chacha20_ietf_keybytes = A6.oi, g2._crypto_stream_chacha20_ietf_noncebytes = A6.pi, g2._crypto_stream_chacha20_ietf_messagebytes_max = A6.qi, g2._crypto_stream_chacha20 = A6.ri, g2._crypto_stream_chacha20_xor_ic = A6.si, g2._crypto_stream_chacha20_xor = A6.ti, g2._crypto_stream_chacha20_ietf = A6.ui, g2._crypto_stream_chacha20_ietf_xor_ic = A6.vi, g2._crypto_stream_chacha20_ietf_xor = A6.wi, g2._crypto_stream_chacha20_ietf_keygen = A6.xi, g2._crypto_stream_chacha20_keygen = A6.yi, g2._crypto_stream_keybytes = A6.zi, g2._crypto_stream_noncebytes = A6.Ai, g2._crypto_stream_messagebytes_max = A6.Bi, g2._crypto_stream_primitive = A6.Ci, g2._crypto_stream = A6.Di, g2._crypto_stream_xor = A6.Ei, g2._crypto_stream_keygen = A6.Fi, g2._crypto_stream_salsa20_keybytes = A6.Gi, g2._crypto_stream_salsa20_noncebytes = A6.Hi, g2._crypto_stream_salsa20_messagebytes_max = A6.Ii, g2._crypto_stream_salsa20 = A6.Ji, g2._crypto_stream_salsa20_xor_ic = A6.Ki, g2._crypto_stream_salsa20_xor = A6.Li, g2._crypto_stream_salsa20_keygen = A6.Mi, g2._crypto_stream_xsalsa20 = A6.Ni, g2._crypto_stream_xsalsa20_xor_ic = A6.Oi, g2._crypto_stream_xsalsa20_xor = A6.Pi, g2._crypto_stream_xsalsa20_keybytes = A6.Qi, g2._crypto_stream_xsalsa20_noncebytes = A6.Ri, g2._crypto_stream_xsalsa20_messagebytes_max = A6.Si, g2._crypto_stream_xsalsa20_keygen = A6.Ti, g2._crypto_verify_16_bytes = A6.Ui, g2._crypto_verify_32_bytes = A6.Vi, g2._crypto_verify_64_bytes = A6.Wi, g2._crypto_verify_16 = A6.Xi, g2._crypto_verify_32 = A6.Yi, g2._crypto_verify_64 = A6.Zi, g2._crypto_xof_shake128_blockbytes = A6._i, g2._crypto_xof_shake128_statebytes = A6.$i, g2._crypto_xof_shake128_domain_standard = A6.aj, g2._crypto_xof_shake128 = A6.bj, g2._crypto_xof_shake128_init = A6.cj, g2._crypto_xof_shake128_init_with_domain = A6.dj, g2._crypto_xof_shake128_update = A6.ej, g2._crypto_xof_shake128_squeeze = A6.fj, g2._crypto_xof_shake256_blockbytes = A6.gj, g2._crypto_xof_shake256_statebytes = A6.hj, g2._crypto_xof_shake256_domain_standard = A6.ij, g2._crypto_xof_shake256 = A6.jj, g2._crypto_xof_shake256_init = A6.kj, g2._crypto_xof_shake256_init_with_domain = A6.lj, g2._crypto_xof_shake256_update = A6.mj, g2._crypto_xof_shake256_squeeze = A6.nj, g2._crypto_xof_turboshake128_blockbytes = A6.oj, g2._crypto_xof_turboshake128_statebytes = A6.pj, g2._crypto_xof_turboshake128_domain_standard = A6.qj, g2._crypto_xof_turboshake128 = A6.rj, g2._crypto_xof_turboshake128_init = A6.sj, g2._crypto_xof_turboshake128_init_with_domain = A6.tj, g2._crypto_xof_turboshake128_update = A6.uj, g2._crypto_xof_turboshake128_squeeze = A6.vj, g2._crypto_xof_turboshake256_blockbytes = A6.wj, g2._crypto_xof_turboshake256_statebytes = A6.xj, g2._crypto_xof_turboshake256_domain_standard = A6.yj, g2._crypto_xof_turboshake256 = A6.zj, g2._crypto_xof_turboshake256_init = A6.Aj, g2._crypto_xof_turboshake256_init_with_domain = A6.Bj, g2._crypto_xof_turboshake256_update = A6.Cj, g2._crypto_xof_turboshake256_squeeze = A6.Dj, g2._randombytes_implementation_name = A6.Ej, g2._randombytes_random = A6.Fj, g2._randombytes_stir = A6.Gj, g2._randombytes_uniform = A6.Hj, g2._randombytes_buf = A6.Ij, g2._randombytes_buf_deterministic = A6.Jj, g2._randombytes_seedbytes = A6.Kj, g2._randombytes_close = A6.Lj, g2._randombytes = A6.Mj, g2._sodium_bin2hex = A6.Nj, g2._sodium_hex2bin = A6.Oj, g2._sodium_base64_encoded_len = A6.Pj, g2._sodium_bin2base64 = A6.Qj, g2._sodium_base642bin = A6.Rj, g2._sodium_ip2bin = A6.Sj, g2._sodium_bin2ip = A6.Tj, g2._sodium_init = A6.Uj, g2._sodium_pad = A6.Vj, g2._sodium_unpad = A6.Wj, g2._sodium_version_string = A6.Xj, g2._sodium_library_version_major = A6.Yj, g2._sodium_library_version_minor = A6.Zj, g2._sodium_library_minimal = A6._j, g2._crypto_box_curve25519xchacha20poly1305_seed_keypair = A6.$j, g2._crypto_box_curve25519xchacha20poly1305_keypair = A6.ak, g2._crypto_box_curve25519xchacha20poly1305_beforenm = A6.bk, g2._crypto_box_curve25519xchacha20poly1305_detached_afternm = A6.ck, g2._crypto_box_curve25519xchacha20poly1305_detached = A6.dk, g2._crypto_box_curve25519xchacha20poly1305_easy_afternm = A6.ek, g2._crypto_box_curve25519xchacha20poly1305_easy = A6.fk, g2._crypto_box_curve25519xchacha20poly1305_open_detached_afternm = A6.gk, g2._crypto_box_curve25519xchacha20poly1305_open_detached = A6.hk, g2._crypto_box_curve25519xchacha20poly1305_open_easy_afternm = A6.ik, g2._crypto_box_curve25519xchacha20poly1305_open_easy = A6.jk, g2._crypto_box_curve25519xchacha20poly1305_seedbytes = A6.kk, g2._crypto_box_curve25519xchacha20poly1305_publickeybytes = A6.lk, g2._crypto_box_curve25519xchacha20poly1305_secretkeybytes = A6.mk, g2._crypto_box_curve25519xchacha20poly1305_beforenmbytes = A6.nk, g2._crypto_box_curve25519xchacha20poly1305_noncebytes = A6.ok, g2._crypto_box_curve25519xchacha20poly1305_macbytes = A6.pk, g2._crypto_box_curve25519xchacha20poly1305_messagebytes_max = A6.qk, g2._crypto_box_curve25519xchacha20poly1305_seal = A6.rk, g2._crypto_box_curve25519xchacha20poly1305_seal_open = A6.sk, g2._crypto_box_curve25519xchacha20poly1305_sealbytes = A6.tk, g2._crypto_core_ed25519_is_valid_point = A6.uk, g2._crypto_core_ed25519_add = A6.vk, g2._crypto_core_ed25519_sub = A6.wk, g2._crypto_core_ed25519_from_uniform = A6.xk, g2._crypto_core_ed25519_from_hash = A6.yk, g2._crypto_core_ed25519_random = A6.zk, g2._crypto_core_ed25519_scalar_random = A6.Ak, g2._crypto_core_ed25519_scalar_invert = A6.Bk, g2._crypto_core_ed25519_scalar_negate = A6.Ck, g2._crypto_core_ed25519_scalar_complement = A6.Dk, g2._crypto_core_ed25519_scalar_add = A6.Ek, g2._crypto_core_ed25519_scalar_reduce = A6.Fk, g2._crypto_core_ed25519_scalar_sub = A6.Gk, g2._crypto_core_ed25519_scalar_mul = A6.Hk, g2._crypto_core_ed25519_bytes = A6.Ik, g2._crypto_core_ed25519_nonreducedscalarbytes = A6.Jk, g2._crypto_core_ed25519_uniformbytes = A6.Kk, g2._crypto_core_ed25519_hashbytes = A6.Lk, g2._crypto_core_ed25519_scalarbytes = A6.Mk, g2._crypto_core_ristretto255_is_valid_point = A6.Nk, g2._crypto_core_ristretto255_add = A6.Ok, g2._crypto_core_ristretto255_sub = A6.Pk, g2._crypto_core_ristretto255_from_hash = A6.Qk, g2._crypto_core_ristretto255_random = A6.Rk, g2._crypto_core_ristretto255_scalar_random = A6.Sk, g2._crypto_core_ristretto255_scalar_invert = A6.Tk, g2._crypto_core_ristretto255_scalar_negate = A6.Uk, g2._crypto_core_ristretto255_scalar_complement = A6.Vk, g2._crypto_core_ristretto255_scalar_add = A6.Wk, g2._crypto_core_ristretto255_scalar_sub = A6.Xk, g2._crypto_core_ristretto255_scalar_mul = A6.Yk, g2._crypto_core_ristretto255_scalar_reduce = A6.Zk, g2._crypto_core_ristretto255_bytes = A6._k, g2._crypto_core_ristretto255_nonreducedscalarbytes = A6.$k, g2._crypto_core_ristretto255_hashbytes = A6.al, g2._crypto_core_ristretto255_scalarbytes = A6.bl, g2._crypto_pwhash_scryptsalsa208sha256_ll = A6.cl, g2._crypto_pwhash_scryptsalsa208sha256_bytes_min = A6.dl, g2._crypto_pwhash_scryptsalsa208sha256_bytes_max = A6.el, g2._crypto_pwhash_scryptsalsa208sha256_passwd_min = A6.fl, g2._crypto_pwhash_scryptsalsa208sha256_passwd_max = A6.gl, g2._crypto_pwhash_scryptsalsa208sha256_saltbytes = A6.hl, g2._crypto_pwhash_scryptsalsa208sha256_strbytes = A6.il, g2._crypto_pwhash_scryptsalsa208sha256_strprefix = A6.jl, g2._crypto_pwhash_scryptsalsa208sha256_opslimit_min = A6.kl, g2._crypto_pwhash_scryptsalsa208sha256_opslimit_max = A6.ll, g2._crypto_pwhash_scryptsalsa208sha256_memlimit_min = A6.ml, g2._crypto_pwhash_scryptsalsa208sha256_memlimit_max = A6.nl, g2._crypto_pwhash_scryptsalsa208sha256_opslimit_interactive = A6.ol, g2._crypto_pwhash_scryptsalsa208sha256_memlimit_interactive = A6.pl, g2._crypto_pwhash_scryptsalsa208sha256_opslimit_sensitive = A6.ql, g2._crypto_pwhash_scryptsalsa208sha256_memlimit_sensitive = A6.rl, g2._crypto_pwhash_scryptsalsa208sha256 = A6.sl, g2._crypto_pwhash_scryptsalsa208sha256_str = A6.tl, g2._crypto_pwhash_scryptsalsa208sha256_str_verify = A6.ul, g2._crypto_pwhash_scryptsalsa208sha256_str_needs_rehash = A6.vl, g2._crypto_scalarmult_ed25519 = A6.wl, g2._crypto_scalarmult_ed25519_noclamp = A6.xl, g2._crypto_scalarmult_ed25519_base = A6.yl, g2._crypto_scalarmult_ed25519_base_noclamp = A6.zl, g2._crypto_scalarmult_ed25519_bytes = A6.Al, g2._crypto_scalarmult_ed25519_scalarbytes = A6.Bl, g2._crypto_scalarmult_ristretto255 = A6.Cl, g2._crypto_scalarmult_ristretto255_base = A6.Dl, g2._crypto_scalarmult_ristretto255_bytes = A6.El, g2._crypto_scalarmult_ristretto255_scalarbytes = A6.Fl, g2._crypto_secretbox_xchacha20poly1305_detached = A6.Gl, g2._crypto_secretbox_xchacha20poly1305_easy = A6.Hl, g2._crypto_secretbox_xchacha20poly1305_open_detached = A6.Il, g2._crypto_secretbox_xchacha20poly1305_open_easy = A6.Jl, g2._crypto_secretbox_xchacha20poly1305_keybytes = A6.Kl, g2._crypto_secretbox_xchacha20poly1305_noncebytes = A6.Ll, g2._crypto_secretbox_xchacha20poly1305_macbytes = A6.Ml, g2._crypto_secretbox_xchacha20poly1305_messagebytes_max = A6.Nl, g2._crypto_shorthash_siphashx24_bytes = A6.Ol, g2._crypto_shorthash_siphashx24_keybytes = A6.Pl, g2._crypto_shorthash_siphashx24 = A6.Ql, g2._crypto_sign_edwards25519sha512batch_keypair = A6.Rl, g2._crypto_sign_edwards25519sha512batch = A6.Sl, g2._crypto_sign_edwards25519sha512batch_open = A6.Tl, g2._crypto_stream_salsa2012 = A6.Ul, g2._crypto_stream_salsa2012_xor = A6.Vl, g2._crypto_stream_salsa2012_keybytes = A6.Wl, g2._crypto_stream_salsa2012_noncebytes = A6.Xl, g2._crypto_stream_salsa2012_messagebytes_max = A6.Yl, g2._crypto_stream_salsa2012_keygen = A6.Zl, g2._crypto_stream_salsa208 = A6._l, g2._crypto_stream_salsa208_xor = A6.$l, g2._crypto_stream_salsa208_keybytes = A6.am, g2._crypto_stream_salsa208_noncebytes = A6.bm, g2._crypto_stream_salsa208_messagebytes_max = A6.cm, g2._crypto_stream_salsa208_keygen = A6.dm, g2._crypto_stream_xchacha20_keybytes = A6.em, g2._crypto_stream_xchacha20_noncebytes = A6.fm, g2._crypto_stream_xchacha20_messagebytes_max = A6.gm, g2._crypto_stream_xchacha20 = A6.hm, g2._crypto_stream_xchacha20_xor_ic = A6.im, g2._crypto_stream_xchacha20_xor = A6.jm, g2._crypto_stream_xchacha20_keygen = A6.km, g2._malloc = A6.lm, g2._free = A6.mm, A6.dynCall_iiiji, A6.dynCall_iiij, A6.dynCall_iijii, A6.dynCall_iiijiji, A6.dynCall_iiijiii, e = A6.e, A6.__indirect_function_table;
      })(_2 = A5.exports), N2(), _2;
    }
    var C3 = { a: q2 };
    return g2.instantiateWasm ? new Promise((I3, B3) => {
      g2.instantiateWasm(C3, (g3, C4) => {
        I3(A4(g3));
      });
    }) : (o2 ??= ((A5) => {
      for (var I3, g3, C4 = 0, B3 = 0, Q3 = 379996, E3 = new Uint8Array(284997 - ("=" == A5[379994]) - ("=" == A5[379995])); C4 < Q3; C4 += 4, B3 += 3) I3 = R2[A5.charCodeAt(C4 + 1)], g3 = R2[A5.charCodeAt(C4 + 2)], E3[B3] = R2[A5.charCodeAt(C4)] << 2 | I3 >> 4, E3[B3 + 1] = I3 << 4 | g3 >> 2, E3[B3 + 2] = g3 << 6 | R2[A5.charCodeAt(C4 + 3)];
      return E3;
    })("AGFzbQEAAAAB9gIpYAJ/fwF/YAABf2ADf39+AX9gA39/fwF/YAN/f38AYAR/f39/AX9gAn9/AGAFf39/f38Bf2AGf39/f39/AX9gAX8Bf2ABfwBgC39/f39/f39/f39/AX9gB39/f39/f38Bf2AEf39/fwBgBn9/fn9+fwF/YAl/f39/f39/f38Bf2AEf35/fwF/YAZ/f35/f38Bf2AEf39+fwF/YAh/f39/f39/fwF/YAAAYAV/f35/fwF/YAZ/f39+f38Bf2AMf39/f39/f39/f39/AX9gCn9/f39/f39/f38Bf2AIf39+f39+f38Bf2AJf39/f35/fn9/AX9gBX9/f35/AX9gA39/fgBgBX9/fn5/AX9gCH9+f35/fn9/AX9gBX9/fn5/AGAEf39/fgF/YAR/f39+AGAFf39/f38AYAV+f39/fwBgCX9/f39+f39/fwF/YAp/f39/f35/f39/AX9gBn9/f39/fwBgCH9/f35/f39/AX9gBX9/fn9/AAIZBAFhAWEADQFhAWIAAwFhAWMAFAFhAWQACQOoBKYEBgQEBgQBAQkUAgYGBAoEAgEEBgoNAQoABgYABQMBBgkECgoJAQECAwICBQIGAwkEBAYFAQADFAMBAwMAAhAECQAGAAARDgADAAADAAkBBQUFBgkWFgoDAAEBBhAEBgAICAANCRABABYWBgoCAgIACSABAw0JARYNFRUhCgYKIgMJCQQEBgUcIwYcFQMBAQEBABMHCRUWBAYFDQIDAQYEAAYGBAYJDRQEBAYGCAwMCAcHCAgIBwAMBQcHCAUFBQwIDAwMDAUHBwAAGRoDEREEAwUBJAcKJSYVFQEBGRkaGgAAAxADERECHR4BAQECHR4BBQwDAwMFCQEGAwMFAAMBAQMNBAEAAQEnBAQGBAYGAAoDFCgBBB8EBgQBBgQfBAYECg4QAAMIEwcIBwgHCAgHCAUFDBgYCAcMEwwIEwQFBwUHBQcFBxMIEwcIDAcIEwcYGAgFBRMLBQsFBQUMCwUFBQUPCAcMEwwIEwcHBwcFCwsLFwsLCwsLFwsXCwsXCwsLFwsBAQEBBwcDAwEBAwEBEgASAAADAQMDAAMBAgESFQQEBA0EAA0EBAQEBA0EDRIEBAAAAwMBAQEBAwADAREREgMFAwUJAAMBAAABAwMAAQEBAQEDAwAMBQAAGxsbAwUDAAMBAQEDCQkDCg0KAQEHBwgAAwMBAQEKAwMGBAQGBgAKCgADAwkKAAADAwkBBwoHAAMBBAkBBQEBFAYBBxEOEBABDw8PDwQEAXAAHgUGAQFAgIACBggBfwFBgMkGCweWHsYFAWUCAAFmAAoBZwAhAWgACgFpAAkBagCdAgFrAH8BbACFAwFtAIQDAW4AgwMBbwCCAwFwAAkBcQAhAXIACQFzAAkBdACdAgF1ABEBdgCBAwF3AIADAXgA/wIBeQD+AgF6ACEBQQD9AgFCAPwCAUMA+wIBRAD6AgFFAPkCAUYA+AIBRwD3AgFIAPYCAUkACQFKAJcCAUsAIQFMAAoBTQA3AU4AEQFPAAkBUAApAVEAIQFSAAoBUwA3AVQAEQFVAPUCAVYA9AIBVwDzAgFYAPICAVkACQFaACgBXwAhASQACgJhYQA3AmJhABECY2EACQJkYQAJAmVhAI8DAmZhAMoBAmdhAMkBAmhhABECaWEACQJqYQAJAmthAFwCbGEAEQJtYQA+Am5hAPECAm9hAE8CcGEA8AICcWEA7wICcmEAFAJzYQAJAnRhAKABAnVhABECdmEAOQJ3YQDIAQJ4YQA/AnlhAO4CAnphAO0CAkFhAAkCQmEACQJDYQCgAQJEYQARAkVhAJQCAkZhAMgBAkdhAJYDAkhhAMoBAklhAMkBAkphAAkCS2EACQJMYQAJAk1hAAkCTmEAKAJPYQAJAlBhAAoCUWEACgJSYQA3AlNhAMADAlRhAL8DAlVhAL4DAlZhAL0DAldhAGQCWGEAYwJZYQDHAQJaYQDGAQJfYQDFAQIkYQDsAgJhYgDrAgJiYgDqAgJjYgDEAQJkYgDpAgJlYgDDAQJmYgDoAgJnYgDnAgJoYgDmAgJpYgDdAQJqYgCPAQJrYgBMAmxiAEsCbWIAZAJuYgBjAm9iAMcBAnBiAMYBAnFiAAkCcmIACQJzYgAJAnRiAAkCdWIAKAJ2YgAJAndiAAoCeGIACgJ5YgA3AnpiAB8CQWIACQJCYgAKAkNiAAkCRGIACgJFYgA2AkZiAAkCR2IACgJIYgAJAkliAAoCSmIA8AMCS2IA7wMCTGIAGAJNYgDuAwJOYgDtAwJPYgAlAlBiAFQCUWIAFAJSYgAKAlNiAAkCVGIACgJVYgBTAlZiABQCV2IACgJYYgAJAlliAAoCWmIAUgJfYgAUAiRiAAoCYWMACQJiYwAKAmNjAAoCZGMAFAJlYwAJAmZjAAoCZ2MAFAJoYwAJAmljAN4BAmpjAIoCAmtjAMIBAmxjAMUDAm1jAMEBAm5jAMQDAm9jABECcGMACgJxYwAUAnJjAAkCc2MACgJ0YwAUAnVjAAkCdmMACgJ3YwAKAnhjAIoCAnljABECemMAwgECQWMA5QICQmMALgJDYwD0AwJEYwDBAQJFYwArAkZjABQCR2MAwAECSGMAkQMCSWMACQJKYwCGAwJLYwB4AkxjAOQCAk1jADgCTmMA4wICT2MAFAJQYwBcAlFjADICUmMAiQECU2MAHgJUYwDAAQJVYwAJAlZjADwCV2MA6wMCWGMAvwECWWMAiAICWmMA4gICX2MAFAIkYwA8AmFkAOoDAmJkAL8BAmNkAIgCAmRkAOECAmVkAAoCZmQACgJnZAAKAmhkACkCaWQACgJqZAAoAmtkAAkCbGQACgJtZAAKAm5kAAkCb2QACQJwZAAKAnFkAH8CcmQAfwJzZAARAnRkABECdWQAqwMCdmQAqgMCd2QAqQMCeGQApwMCeWQApgMCemQApQMCQWQApAMCQmQAowMCQ2QACgJEZAAUAkVkACkCRmQACQJHZAC+AQJIZADeAQJJZAAKAkpkABQCS2QAKQJMZAAJAk1kAL4BAk5kABECT2QA9wMCUGQA9gMCUWQA9QMCUmQA8wMCU2QAEQJUZADyAwJVZAAJAlZkACECV2QA8QMCWGQAXAJZZACUAgJaZACVBAJfZACUBAIkZACTBAJhZQCSBAJiZQCRBAJjZQAUAmRlACECZWUAkAQCZmUAoAECZ2UAgwICaGUACQJpZQCCAgJqZQAJAmtlAAkCbGUAngMCbWUAnQMCbmUAnAMCb2UAmwMCcGUAmgMCcWUA6AMCcmUA5wMCc2UA5gMCdGUACQJ1ZQAUAnZlAOUDAndlAOQDAnhlAOMDAnllAOIDAnplAOEDAkFlAIMCAkJlAAkCQ2UAggICRGUACQJFZQAJAkZlAIECAkdlAIACAkhlAP8BAkllAP4BAkplAP0BAktlAIwDAkxlAEwCTWUAiwMCTmUAigMCT2UACQJQZQAJAlFlAAkCUmUACQJTZQCJAwJUZQA8AlVlAAoCVmUACQJXZQC9AQJYZQC8AQJZZQDMAQJaZQC7AQJfZQDLAQIkZQCZAwJhZgARAmJmAL0BAmNmALwBAmRmAMwBAmVmALsBAmZmAMsBAmdmAAoCaGYACQJqZgA8AmtmABECbGYAXQJtZgAKAm5mABkCb2YAIQJwZgAZAnFmAAoCcmYAkwECc2YA1gMCdGYAeQJ1ZgAZAnZmAJIBAndmAJEBAnhmAGkCeWYA8wECemYA1QMCQWYA1AMCQmYAKQJDZgDTAwJEZgDgAgJFZgDfAgJGZgDeAgJHZgDdAgJIZgDcAgJJZgBRAkpmAAoCS2YAGQJMZgAhAk1mABkCTmYACgJPZgCTAQJQZgDvAQJRZgBdAlJmABkCU2YAkgECVGYAkQECVWYAUQJWZgDuAQJXZgB5AlhmAO0BAllmAGkCWmYAkAECX2YA2wICJGYAugECYWcA2gICYmcAXQJjZwBRAmRnAFECZWcACgJmZwAZAmdnACECaGcAGQJpZwAKAmpnAJMBAmtnAO8BAmxnAF0CbWcAGQJuZwCSAQJvZwCRAQJwZwBRAnFnAO4BAnJnAHkCc2cA7QECdGcAaQJ1ZwCQAQJ2ZwDZAgJ3ZwC6AQJ4ZwDYAgJ5ZwDXAgJ6ZwDWAgJBZwDSAwJCZwCOAwJDZwCjAQJEZwCNAwJFZwAJAkZnAAkCR2cAIAJIZwCjAQJJZwAJAkpnAAkCS2cACQJMZwAoAk1nAAkCTmcACgJPZwAKAlBnADcCUWcAkgMCUmcAZAJTZwBjAlRnABECVWcAxQECVmcA1QICV2cAxAECWGcAwwECWWcAZAJaZwBjAl9nAAkCJGcAKAJhaAAJAmJoAAoCY2gACgJkaAA3AmVoABECZmgAEQJnaAD9AwJoaAD8AwJpaAD7AwJqaADUAgJraADTAgJsaAD6AwJtaAD5AwJuaAAoAm9oAAkCcGgA+AMCcWgAIQJyaABdAnNoAFECdGgAeQJ1aAApAnZoAAoCd2gAoAMCeGgAuAECeWgAfwJ6aAApAkFoAAoCQmgAuAECQ2gAXAJEaAAUAkVoAAkCRmgACQJHaAAUAkhoAPsBAkloAMsDAkpoAMoDAktoAMkDAkxoALcBAk1oALYBAk5oALUBAk9oALQBAlBoAMgDAlFoAIkBAlJoAMcDAlNoAMYDAlRoAFwCVWgAFAJWaAAJAldoAAkCWGgAFAJZaAD7AQJaaADdAwJfaADcAwIkaAD6AQJhaQCJAQJiaQD5AQJjaQD4AQJkaQDlAQJlaQDkAQJmaQDNAwJnaQDMAwJoaQC0AQJpaQC2AQJqaQC1AQJraQC3AQJsaQAJAm1pACkCbmkAGQJvaQAJAnBpAJcCAnFpABkCcmkA0gICc2kA0QICdGkA0AICdWkAzwICdmkAzgICd2kAzQICeGkAEQJ5aQARAnppAAkCQWkAKAJCaQAZAkNpAM4DAkRpALMBAkVpALIBAkZpABECR2kACQJIaQApAklpABkCSmkAzAICS2kAywICTGkAygICTWkAEQJOaQCzAQJPaQDJAgJQaQCyAQJRaQAJAlJpACgCU2kAGQJUaQARAlVpAAoCVmkACQJXaQAUAlhpAEcCWWkARgJaaQDjAQJfaQCHAgIkaQA8AmFqAHUCYmoAyAICY2oAcwJkagByAmVqAMcCAmZqAOkDAmdqAIkCAmhqADwCaWoAdQJqagDGAgJragBzAmxqAHICbWoAxQICbmoA7AMCb2oAhwICcGoAPAJxagB1AnJqAMQCAnNqAHMCdGoAcgJ1agDDAgJ2agCQAwJ3agCJAgJ4agA8AnlqAHUCemoAwgICQWoAcwJCagByAkNqAMECAkRqAM8DAkVqAJ8EAkZqAJkEAkdqAJUCAkhqAJgEAklqABYCSmoAlwQCS2oACQJMagCWBAJNagDAAgJOagDbAwJPagDaAwJQagDZAwJRagCWAQJSagCVAQJTagDYAwJUagDXAwJVagClBAJWagCgBAJXagCaBAJYagCIAwJZagCHAwJaagBpAl9qACECJGoAjwECYWsATAJiawDQAwJjawCxAQJkawC/AgJlawC+AgJmawC9AgJnawCwAQJoawC8AgJpawCvAQJqawC7AgJrawAJAmxrAAkCbWsACQJuawAJAm9rACgCcGsACgJxawA3AnJrALoCAnNrALkCAnRrAN0BAnVrAI8EAnZrAI4EAndrAI0EAnhrAIwEAnlrAIsEAnprAIoEAkFrAJMCAkJrAJICAkNrAJECAkRrAJACAkVrAI8CAkZrAI4CAkdrAI0CAkhrAIwCAklrAAkCSmsAFAJLawAJAkxrABQCTWsACQJOawCJBAJPawCIBAJQawCHBAJRawCGBAJSawCFBAJTawCEBAJUawCDBAJVawCCBAJWawCBBAJXawCABAJYawD/AwJZawCMAgJaawD+AwJfawAJAiRrABQCYWwAFAJibAAJAmNsALgCAmRsAAoCZWwAGQJmbAAhAmdsABkCaGwACQJpbAC8AwJqbAC7AwJrbAC6AwJsbAAZAm1sANUBAm5sABkCb2wAuQMCcGwA1QECcWwA8wECcmwAkAECc2wAtwICdGwAtgICdWwAtQICdmwAtAICd2wAuAMCeGwAtwMCeWwAtgMCemwAtQMCQWwACQJCbAAJAkNsAJgDAkRsAJcDAkVsAAkCRmwACQJHbACxAQJIbACzAgJJbACwAQJKbACvAQJLbAAJAkxsACgCTWwACgJObAA3Ak9sAAoCUGwACgJRbACyAgJSbADRAwJTbACxAgJUbACwAgJVbACvAgJWbACuAgJXbAAJAlhsACkCWWwAGQJabAARAl9sAK0CAiRsAKwCAmFtAAkCYm0AKQJjbQAZAmRtABECZW0ACQJmbQAoAmdtABkCaG0AqwICaW0AqgICam0AqQICa20AEQJsbQAjAm1tABcJQAEAQQELHcMDsgOoA58DlAOoAqcCpgKlAqkEqASnBKYEpASjBKIEoQSeBJ0EnASbBLQDswOxA7ADrwOuA60DrAMMAREK+NkOpgTLBgIbfgd/IAAgASgCDCIdQQF0rCIHIB2sIhN+IAEoAhAiIKwiBiABKAIIIiFBAXSsIgt+fCABKAIUIh1BAXSsIgggASgCBCIiQQF0rCICfnwgASgCGCIfrCIJIAEoAgAiI0EBdKwiBX58IAEoAiAiHkETbKwiAyAerCIQfnwgASgCJCIeQSZsrCIEIAEoAhwiAUEBdKwiFH58IAIgBn4gCyATfnwgHawiESAFfnwgAyAUfnwgBCAJfnwgAiAHfiAhrCIOIA5+fCAFIAZ+fCABQSZsrCIPIAGsIhV+fCADIB9BAXSsfnwgBCAIfnwiF0KAgIAQfCIYQhqHfCIZQoCAgAh8IhpCGYd8IgogCkKAgIAQfCIMQoCAgOAPg30+AhggACAFIA5+IAIgIqwiDX58IB9BE2ysIgogCX58IAggD358IAMgIEEBdKwiFn58IAQgB358IAggCn4gBSANfnwgBiAPfnwgAyAHfnwgBCAOfnwgHUEmbKwgEX4gI6wiDSANfnwgCiAWfnwgByAPfnwgAyALfnwgAiAEfnwiCkKAgIAQfCINQhqHfCIbQoCAgAh8IhxCGYd8IhIgEkKAgIAQfCISQoCAgOAPg30+AgggACALIBF+IAYgB358IAIgCX58IAUgFX58IAQgEH58IAxCGod8IgwgDEKAgIAIfCIMQoCAgPAPg30+AhwgACAFIBN+IAIgDn58IAkgD358IAMgCH58IAQgBn58IBJCGod8IgMgA0KAgIAIfCIDQoCAgPAPg30+AgwgACAJIAt+IAYgBn58IAcgCH58IAIgFH58IAUgEH58IAQgHqwiBn58IAxCGYd8IgQgBEKAgIAQfCIEQoCAgOAPg30+AiAgACAZIBpCgICA8A+DfSAXIBhCgICAYIN9IANCGYd8IgNCgICAEHwiCEIaiHw+AhQgACADIAhCgICA4A+DfT4CECAAIAcgCX4gESAWfnwgCyAVfnwgAiAQfnwgBSAGfnwgBEIah3wiAiACQoCAgAh8IgJCgICA8A+DfT4CJCAAIBsgHEKAgIDwD4N9IAogDUKAgIBgg30gAkIZh0ITfnwiAkKAgIAQfCIFQhqIfD4CBCAAIAIgBUKAgIDgD4N9PgIAC50JAid+DH8gACACKAIEIiqsIgsgASgCFCIrQQF0rCIUfiACNAIAIgMgATQCGCIGfnwgAigCCCIsrCINIAE0AhAiB358IAIoAgwiLawiECABKAIMIi5BAXSsIhV+fCACKAIQIi+sIhEgATQCCCIIfnwgAigCFCIwrCIWIAEoAgQiMUEBdKwiF358IAIoAhgiMqwiICABNAIAIgl+fCACKAIcIjNBE2ysIgwgASgCJCI0QQF0rCIYfnwgAigCICI1QRNsrCIEIAE0AiAiCn58IAIoAiQiAkETbKwiBSABKAIcIgFBAXSsIhl+fCAHIAt+IAMgK6wiGn58IA0gLqwiG358IAggEH58IBEgMawiHH58IAkgFn58IDJBE2ysIg4gNKwiHX58IAogDH58IAQgAawiHn58IAUgBn58IAsgFX4gAyAHfnwgCCANfnwgECAXfnwgCSARfnwgMEETbKwiHyAYfnwgCiAOfnwgDCAZfnwgBCAGfnwgBSAUfnwiIkKAgIAQfCIjQhqHfCIkQoCAgAh8IiVCGYd8IhIgEkKAgIAQfCITQoCAgOAPg30+AhggACALIBd+IAMgCH58IAkgDX58IC1BE2ysIg8gGH58IAogL0ETbKwiEn58IBkgH358IAYgDn58IAwgFH58IAQgB358IAUgFX58IAkgC34gAyAcfnwgLEETbKwiISAdfnwgCiAPfnwgEiAefnwgBiAffnwgDiAafnwgByAMfnwgBCAbfnwgBSAIfnwgKkETbKwgGH4gAyAJfnwgCiAhfnwgDyAZfnwgBiASfnwgFCAffnwgByAOfnwgDCAVfnwgBCAIfnwgBSAXfnwiIUKAgIAQfCImQhqHfCInQoCAgAh8IihCGYd8Ig8gD0KAgIAQfCIpQoCAgOAPg30+AgggACAGIAt+IAMgHn58IA0gGn58IAcgEH58IBEgG358IAggFn58IBwgIH58IAkgM6wiD358IAQgHX58IAUgCn58IBNCGod8IhMgE0KAgIAIfCITQoCAgPAPg30+AhwgACAIIAt+IAMgG358IA0gHH58IAkgEH58IBIgHX58IAogH358IA4gHn58IAYgDH58IAQgGn58IAUgB358IClCGod8IgQgBEKAgIAIfCIEQoCAgPAPg30+AgwgACALIBl+IAMgCn58IAYgDX58IBAgFH58IAcgEX58IBUgFn58IAggIH58IA8gF358IAkgNawiDH58IAUgGH58IBNCGYd8IgUgBUKAgIAQfCIFQoCAgOAPg30+AiAgACAkICVCgICA8A+DfSAiICNCgICAYIN9IARCGYd8IgRCgICAEHwiDkIaiHw+AhQgACAEIA5CgICA4A+DfT4CECAAIAogC34gAyAdfnwgDSAefnwgBiAQfnwgESAafnwgByAWfnwgGyAgfnwgCCAPfnwgDCAcfnwgCSACrH58IAVCGod8IgMgA0KAgIAIfCIDQoCAgPAPg30+AiQgACAnIChCgICA8A+DfSAhICZCgICAYIN9IANCGYdCE358IgNCgICAEHwiBkIaiHw+AgQgACADIAZCgICA4A+DfT4CAAvgAgEDfyAAIAIoAgAgASgCDCIDQRZ2QfwHcUHApAJqKAIAIAEoAggiBEEOdkH8B3FBwJwCaigCACABKAIEIgVBBnZB/AdxQcCUAmooAgAgASgCACIBQf8BcUECdEHAjAJqKAIAc3NzczYCACAAIAIoAgQgAUEWdkH8B3FBwKQCaigCACADQQ52QfwHcUHAnAJqKAIAIARBBnZB/AdxQcCUAmooAgAgBUH/AXFBAnRBwIwCaigCAHNzc3M2AgQgACACKAIIIAVBFnZB/AdxQcCkAmooAgAgAUEOdkH8B3FBwJwCaigCACADQQZ2QfwHcUHAlAJqKAIAIARB/wFxQQJ0QcCMAmooAgBzc3NzNgIIIAAgAigCDCAEQRZ2QfwHcUHApAJqKAIAIAVBDnZB/AdxQcCcAmooAgAgAUEGdkH8B3FBwJQCaigCACADQf8BcUECdEHAjAJqKAIAc3NzczYCDAvWAgEBfwJAIAFFDQAgAEEAOgAAIAAgAWoiAkEBa0EAOgAAIAFBA0kNACAAQQA6AAIgAEEAOgABIAJBA2tBADoAACACQQJrQQA6AAAgAUEHSQ0AIABBADoAAyACQQRrQQA6AAAgAUEJSQ0AIABBACAAa0EDcSICaiIAQQA2AgAgACABIAJrQXxxIgJqIgFBBGtBADYCACACQQlJDQAgAEEANgIIIABBADYCBCABQQhrQQA2AgAgAUEMa0EANgIAIAJBGUkNACAAQQA2AhggAEEANgIUIABBADYCECAAQQA2AgwgAUEQa0EANgIAIAFBFGtBADYCACABQRhrQQA2AgAgAUEca0EANgIAIAIgAEEEcUEYciICayIBQSBJDQAgACACaiEAA0AgAEIANwMYIABCADcDECAAQgA3AwggAEIANwMAIABBIGohACABQSBrIgFBH0sNAAsLC/EdAjZ+BX8gACACMwAAIAIxAAJCEIZCgID8AIOEIgUgASgAFyI6QQV2Qf///wBxrSIDfiABMwAVIAExABdCEIZCgID8AIOEIgQgAigAAiI5QQV2Qf///wBxrSILfnwgAjUAB0IHiEL///8AgyIIIAEoAA8iO0EGdkH///8Aca0iBn58IAEoAAoiPEEYdq0gATEADkIIhoQgATEAD0IQhoRCAYhC////AIMiDCACKAAKIj1BBHZB////AHGtIg1+fCA5QRh2rSACMQAGQgiGhCACMQAHQhCGhEICiEL///8AgyIOIDtBGHatIAExABNCCIaEIAExABRCEIaEQgOIIgl+fCACKAAPIjlBBnZB////AHGtIgcgATUAB0IHiEL///8AgyIPfnwgPUEYdq0gAjEADkIIhoQgAjEAD0IQhoRCAYhC////AIMiCiA8QQR2Qf///wBxrSIQfnwgOUEYdq0gAjEAE0IIhoQgAjEAFEIQhoRCA4giESABKAACIjlBGHatIAExAAZCCIaEIAExAAdCEIaEQgKIQv///wCDIhJ+fCACMwAVIAIxABdCEIZCgID8AIOEIhUgOUEFdkH///8Aca0iFn58IAEzAAAgATEAAkIQhkKAgPwAg4QiFyACKAAXIjlBBXZB////AHGtIhh+fCAEIAV+IAkgC358IAggDH58IA0gEH58IAYgDn58IAcgEn58IAogD358IBEgFn58IBUgF358Ih1CgIBAfSIeQhWIfCITIBNCgIBAfSIgQoCAgH+DfSA5QRh2rSACMQAbQgiGhCACMQAcQhCGhEICiEL///8AgyITIAEoABxBB3atIhl+IDpBGHatIAExABtCCIaEIAExABxCEIaEQgKIQv///wCDIhogAigAHEEHdq0iG358IAMgG34gGCAZfnwgEyAafnwiIUKAgEB9Ih9CFYh8IiIgIkKAgEB9IhxCgICA/////wCDfSIiQpPYKH58ICEgH0KAgID/////AIN9IBUgGX4gGCAafnwgBCAbfnwgAyATfnwgAyAYfiARIBl+fCAVIBp+fCAJIBt+fCAEIBN+fCIjQoCAQH0iFEIViHwiH0KAgEB9IiRCFYh8IiFCmNocfnwgHyAkQoCAgH+DfSIfQuf2J358ICMgFEKAgIB/g30gESAafiAHIBl+fCAEIBh+fCADIBV+fCAGIBt+fCAJIBN+fCAKIBl+IAcgGn58IAMgEX58IAkgGH58IAQgFX58IAwgG358IAYgE358IhRCgIBAfSIkQhWIfCIlQoCAQH0iJkIViHwiI0LTjEN+fCAdIAUgCX4gBiALfnwgCCAQfnwgDSAPfnwgDCAOfnwgByAWfnwgCiASfnwgESAXfnwgBSAGfiALIAx+fCAIIA9+fCANIBJ+fCAOIBB+fCAHIBd+fCAKIBZ+fCIpQoCAQH0iKkIViHwiK0KAgEB9IixCFYh8IB5CgICAf4N9ICFCk9gofnwgH0KY2hx+fCAjQuf2J358Ii1CgIBAfSIuQhWHfCIvQoCAQH0iMEIVhyAFIBp+IAMgC358IAggCX58IAYgDX58IAQgDn58IAcgEH58IAogDH58IA8gEX58IBYgGH58IBIgFX58IBMgF358Ih4gGSAbfiIdIB1CgIBAfSInQoCAgP////8Dg30gHEIViHwiHUKT2Ch+ICBCFYh8ICJCmNocfnx8ICFC5/YnfnwgH0LTjEN+fCAeQoCAQH0iMUKAgIB/g30gI0LRqwh+fCIcfCAlICZCgICAf4N9IBQgJ0IViCIeQoOhVn58ICRCgICAf4N9IAMgB34gDSAZfnwgCiAafnwgBCARfnwgBiAYfnwgCSAVfnwgECAbfnwgDCATfnwgDSAafiAIIBl+fCAEIAd+fCADIAp+fCAJIBF+fCAMIBh+fCAGIBV+fCAPIBt+fCAQIBN+fCIUQoCAQH0iJEIViHwiJUKAgEB9IiZCFYh8IidCgIBAfSIoQhWHfCIgQoOhVn58IBxCgIBAfSIyQoCAgH+DfSIcIBxCgIBAfSIzQoCAgH+DfSAvIDBCgICAf4N9ICBC0asIfnwgJyAoQoCAgH+DfSAdQoOhVn4gHkLRqwh+fCAlfCAmQoCAgH+DfSAUIB5C04xDfnwgHULRqwh+fCAiQoOhVn58ICRCgICAf4N9IAMgDX4gCCAafnwgDiAZfnwgByAJfnwgBCAKfnwgBiARfnwgECAYfnwgDCAVfnwgEiAbfnwgDyATfnwgAyAIfiALIBl+fCAEIA1+fCAOIBp+fCAGIAd+fCAJIAp+fCAMIBF+fCAPIBh+fCAQIBV+fCAWIBt+fCASIBN+fCIkQoCAQH0iJUIViHwiJkKAgEB9Ii9CFYh8IjBCgIBAfSInQhWHfCIUQoCAQH0iKEIVh3wiHEKDoVZ+fCAtIC5CgICAf4N9ICsgLEKAgIB/g30gH0KT2Ch+fCAjQpjaHH58ICkgKkKAgIB/g30gBSAMfiALIBB+fCAIIBJ+fCANIBZ+fCAOIA9+fCAKIBd+fCAFIBB+IAsgD358IAggFn58IA0gF358IA4gEn58IilCgIBAfSIqQhWIfCIrQoCAQH0iLEIViHwgI0KT2Ch+fCItQoCAQH0iLkIVh3wiNEKAgEB9IjVCFYd8ICBC04xDfnwgHELRqwh+fCAUIChCgICAf4N9IhRCg6FWfnwiKEKAgEB9IjZCFYd8IjdCgIBAfSI4QhWHfCA3IDhCgICAf4N9ICggNkKAgIB/g30gNCA1QoCAgH+DfSAgQuf2J358IBxC04xDfnwgFELRqwh+fCAwICdCgICAf4N9IB1C04xDfiAeQuf2J358ICJC0asIfnwgIUKDoVZ+fCAmfCAvQoCAgH+DfSAdQuf2J34gHkKY2hx+fCAiQtOMQ358ICR8ICFC0asIfnwgH0KDoVZ+fCAlQoCAgH+DfSAFIBl+IAsgGn58IAQgCH58IAkgDX58IAMgDn58IAcgDH58IAYgCn58IBAgEX58IBIgGH58IA8gFX58IBcgG358IBMgFn58IDFCFYh8IgZCgIBAfSIMQhWIfCINQoCAQH0iCUIVh3wiBEKAgEB9IgdCFYd8IgNCg6FWfnwgLSAuQoCAgH+DfSAgQpjaHH58IBxC5/YnfnwgFELTjEN+fCADQtGrCH58IAQgB0KAgIB/g30iBEKDoVZ+fCIHQoCAQH0iCkIVh3wiEEKAgEB9IhFCFYd8IBAgEUKAgIB/g30gByAKQoCAgH+DfSArICxCgICAf4N9ICBCk9gofnwgHEKY2hx+fCAUQuf2J358IA0gCUKAgIB/g30gHUKY2hx+IB5Ck9gofnwgIkLn9id+fCAhQtOMQ358IB9C0asIfnwgBnwgI0KDoVZ+fCAMQoCAgH+DfSAyQhWHfCIMQoCAQH0iDUIVh3wiBkKDoVZ+fCADQtOMQ358IARC0asIfnwgKSAqQoCAgH+DfSAFIA9+IAsgEn58IAggF358IA4gFn58IAUgEn4gCyAWfnwgDiAXfnwiDkKAgEB9IglCFYh8IgdCgIBAfSIPQhWIfCAcQpPYKH58IBRCmNocfnwgBkLRqwh+fCADQuf2J358IARC04xDfnwiCkKAgEB9IhBCFYd8IhFCgIBAfSISQhWHfCARIAwgDUKAgIB/g30gM0IVh3wiDEKAgEB9Ig1CFYciCEKDoVZ+fCASQoCAgH+DfSAKIAhC0asIfnwgEEKAgIB/g30gByAPQoCAgH+DfSAUQpPYKH58IAZC04xDfnwgA0KY2hx+fCAEQuf2J358IA4gCyAXfiAFIBZ+fCAFIBd+IgVCgIBAfSILQhWIfCIHQoCAQH0iD0IViHwgCUKAgID///8Hg30gBkLn9id+fCADQpPYKH58IARCmNocfnwiA0KAgEB9Ig5CFYd8IglCgIBAfSIKQhWHfCAJIAhC04xDfnwgCkKAgIB/g30gAyAIQuf2J358IA5CgICAf4N9IAcgD0KAgID///8Hg30gBkKY2hx+fCAEQpPYKH58IAUgC0KAgID///8Bg30gBkKT2Ch+fCIFQoCAQH0iA0IVh3wiBEKAgEB9IgtCFYd8IAQgCEKY2hx+fCALQoCAgH+DfSAFIANCgICAf4N9IAhCk9gofnwiA0IVh3wiCEIVh3wiBkIVh3wiDkIVh3wiCUIVh3wiB0IVh3wiD0IVh3wiCkIVh3wiEEIVh3wiEUIVh3wiEkIVhyAMIA1CgICAf4N9fCILQhWHIgVCk9gofiADQv///wCDfCIEPAAAIAAgBEIIiDwAASAAIAVCmNocfiAIQv///wCDfCAEQhWHfCIDQguIPAAEIAAgA0IDiDwAAyAAIARCEIhCH4MgA0IFhoQ8AAIgACAFQuf2J34gBkL///8Ag3wgA0IVh3wiBEIGiDwABiAAIARCAoYgA0KAgOAAg0ITiIQ8AAUgACAFQtOMQ34gDkL///8Ag3wgBEIVh3wiA0IJiDwACSAAIANCAYg8AAggACADQgeGIARCgID/AINCDoiEPAAHIAAgBULRqwh+IAlC////AIN8IANCFYd8IgRCDIg8AAwgACAEQgSIPAALIAAgBEIEhiADQoCA+ACDQhGIhDwACiAAIAVCg6FWfiAHQv///wCDfCAEQhWHfCIDQgeIPAAOIAAgA0IBhiAEQoCAwACDQhSIhDwADSAAIA9C////AIMgA0IVh3wiBUIKiDwAESAAIAVCAog8ABAgACAFQgaGIANCgID+AINCD4iEPAAPIAAgCkL///8AgyAFQhWHfCIDQg2IPAAUIAAgA0IFiDwAEyAAIBBC////AIMgA0IVh3wiBDwAFSAAIANCA4YgBUKAgPAAg0ISiIQ8ABIgACAEQgiIPAAWIAAgEUL///8AgyAEQhWHfCIFQguIPAAZIAAgBUIDiDwAGCAAIARCEIhCH4MgBUIFhoQ8ABcgACASQv///wCDIAVCFYd8IgNCBog8ABsgACADQgKGIAVCgIDgAINCE4iEPAAaIAAgA0IVhyIEIAtC////AIN8IgVCEYg8AB8gACAFQgmIPAAeIAAgBUIHhiADQoCA/wCDQg6IhDwAHCAAIASnIAunakEBdq08AB0LBABBIAsEAEEQC8AEARN/IABBGHYiBEEBdCIDIABBH3VBG3FzIgggBHMiAsBBB3ZBG3EgAkEBdCIBcyIOIABBEHYiAsBBB3ZBG3EgAkEBdCIJcyIFQQF0Ig8gCcBBB3ZBG3FzIgkgAnMiBnNBAXQgAcBBB3ZBG3EgAEEBdCIBIADAQQd2QRtxcyIHQQF0IgrAQQd2QRtxIAogAcBBB3ZBG3FzIgpBAXRzc3MgBsBBB3ZBG3FzIABBCHYiAcBBB3ZBG3EgAUEBdCIGcyILIAFzIgzAQQd2QRtxIAxBAXQiDHMiECABcyINQQF0cyANwEEHdkEbcXMgAHMgBHMgAnNB/wFxQQh0IAAgB3MiB8BBB3ZBG3EgB0EBdCIHcyINIABzIhEgC0EBdCILIAbAQQd2QRtxcyIGIAFzIhIgAiAFcyIFwEEHdkEbcSAFQQF0IgVzIhNzc0EBdCAFwEEHdkEbcSAIQQF0IgjAQQd2QRtxIAggA8BBB3ZBG3FzIgNBAXRzc3MgEsBBB3ZBG3FzIBHAQQd2QRtxcyAEcyACcyABc0H/AXFyIAvAQQd2QRtxIAfAQQd2QRtxIAMgBHMiA0EBdHNzIAZBAXRzIAPAQQd2QRtxcyANIAIgE3MiA3NBAXRzIAPAQQd2QRtxcyAAcyAEcyABc0H/AXFBEHRyIAAgDMBBB3ZBG3EgD8BBB3ZBG3EgCSAAIApzIgBzQQF0cyAAwEEHdkEbcXNzIAQgDnMiACAQc0EBdHMgAMBBB3ZBG3FzcyACcyABc0EYdHILGQEBf0HYyAIoAgAiAARAIAARFAALEKoBAAvoAQIGfwJ+An8gAkIAUgRAIABB4AFqIQggAEHgAGohBCAAKADgAiEFIABBQGshBgNAIAQgBWohB0GAAiAFayIDrSIJIAJaBEAgAqciAwRAIAcgASAD/AoAAAsgACAAKADgAiADajYA4AJBAAwDCyADBEAgByABIAP8CgAACyAAIAAoAOACIANqNgDgAiAGIAYpAAAiCkKAAXw3AAAgACAAKQBIIApC/35WrXw3AEggACAEEF4gBCAIQYAB/AoAACAAIAAoAOACQYABayIFNgDgAiABIANqIQEgAiAJfSICQgBSDQALC0EACwufBAETfyABKAIoIQIgASgCBCEDIAEoAiwhBCABKAIIIQUgASgCMCEGIAEoAgwhByABKAI0IQggASgCECEJIAEoAjghCiABKAIUIQsgASgCPCEMIAEoAhghDSABQUBrIg4oAgAhDyABKAIcIRAgASgCRCERIAEoAiAhEiABKAJIIRMgASgCACEUIAAgASgCJCABKAJMajYCJCAAIBIgE2o2AiAgACAQIBFqNgIcIAAgDSAPajYCGCAAIAsgDGo2AhQgACAJIApqNgIQIAAgByAIajYCDCAAIAUgBmo2AgggACADIARqNgIEIAAgAiAUajYCACABKAIoIQIgASgCBCEDIAEoAiwhBCABKAIIIQUgASgCMCEGIAEoAgwhByABKAI0IQggASgCECEJIAEoAjghCiABKAIUIQsgASgCPCEMIAEoAhghDSAOKAIAIQ4gASgCHCEPIAEoAkQhECABKAIgIREgASgCSCESIAEoAgAhEyAAIAEoAkwgASgCJGs2AkwgACASIBFrNgJIIAAgECAPazYCRCAAQUBrIA4gDWs2AgAgACAMIAtrNgI8IAAgCiAJazYCOCAAIAggB2s2AjQgACAGIAVrNgIwIAAgBCADazYCLCAAIAIgE2s2AiggACABKQJQNwJQIAAgASkCWDcCWCAAIAEpAmA3AmAgACABKQJoNwJoIAAgASkCcDcCcCAAQfgAaiABQfgAakGgDRAFC+gEAQl/IAAgASgCICIFIAEoAhwiBiABKAIYIgcgASgCFCIIIAEoAhAiCSABKAIMIgogASgCCCIEIAEoAgQiAyABKAIAIgIgASgCJCIBQRNsQYCAgAhqQRl2akEadWpBGXVqQRp1akEZdWpBGnVqQRl1akEadWpBGXVqQRp1IAFqQRl1QRNsIAJqIgI6AAAgACACQRB2OgACIAAgAkEIdjoAASAAIAMgAkEadWoiA0EOdjoABSAAIANBBnY6AAQgACACQRh2QQNxIANBAnRyOgADIAAgBCADQRl1aiICQQ12OgAIIAAgAkEFdjoAByAAIAJBA3QgA0GAgIAOcUEWdnI6AAYgACAKIAJBGnVqIgRBC3Y6AAsgACAEQQN2OgAKIAAgBEEFdCACQYCAgB9xQRV2cjoACSAAIAkgBEEZdWoiAkESdjoADyAAIAJBCnY6AA4gACACQQJ2OgANIAAgCCACQRp1aiIDOgAQIAAgAkEGdCAEQYCA4A9xQRN2cjoADCAAIANBEHY6ABIgACADQQh2OgARIAAgByADQRl1aiICQQ92OgAVIAAgAkEHdjoAFCAAIANBGHZBAXEgAkEBdHI6ABMgACAGIAJBGnVqIgNBDXY6ABggACADQQV2OgAXIAAgA0EDdCACQYCAgBxxQRd2cjoAFiAAIAUgA0EZdWoiAkEMdjoAGyAAIAJBBHY6ABogACACQQR0IANBgICAD3FBFXZyOgAZIAAgASACQRp1aiIBQQp2OgAeIAAgAUECdjoAHSAAIAFBgIDwD3FBEnY6AB8gACABQQZ0IAJBgIDAH3FBFHZyOgAcC/ACAQN/IAAgAigCACABKAIAIgRB/wFxQcCsAmotAAAgASgCDCIDQQh2Qf8BcUHArAJqLQAAQQh0ciABKAIIIgVBEHZB/wFxQcCsAmotAABBEHRyIAEoAgQiAUEYdkHArAJqLQAAQRh0chALczYCACAAIAIoAgQgAUH/AXFBwKwCai0AACAEQQh2Qf8BcUHArAJqLQAAQQh0ciADQRB2Qf8BcUHArAJqLQAAQRB0ciAFQRh2QcCsAmotAABBGHRyEAtzNgIEIAAgAigCCCAFQf8BcUHArAJqLQAAIAFBCHZB/wFxQcCsAmotAABBCHRyIARBEHZB/wFxQcCsAmotAABBEHRyIANBGHZBwKwCai0AAEEYdHIQC3M2AgggACACKAIMIANB/wFxQcCsAmotAAAgBUEIdkH/AXFBwKwCai0AAEEIdHIgAUEQdkH/AXFBwKwCai0AAEEQdHIgBEEYdkHArAJqLQAAQRh0chALczYCDAsIACAAQSAQFgvwCQEefyABKAIoIQMgASgCBCEEIAEoAiwhBSABKAIIIQYgASgCMCEHIAEoAgwhCCABKAI0IQkgASgCECEKIAEoAjghCyABKAIUIQwgASgCPCENIAEoAhghDiABQUBrIg8oAgAhECABKAIcIREgASgCRCESIAEoAiAhEyABKAJIIRQgASgCACEVIAAgASgCJCABKAJMajYCJCAAIBMgFGo2AiAgACARIBJqNgIcIAAgDiAQajYCGCAAIAwgDWo2AhQgACAKIAtqNgIQIAAgCCAJajYCDCAAIAYgB2o2AgggACAEIAVqNgIEIAAgAyAVajYCACABKAIoIQUgASgCBCEDIAEoAiwhBiABKAIIIQcgASgCMCEIIAEoAgwhCSABKAI0IQogASgCECELIAEoAjghDCABKAIUIQ0gASgCPCEOIAEoAhghECAPKAIAIQ8gASgCHCEEIAEoAkQhESABKAIgIRIgASgCSCETIAEoAgAhFCAAIAEoAkwgASgCJGs2AkwgACATIBJrNgJIIAAgESAEazYCRCAAQUBrIgQgDyAQazYCACAAIA4gDWs2AjwgACAMIAtrNgI4IAAgCiAJazYCNCAAIAggB2s2AjAgACAGIANrNgIsIABBKGoiAyAFIBRrNgIAIABB0ABqIAAgAhAFIAMgAyACQShqEAUgAEH4AGogAkH4AGogAUH4AGoQBSAAIAFB0ABqIAJB0ABqEAUgACgCBCEVIAAoAgghFiAAKAIMIRcgACgCECEYIAAoAhQhGSAAKAIYIRogACgCHCEbIAAoAiAhHCAAKAIkIR0gAygCACEBIAAoAlAhAiAAKAIsIQUgACgCVCEGIAAoAjAhByAAKAJYIQggACgCNCEJIAAoAlwhCiAAKAI4IQsgACgCYCEMIAAoAjwhDSAAKAJkIQ4gBCgCACEPIAAoAmghECAAKAJEIREgACgCbCESIAAoAkghEyAAKAJwIRQgACgCACEeIAAgACgCTCIfIAAoAnQiIGo2AkwgACATIBRqNgJIIAAgESASajYCRCAEIA8gEGo2AgAgACANIA5qNgI8IAAgCyAMajYCOCAAIAkgCmo2AjQgACAHIAhqNgIwIAAgBSAGajYCLCADIAEgAmo2AgAgACAgIB9rNgIkIAAgFCATazYCICAAIBIgEWs2AhwgACAQIA9rNgIYIAAgDiANazYCFCAAIAwgC2s2AhAgACAKIAlrNgIMIAAgCCAHazYCCCAAIAYgBWs2AgQgACACIAFrNgIAIAAgHUEBdCIBIAAoApwBIgJrNgKcASAAIBxBAXQiAyAAKAKYASIEazYCmAEgACAbQQF0IgUgACgClAEiBms2ApQBIAAgGkEBdCIHIAAoApABIghrNgKQASAAIBlBAXQiCSAAKAKMASIKazYCjAEgACAYQQF0IgsgACgCiAEiDGs2AogBIAAgF0EBdCINIAAoAoQBIg5rNgKEASAAIBZBAXQiDyAAKAKAASIQazYCgAEgACAVQQF0IhEgACgCfCISazYCfCAAIB5BAXQiEyAAKAJ4IhRrNgJ4IAAgAyAEajYCcCAAIAUgBmo2AmwgACAHIAhqNgJoIAAgCSAKajYCZCAAIAsgDGo2AmAgACANIA5qNgJcIAAgDyAQajYCWCAAIBEgEmo2AlQgACATIBRqNgJQIAAgASACajYCdAuSBgIIfgN/IwBBwAVrIgwkAAJAIAJQDQAgACAAKQNIIgMgAkIDhnwiBDcDSCAAQUBrIgsgCykDACADIARWrXwgAkI9iHw3AwAgAEHQAGohC0KAASADQgOIQv8AgyIEfSIFIAJYBEAgBUIDgyEGQgAhAwJAIARC/wCFQgNaBEAgBUL8AYMhCgNAIAsgAyAEfKdqIAEgA6dqLQAAOgAAIAsgA0IBhCIIIAR8p2ogASAIp2otAAA6AAAgCyADQgKEIgggBHynaiABIAinai0AADoAACALIANCA4QiCCAEfKdqIAEgCKdqLQAAOgAAIANCBHwhAyAJQgR8IgkgClINAAsgBlANAQsDQCALIAMgBHynaiABIAOnai0AADoAACADQgF8IQMgB0IBfCIHIAZSDQALCyAAIAsgDCAMQYAFaiINEHsgASAFp2ohASACIAV9IgJC/wBWBEADQCAAIAEgDCANEHsgAUGAAWohASACQoABfSICQv8AVg0ACwsCQCACUA0AIAJCA4MhBEIAIQdCACEDIAJCBFoEQCACQvwAgyEFQgAhAgNAIAsgA6ciAGogACABai0AADoAACALIABBAXIiDWogASANai0AADoAACALIABBAnIiDWogASANai0AADoAACALIABBA3IiAGogACABai0AADoAACADQgR8IQMgAkIEfCICIAVSDQALIARQDQELA0AgCyADpyIAaiAAIAFqLQAAOgAAIANCAXwhAyAHQgF8IgcgBFINAAsLIAxBwAUQBwwBCyACQgODIQVCACEDIAJCBFoEQCACQnyDIQIDQCALIAMgBHynaiABIAOnai0AADoAACALIANCAYQiBiAEfKdqIAEgBqdqLQAAOgAAIAsgA0IChCIGIAR8p2ogASAGp2otAAA6AAAgCyADQgOEIgYgBHynaiABIAanai0AADoAACADQgR8IQMgCUIEfCIJIAJSDQALIAVQDQELA0AgCyADIAR8p2ogASADp2otAAA6AAAgA0IBfCEDIAdCAXwiByAFUg0ACwsgDEHABWokAEEACwUAQcAAC+cDAQp/A0AgACAJQQN0IgRqIgYgCUEBdEGguwJqLgEAIgggAiAEQQJyIgNqIgcuAQAgASADaiIKLgEAbCIFQYCAhJh/bEEQdUH/ZWwgBWpBEHVsIgVBgICEmH9sQRB1Qf9lbCAFakEQdiIFOwEAIAYgBSACIARqIgYuAQAgASAEaiILLgEAbCIMQYCAhJh/bEEQdUH/ZWwgDGpBEHZqOwEAIAAgA2oiAyAHLgEAIAsuAQBsIgdBgICEmH9sQRB1Qf9lbCAHakEQdiIHOwEAIAMgBi4BACAKLgEAbCIDQYCAhJh/bEEQdUH/ZWwgA2pBEHYgB2o7AQAgACAEQQRyIgNqIgYgCCACIARBBnIiBGoiBy4BACABIARqIgouAQBsIgVBgICEmH9sQRB1Qf9lbCAFakEQdWwiCEGAgPznAGxBEHVB/2VsIAhrQRB2Igg7AQAgBiAIIAIgA2oiBi4BACABIANqIgMuAQBsIgVBgICEmH9sQRB1Qf9lbCAFakEQdmo7AQAgACAEaiIEIAcuAQAgAy4BAGwiA0GAgISYf2xBEHVB/2VsIANqQRB2IgM7AQAgBCAGLgEAIAouAQBsIgRBgICEmH9sQRB1Qf9lbCAEakEQdiADajsBACAJQQFqIglBwABHDQALCxoAEDogAQRAIAAgAUHcyAIoAgAoAhARBgALC4IMAQh/AkAgAEUNACAAQQhrIgMgAEEEaygCACICQXhxIgBqIQUCQCACQQFxDQAgAkECcUUNASADIAMoAgAiBGsiA0HUxAIoAgBJDQEgACAEaiEAAkACQAJAQdjEAigCACADRwRAIAMoAgwhASAEQf8BTQRAIAEgAygCCCICRw0CQcTEAkHExAIoAgBBfiAEQQN2d3E2AgAMBQsgAygCGCEHIAEgA0cEQCADKAIIIgIgATYCDCABIAI2AggMBAsgAygCFCICBH8gA0EUagUgAygCECICRQ0DIANBEGoLIQQDQCAEIQYgAiIBQRRqIQQgASgCFCICDQAgAUEQaiEEIAEoAhAiAg0ACyAGQQA2AgAMAwsgBSgCBCICQQNxQQNHDQNBzMQCIAA2AgAgBSACQX5xNgIEIAMgAEEBcjYCBCAFIAA2AgAPCyACIAE2AgwgASACNgIIDAILQQAhAQsgB0UNAAJAIAMoAhwiBEECdCICKAL0xgIgA0YEQCACQfTGAmogATYCACABDQFByMQCQcjEAigCAEF+IAR3cTYCAAwCCwJAIAMgBygCEEYEQCAHIAE2AhAMAQsgByABNgIUCyABRQ0BCyABIAc2AhggAygCECICBEAgASACNgIQIAIgATYCGAsgAygCFCICRQ0AIAEgAjYCFCACIAE2AhgLIAMgBU8NACAFKAIEIgRBAXFFDQACQAJAAkACQCAEQQJxRQRAQdzEAigCACAFRgRAQdzEAiADNgIAQdDEAkHQxAIoAgAgAGoiADYCACADIABBAXI2AgQgA0HYxAIoAgBHDQZBzMQCQQA2AgBB2MQCQQA2AgAPC0HYxAIoAgAiByAFRgRAQdjEAiADNgIAQczEAkHMxAIoAgAgAGoiADYCACADIABBAXI2AgQgACADaiAANgIADwsgBEF4cSAAaiEAIAUoAgwhASAEQf8BTQRAIAUoAggiAiABRgRAQcTEAkHExAIoAgBBfiAEQQN2d3E2AgAMBQsgAiABNgIMIAEgAjYCCAwECyAFKAIYIQggASAFRwRAIAUoAggiAiABNgIMIAEgAjYCCAwDCyAFKAIUIgIEfyAFQRRqBSAFKAIQIgJFDQIgBUEQagshBANAIAQhBiACIgFBFGohBCABKAIUIgINACABQRBqIQQgASgCECICDQALIAZBADYCAAwCCyAFIARBfnE2AgQgAyAAQQFyNgIEIAAgA2ogADYCAAwDC0EAIQELIAhFDQACQCAFKAIcIgRBAnQiAigC9MYCIAVGBEAgAkH0xgJqIAE2AgAgAQ0BQcjEAkHIxAIoAgBBfiAEd3E2AgAMAgsCQCAFIAgoAhBGBEAgCCABNgIQDAELIAggATYCFAsgAUUNAQsgASAINgIYIAUoAhAiAgRAIAEgAjYCECACIAE2AhgLIAUoAhQiAkUNACABIAI2AhQgAiABNgIYCyADIABBAXI2AgQgACADaiAANgIAIAMgB0cNAEHMxAIgADYCAA8LIABB/wFNBEAgAEH4AXFB7MQCaiECAn9BxMQCKAIAIgRBASAAQQN2dCIAcUUEQEHExAIgACAEcjYCACACDAELIAIoAggLIQAgAiADNgIIIAAgAzYCDCADIAI2AgwgAyAANgIIDwtBHyEBIABB////B00EQCAAQSYgAEEIdmciAmt2QQFxIAJBAXRyQT5zIQELIAMgATYCHCADQgA3AhAgAUECdEH0xgJqIQQCfwJAAn9ByMQCKAIAIgZBASABdCICcUUEQEHIxAIgAiAGcjYCACAEIAM2AgBBGCEBQQgMAQsgAEEZIAFBAXZrQQAgAUEfRxt0IQEgBCgCACEEA0AgBCICKAIEQXhxIABGDQIgAUEddiEEIAFBAXQhASACIARBBHFqIgYoAhAiBA0ACyAGIAM2AhBBGCEBIAIhBEEICyEAIAMiAgwBCyACKAIIIgQgAzYCDCACIAM2AghBGCEAQQghAUEACyEGIAEgA2ogBDYCACADIAI2AgwgACADaiAGNgIAQeTEAkHkxAIoAgBBAWsiAEF/IAAbNgIACwvpAQEFfwJAIANFDQAgA0EDcSEHIAAgAmohAkEAIQAgA0EETwRAIANBfHEhCEEAIQMDQCAAIAJqIgQgBC0AACAAIAFqLQAAczoAACACIABBAXIiBGoiBSAFLQAAIAEgBGotAABzOgAAIAIgAEECciIEaiIFIAUtAAAgASAEai0AAHM6AAAgAiAAQQNyIgRqIgUgBS0AACABIARqLQAAczoAACAAQQRqIQAgA0EEaiIDIAhHDQALIAdFDQELA0AgACACaiIDIAMtAAAgACABai0AAHM6AAAgAEEBaiEAIAZBAWoiBiAHRw0ACwsLBABBfwuocQIzfgJ/IwBB0AFrIjQkACA0IABByAH8CgAAIDQgNCkDqAEiIiA0KQOAASItIDQpA1giJCA0KQMwIiggNCkDCCIChYWFhSIpIDQpA7gBIi4gNCkDkAEiKiA0KQNoIiUgNEFAayI1KQMAIi8gNCkDGCIEhYWFhSIHQgGJhSImIDQpAzgiCYVCBokiMSACIDQpA6ABIgEgNCkDeCIrIDQpA1AiFCA0KQMoIjAgNCkDACIMhYWFhSILIDQpA7ABIg0gNCkDiAEiDyA0KQNgIiwgCSA0KQMQIgqFhYWFIgVCAYmFIhCFQgGJIhVCf4WDIAEgNCkDwAEiBiA0KQOYASIOIDQpA3AiAyA0KQNIIgIgNCkDICIJhYWFhSIBIClCAYmFIhqFQhKJIhGFIicgByALQgGJhSIHIAaFQg6JIhsgECAohUIsiSIcIAwgGoUiHUJ/hYOFIjKFIAFCAYkgBYUiCyAuhUI4iSIBIBogMIVCJIkiEiAHIAmFQhuJIh5Cf4WDhSIjhSANICaFQj2JIg0gAiAHhUIUiSIfIAQgC4VCHIkiIEJ/hYOFIiiFIBAgIoVCAokiISALIC+FQjeJIhMgCiAmhUI+iSIWQn+Fg4UiIoUiKUIBiSAQICSFQgqJIhcgASAPICaFQg+JIgpCf4WDhSIuICYgLIVCK4kiGCAbIAsgKoVCFYkiBUJ/hYOFIiogAyAHhUIniSIZICEgGiArhUIpiSIGQn+Fg4UiJCALICWFQhmJIiYgESAHIA6FQgiJIgNCf4WDhSIJIBQgGoVCA4kiJSANIBAgLYVCLYkiAkJ/hYOFIi+FhYWFIgSFIgggHiABQn+FgyAKhSIBhUIViSIaIAkgAyAmQn+FgyAxhSIHIAUgGEJ/hYMgHIUiKyATIAYgGUJ/hYOFIhQgCiAXQn+FgyAShSIwIAIgJUJ/hYMgH4UiDIWFhYUiCyABICAgDUJ/hYMgAoUiDSAWICFCf4WDIAaFIg8gFSARQn+FgyADhSIsIAUgHSAbQn+Fg4UiCoWFhYUiBUIBiYUiEIVCK4kiEUJ/hYMgDCAZIBNCf4WDIBaFIgYgJiAxQn+FgyAVhSIOIBcgEkJ/hYMgHoUiAyAdIBggHEJ/hYOFQgGFIgIgICAlIB9Cf4WDhSIJhYWFhSIBIARCAYmFIhWFQiyJIgyFIiUgBSABQgGJhSIEICiFQhSJIhsgFSAwhUItiSIcIA4gC0IBiSAphSILhUIDiSIdQn+Fg4UiKIUgECAvhUIGiSISIAQgI4VCCIkiHiAIICyFQhmJIh9Cf4WDhSIphSAJIAuFQiSJIiAgECAuhUIPiSIhIAcgFYVCCokiE0J/hYOFIi2FIAggDYVCN4kiFiADIAuFQimJIhcgBCAnhUIniSIYQn+Fg4UiLoUiAUIBiSAUIBWFQgKJIhkgFiAQICqFQj6JIixCf4WDhSInIAggD4VCOIkiJiAgIAQgMoVCG4kiBUJ/hYOFIiMgBiALhUISiSIGIBIgFSArhUIBiSIOQn+Fg4UiKiAEICKFQg6JIiIgDCACIAuFIgNCf4WDhSIvIBAgJIVCPYkiJCAbIAggCoVCHIkiAkJ/hYOFIgSFhYWFIgeFIgggAyARIAxCf4WDhUKCgQKFIgmFIhUgASAsIBlCf4WDIBeFIisgBSAmQn+FgyAhhSIUIA4gBkJ/hYMgHoUiMCACICRCf4WDIByFIgwgGiADICJCf4WDhSILhYWFhSINQgGJhSIQIAYgHkJ/hYMgH4UiAYVCK4kiMSAoIBggFkJ/hYMgLIUiDyATICBCf4WDIAWFIiwgHyASQn+FgyAOhSIKIAkgHSAbQn+FgyAChSIFhYWFhSIGIBkgF0J/hYMgGIUiDiAmICFCf4WDIBOFIgMgIiAaQn+FgyARhSICICQgHEJ/hYMgHYUiCYUgAYWFhSIBQgGJhSIahUIsiSIRQn+Fg4VCioGCgICAgICAf4UiMiAHQgGJIAGFIgcgC4VCHIkiGyAIIAqFQgOJIhwgBkIBiSANhSILIASFQhSJIh1Cf4WDhSIihSAaICWFQgGJIhIgByAwhUIZiSIeIAkgEIVCBokiH0J/hYOFIiSFIAsgL4VCG4kiDSAaICmFQgqJIiAgBSAIhUIkiSIhQn+Fg4UiJYUgAiAQhUI+iSIBIAsgKoVCJ4kiEyAHIAyFQjeJIhZCf4WDhSIohSIpQgGJIAggLIVCKYkiFyABIBogLoVCAokiCkJ/hYOFIi4gAyAQhUIPiSIYIA0gByArhUI4iSIFQn+Fg4UiCSALICOFQgiJIhkgEiAIIA+FQhKJIgZCf4WDhSIqIAcgFIVCFYkiJiAVIAsgJ4VCDokiA0J/hYOFIiMgGiAthUItiSInIBsgDiAQhUI9iSICQn+Fg4UiL4WFhYUiBIUiCCAWIAFCf4WDIAqFIgGFQg6JIhAgCSAKIBdCf4WDIBOFIgcgBSAYQn+FgyAghSIrIAYgGUJ/hYMgHoUiFCADICZCf4WDIDGFIjAgAiAnQn+FgyAchSIMhYWFhSILIAEgISANQn+FgyAFhSINIB8gEkJ/hYMgBoUiDyARIBVCf4WDIAOFIiwgHSAbQn+FgyAChSIKhYWFhSIFQgGJhSIahUIViSIVQn+FgyAUIBcgE0J/hYMgFoUiBiAYICBCf4WDICGFIg4gGSAeQn+FgyAfhSIDICYgMUJ/hYMgEYUiAiAnIBxCf4WDIB2FIgmFhYWFIgEgBEIBiYUiBIVCK4kiEYUiJyABQgGJIAWFIhQgJIVCA4kiASAEIAeFQj2JIhsgC0IBiSAphSILIA6FQi2JIhxCf4WDhSIkhSAaICqFQhmJIh0gFCAohUISiSISIAggDYVCCIkiHkJ/hYOFIiaFIAMgC4VCCokiHyAaIC6FQjiJIiAgBCArhUIPiSIhQn+Fg4UiLYUgCCAPhUIniSIPIAYgC4VCAokiEyAUICWFQimJIhZCf4WDhSIohSIpQgGJIAQgMIVCPokiFyAPIBogL4VCN4kiBUJ/hYOFIi4gCCAshUIbiSIYIB8gFCAihUIkiSIGQn+Fg4UiKiACIAuFQgGJIhkgHSAEIAyFQgaJIg5Cf4WDhSIlIBQgMoUiIiARIAkgC4VCLIkiA0J/hYOFQoCAgoCIgICAgH+FIgkgGiAjhUIciSIjIAEgCCAKhUIUiSICQn+Fg4UiL4WFhYUiBIUiCCAcIAFCf4WDIAKFIgGFQiyJIhogCSAFIBdCf4WDIBOFIgcgBiAYQn+FgyAghSIrIA4gGUJ/hYMgEoUiFCADICJCf4WDIBCFIjAgAiAjQn+FgyAbhSIMhYWFhSILIBYgD0J/hYMgBYUiDSAhIB9Cf4WDIAaFIg8gHiAdQn+FgyAOhSIsIBUgEUJ/hYMgA4UiCiABhYWFhSIFQgGJhSIRhSIxQn+FgyAHIBcgE0J/hYMgFoUiBiAYICBCf4WDICGFIg4gGSASQn+FgyAehSIDICIgEEJ/hYMgFYUiAiAjIBtCf4WDIByFIgmFhYWFIgEgBEIBiYUiBIVCDokiFYUiMiABQgGJIAWFIgcgKIVCPYkiGyAEIAyFQhSJIhwgAiALQgGJICmFIgKFQhyJIh1Cf4WDhSIohSARIC6FQhKJIhIgByAkhUIGiSIeIAggCoVCAYkiH0J/hYOFIiKFIAIgBoVCOIkiASARIC+FQiSJIiAgBCAwhUIbiSIhQn+Fg4UiI4UgCCANhUICiSINIAIgCYVCN4kiEyAHICeFQj6JIhZCf4WDhSInhSIpQgGJIAQgFIVCJ4kiFyANIBEgKoVCKYkiCkJ/hYOFIiQgCCAshUIKiSIYIAEgByAthUIPiSIFQn+Fg4UiLiACIAOFQhmJIhkgEiAEICuFQgiJIgZCf4WDhSIJIAcgJoVCK4kiLSAVIAIgDoVCFYkiA0J/hYOFIiogESAlhUIDiSIlIBsgCCAPhUItiSICQn+Fg4UiL4WFhYUiBIUiCCAhIAFCf4WDIAWFIgGFQhWJIhEgCSAKIBdCf4WDIBOFIgcgBSAYQn+FgyAghSIrIAYgGUJ/hYMgHoUiFCADIC1Cf4WDIBqFIjAgAiAlQn+FgyAchSIMhYWFhSILIBYgDUJ/hYMgCoUiDSABIB8gEkJ/hYMgBoUiDyAxIBVCf4WDIAOFIiwgHSAbQn+FgyAChSIKhYWFhSIFQgGJhSIQhUIriSIbQn+FgyAMIBcgE0J/hYMgFoUiBiAYICBCf4WDICGFIg4gGSAeQn+FgyAfhSIDIDEgLSAaQn+Fg4VCi4EChSICICUgHEJ/hYMgHYUiCYWFhYUiASAEQgGJhSIVhUIsiSIMhSIlIAFCAYkgBYUiBCAohUIUiSIcIBUgK4VCLYkiHSADIAtCAYkgKYUiA4VCA4kiEkJ/hYOFIiiFIBAgL4VCBokiHiAEICOFQgiJIh8gCCAPhUIZiSIgQn+Fg4UiKYUgAyAJhUIkiSIhIBAgLoVCD4kiEyAUIBWFQgqJIhZCf4WDhSIthSAIIAqFQjeJIg8gAyAOhUIpiSIXIAQgIoVCJ4kiGEJ/hYOFIi6FIgFCAYkgByAVhUICiSIZIA8gECAqhUI+iSIKQn+Fg4UiIiAIIA2FQjiJIiYgISAEIDKFQhuJIgVCf4WDhSIjIAMgBoVCEokiBiAeIBUgMIVCAYkiDkJ/hYOFIiogBCAnhUIOiSInIAwgAiADhSIDQn+Fg4UiLyAQICSFQj2JIiQgHCAIICyFQhyJIgJCf4WDhSIEhYWFhSIHhSIIIAMgGyAMQn+Fg4VCgYCAgAiFIgmFIhUgASAKIBlCf4WDIBeFIisgBSAmQn+FgyAThSIUIA4gBkJ/hYMgH4UiMCADICdCf4WDIBGFIgwgAiAkQn+FgyAdhSILhYWFhSINQgGJhSIQIAYgH0J/hYMgIIUiAYVCK4kiMSAoIBggD0J/hYMgCoUiDyAWICFCf4WDIAWFIiwgICAeQn+FgyAOhSIKIAkgEiAcQn+FgyAChSIFhYWFhSIGIBkgF0J/hYMgGIUiDiAmIBNCf4WDIBaFIgMgJyARQn+FgyAbhSICICQgHUJ/hYMgEoUiCYUgAYWFhSIBQgGJhSIahUIsiSIRQn+Fg4VCgYGCgIiAgICAf4UiMiAHQgGJIAGFIgcgDIVCHIkiGyAIIAqFQgOJIhwgBkIBiSANhSIMIASFQhSJIh1Cf4WDhSInhSAaICWFQgGJIhIgByAwhUIZiSIeIAkgEIVCBokiH0J/hYOFIiSFIAwgL4VCG4kiDSAaICmFQgqJIiAgBSAIhUIkiSIhQn+Fg4UiJYUgAiAQhUI+iSIBIAwgKoVCJ4kiEyAHIAuFQjeJIhZCf4WDhSIohSIpQgGJIAggLIVCKYkiFyABIBogLoVCAokiCkJ/hYOFIi4gAyAQhUIPiSIYIA0gByArhUI4iSIFQn+Fg4UiCSAMICOFQgiJIhkgEiAIIA+FQhKJIgZCf4WDhSIqIAcgFIVCFYkiJiAVIAwgIoVCDokiA0J/hYOFIiMgGiAthUItiSIiIBsgDiAQhUI9iSICQn+Fg4UiL4WFhYUiBIUiCCAWIAFCf4WDIAqFIgGFQg6JIhAgCSAKIBdCf4WDIBOFIgcgBSAYQn+FgyAghSIrIAYgGUJ/hYMgHoUiFCADICZCf4WDIDGFIjAgAiAiQn+FgyAchSIMhYWFhSILIAEgISANQn+FgyAFhSINIB8gEkJ/hYMgBoUiDyARIBVCf4WDIAOFIiwgHSAbQn+FgyAChSIKhYWFhSIFQgGJhSIahUIViSIVQn+FgyAUIBcgE0J/hYMgFoUiBiAYICBCf4WDICGFIg4gGSAeQn+FgyAfhSIDICYgMUJ/hYMgEYUiAiAiIBxCf4WDIB2FIgmFhYWFIgEgBEIBiYUiBIVCK4kiEYUiIiABQgGJIAWFIhQgJIVCA4kiASAEIAeFQj2JIhsgC0IBiSAphSILIA6FQi2JIhxCf4WDhSIkhSAaICqFQhmJIh0gFCAohUISiSISIAggDYVCCIkiHkJ/hYOFIiaFIAMgC4VCCokiHyAaIC6FQjiJIiAgBCArhUIPiSIhQn+Fg4UiLYUgCCAPhUIniSIPIAYgC4VCAokiEyAUICWFQimJIhZCf4WDhSIohSIpQgGJIAQgMIVCPokiFyAPIBogL4VCN4kiBUJ/hYOFIi4gCCAshUIbiSIYIB8gFCAnhUIkiSIGQn+Fg4UiKiACIAuFQgGJIhkgHSAEIAyFQgaJIg5Cf4WDhSIlIBQgMoUiJyARIAkgC4VCLIkiA0J/hYOFQomAgoCAgICAgH+FIgkgGiAjhUIciSIjIAEgCCAKhUIUiSICQn+Fg4UiL4WFhYUiBIUiCCAcIAFCf4WDIAKFIgGFQiyJIhogCSAFIBdCf4WDIBOFIgcgBiAYQn+FgyAghSIrIA4gGUJ/hYMgEoUiFCADICdCf4WDIBCFIjAgAiAjQn+FgyAbhSIMhYWFhSILIBYgD0J/hYMgBYUiDSAhIB9Cf4WDIAaFIg8gHiAdQn+FgyAOhSIsIBUgEUJ/hYMgA4UiCiABhYWFhSIFQgGJhSIRhSIxQn+FgyAHIBcgE0J/hYMgFoUiBiAYICBCf4WDICGFIg4gGSASQn+FgyAehSIDICcgEEJ/hYMgFYUiAiAjIBtCf4WDIByFIgmFhYWFIgEgBEIBiYUiBIVCDokiFYUiMiABQgGJIAWFIgcgKIVCPYkiGyAEIAyFQhSJIhwgAiALQgGJICmFIgKFQhyJIh1Cf4WDhSIohSARIC6FQhKJIhIgByAkhUIGiSIeIAggCoVCAYkiH0J/hYOFIieFIAIgBoVCOIkiASARIC+FQiSJIiAgBCAwhUIbiSIhQn+Fg4UiI4UgCCANhUICiSINIAIgCYVCN4kiEyAHICKFQj6JIhZCf4WDhSIihSIpQgGJIAQgFIVCJ4kiFyANIBEgKoVCKYkiCkJ/hYOFIiQgCCAshUIKiSIYIAEgByAthUIPiSIFQn+Fg4UiLiACIAOFQhmJIhkgEiAEICuFQgiJIgZCf4WDhSIJIAcgJoVCK4kiLSAVIAIgDoVCFYkiA0J/hYOFIiogESAlhUIDiSIlIBsgCCAPhUItiSICQn+Fg4UiL4WFhYUiBIUiCCAhIAFCf4WDIAWFIgGFQhWJIhEgCSAKIBdCf4WDIBOFIgcgBSAYQn+FgyAghSIrIAYgGUJ/hYMgHoUiFCADIC1Cf4WDIBqFIjAgAiAlQn+FgyAchSIMhYWFhSILIBYgDUJ/hYMgCoUiDSABIB8gEkJ/hYMgBoUiDyAxIBVCf4WDIAOFIiwgHSAbQn+FgyAChSIKhYWFhSIFQgGJhSIQhUIriSIbQn+FgyAMIBcgE0J/hYMgFoUiBiAYICBCf4WDICGFIg4gGSAeQn+FgyAfhSIDIDEgLSAaQn+Fg4VCigGFIgIgJSAcQn+FgyAdhSIJhYWFhSIBIARCAYmFIhWFQiyJIgyFIiUgAUIBiSAFhSIEICiFQhSJIhwgFSArhUItiSIdIAMgC0IBiSAphSIDhUIDiSISQn+Fg4UiKIUgECAvhUIGiSIeIAQgI4VCCIkiHyAIIA+FQhmJIiBCf4WDhSIphSADIAmFQiSJIiEgECAuhUIPiSITIBQgFYVCCokiFkJ/hYOFIi2FIAggCoVCN4kiDyADIA6FQimJIhcgBCAnhUIniSIYQn+Fg4UiLoUiAUIBiSAHIBWFQgKJIhkgDyAQICqFQj6JIgpCf4WDhSInIAggDYVCOIkiJiAhIAQgMoVCG4kiBUJ/hYOFIiMgAyAGhUISiSIGIB4gFSAwhUIBiSIOQn+Fg4UiKiAEICKFQg6JIiIgDCACIAOFIgNCf4WDhSIvIBAgJIVCPYkiJCAcIAggLIVCHIkiAkJ/hYOFIgSFhYWFIgeFIgggAyAbIAxCf4WDhUKIAYUiCYUiFSABIAogGUJ/hYMgF4UiKyAFICZCf4WDIBOFIhQgDiAGQn+FgyAfhSIwIAMgIkJ/hYMgEYUiDCACICRCf4WDIB2FIguFhYWFIg1CAYmFIhAgBiAfQn+FgyAghSIBhUIriSIxICggGCAPQn+FgyAKhSIPIBYgIUJ/hYMgBYUiLCAgIB5Cf4WDIA6FIgogCSASIBxCf4WDIAKFIgWFhYWFIgYgGSAXQn+FgyAYhSIOICYgE0J/hYMgFoUiAyAiIBFCf4WDIBuFIgIgJCAdQn+FgyAShSIJhSABhYWFIgFCAYmFIhqFQiyJIhFCf4WDhUKJgIKACIUiMiAHQgGJIAGFIgcgDIVCHIkiGyAIIAqFQgOJIhwgBkIBiSANhSIMIASFQhSJIh1Cf4WDhSIihSAaICWFQgGJIhIgByAwhUIZiSIeIAkgEIVCBokiH0J/hYOFIiSFIAwgL4VCG4kiDSAaICmFQgqJIiAgBSAIhUIkiSIhQn+Fg4UiJYUgAiAQhUI+iSIBIAwgKoVCJ4kiEyAHIAuFQjeJIhZCf4WDhSIohSIpQgGJIAggLIVCKYkiFyABIBogLoVCAokiCkJ/hYOFIi4gAyAQhUIPiSIYIA0gByArhUI4iSIFQn+Fg4UiCSAMICOFQgiJIhkgEiAIIA+FQhKJIgZCf4WDhSIqIAcgFIVCFYkiJiAVIAwgJ4VCDokiA0J/hYOFIiMgGiAthUItiSInIBsgDiAQhUI9iSICQn+Fg4UiL4WFhYUiBIUiCCAWIAFCf4WDIAqFIgGFQg6JIhAgCSAKIBdCf4WDIBOFIgcgBSAYQn+FgyAghSIrIAYgGUJ/hYMgHoUiFCADICZCf4WDIDGFIjAgAiAnQn+FgyAchSIMhYWFhSILIAEgISANQn+FgyAFhSINIB8gEkJ/hYMgBoUiDyARIBVCf4WDIAOFIiwgHSAbQn+FgyAChSIKhYWFhSIFQgGJhSIahUIViSIVQn+FgyAUIBcgE0J/hYMgFoUiBiAYICBCf4WDICGFIg4gGSAeQn+FgyAfhSIDICYgMUJ/hYMgEYUiAiAnIBxCf4WDIB2FIgmFhYWFIgEgBEIBiYUiBIVCK4kiEYUiLSABQgGJIAWFIhQgJIVCA4kiASAEIAeFQj2JIhsgC0IBiSAphSILIA6FQi2JIhxCf4WDhSIkhSAaICqFQhmJIh0gFCAohUISiSISIAggDYVCCIkiHkJ/hYOFIiaFIAMgC4VCCokiHyAaIC6FQjiJIiAgBCArhUIPiSIhQn+Fg4UiJ4UgCCAPhUIniSIPIAYgC4VCAokiEyAUICWFQimJIhZCf4WDhSIohSIpQgGJIAQgMIVCPokiFyAPIBogL4VCN4kiBUJ/hYOFIi4gCCAshUIbiSIYIB8gFCAihUIkiSIGQn+Fg4UiKiACIAuFQgGJIhkgHSAEIAyFQgaJIg5Cf4WDhSIlIBQgMoUiIiARIAkgC4VCLIkiA0J/hYOFQoqAgIAIhSIJIBogI4VCHIkiIyABIAggCoVCFIkiAkJ/hYOFIi+FhYWFIgSFIgggHCABQn+FgyAChSIBhUIsiSIaIAkgBSAXQn+FgyAThSIHIAYgGEJ/hYMgIIUiKyAOIBlCf4WDIBKFIhQgAyAiQn+FgyAQhSIwIAIgI0J/hYMgG4UiDIWFhYUiCyAWIA9Cf4WDIAWFIg0gISAfQn+FgyAGhSIPIB4gHUJ/hYMgDoUiLCAVIBFCf4WDIAOFIgogAYWFhYUiBUIBiYUiEYUiMUJ/hYMgByAXIBNCf4WDIBaFIgYgGCAgQn+FgyAhhSIOIBkgEkJ/hYMgHoUiAyAiIBBCf4WDIBWFIgIgIyAbQn+FgyAchSIJhYWFhSIBIARCAYmFIgSFQg6JIhWFIjIgAUIBiSAFhSIHICiFQj2JIhsgBCAMhUIUiSIcIAIgC0IBiSAphSIChUIciSIdQn+Fg4UiKIUgESAuhUISiSISIAcgJIVCBokiHiAIIAqFQgGJIh9Cf4WDhSIihSACIAaFQjiJIgEgESAvhUIkiSIgIAQgMIVCG4kiIUJ/hYOFIiOFIAggDYVCAokiDSACIAmFQjeJIhMgByAthUI+iSIWQn+Fg4UiLYUiKUIBiSAEIBSFQieJIhcgDSARICqFQimJIgpCf4WDhSIkIAggLIVCCokiGCABIAcgJ4VCD4kiBUJ/hYOFIi4gAiADhUIZiSIZIBIgBCArhUIIiSIGQn+Fg4UiCSAHICaFQiuJIicgFSACIA6FQhWJIgNCf4WDhSIqIBEgJYVCA4kiJSAbIAggD4VCLYkiAkJ/hYOFIi+FhYWFIgSFIgggISABQn+FgyAFhSIBhUIViSIRIAkgCiAXQn+FgyAThSIHIAUgGEJ/hYMgIIUiKyAGIBlCf4WDIB6FIhQgAyAnQn+FgyAahSIwIAIgJUJ/hYMgHIUiDIWFhYUiCyAWIA1Cf4WDIAqFIg0gASAfIBJCf4WDIAaFIg8gMSAVQn+FgyADhSIsIB0gG0J/hYMgAoUiCoWFhYUiBUIBiYUiEIVCK4kiG0J/hYMgDCAXIBNCf4WDIBaFIgYgGCAgQn+FgyAhhSIOIBkgHkJ/hYMgH4UiAyAxICcgGkJ/hYOFQouBgoAIhSICICUgHEJ/hYMgHYUiCYWFhYUiASAEQgGJhSIVhUIsiSIMhSIlIAFCAYkgBYUiBCAohUIUiSIcIBUgK4VCLYkiHSADIAtCAYkgKYUiA4VCA4kiEkJ/hYOFIiiFIBAgL4VCBokiHiAEICOFQgiJIh8gCCAPhUIZiSIgQn+Fg4UiKYUgAyAJhUIkiSIhIBAgLoVCD4kiEyAUIBWFQgqJIhZCf4WDhSInhSAIIAqFQjeJIg8gAyAOhUIpiSIXIAQgIoVCJ4kiGEJ/hYOFIi6FIgFCAYkgByAVhUICiSIZIA8gECAqhUI+iSIKQn+Fg4UiIiAIIA2FQjiJIiYgISAEIDKFQhuJIgVCf4WDhSIjIAMgBoVCEokiBiAeIBUgMIVCAYkiDkJ/hYOFIiogBCAthUIOiSItIAwgAiADhSIDQn+Fg4UiLyAQICSFQj2JIiQgHCAIICyFQhyJIgJCf4WDhSIEhYWFhSIHhSIIIAMgGyAMQn+Fg4VCi4GAgICAgICAf4UiCYUiFSABIAogGUJ/hYMgF4UiKyAFICZCf4WDIBOFIhQgDiAGQn+FgyAfhSIwIAMgLUJ/hYMgEYUiDCACICRCf4WDIB2FIguFhYWFIg1CAYmFIhAgBiAfQn+FgyAghSIBhUIriSIxICggGCAPQn+FgyAKhSIPIBYgIUJ/hYMgBYUiLCAgIB5Cf4WDIA6FIgogCSASIBxCf4WDIAKFIgWFhYWFIgYgGSAXQn+FgyAYhSIOICYgE0J/hYMgFoUiAyAtIBFCf4WDIBuFIgIgJCAdQn+FgyAShSIJhSABhYWFIgFCAYmFIhqFQiyJIhFCf4WDhUKJgYKAgICAgIB/hSIyIAdCAYkgAYUiByAMhUIciSIbIAggCoVCA4kiHCAGQgGJIA2FIgwgBIVCFIkiHUJ/hYOFIi2FIBogJYVCAYkiEiAHIDCFQhmJIh4gCSAQhUIGiSIfQn+Fg4UiJYUgDCAvhUIbiSINIBogKYVCCokiICAFIAiFQiSJIiFCf4WDhSIkhSACIBCFQj6JIgEgDCAqhUIniSITIAcgC4VCN4kiFkJ/hYOFIiiFIilCAYkgCCAshUIpiSIXIAEgGiAuhUICiSIKQn+Fg4UiLiADIBCFQg+JIhggDSAHICuFQjiJIgVCf4WDhSIJIAwgI4VCCIkiGSASIAggD4VCEokiBkJ/hYOFIiogByAUhUIViSImIBUgDCAihUIOiSIDQn+Fg4UiIiAaICeFQi2JIiMgGyAOIBCFQj2JIgJCf4WDhSIvhYWFhSIEhSIIIBYgAUJ/hYMgCoUiAYVCDokiECAJIAogF0J/hYMgE4UiByAFIBhCf4WDICCFIisgBiAZQn+FgyAehSIUIAMgJkJ/hYMgMYUiMCACICNCf4WDIByFIgyFhYWFIgsgASAhIA1Cf4WDIAWFIg0gHyASQn+FgyAGhSIPIBEgFUJ/hYMgA4UiLCAdIBtCf4WDIAKFIgqFhYWFIgVCAYmFIhqFQhWJIhVCf4WDIBQgFyATQn+FgyAWhSIGIBggIEJ/hYMgIYUiDiAZIB5Cf4WDIB+FIgMgJiAxQn+FgyARhSICICMgHEJ/hYMgHYUiCYWFhYUiASAEQgGJhSIEhUIriSIRhSIjIAFCAYkgBYUiFCAlhUIDiSIBIAQgB4VCPYkiGyALQgGJICmFIgsgDoVCLYkiHEJ/hYOFIiWFIBogKoVCGYkiHSAUICiFQhKJIhIgCCANhUIIiSIeQn+Fg4UiJoUgAyALhUIKiSIfIBogLoVCOIkiICAEICuFQg+JIiFCf4WDhSInhSAIIA+FQieJIg8gBiALhUICiSITIBQgJIVCKYkiFkJ/hYOFIiiFIilCAYkgBCAwhUI+iSIXIA8gGiAvhUI3iSIFQn+Fg4UiLiAIICyFQhuJIhggHyAUIC2FQiSJIgZCf4WDhSIqIAIgC4VCAYkiGSAdIAQgDIVCBokiDkJ/hYOFIiQgFCAyhSItIBEgCSALhUIsiSIDQn+Fg4VCg4CCgICAgICAf4UiCSAaICKFQhyJIiIgASAIIAqFQhSJIgJCf4WDhSIvhYWFhSIEhSIIIBwgAUJ/hYMgAoUiAYVCLIkiGiAJIAUgF0J/hYMgE4UiByAGIBhCf4WDICCFIisgDiAZQn+FgyAShSIUIAMgLUJ/hYMgEIUiMCACICJCf4WDIBuFIgyFhYWFIgsgFiAPQn+FgyAFhSINICEgH0J/hYMgBoUiDyAeIB1Cf4WDIA6FIiwgFSARQn+FgyADhSIKIAGFhYWFIgVCAYmFIhGFIjFCf4WDIAcgFyATQn+FgyAWhSIGIBggIEJ/hYMgIYUiDiAZIBJCf4WDIB6FIgMgLSAQQn+FgyAVhSICICIgG0J/hYMgHIUiCYWFhYUiASAEQgGJhSIEhUIOiSIVhSIyIAFCAYkgBYUiByAohUI9iSIbIAQgDIVCFIkiHCACIAtCAYkgKYUiAoVCHIkiHUJ/hYOFIiiFIBEgLoVCEokiEiAHICWFQgaJIh4gCCAKhUIBiSIfQn+Fg4UiIoUgAiAGhUI4iSIBIBEgL4VCJIkiICAEIDCFQhuJIiFCf4WDhSIlhSAIIA2FQgKJIg0gAiAJhUI3iSITIAcgI4VCPokiFkJ/hYOFIi2FIilCAYkgBCAUhUIniSIXIA0gESAqhUIpiSIKQn+Fg4UiIyAIICyFQgqJIhggASAHICeFQg+JIgVCf4WDhSIuIAIgA4VCGYkiGSASIAQgK4VCCIkiBkJ/hYOFIgkgByAmhUIriSInIBUgAiAOhUIViSIDQn+Fg4UiKiARICSFQgOJIiQgGyAIIA+FQi2JIgJCf4WDhSIvhYWFhSIEhSIIICEgAUJ/hYMgBYUiAYVCFYkiESAJIAogF0J/hYMgE4UiByAFIBhCf4WDICCFIisgBiAZQn+FgyAehSIUIAMgJ0J/hYMgGoUiMCACICRCf4WDIByFIgyFhYWFIgsgFiANQn+FgyAKhSINIAEgHyASQn+FgyAGhSIPIDEgFUJ/hYMgA4UiLCAdIBtCf4WDIAKFIgqFhYWFIgVCAYmFIhCFQiuJIhtCf4WDIAwgFyATQn+FgyAWhSIGIBggIEJ/hYMgIYUiDiAZIB5Cf4WDIB+FIgMgMSAnIBpCf4WDhUKCgIKAgICAgIB/hSICICQgHEJ/hYMgHYUiCYWFhYUiASAEQgGJhSIVhUIsiSIMhSIkIAFCAYkgBYUiBCAohUIUiSIcIBUgK4VCLYkiHSADIAtCAYkgKYUiA4VCA4kiEkJ/hYOFIiiFIBAgL4VCBokiHiAEICWFQgiJIh8gCCAPhUIZiSIgQn+Fg4UiKYUgAyAJhUIkiSIhIBAgLoVCD4kiEyAUIBWFQgqJIhZCf4WDhSInhSAIIAqFQjeJIg8gAyAOhUIpiSIXIAQgIoVCJ4kiGEJ/hYOFIi6FIgFCAYkgByAVhUICiSIZIA8gECAqhUI+iSIKQn+Fg4UiIiAIIA2FQjiJIiYgISAEIDKFQhuJIgVCf4WDhSIlIAMgBoVCEokiBiAeIBUgMIVCAYkiDkJ/hYOFIiogBCAthUIOiSItIAwgAiADhSIDQn+Fg4UiLyAQICOFQj2JIiMgHCAIICyFQhyJIgJCf4WDhSIEhYWFhSIHhSIIIAMgGyAMQn+Fg4VCgIGAgICAgICAf4UiCYUiMSABIAogGUJ/hYMgF4UiKyAFICZCf4WDIBOFIhQgDiAGQn+FgyAfhSIwIAMgLUJ/hYMgEYUiDCACICNCf4WDIB2FIguFhYWFIg1CAYmFIhAgBiAfQn+FgyAghSIBhUIriSIVICggGCAPQn+FgyAKhSIPIBYgIUJ/hYMgBYUiLCAgIB5Cf4WDIA6FIgogCSASIBxCf4WDIAKFIgWFhYWFIgYgGSAXQn+FgyAYhSIOICYgE0J/hYMgFoUiAyAtIBFCf4WDIBuFIgIgIyAdQn+FgyAShSIJhSABhYWFIgFCAYmFIhqFQiyJIhFCf4WDhUKKgAKFIiYgB0IBiSABhSIHIAyFQhyJIhsgCCAKhUIDiSIcIAZCAYkgDYUiDCAEhUIUiSIdQn+Fg4UiMoUgGiAkhUIBiSISIAcgMIVCGYkiHiAJIBCFQgaJIh9Cf4WDhSIjhSAMIC+FQhuJIg0gGiAphUIKiSIgIAUgCIVCJIkiIUJ/hYOFIiSFIAIgEIVCPokiASAMICqFQieJIhMgByALhUI3iSIWQn+Fg4UiKIUiKUIBiSAIICyFQimJIhcgASAaIC6FQgKJIgpCf4WDhSIuIAMgEIVCD4kiGCANIAcgK4VCOIkiBUJ/hYOFIgkgDCAlhUIIiSIZIBIgCCAPhUISiSIGQn+Fg4UiKiAHIBSFQhWJIi0gMSAMICKFQg6JIgNCf4WDhSIlIBogJ4VCLYkiIiAbIA4gEIVCPYkiAkJ/hYOFIi+FhYWFIgSFIgggFiABQn+FgyAKhSIBhUIOiSIaIAkgCiAXQn+FgyAThSIHIAUgGEJ/hYMgIIUiKyAGIBlCf4WDIB6FIhQgAyAtQn+FgyAVhSIwIAIgIkJ/hYMgHIUiDIWFhYUiCyABICEgDUJ/hYMgBYUiDSAfIBJCf4WDIAaFIg8gESAxQn+FgyADhSIsIB0gG0J/hYMgAoUiCoWFhYUiBUIBiYUiEIVCFYkiMUJ/hYMgFCAXIBNCf4WDIBaFIgYgGCAgQn+FgyAhhSIOIBkgHkJ/hYMgH4UiAyAtIBVCf4WDIBGFIgIgIiAcQn+FgyAdhSIJhYWFhSIBIARCAYmFIgSFQiuJIhGFIiIgAUIBiSAFhSIUICOFQgOJIgEgBCAHhUI9iSIbIAtCAYkgKYUiCyAOhUItiSIcQn+Fg4UiI4UgECAqhUIZiSIdIBQgKIVCEokiEiAIIA2FQgiJIh5Cf4WDhSIthSADIAuFQgqJIh8gECAuhUI4iSIgIAQgK4VCD4kiIUJ/hYOFIieFIAggD4VCJ4kiDyAGIAuFQgKJIhMgFCAkhUIpiSIWQn+Fg4UiKIUiKUIBiSAEIDCFQj6JIhcgDyAQIC+FQjeJIgVCf4WDhSIuIAggLIVCG4kiGCAfIBQgMoVCJIkiBkJ/hYOFIiogAiALhUIBiSIZIB0gBCAMhUIGiSIOQn+Fg4UiJCAUICaFIjIgESAJIAuFQiyJIgNCf4WDhUKKgICAiICAgIB/hSIJIBAgJYVCHIkiJSABIAggCoVCFIkiAkJ/hYOFIi+FhYWFIgSFIjMgHCABQn+FgyAChSIBhUIsiSIQIAkgBSAXQn+FgyAThSIHIAYgGEJ/hYMgIIUiKyAOIBlCf4WDIBKFIhQgAyAyQn+FgyAahSIwIAIgJUJ/hYMgG4UiDIWFhYUiCyAWIA9Cf4WDIAWFIg0gISAfQn+FgyAGhSIPIB4gHUJ/hYMgDoUiLCAxIBFCf4WDIAOFIgogAYWFhYUiBUIBiYUiCIUiFUJ/hYMgByAXIBNCf4WDIBaFIgYgGCAgQn+FgyAhhSIOIBkgEkJ/hYMgHoUiAyAyIBpCf4WDIDGFIgIgJSAbQn+FgyAchSIJhYWFhSIBIARCAYmFIgSFQg6JIhGFIiYgAUIBiSAFhSIHICiFQj2JIhsgBCAMhUIUiSIcIAIgC0IBiSAphSIChUIciSIdQn+Fg4UiJYUgCCAuhUISiSISIAcgI4VCBokiHiAKIDOFQgGJIh9Cf4WDhSIyhSACIAaFQjiJIgEgCCAvhUIkiSIgIAQgMIVCG4kiIUJ/hYOFIiiFIA0gM4VCAokiDSACIAmFQjeJIhMgByAihUI+iSIWQn+Fg4UiIoUiKUIBiSAEIBSFQieJIhcgDSAIICqFQimJIgpCf4WDhSIjICwgM4VCCokiGCABIAcgJ4VCD4kiBUJ/hYOFIi4gAiADhUIZiSIZIBIgBCArhUIIiSIGQn+Fg4UiCSAHIC2FQiuJIicgESACIA6FQhWJIgNCf4WDhSIqIAggJIVCA4kiJCAbIA8gM4VCLYkiAkJ/hYOFIi+FhYWFIgSFIjMgISABQn+FgyAFhSIBhUIViSIaIAkgCiAXQn+FgyAThSIHIAUgGEJ/hYMgIIUiKyAGIBlCf4WDIB6FIhQgAyAnQn+FgyAQhSIwIAIgJEJ/hYMgHIUiDIWFhYUiCyAWIA1Cf4WDIAqFIg0gASAfIBJCf4WDIAaFIg8gFSARQn+FgyADhSIsIB0gG0J/hYMgAoUiCoWFhYUiBUIBiYUiCIVCK4kiMUJ/hYMgDCAXIBNCf4WDIBaFIgYgGCAgQn+FgyAhhSIOIBkgHkJ/hYMgH4UiAiAVICcgEEJ/hYOFQoGBgoCIgICAgH+FIgMgJCAcQn+FgyAdhSIJhYWFhSIBIARCAYmFIhGFQiyJIgyFIiQgAUIBiSAFhSIEICWFQhSJIhsgESArhUItiSIcIAtCAYkgKYUiASAChUIDiSIdQn+Fg4UiLYUgCCAvhUIGiSISIAQgKIVCCIkiHiAPIDOFQhmJIh9Cf4WDhSInhSABIAmFQiSJIiAgCCAuhUIPiSIhIBEgFIVCCokiE0J/hYOFIiWFIAogM4VCN4kiDyABIA6FQimJIhYgBCAyhUIniSIXQn+Fg4UiKIUiKUIBiSAHIBGFQgKJIhggDyAIICqFQj6JIgpCf4WDhSICIA0gM4VCOIkiGSAgIAQgJoVCG4kiBUJ/hYOFIi4gASAGhUISiSIyIBIgESAwhUIBiSIGQn+Fg4UiKiAEICKFQg6JIiIgDCABIAOFIg5Cf4WDhSIvIAggI4VCPYkiIyAbICwgM4VCHIkiA0J/hYOFIgSFhYWFIgeFIgggDiAxIAxCf4WDhUKAgYKAgICAgIB/hSIJhSIVIAIgCiAYQn+FgyAWhSIrIAUgGUJ/hYMgIYUiASAGIDJCf4WDIB6FIhQgDiAiQn+FgyAahSIwIAMgI0J/hYMgHIUiDIWFhYUiCyAXIA9Cf4WDIAqFIg0gEyAgQn+FgyAFhSIPIB8gEkJ/hYMgBoUiLCAJIB0gG0J/hYMgA4UiCoWFhYUiBUIBiYUiEIVCDokiEUJ/hYMgASAYIBZCf4WDIBeFIgYgGSAhQn+FgyAThSIOIDIgHkJ/hYMgH4UiAyAiIBpCf4WDIDGFIgIgIyAcQn+FgyAdhSIJhYWFhSIBIAdCAYmFIjGFQhWJIhaFIiIgAUIBiSAFhSIHICWFQi2JIhsgMCAxhUIciSIcIAtCAYkgKYUiASAGhUI9iSIdQn+Fg4UiI4UgECAuhUIIiSISIAcgJIVCAYkiHiAIIA2FQhKJIh9Cf4WDhSIkhSABIA6FQg+JIhcgECAvhUIbiSIgICsgMYVCOIkiIUJ/hYOFIiWFIAggD4VCKYkiDSABIAKFQj6JIhMgByAohUICiSIYQn+Fg4UiKIUiKUIBiSAMIDGFQjeJIhkgDSAQICqFQieJIg9Cf4WDhSICIAggCoVCJIkiJiAXIAcgJ4VCCokiBUJ/hYOFIi4gASAJhUIGiSIyIBIgFCAxhUIZiSIGQn+Fg4UiKiAHIC2FQiyJIi0gFiABIAOFQiuJIg5Cf4WDhSIvIAQgEIVCFIkiJyAbIAggLIVCA4kiA0J/hYOFIgSFhYWFIgeFIjEgESAWQn+FgyAOhSIJhUI+iSIWIAIgDyAZQn+FgyAThSIrIAUgJkJ/hYMgIIUiASAGIDJCf4WDIB6FIhQgFSAOIC1Cf4WDhUKBgICACIUiMCADICdCf4WDIByFIgyFhYWFIgsgGCANQn+FgyAPhSINICEgF0J/hYMgBYUiDyAfIBJCf4WDIAaFIiwgCSAdIBtCf4WDIAOFIgqFhYWFIgVCAYmFIhKFQgKJIhdCf4WDIAEgGSATQn+FgyAYhSIGICYgIEJ/hYMgIYUiDiAyIB5Cf4WDIB+FIgMgLSAVQn+FgyARhSICICcgHEJ/hYMgHYUiCYWFhYUiASAHQgGJhSIThUIpiSIYhTcDuAEgNCADIAtCAYkgKYUiA4VCJ4kiGSABQgGJIAWFIgEgI4VCN4kiJkJ/hYMgFoU3A6ABIDQgDyAxhUIPiSIyIAIgA4VCG4kiLSABICiFQjiJIidCf4WDhTcDkAEgNCAMIBOFQiSJIiMgMiASICqFQgqJIihCf4WDhTcDgAEgNCATICuFQhKJIikgCiAxhUIGiSIqIBIgL4VCAYkiB0J/hYOFNwNwIDQgAyAOhUIIiSIrIAEgJIVCGYkiDEJ/hYMgKoU3A1ggNCANIDGFQj2JIgsgAyAJhUIUiSINIAEgIoVCHIkiD0J/hYOFNwNIIDQgEyAUhUIDiSIKIAsgEiAuhUItiSIFQn+Fg4U3AzggNCADIAaFQg6JIg4gBCAShUIsiSIDIBMgMIUiAkJ/hYOFNwMgIDQgLCAxhUIriSIJIA4gASAlhUIViSIBQn+Fg4U3AxAgNCAmIBZCf4WDIBeFNwPAASA0IBcgGEJ/hYMgGYU3A7ABIDQgGCAZQn+FgyAmhTcDqAEgNCAjIC1Cf4WDICeFNwOYASA0ICcgMkJ/hYMgKIU3A4gBIDQgKCAjQn+FgyAthTcDeCA0IAcgKUJ/hYMgK4U3A2ggNCApICtCf4WDIAyFNwNgIDQgDCAqQn+FgyAHhTcDUCA1IA8gC0J/hYMgBYU3AwAgNCAFIApCf4WDIA2FNwMwIDQgCiANQn+FgyAPhTcDKCA0IAIgDkJ/hYMgAYU3AxggNCABIAlCf4WDIAOFNwMIIDQgAiAJIANCf4WDhUKIgIKAiICAgIB/hTcDACAAIDRByAH8CgAAIDRB0AFqJAALxgEBBX8jAEEQayICQQA6AA8CQCABRQ0AIAFBA3EhBCABQQRPBEAgAUF8cSEGA0AgAiAAIANqIgEtAAAgAi0AD3I6AA8gAiABLQABIAItAA9yOgAPIAIgAS0AAiACLQAPcjoADyACIAEtAAMgAi0AD3I6AA8gA0EEaiEDIAVBBGoiBSAGRw0ACyAERQ0BC0EAIQEDQCACIAAgA2otAAAgAi0AD3I6AA8gA0EBaiEDIAFBAWoiASAERw0ACwsgAi0AD0EBa0EfdguFCAEgfyMAQTBrIgIkACAAIAEQBCAAQdAAaiABQShqEAQgAEH4AGogAUHQAGoQrQEgASgCKCEDIAEoAiwhBCABKAIEIQUgASgCMCEGIAEoAgghByABKAI0IQggASgCDCEJIAEoAjghCiABKAIQIQsgASgCPCEMIAEoAhQhDSABQUBrKAIAIQ4gASgCGCEPIAEoAkQhECABKAIcIREgASgCSCESIAEoAiAhEyABKAIAIRQgACABKAJMIAEoAiRqNgJMIAAgEiATajYCSCAAIBAgEWo2AkQgAEFAayIWIA4gD2o2AgAgACAMIA1qNgI8IAAgCiALajYCOCAAIAggCWo2AjQgACAGIAdqNgIwIAAgBCAFajYCLCAAQShqIgEgAyAUajYCACACIAEQBCAAKAJQIQMgACgCBCEEIAAoAlQhBSAAKAIIIQYgACgCWCEHIAAoAgwhCCAAKAJcIQkgACgCECEKIAAoAmAhCyAAKAIUIQwgACgCZCENIAAoAhghDiAAKAJoIQ8gACgCHCEQIAAoAmwhESAAKAIgIRIgACgCcCETIAAoAgAhFCAAIAAoAnQiFSAAKAIkIhdrIhg2AnQgACATIBJrIhk2AnAgACARIBBrIho2AmwgACAPIA5rIhs2AmggACANIAxrIhw2AmQgACALIAprIh02AmAgACAJIAhrIh42AlwgACAHIAZrIh82AlggACAFIARrIiA2AlQgACADIBRrIiE2AlAgACAVIBdqIhU2AkwgACASIBNqIhI2AkggACAQIBFqIhA2AkQgFiAOIA9qIg42AgAgACAMIA1qIgw2AjwgACAKIAtqIgo2AjggACAIIAlqIgg2AjQgACAGIAdqIgY2AjAgACAEIAVqIgQ2AiwgASADIBRqIgE2AgAgAigCACEDIAIoAgQhBSACKAIIIQcgAigCDCEJIAIoAhAhCyACKAIUIQ0gAigCGCEPIAIoAhwhESACKAIgIRMgACACKAIkIBVrNgIkIAAgEyASazYCICAAIBEgEGs2AhwgACAPIA5rNgIYIAAgDSAMazYCFCAAIAsgCms2AhAgACAJIAhrNgIMIAAgByAGazYCCCAAIAUgBGs2AgQgACADIAFrNgIAIAAoAnghASAAKAJ8IQMgACgCgAEhBCAAKAKEASEFIAAoAogBIQYgACgCjAEhByAAKAKQASEIIAAoApQBIQkgACgCmAEhCiAAIAAoApwBIBhrNgKcASAAIAogGWs2ApgBIAAgCSAaazYClAEgACAIIBtrNgKQASAAIAcgHGs2AowBIAAgBiAdazYCiAEgACAFIB5rNgKEASAAIAQgH2s2AoABIAAgAyAgazYCfCAAIAEgIWs2AnggAkEwaiQAC6UFAQN/IwBBsAFrIgIkACACIAEoAAA2AgBBBCEDIAIgASgABDYCBCACIAEoAAg2AgggAiABKAAMIgE2AgwDQCACIANBAnRqIgQgA0EDcQR/IAEFIANBAnZBsIwCai0AACABQRh3IgFBCHZB/wFxQcCuAmotAABBCHQgAUH/AXFBwK4Cai0AAHIgAUEQdkH/AXFBwK4Cai0AAEEQdHIgAUEYdkHArgJqLQAAQRh0cnMLIARBEGsoAgBzIgE2AgAgA0EBaiIDQSxHDQALIAAgAigCADYCACAAIAIoAgQ2AgQgACACKAIINgIIIAAgAigCDDYCDCAAIAIoAhA2AhAgACACKAIUNgIUIAAgAigCGDYCGCAAIAIoAhw2AhwgACACKAIgNgIgIAAgAigCJDYCJCAAIAIoAig2AiggACACKAIsNgIsIAAgAigCMDYCMCAAIAIoAjQ2AjQgACACKAI4NgI4IAAgAigCPDYCPCAAQUBrIAIoAkA2AgAgACACKAJENgJEIAAgAigCSDYCSCAAIAIoAkw2AkwgACACKAJQNgJQIAAgAigCVDYCVCAAIAIoAlg2AlggACACKAJcNgJcIAAgAigCYDYCYCAAIAIoAmQ2AmQgACACKAJoNgJoIAAgAigCbDYCbCAAIAIoAnA2AnAgACACKAJ0NgJ0IAAgAigCeDYCeCAAIAIoAnw2AnwgACACKAKAATYCgAEgACACKAKEATYChAEgACACKAKIATYCiAEgACACKAKMATYCjAEgACACKAKQATYCkAEgACACKAKUATYClAEgACACKAKYATYCmAEgACACKAKcATYCnAEgACACKAKgATYCoAEgACACKAKkATYCpAEgACACKAKoATYCqAEgACACKAKsATYCrAEgAkGwAWokAAvKCAIBfgR/IwBBwAVrIgQkACAAQdAAaiIFIAAoAkhBA3ZB/wBxIgNqIQYCQCADQfAATwRAQYABIANrIgMEQCAGQZC2AiAD/AoAAAsgACAFIAQgBEGABWoQeyAFQQBB8AD8CwAMAQtB8AAgA2siA0UNACAGQZC2AiAD/AoAAAsgACAAQUBrKQMAIgJCOIYgAkKA/gODQiiGhCACQoCA/AeDQhiGIAJCgICA+A+DQgiGhIQgAkIIiEKAgID4D4MgAkIYiEKAgPwHg4QgAkIoiEKA/gODIAJCOIiEhIQ3A8ABIAAgACkDSCICQjiGIAJCgP4Dg0IohoQgAkKAgPwHg0IYhiACQoCAgPgPg0IIhoSEIAJCCIhCgICA+A+DIAJCGIhCgID8B4OEIAJCKIhCgP4DgyACQjiIhISENwPIASAAIAUgBCAEQYAFahB7IAEgACkDACICQjiGIAJCgP4Dg0IohoQgAkKAgPwHg0IYhiACQoCAgPgPg0IIhoSEIAJCCIhCgICA+A+DIAJCGIhCgID8B4OEIAJCKIhCgP4DgyACQjiIhISENwAAIAEgACkDCCICQjiGIAJCgP4Dg0IohoQgAkKAgPwHg0IYhiACQoCAgPgPg0IIhoSEIAJCCIhCgICA+A+DIAJCGIhCgID8B4OEIAJCKIhCgP4DgyACQjiIhISENwAIIAEgACkDECICQjiGIAJCgP4Dg0IohoQgAkKAgPwHg0IYhiACQoCAgPgPg0IIhoSEIAJCCIhCgICA+A+DIAJCGIhCgID8B4OEIAJCKIhCgP4DgyACQjiIhISENwAQIAEgACkDGCICQjiGIAJCgP4Dg0IohoQgAkKAgPwHg0IYhiACQoCAgPgPg0IIhoSEIAJCCIhCgICA+A+DIAJCGIhCgID8B4OEIAJCKIhCgP4DgyACQjiIhISENwAYIAEgACkDICICQjiGIAJCgP4Dg0IohoQgAkKAgPwHg0IYhiACQoCAgPgPg0IIhoSEIAJCCIhCgICA+A+DIAJCGIhCgID8B4OEIAJCKIhCgP4DgyACQjiIhISENwAgIAEgACkDKCICQjiGIAJCgP4Dg0IohoQgAkKAgPwHg0IYhiACQoCAgPgPg0IIhoSEIAJCCIhCgICA+A+DIAJCGIhCgID8B4OEIAJCKIhCgP4DgyACQjiIhISENwAoIAEgACkDMCICQjiGIAJCgP4Dg0IohoQgAkKAgPwHg0IYhiACQoCAgPgPg0IIhoSEIAJCCIhCgICA+A+DIAJCGIhCgID8B4OEIAJCKIhCgP4DgyACQjiIhISENwAwIAEgACkDOCICQjiGIAJCgP4Dg0IohoQgAkKAgPwHg0IYhiACQoCAgPgPg0IIhoSEIAJCCIhCgICA+A+DIAJCGIhCgID8B4OEIAJCKIhCgP4DgyACQjiIhISENwA4IARBwAUQByAAQdABEAcgBEHABWokAEEAC44FARF/An8gA0UEQEGy2ojLByEGQe7IgZkDIQdB5fDBiwYhBEH0yoHZBgwBCyADKAAIIQYgAygABCEHIAMoAAAhBCADKAAMCyEPIAEoAAwhBSABKAAIIQwgASgABCEIIAIoABwhCiACKAAYIQsgAigAFCEQIAIoABAhDiACKAAMIQMgAigACCENIAIoAAQhCSABKAAAIQEgAigAACECA0AgAiABIAIgBGoiAnNBEHciASAOaiIEc0EMdyIOIAJqIhEgAXNBCHciASAEaiIEIA5zQQd3IgIgAyAFIAMgD2oiA3NBEHciBSAKaiIKc0EMdyIOIANqIgNqIg8gDSAMIAYgDWoiBnNBEHciDCALaiINc0EMdyILIAZqIgYgDHNBCHciE3NBEHciDCAJIAggByAJaiIHc0EQdyIIIBBqIglzQQx3IhQgB2oiByAIc0EIdyIIIAlqIglqIhAgAnNBDHciAiAPaiIPIAxzQQh3IgwgEGoiECACc0EHdyECIAQgAyAFc0EIdyIEIApqIgUgDnNBB3ciAyAGaiIGIAhzQRB3IghqIgogA3NBDHciAyAGaiIGIAhzQQh3IgggCmoiDiADc0EHdyEDIAUgASANIBNqIgUgC3NBB3ciASAHaiIHc0EQdyINaiIKIAFzQQx3IgsgB2oiByANc0EIdyIBIApqIgogC3NBB3chDSAFIAQgCSAUc0EHdyIEIBFqIgVzQRB3IglqIgsgBHNBDHciESAFaiIEIAlzQQh3IgUgC2oiCyARc0EHdyEJIBJBAWoiEkEKRw0ACyAAIAQ2AAAgACAFNgAcIAAgDDYAGCAAIAg2ABQgACABNgAQIAAgDzYADCAAIAY2AAggACAHNgAEQQALyAQBAn8jAEEQayIDJAAgA0EAOgAPQX8hBCAAIAEgAkG4vQIoAgARAwBFBEAgAyAALQAAIAMtAA9yOgAPIAMgAC0AASADLQAPcjoADyADIAAtAAIgAy0AD3I6AA8gAyAALQADIAMtAA9yOgAPIAMgAC0ABCADLQAPcjoADyADIAAtAAUgAy0AD3I6AA8gAyAALQAGIAMtAA9yOgAPIAMgAC0AByADLQAPcjoADyADIAAtAAggAy0AD3I6AA8gAyAALQAJIAMtAA9yOgAPIAMgAC0ACiADLQAPcjoADyADIAAtAAsgAy0AD3I6AA8gAyAALQAMIAMtAA9yOgAPIAMgAC0ADSADLQAPcjoADyADIAAtAA4gAy0AD3I6AA8gAyAALQAPIAMtAA9yOgAPIAMgAC0AECADLQAPcjoADyADIAAtABEgAy0AD3I6AA8gAyAALQASIAMtAA9yOgAPIAMgAC0AEyADLQAPcjoADyADIAAtABQgAy0AD3I6AA8gAyAALQAVIAMtAA9yOgAPIAMgAC0AFiADLQAPcjoADyADIAAtABcgAy0AD3I6AA8gAyAALQAYIAMtAA9yOgAPIAMgAC0AGSADLQAPcjoADyADIAAtABogAy0AD3I6AA8gAyAALQAbIAMtAA9yOgAPIAMgAC0AHCADLQAPcjoADyADIAAtAB0gAy0AD3I6AA8gAyAALQAeIAMtAA9yOgAPIAMgAC0AHyADLQAPcjoADyADLQAPQRd0QYCAgARrQR91IQQLIANBEGokACAECwQAQQALYgEDfyMAQbABayICJAAgAkHgAGoiAyABQdAAahBFIAJBMGoiBCABIAMQBSACIAFBKGogAxAFIAAgAhAPIAJBkAFqIAQQDyAAIAAtAB8gAi0AkAFBB3RzOgAfIAJBsAFqJAALxSgBC38jAEEQayIKJAACQAJAAkACQAJAAkACQAJAAkACQCAAQfQBTQRAQcTEAigCACIEQRAgAEELakH4A3EgAEELSRsiBkEDdiIAdiIBQQNxBEACQCABQX9zQQFxIABqIgNBA3QiAUHsxAJqIgAgASgC9MQCIgIoAggiBUYEQEHExAIgBEF+IAN3cTYCAAwBCyAFIAA2AgwgACAFNgIICyACQQhqIQAgAiABQQNyNgIEIAEgAmoiASABKAIEQQFyNgIEDAsLIAZBzMQCKAIAIghNDQEgAQRAAkBBAiAAdCICQQAgAmtyIAEgAHRxaCIDQQN0IgFB7MQCaiICIAEoAvTEAiIAKAIIIgVGBEBBxMQCIARBfiADd3EiBDYCAAwBCyAFIAI2AgwgAiAFNgIICyAAIAZBA3I2AgQgACAGaiIHIAEgBmsiBUEBcjYCBCAAIAFqIAU2AgAgCARAIAhBeHFB7MQCaiEBQdjEAigCACECAn8gBEEBIAhBA3Z0IgNxRQRAQcTEAiADIARyNgIAIAEMAQsgASgCCAshAyABIAI2AgggAyACNgIMIAIgATYCDCACIAM2AggLIABBCGohAEHYxAIgBzYCAEHMxAIgBTYCAAwLC0HIxAIoAgAiC0UNASALaEECdCgC9MYCIgEoAgRBeHEgBmshAyABIQIDQAJAIAEoAhAiAEUEQCABKAIUIgBFDQELIAAoAgRBeHEgBmsiASADIAEgA0kiARshAyAAIAIgARshAiAAIQEMAQsLIAIoAhghCSACIAIoAgwiAEcEQCACKAIIIgEgADYCDCAAIAE2AggMCgsgAigCFCIBBH8gAkEUagUgAigCECIBRQ0DIAJBEGoLIQUDQCAFIQcgASIAQRRqIQUgACgCFCIBDQAgAEEQaiEFIAAoAhAiAQ0ACyAHQQA2AgAMCQtBfyEGIABBv39LDQAgAEELaiIBQXhxIQZByMQCKAIAIgdFDQBBHyEIQQAgBmshAyAAQfT//wdNBEAgBkEmIAFBCHZnIgBrdkEBcSAAQQF0a0E+aiEICwJAAkACQCAIQQJ0KAL0xgIiAUUEQEEAIQAMAQtBACEAIAZBGSAIQQF2a0EAIAhBH0cbdCECA0ACQCABKAIEQXhxIAZrIgQgA08NACABIQUgBCIDDQBBACEDIAEhAAwDCyAAIAEoAhQiBCAEIAEgAkEddkEEcWooAhAiAUYbIAAgBBshACACQQF0IQIgAQ0ACwsgACAFckUEQEEAIQVBAiAIdCIAQQAgAGtyIAdxIgBFDQMgAGhBAnQoAvTGAiEACyAARQ0BCwNAIAAoAgRBeHEgBmsiAiADSSEBIAIgAyABGyEDIAAgBSABGyEFIAAoAhAiAQR/IAEFIAAoAhQLIgANAAsLIAVFDQAgA0HMxAIoAgAgBmtPDQAgBSgCGCEIIAUgBSgCDCIARwRAIAUoAggiASAANgIMIAAgATYCCAwICyAFKAIUIgEEfyAFQRRqBSAFKAIQIgFFDQMgBUEQagshAgNAIAIhBCABIgBBFGohAiAAKAIUIgENACAAQRBqIQIgACgCECIBDQALIARBADYCAAwHCyAGQczEAigCACIFTQRAQdjEAigCACEAAkAgBSAGayIBQRBPBEAgACAGaiICIAFBAXI2AgQgACAFaiABNgIAIAAgBkEDcjYCBAwBCyAAIAVBA3I2AgQgACAFaiIBIAEoAgRBAXI2AgRBACEBQQAhAgtBzMQCIAE2AgBB2MQCIAI2AgAgAEEIaiEADAkLIAZB0MQCKAIAIgJJBEBB0MQCIAIgBmsiATYCAEHcxAJB3MQCKAIAIgAgBmoiAjYCACACIAFBAXI2AgQgACAGQQNyNgIEIABBCGohAAwJC0EAIQAgBkEvaiIDAn9BnMgCKAIABEBBpMgCKAIADAELQajIAkJ/NwIAQaDIAkKAoICAgIAENwIAQZzIAiAKQQxqQXBxQdiq1aoFczYCAEGwyAJBADYCAEGAyAJBADYCAEGAIAsiAWoiBEEAIAFrIgdxIgEgBk0NCEH8xwIoAgAiBQRAQfTHAigCACIIIAFqIgkgCE0NCSAFIAlJDQkLAkBBgMgCLQAAQQRxRQRAAkACQAJAAkBB3MQCKAIAIgUEQEGEyAIhAANAIAAoAgAiCCAFTQRAIAUgCCAAKAIEakkNAwsgACgCCCIADQALC0EAEFAiAkF/Rg0DIAEhBEGgyAIoAgAiAEEBayIFIAJxBEAgASACayACIAVqQQAgAGtxaiEECyAEIAZNDQNB/McCKAIAIgAEQEH0xwIoAgAiBSAEaiIHIAVNDQQgACAHSQ0ECyAEEFAiACACRw0BDAULIAQgAmsgB3EiBBBQIgIgACgCACAAKAIEakYNASACIQALIABBf0YNASAGQTBqIARNBEAgACECDAQLQaTIAigCACICIAMgBGtqQQAgAmtxIgIQUEF/Rg0BIAIgBGohBCAAIQIMAwsgAkF/Rw0CC0GAyAJBgMgCKAIAQQRyNgIACyABEFAhAkEAEFAhACACQX9GDQUgAEF/Rg0FIAAgAk0NBSAAIAJrIgQgBkEoak0NBQtB9McCQfTHAigCACAEaiIANgIAQfjHAigCACAASQRAQfjHAiAANgIACwJAQdzEAigCACIDBEBBhMgCIQADQCACIAAoAgAiASAAKAIEIgVqRg0CIAAoAggiAA0ACwwEC0HUxAIoAgAiAEEAIAAgAk0bRQRAQdTEAiACNgIAC0EAIQBBiMgCIAQ2AgBBhMgCIAI2AgBB5MQCQX82AgBB6MQCQZzIAigCADYCAEGQyAJBADYCAANAIABBA3QiASABQezEAmoiBTYC9MQCIAEgBTYC+MQCIABBAWoiAEEgRw0AC0HQxAIgBEEoayIAQXggAmtBB3EiAWsiBTYCAEHcxAIgASACaiIBNgIAIAEgBUEBcjYCBCAAIAJqQSg2AgRB4MQCQazIAigCADYCAAwECyACIANNDQIgASADSw0CIAAoAgxBCHENAiAAIAQgBWo2AgRB3MQCIANBeCADa0EHcSIAaiIBNgIAQdDEAkHQxAIoAgAgBGoiAiAAayIANgIAIAEgAEEBcjYCBCACIANqQSg2AgRB4MQCQazIAigCADYCAAwDC0EAIQAMBgtBACEADAQLQdTEAigCACACSwRAQdTEAiACNgIACyACIARqIQVBhMgCIQACQANAIAUgACgCACIBRwRAIAAoAggiAA0BDAILCyAALQAMQQhxRQ0DC0GEyAIhAANAAkAgACgCACIBIANNBEAgAyABIAAoAgRqIgVJDQELIAAoAgghAAwBCwtB0MQCIARBKGsiAEF4IAJrQQdxIgFrIgc2AgBB3MQCIAEgAmoiATYCACABIAdBAXI2AgQgACACakEoNgIEQeDEAkGsyAIoAgA2AgAgAyAFQScgBWtBB3FqQS9rIgAgACADQRBqSRsiAUEbNgIEIAFBjMgCKQIANwIQIAFBhMgCKQIANwIIQYzIAiABQQhqNgIAQYjIAiAENgIAQYTIAiACNgIAQZDIAkEANgIAIAFBGGohAANAIABBBzYCBCAAQQhqIABBBGohACAFSQ0ACyABIANGDQAgASABKAIEQX5xNgIEIAMgASADayICQQFyNgIEIAEgAjYCAAJ/IAJB/wFNBEAgAkH4AXFB7MQCaiEAAn9BxMQCKAIAIgFBASACQQN2dCICcUUEQEHExAIgASACcjYCACAADAELIAAoAggLIQEgACADNgIIIAEgAzYCDEEMIQJBCAwBC0EfIQAgAkH///8HTQRAIAJBJiACQQh2ZyIAa3ZBAXEgAEEBdHJBPnMhAAsgAyAANgIcIANCADcCECAAQQJ0QfTGAmohAQJAAkBByMQCKAIAIgVBASAAdCIEcUUEQEHIxAIgBCAFcjYCACABIAM2AgAMAQsgAkEZIABBAXZrQQAgAEEfRxt0IQAgASgCACEFA0AgBSIBKAIEQXhxIAJGDQIgAEEddiEFIABBAXQhACABIAVBBHFqIgQoAhAiBQ0ACyAEIAM2AhALIAMgATYCGEEIIQIgAyIBIQBBDAwBCyABKAIIIgAgAzYCDCABIAM2AgggAyAANgIIQQAhAEEYIQJBDAsgA2ogATYCACACIANqIAA2AgALQdDEAigCACIAIAZNDQBB0MQCIAAgBmsiATYCAEHcxAJB3MQCKAIAIgAgBmoiAjYCACACIAFBAXI2AgQgACAGQQNyNgIEIABBCGohAAwEC0HAxAJBMDYCAEEAIQAMAwsgACACNgIAIAAgACgCBCAEajYCBCACQXggAmtBB3FqIgggBkEDcjYCBCABQXggAWtBB3FqIgQgBiAIaiIDayEHAkBB3MQCKAIAIARGBEBB3MQCIAM2AgBB0MQCQdDEAigCACAHaiIANgIAIAMgAEEBcjYCBAwBC0HYxAIoAgAgBEYEQEHYxAIgAzYCAEHMxAJBzMQCKAIAIAdqIgA2AgAgAyAAQQFyNgIEIAAgA2ogADYCAAwBCyAEKAIEIgBBA3FBAUYEQCAAQXhxIQkgBCgCDCECAkAgAEH/AU0EQCAEKAIIIgEgAkYEQEHExAJBxMQCKAIAQX4gAEEDdndxNgIADAILIAEgAjYCDCACIAE2AggMAQsgBCgCGCEGAkAgAiAERwRAIAQoAggiACACNgIMIAIgADYCCAwBCwJAIAQoAhQiAAR/IARBFGoFIAQoAhAiAEUNASAEQRBqCyEBA0AgASEFIAAiAkEUaiEBIAAoAhQiAA0AIAJBEGohASACKAIQIgANAAsgBUEANgIADAELQQAhAgsgBkUNAAJAIAQoAhwiAEECdCIBKAL0xgIgBEYEQCABQfTGAmogAjYCACACDQFByMQCQcjEAigCAEF+IAB3cTYCAAwCCwJAIAQgBigCEEYEQCAGIAI2AhAMAQsgBiACNgIUCyACRQ0BCyACIAY2AhggBCgCECIABEAgAiAANgIQIAAgAjYCGAsgBCgCFCIARQ0AIAIgADYCFCAAIAI2AhgLIAcgCWohByAEIAlqIgQoAgQhAAsgBCAAQX5xNgIEIAMgB0EBcjYCBCADIAdqIAc2AgAgB0H/AU0EQCAHQfgBcUHsxAJqIQACf0HExAIoAgAiAUEBIAdBA3Z0IgJxRQRAQcTEAiABIAJyNgIAIAAMAQsgACgCCAshASAAIAM2AgggASADNgIMIAMgADYCDCADIAE2AggMAQtBHyECIAdB////B00EQCAHQSYgB0EIdmciAGt2QQFxIABBAXRyQT5zIQILIAMgAjYCHCADQgA3AhAgAkECdEH0xgJqIQACQAJAQcjEAigCACIBQQEgAnQiBXFFBEBByMQCIAEgBXI2AgAgACADNgIADAELIAdBGSACQQF2a0EAIAJBH0cbdCECIAAoAgAhAQNAIAEiACgCBEF4cSAHRg0CIAJBHXYhASACQQF0IQIgACABQQRxaiIFKAIQIgENAAsgBSADNgIQCyADIAA2AhggAyADNgIMIAMgAzYCCAwBCyAAKAIIIgEgAzYCDCAAIAM2AgggA0EANgIYIAMgADYCDCADIAE2AggLIAhBCGohAAwCCwJAIAhFDQACQCAFKAIcIgFBAnQiAigC9MYCIAVGBEAgAkH0xgJqIAA2AgAgAA0BQcjEAiAHQX4gAXdxIgc2AgAMAgsCQCAFIAgoAhBGBEAgCCAANgIQDAELIAggADYCFAsgAEUNAQsgACAINgIYIAUoAhAiAQRAIAAgATYCECABIAA2AhgLIAUoAhQiAUUNACAAIAE2AhQgASAANgIYCwJAIANBD00EQCAFIAMgBmoiAEEDcjYCBCAAIAVqIgAgACgCBEEBcjYCBAwBCyAFIAZBA3I2AgQgBSAGaiIEIANBAXI2AgQgAyAEaiADNgIAIANB/wFNBEAgA0H4AXFB7MQCaiEAAn9BxMQCKAIAIgFBASADQQN2dCICcUUEQEHExAIgASACcjYCACAADAELIAAoAggLIQEgACAENgIIIAEgBDYCDCAEIAA2AgwgBCABNgIIDAELQR8hACADQf///wdNBEAgA0EmIANBCHZnIgBrdkEBcSAAQQF0ckE+cyEACyAEIAA2AhwgBEIANwIQIABBAnRB9MYCaiEBAkACQCAHQQEgAHQiAnFFBEBByMQCIAIgB3I2AgAgASAENgIAIAQgATYCGAwBCyADQRkgAEEBdmtBACAAQR9HG3QhACABKAIAIQEDQCABIgIoAgRBeHEgA0YNAiAAQR12IQEgAEEBdCEAIAIgAUEEcWoiBygCECIBDQALIAcgBDYCECAEIAI2AhgLIAQgBDYCDCAEIAQ2AggMAQsgAigCCCIAIAQ2AgwgAiAENgIIIARBADYCGCAEIAI2AgwgBCAANgIICyAFQQhqIQAMAQsCQCAJRQ0AAkAgAigCHCIBQQJ0IgUoAvTGAiACRgRAIAVB9MYCaiAANgIAIAANAUHIxAIgC0F+IAF3cTYCAAwCCwJAIAIgCSgCEEYEQCAJIAA2AhAMAQsgCSAANgIUCyAARQ0BCyAAIAk2AhggAigCECIBBEAgACABNgIQIAEgADYCGAsgAigCFCIBRQ0AIAAgATYCFCABIAA2AhgLAkAgA0EPTQRAIAIgAyAGaiIAQQNyNgIEIAAgAmoiACAAKAIEQQFyNgIEDAELIAIgBkEDcjYCBCACIAZqIgUgA0EBcjYCBCADIAVqIAM2AgAgCARAIAhBeHFB7MQCaiEAQdjEAigCACEBAn9BASAIQQN2dCIHIARxRQRAQcTEAiAEIAdyNgIAIAAMAQsgACgCCAshBCAAIAE2AgggBCABNgIMIAEgADYCDCABIAQ2AggLQdjEAiAFNgIAQczEAiADNgIACyACQQhqIQALIApBEGokACAAC/UCAQN/IwBBsANrIgMkACADIAEpABg3AxggAyABKQAQNwMQIAMgASkACDcDCCADIAEpAAA3AwAgAyACOgAgIANBMGoiAUEAQcgB/AsAIAFBgD47AeQBIAFBADYC4AEgASADQiEQcRogASADQbACakGAARB2GgNAIAAgBEEEdGoiAiADQbACaiIFIARBAnRqKAIAIgFBAXZB1arVqgVxIAFB1arVqgVxaiIBQRx2QQNxIAFBHnZrOwEOIAIgAUEYdkEDcSABQRp2QQNxazsBDCACIAFBFHZBA3EgAUEWdkEDcWs7AQogAiABQRB2QQNxIAFBEnZBA3FrOwEIIAIgAUEMdkEDcSABQQ52QQNxazsBBiACIAFBCHZBA3EgAUEKdkEDcWs7AQQgAiABQQR2QQNxIAFBBnZBA3FrOwECIAIgAUEDcSABQQJ2QQNxazsBACAEQQFqIgRBIEcNAAsgA0EwakGAAhAHIAVBgAEQByADQbADaiQAC9c5AS5+IAAgACkAqAEiCiAAKQCAASIbIAApAFgiFSAAKQAwIgEgACkACCIDhYWFhSICIAApALgBIg4gACkAkAEiCyAAKQBoIhwgACkAQCIGIAApABgiEIWFhYUiFkIBiYUiBSAAKQA4IgSFQgaJIhkgAyAAKQCgASIXIAApAHgiEyAAKQBQIiEgACkAKCIRIAApAAAiDIWFhYUiFCAAKQCwASINIAApAIgBIgcgACkAYCIPIAQgACkAECIYhYWFhSIIQgGJhSIEhUIBiSIaQn+FgyAAKQDAASISIAApAJgBIh4gACkAcCIJIAApAEgiIiAAKQAgIiOFhYWFIiQgAkIBiYUiAyAXhUISiSIXhSImIBYgFEIBiYUiAiAShUIOiSIWIAEgBIVCLIkiFCADIAyFIgxCf4WDhSIlhSAkQgGJIAiFIgEgDoVCOIkiDiADIBGFQiSJIhEgAiAjhUIbiSIIQn+Fg4UiI4UgBSANhUI9iSINIAIgIoVCFIkiEiABIBCFQhyJIhBCf4WDhSIihSAEIAqFQgKJIgogASAGhUI3iSIGIAUgGIVCPokiGEJ/hYOFIiSFIh1CAYkgBCAVhUIKiSIVIA4gBSAHhUIPiSIHQn+Fg4UiHyAFIA+FQiuJIg8gFiABIAuFQhWJIgtCf4WDhSInIAIgCYVCJ4kiCSAKIAMgE4VCKYkiE0J/hYOFIiAgASAchUIZiSIBIBcgAiAehUIIiSICQn+Fg4UiHCADICGFQgOJIgMgDSAEIBuFQi2JIgRCf4WDhSIbhYWFhSIhhSIFIAggDkJ/hYMgB4UiHoVCFYkiDiAcIAIgAUJ/hYMgGYUiKCALIA9Cf4WDIBSFIikgBiATIAlCf4WDhSIqIAcgFUJ/hYMgEYUiByAEIANCf4WDIBKFIiuFhYWFIiwgHiAQIA1Cf4WDIASFIi0gGCAKQn+FgyAThSITIBogF0J/hYMgAoUiDSALIAwgFkJ/hYOFIi6FhYWFIgJCAYmFIgSFQiuJIhdCf4WDICsgCSAGQn+FgyAYhSIJIAEgGUJ/hYMgGoUiCiAVIBFCf4WDIAiFIgYgDCAPIBRCf4WDhUKLgYKACIUiHCAQIAMgEkJ/hYOFIhKFhYWFIgEgIUIBiYUiA4VCLIkiGYUiISABQgGJIAKFIgIgIoVCFIkiGiADIAeFQi2JIhYgCiAsQgGJIB2FIgGFQgOJIhRCf4WDhSIehSAEIBuFQgaJIgwgAiAjhUIIiSIRIAUgDYVCGYkiCEJ/hYOFIiKFIAEgEoVCJIkiDSAEIB+FQg+JIhIgAyAohUIKiSIQQn+Fg4UiI4UgBSAthUI3iSIKIAEgBoVCKYkiBiACICaFQieJIhhCf4WDhSImhSIdQgGJIAMgKoVCAokiFSAKIAQgJ4VCPokiB0J/hYOFIh8gBSAThUI4iSIPIA0gAiAlhUIbiSILQn+Fg4UiJSABIAmFQhKJIgkgDCADICmFQgGJIgNCf4WDhSInIAIgJIVCDokiAiAZIAEgHIUiAUJ/hYOFIhwgBCAghUI9iSITIBogBSAuhUIciSIbQn+Fg4UiJIWFhYUiIIUiBSABIBcgGUJ/hYOFQouBgICAgICAgH+FIiiFIhkgHSAHIBVCf4WDIAaFIikgCyAPQn+FgyAShSIqIAMgCUJ/hYMgEYUiKyAbIBNCf4WDIBaFIiwgASACQn+FgyAOhSIBhYWFhSItQgGJhSIEIAkgEUJ/hYMgCIUiCYVCK4kiESAeIBggCkJ/hYMgB4UiHSAQIA1Cf4WDIAuFIgcgCCAMQn+FgyADhSIMICggFCAaQn+FgyAbhSIKhYWFhSIIIBUgBkJ/hYMgGIUiGyAPIBJCf4WDIBCFIg8gAiAOQn+FgyAXhSIGIBMgFkJ/hYMgFIUiDYUgCYWFhSICQgGJhSIDhUIsiSIaQn+Fg4VCiYGCgICAgICAf4UiHiAgQgGJIAKFIgIgAYVCHIkiFyAFIAyFQgOJIhYgCEIBiSAthSIBICSFQhSJIhRCf4WDhSIkhSADICGFQgGJIgwgAiArhUIZiSIOIAQgDYVCBokiCEJ/hYOFIiGFIAEgHIVCG4kiDSADICKFQgqJIhIgBSAKhUIkiSIQQn+Fg4UiHIUgBCAGhUI+iSIKIAEgJ4VCJ4kiBiACICyFQjeJIhhCf4WDhSIihSInQgGJIAUgB4VCKYkiFSAKIAMgJoVCAokiB0J/hYOFIiYgBCAPhUIPiSIPIA0gAiAphUI4iSILQn+Fg4UiICABICWFQgiJIgkgDCAFIB2FQhKJIhNCf4WDhSIlIAIgKoVCFYkiAiAZIAEgH4VCDokiAUJ/hYOFIh0gAyAjhUItiSIDIBcgBCAbhUI9iSIEQn+Fg4UiG4WFhYUiI4UiBSAYIApCf4WDIAeFIh+FQg6JIgogICAHIBVCf4WDIAaFIgcgCyAPQn+FgyAShSIoIBMgCUJ/hYMgDoUiKSABIAJCf4WDIBGFIiogBCADQn+FgyAWhSIrhYWFhSIsIB8gECANQn+FgyALhSINIAggDEJ/hYMgE4UiCyAaIBlCf4WDIAGFIhMgFCAXQn+FgyAEhSIthYWFhSIBQgGJhSIEhUIViSIZQn+FgyApIBUgBkJ/hYMgGIUiBiAPIBJCf4WDIBCFIgwgCSAOQn+FgyAIhSIIIAIgEUJ/hYMgGoUiCSADIBZCf4WDIBSFIh+FhYWFIgIgI0IBiYUiA4VCK4kiGoUiIyACQgGJIAGFIgIgIYVCA4kiFyADIAeFQj2JIhYgLEIBiSAnhSIBIAyFQi2JIhRCf4WDhSIhhSAEICWFQhmJIgwgAiAihUISiSIOIAUgDYVCCIkiEUJ/hYOFIiKFIAEgCIVCCokiCCAEICaFQjiJIg0gAyAohUIPiSISQn+Fg4UiJoUgBSALhUIniSIQIAEgBoVCAokiBiACIByFQimJIhhCf4WDhSIchSIlQgGJIAMgKoVCPokiFSAQIAQgG4VCN4kiB0J/hYOFIhsgBSAThUIbiSIPIAggAiAkhUIkiSILQn+Fg4UiJCABIAmFQgGJIgkgDCADICuFQgaJIgNCf4WDhSInIAIgHoUiAiAaIAEgH4VCLIkiAUJ/hYOFQoOAgoCAgICAgH+FIh4gBCAdhUIciSITIBcgBSAthUIUiSIEQn+Fg4UiHYWFhYUiH4UiBSAUIBdCf4WDIASFIiCFQiyJIhcgHiAHIBVCf4WDIAaFIiggCyAPQn+FgyANhSIpIAMgCUJ/hYMgDoUiKiABIAJCf4WDIAqFIisgBCATQn+FgyAWhSIshYWFhSItIBggEEJ/hYMgB4UiByASIAhCf4WDIAuFIi4gESAMQn+FgyADhSILIBkgGkJ/hYMgAYUiCCAghYWFhSIBQgGJhSIEhSIaQn+FgyAoIBUgBkJ/hYMgGIUiECAPIA1Cf4WDIBKFIh4gCSAOQn+FgyARhSIJIAIgCkJ/hYMgGYUiDCATIBZCf4WDIBSFIgaFhYWFIgIgH0IBiYUiA4VCDokiGYUiHyACQgGJIAGFIgIgHIVCPYkiFiADICyFQhSJIhQgLUIBiSAlhSIBIAyFQhyJIgxCf4WDhSIchSAEIBuFQhKJIg4gAiAhhUIGiSIRIAUgCIVCAYkiCEJ/hYOFIhuFIAEgEIVCOIkiDSAEIB2FQiSJIhIgAyArhUIbiSIQQn+Fg4UiIYUgBSAHhUICiSIKIAEgBoVCN4kiBiACICOFQj6JIhhCf4WDhSIjhSIlQgGJIAMgKoVCJ4kiFSAKIAQgJIVCKYkiB0J/hYOFIiQgBSALhUIKiSIPIA0gAiAmhUIPiSILQn+Fg4UiJiABIAmFQhmJIgkgDiADICmFQgiJIgNCf4WDhSIdIAIgIoVCK4kiAiAZIAEgHoVCFYkiAUJ/hYOFIh4gBCAnhUIDiSITIBYgBSAuhUItiSIEQn+Fg4UiIoWFhYUiJ4UiBSAQIA1Cf4WDIAuFIiCFQhWJIg0gHSAHIBVCf4WDIAaFIiggCyAPQn+FgyAShSILIAMgCUJ/hYMgEYUiKSABIAJCf4WDIBeFIiogBCATQn+FgyAUhSIrhYWFhSIsIBggCkJ/hYMgB4UiLSAgIAggDkJ/hYMgA4UiCiAaIBlCf4WDIAGFIi4gDCAWQn+FgyAEhSIHhYWFhSIBQgGJhSIEhUIriSIZQn+FgyArIBUgBkJ/hYMgGIUiHSAPIBJCf4WDIBCFIgYgCSARQn+FgyAIhSIOIBogAiAXQn+Fg4VCgoCCgICAgICAf4UiICATIBRCf4WDIAyFIgiFhYWFIgIgJ0IBiYUiA4VCLIkiGoUiJyACQgGJIAGFIgIgHIVCFIkiFyADIAuFQi2JIhYgLEIBiSAlhSIBIA6FQgOJIhRCf4WDhSIchSAEICKFQgaJIgwgAiAhhUIIiSIOIAUgCoVCGYkiEUJ/hYOFIiGFIAEgCIVCJIkiCCAEICaFQg+JIhIgAyAphUIKiSIQQn+Fg4UiIoUgBSAHhUI3iSIKIAEgBoVCKYkiBiACIBuFQieJIhhCf4WDhSImhSIlQgGJIAMgKIVCAokiFSAKIAQgHoVCPokiB0J/hYOFIh4gBSAthUI4iSIPIAggAiAfhUIbiSILQn+Fg4UiHyABIB2FQhKJIgkgDCADICqFQgGJIgNCf4WDhSIdIAIgI4VCDokiAiAaIAEgIIUiAUJ/hYOFIiMgBCAkhUI9iSITIBcgBSAuhUIciSIbQn+Fg4UiJIWFhYUiIIUiBSABIBkgGkJ/hYOFQoCBgICAgICAgH+FIiiFIhogJSAHIBVCf4WDIAaFIikgCyAPQn+FgyAShSIqIAMgCUJ/hYMgDoUiKyABIAJCf4WDIA2FIgEgGyATQn+FgyAWhSIshYWFhSItQgGJhSIEIAkgDkJ/hYMgEYUiCYVCK4kiDiAcIBggCkJ/hYMgB4UiJSAQIAhCf4WDIAuFIgcgESAMQn+FgyADhSIMICggFCAXQn+FgyAbhSIKhYWFhSIRIBUgBkJ/hYMgGIUiGyAPIBJCf4WDIBCFIg8gAiANQn+FgyAZhSIGIBMgFkJ/hYMgFIUiCIUgCYWFhSICQgGJhSIDhUIsiSIZQn+Fg4VCioAChSIcICBCAYkgAoUiAiABhUIciSIXIAUgDIVCA4kiFiARQgGJIC2FIgEgJIVCFIkiFEJ/hYOFIiSFIAMgJ4VCAYkiDCACICuFQhmJIhEgBCAIhUIGiSIIQn+Fg4UiJ4UgASAjhUIbiSINIAMgIYVCCokiEiAFIAqFQiSJIhBCf4WDhSIhhSAEIAaFQj6JIgogASAdhUIniSIGIAIgLIVCN4kiGEJ/hYOFIiOFIh1CAYkgBSAHhUIpiSIVIAogAyAmhUICiSIHQn+Fg4UiJiAEIA+FQg+JIg8gDSACICmFQjiJIgtCf4WDhSIgIAEgH4VCCIkiCSAMIAUgJYVCEokiE0J/hYOFIiUgAiAqhUIViSICIBogASAehUIOiSIBQn+Fg4UiHiADICKFQi2JIgMgFyAEIBuFQj2JIgRCf4WDhSIbhYWFhSIihSIFIBggCkJ/hYMgB4UiH4VCDokiCiAgIAcgFUJ/hYMgBoUiByALIA9Cf4WDIBKFIiggEyAJQn+FgyARhSIpIAEgAkJ/hYMgDoUiKiAEIANCf4WDIBaFIiuFhYWFIiwgHyAQIA1Cf4WDIAuFIg0gCCAMQn+FgyAThSILIBkgGkJ/hYMgAYUiEyAUIBdCf4WDIASFIi2FhYWFIgFCAYmFIgSFQhWJIhpCf4WDICkgFSAGQn+FgyAYhSIGIA8gEkJ/hYMgEIUiDCAJIBFCf4WDIAiFIgggAiAOQn+FgyAZhSIJIAMgFkJ/hYMgFIUiH4WFhYUiAiAiQgGJhSIDhUIriSIZhSIiIAJCAYkgAYUiAiAnhUIDiSIXIAMgB4VCPYkiFiAsQgGJIB2FIgEgDIVCLYkiFEJ/hYOFIh2FIAQgJYVCGYkiDCACICOFQhKJIg4gBSANhUIIiSIRQn+Fg4UiI4UgASAIhUIKiSIIIAQgJoVCOIkiDSADICiFQg+JIhJCf4WDhSImhSAFIAuFQieJIhAgASAGhUICiSIGIAIgIYVCKYkiGEJ/hYOFIiGFIiVCAYkgAyAqhUI+iSIVIBAgBCAbhUI3iSIHQn+Fg4UiGyAFIBOFQhuJIg8gCCACICSFQiSJIgtCf4WDhSIkIAEgCYVCAYkiCSAMIAMgK4VCBokiA0J/hYOFIicgAiAchSICIBkgASAfhUIsiSIBQn+Fg4VCioCAgIiAgICAf4UiHCAEIB6FQhyJIhMgFyAFIC2FQhSJIgRCf4WDhSIehYWFhSIfhSIFIBQgF0J/hYMgBIUiIIVCLIkiFyAcIAcgFUJ/hYMgBoUiKCALIA9Cf4WDIA2FIikgAyAJQn+FgyAOhSIqIAEgAkJ/hYMgCoUiKyAEIBNCf4WDIBaFIiyFhYWFIi0gGCAQQn+FgyAHhSIHIBIgCEJ/hYMgC4UiLiARIAxCf4WDIAOFIgsgGiAZQn+FgyABhSIIICCFhYWFIgFCAYmFIgSFIhlCf4WDICggFSAGQn+FgyAYhSIQIA8gDUJ/hYMgEoUiHCAJIA5Cf4WDIBGFIgkgAiAKQn+FgyAahSIMIBMgFkJ/hYMgFIUiBoWFhYUiAiAfQgGJhSIDhUIOiSIahSIfIAJCAYkgAYUiAiAhhUI9iSIWIAMgLIVCFIkiFCAtQgGJICWFIgEgDIVCHIkiDEJ/hYOFIiGFIAQgG4VCEokiDiACIB2FQgaJIhEgBSAIhUIBiSIIQn+Fg4UiG4UgASAQhUI4iSINIAQgHoVCJIkiEiADICuFQhuJIhBCf4WDhSIehSAFIAeFQgKJIgogASAGhUI3iSIGIAIgIoVCPokiGEJ/hYOFIiKFIiVCAYkgAyAqhUIniSIVIAogBCAkhUIpiSIHQn+Fg4UiJCAFIAuFQgqJIg8gDSACICaFQg+JIgtCf4WDhSImIAEgCYVCGYkiCSAOIAMgKYVCCIkiA0J/hYOFIh0gAiAjhUIriSICIBogASAchUIViSIBQn+Fg4UiHCAEICeFQgOJIhMgFiAFIC6FQi2JIgRCf4WDhSIjhYWFhSInhSIFIBAgDUJ/hYMgC4UiIIVCFYkiDSAdIAcgFUJ/hYMgBoUiKCALIA9Cf4WDIBKFIgsgAyAJQn+FgyARhSIpIAEgAkJ/hYMgF4UiKiAEIBNCf4WDIBSFIiuFhYWFIiwgGCAKQn+FgyAHhSItICAgCCAOQn+FgyADhSIKIBkgGkJ/hYMgAYUiLiAMIBZCf4WDIASFIgeFhYWFIgFCAYmFIgSFQiuJIhpCf4WDICsgFSAGQn+FgyAYhSIdIA8gEkJ/hYMgEIUiBiAJIBFCf4WDIAiFIg4gGSACIBdCf4WDhUKBgYKAiICAgIB/hSIgIBMgFEJ/hYMgDIUiCIWFhYUiAiAnQgGJhSIDhUIsiSIZhSInIAJCAYkgAYUiAiAhhUIUiSIXIAMgC4VCLYkiFiAsQgGJICWFIgEgDoVCA4kiFEJ/hYOFIiGFIAQgI4VCBokiDCACIB6FQgiJIg4gBSAKhUIZiSIRQn+Fg4UiHoUgASAIhUIkiSIIIAQgJoVCD4kiEiADICmFQgqJIhBCf4WDhSIjhSAFIAeFQjeJIgogASAGhUIpiSIGIAIgG4VCJ4kiGEJ/hYOFIhuFIiZCAYkgAyAohUICiSIVIAogBCAchUI+iSIHQn+Fg4UiHCAFIC2FQjiJIg8gCCACIB+FQhuJIgtCf4WDhSIlIAEgHYVCEokiCSAMIAMgKoVCAYkiA0J/hYOFIh0gAiAihUIOiSICIBkgASAghSIBQn+Fg4UiIiAEICSFQj2JIhMgFyAFIC6FQhyJIgRCf4WDhSIkhYWFhSIfhSIFIAEgGiAZQn+Fg4VCgIGCgICAgICAf4UiIIUiGSAcIAcgFUJ/hYMgBoUiKCALIA9Cf4WDIBKFIikgAyAJQn+FgyAOhSIqIAEgAkJ/hYMgDYUiASAEIBNCf4WDIBaFIiuFhYWFIiwgGCAKQn+FgyAHhSIKIBAgCEJ/hYMgC4UiByARIAxCf4WDIAOFIi0gICAUIBdCf4WDIASFIguFhYWFIgxCAYmFIgSFQg6JIhdCf4WDIBUgBkJ/hYMgGIUiCCAPIBJCf4WDIBCFIhIgCSAOQn+FgyARhSIcIAIgDUJ/hYMgGoUiBiATIBZCf4WDIBSFIgmFhYWFIgIgH0IBiYUiAyAphUIViSIahSIfIAJCAYkgDIUiAiAjhUItiSIWIAEgA4VCHIkiFCAsQgGJICaFIgEgCIVCPYkiDEJ/hYOFIiOFIAQgJYVCCIkiDiACICeFQgGJIhEgBSAKhUISiSIIQn+Fg4UiJoUgASAShUIPiSINIAQgIoVCG4kiEiADICiFQjiJIhBCf4WDhSIihSAFIAeFQimJIgogASAGhUI+iSIGIAIgG4VCAokiGEJ/hYOFIhuFIiVCAYkgAyArhUI3iSIVIAogBCAdhUIniSIHQn+Fg4UiHSAFIAuFQiSJIg8gDSACIB6FQgqJIgtCf4WDhSIeIAEgCYVCBokiCSAOIAMgKoVCGYkiA0J/hYOFIicgAiAhhUIsiSICIBogASAchUIriSIBQn+Fg4UiHCAEICSFQhSJIhMgFiAFIC2FQgOJIgRCf4WDhSIhhYWFhSIkhSIFIBcgGkJ/hYMgAYUiIIVCPokiGiAdIAcgFUJ/hYMgBoUiKCALIA9Cf4WDIBKFIikgAyAJQn+FgyARhSIqIBkgASACQn+Fg4VCgYCAgAiFIisgBCATQn+FgyAUhSIshYWFhSIBIBggCkJ/hYMgB4UiByAQIA1Cf4WDIAuFIg0gCCAOQn+FgyADhSItICAgDCAWQn+FgyAEhSIKhYWFhSIOQgGJhSIEhUICiSIWQn+FgyAVIAZCf4WDIBiFIh0gDyASQn+FgyAQhSIGIAkgEUJ/hYMgCIUiESACIBlCf4WDIBeFIgggEyAUQn+FgyAMhSIPhYWFhSIUICRCAYmFIgMgKYVCKYkiGYU3ALgBIAAgAUIBiSAlhSICIBGFQieJIhcgFEIBiSAOhSIBICOFQjeJIhRCf4WDIBqFNwCgASAAIAUgDYVCD4kiDCACIAiFQhuJIg4gASAbhUI4iSIRQn+Fg4U3AJABIAAgAyAshUIkiSIIIAwgBCAnhUIKiSINQn+Fg4U3AIABIAAgAyAohUISiSISIAUgCoVCBokiECAEIByFQgGJIgpCf4WDhTcAcCAAIAIgBoVCCIkiBiABICaFQhmJIhhCf4WDIBCFNwBYIAAgBSAHhUI9iSIVIAIgD4VCFIkiByABIB+FQhyJIg9Cf4WDhTcASCAAIAMgKoVCA4kiCyAVIAQgHoVCLYkiCUJ/hYOFNwA4IAAgAiAdhUIOiSICIAQgIYVCLIkiBCADICuFIgNCf4WDhTcAICAAIAUgLYVCK4kiBSACIAEgIoVCFYkiAUJ/hYOFNwAQIAAgFCAaQn+FgyAWhTcAwAEgACAWIBlCf4WDIBeFNwCwASAAIBkgF0J/hYMgFIU3AKgBIAAgCCAOQn+FgyARhTcAmAEgACARIAxCf4WDIA2FNwCIASAAIA0gCEJ/hYMgDoU3AHggACAKIBJCf4WDIAaFNwBoIAAgEiAGQn+FgyAYhTcAYCAAIBggEEJ/hYMgCoU3AFAgACAPIBVCf4WDIAmFNwBAIAAgCSALQn+FgyAHhTcAMCAAIAsgB0J/hYMgD4U3ACggACADIAJCf4WDIAGFNwAYIAAgASAFQn+FgyAEhTcACCAAIAMgBSAEQn+Fg4VCiICCgIiAgICAf4U3AAAL9xICFX4DfyAAIAAoACwiFkEFdkH///8Aca0gACgAPEEDdq0iAkKDoVZ+IAAzACogADEALEIQhkKAgPwAg4R8IgtCgIBAfSIIQhWHfCIBQoOhVn4gADUAMUIHiEL///8AgyIDQtOMQ34gACgAFyIXQRh2rSAAMQAbQgiGhCAAMQAcQhCGhEICiEL///8Ag3wgACgANCIYQQR2Qf///wBxrSIEQuf2J358IBZBGHatIAAxADBCCIaEIAAxADFCEIaEQgKIQv///wCDIgVC0asIfnwgADUAOUIGiEL///8AgyIGQpPYKH58IBhBGHatIAAxADhCCIaEIAAxADlCEIaEQgGIQv///wCDIglCmNocfnwiB3wgB0KAgEB9IhFCgICAf4N9IBdBBXZB////AHGtIANC5/YnfnwgBEKY2hx+fCAFQtOMQ358IAlCk9gofnwgA0KY2hx+IAAzABUgADEAF0IQhkKAgPwAg4R8IARCk9gofnwgBULn9id+fCIHQoCAQH0iCkIViHwiDEKAgEB9Ig1CFYd8Ig8gD0KAgEB9Ig9CgICAf4N9IAwgAULRqwh+fCANQoCAgH+DfSALIAhCgICAf4N9IAJC0asIfiAAKAAkIhZBGHatIAAxAChCCIaEIAAxAClCEIaEQgOIfCAGQoOhVn58IBZBBnZB////AHGtIAJC04xDfnwgBkLRqwh+fCAJQoOhVn58IgxCgIBAfSINQhWHfCIIQoCAQH0iDkIVh3wiC0KDoVZ+fCAHIApCgICA////A4N9IANCk9gofiAAKAAPIhZBGHatIAAxABNCCIaEIAAxABRCEIaEQgOIfCAFQpjaHH58IBZBBnZB////AHGtIAVCk9gofnwiCkKAgEB9IhJCFYh8IgdCgIBAfSIQQhWIfCABQtOMQ358IAtC0asIfnwgCCAOQoCAgH+DfSIIQoOhVn58Ig5CgIBAfSITQhWHfCIUQoCAQH0iFUIVh3wgFCAVQoCAgH+DfSAOIBNCgICAf4N9IAcgEEKAgID///////8Ag30gAULn9id+fCALQtOMQ358IAhC0asIfnwgDCANQoCAgH+DfSAEQoOhVn4gACgAHyIWQRh2rSAAMQAjQgiGhCAAMQAkQhCGhEIBiEL///8Ag3wgAkLn9id+fCAGQtOMQ358IAlC0asIfnwgFkEEdkH///8Aca0gA0KDoVZ+fCAEQtGrCH58IAJCmNocfnwgBkLn9id+fCAJQtOMQ358IgxCgIBAfSINQhWHfCIOQoCAQH0iEEIVh3wiB0KDoVZ+fCAKIBJCgICA////AYN9IAFCmNocfnwgC0Ln9id+fCAIQtOMQ358IAdC0asIfnwgDiAQQoCAgH+DfSIKQoOhVn58Ig5CgIBAfSISQhWHfCIQQoCAQH0iE0IVh3wgECATQoCAgH+DfSAOIBJCgICAf4N9IAFCk9gofiAAKAAKIhZBGHatIAAxAA5CCIaEIAAxAA9CEIaEQgGIQv///wCDfCALQpjaHH58IAhC5/YnfnwgB0LTjEN+fCAKQtGrCH58IAwgDUKAgIB/g30gA0LRqwh+IAA1ABxCB4hC////AIN8IARC04xDfnwgBUKDoVZ+fCACQpPYKH58IAZCmNocfnwgCULn9id+fCARQhWHfCIBQoCAQH0iA0IVh3wiAkKDoVZ+fCAWQQR2Qf///wBxrSALQpPYKH58IAhCmNocfnwgB0Ln9id+fCAKQtOMQ358IAJC0asIfnwiBEKAgEB9IgVCFYd8IgZCgIBAfSIJQhWHfCAGIAEgA0KAgIB/g30gD0IVh3wiA0KAgEB9IgtCFYciAUKDoVZ+fCAJQoCAgH+DfSABQtGrCH4gBHwgBUKAgIB/g30gCEKT2Ch+IAA1AAdCB4hC////AIN8IAdCmNocfnwgCkLn9id+fCACQtOMQ358IAdCk9gofiAAKAACIhZBGHatIAAxAAZCCIaEIAAxAAdCEIaEQgKIQv///wCDfCAKQpjaHH58IAJC5/YnfnwiBEKAgEB9IgVCFYd8IgZCgIBAfSIJQhWHfCAGIAFC04xDfnwgCUKAgIB/g30gAULn9id+IAR8IAVCgICAf4N9IBZBBXZB////AHGtIApCk9gofnwgAkKY2hx+fCACQpPYKH4gADMAACAAMQACQhCGQoCA/ACDhHwiAkKAgEB9IgRCFYd8IgVCgIBAfSIGQhWHfCABQpjaHH4gBXwgBkKAgIB/g30gAiAEQoCAgH+DfSABQpPYKH58IgFCFYd8IgVCFYd8IgZCFYd8IglCFYd8IghCFYd8IgdCFYd8IgpCFYd8IhFCFYd8IgxCFYd8Ig1CFYd8Ig9CFYcgAyALQoCAgH+DfXwiBEIVhyICQpPYKH4gAUL///8Ag3wiAzwAACAAIANCCIg8AAEgACACQpjaHH4gBUL///8Ag3wgA0IVh3wiAUILiDwABCAAIAFCA4g8AAMgACADQhCIQh+DIAFCBYaEPAACIAAgAkLn9id+IAZC////AIN8IAFCFYd8IgNCBog8AAYgACADQgKGIAFCgIDgAINCE4iEPAAFIAAgAkLTjEN+IAlC////AIN8IANCFYd8IgFCCYg8AAkgACABQgGIPAAIIAAgAUIHhiADQoCA/wCDQg6IhDwAByAAIAJC0asIfiAIQv///wCDfCABQhWHfCIDQgyIPAAMIAAgA0IEiDwACyAAIANCBIYgAUKAgPgAg0IRiIQ8AAogACACQoOhVn4gB0L///8Ag3wgA0IVh3wiAUIHiDwADiAAIAFCAYYgA0KAgMAAg0IUiIQ8AA0gACAKQv///wCDIAFCFYd8IgJCCog8ABEgACACQgKIPAAQIAAgAkIGhiABQoCA/gCDQg+IhDwADyAAIBFC////AIMgAkIVh3wiAUINiDwAFCAAIAFCBYg8ABMgACAMQv///wCDIAFCFYd8IgM8ABUgACABQgOGIAJCgIDwAINCEoiEPAASIAAgA0IIiDwAFiAAIA1C////AIMgA0IVh3wiAkILiDwAGSAAIAJCA4g8ABggACADQhCIQh+DIAJCBYaEPAAXIAAgD0L///8AgyACQhWHfCIBQgaIPAAbIAAgAUIChiACQoCA4ACDQhOIhDwAGiAAIAFCFYciAyAEQv///wCDfCICQhGIPAAfIAAgAkIJiDwAHiAAIAJCB4YgAUKAgP8Ag0IOiIQ8ABwgACADpyAEp2pBAXatPAAdC30BA38CQAJAIAAiAUEDcUUNACABLQAARQRAQQAPCwNAIAFBAWoiAUEDcUUNASABLQAADQALDAELA0AgASICQQRqIQFBgIKECCACKAIAIgNrIANyQYCBgoR4cUGAgYKEeEYNAAsDQCACIgFBAWohAiABLQAADQALCyABIABrCwQAQRgLBABBCAufAQEFfyACpyEFIAAtAOwBBH8gABAaIABBADYC4AEgAEEAOgDsAUF/BUEACyAFBEAgACgC4AEhAwNAIAAoAuQBIgQgA0YEQCAAEBogAEEANgLgASAAKALkASEEQQAhAwsgACABIAZqIAMgBCADayIDIAUgBmsiBCADIARJGyIEEBggACAAKALgASAEaiIDNgLgASAEIAZqIgYgBUkNAAsLCyMAIAJBgAJPBEBB3ApBhQpB6wBB4wgQAAALIAAgASACEJ8BCw0AIAAgASACEC0aQQAL7AUCCH4DfyMAQaACayIMJAACQCACUA0AIAAgACkDICIDIAJCA4Z8NwMgIABBKGohC0LAACADQgOIQj+DIgR9IgUgAlgEQCAFQgODIQZCACEDAkAgBEI/hUIDWgRAIAVC/ACDIQoDQCALIAMgBHynaiABIAOnai0AADoAACALIANCAYQiCCAEfKdqIAEgCKdqLQAAOgAAIAsgA0IChCIIIAR8p2ogASAIp2otAAA6AAAgCyADQgOEIgggBHynaiABIAinai0AADoAACADQgR8IQMgCUIEfCIJIApSDQALIAZQDQELA0AgCyADIAR8p2ogASADp2otAAA6AAAgA0IBfCEDIAdCAXwiByAGUg0ACwsgACALIAwgDEGAAmoiDRB3IAEgBadqIQEgAiAFfSICQj9WBEADQCAAIAEgDCANEHcgAUFAayEBIAJCQHwiAkI/Vg0ACwsCQCACUA0AIAJCA4MhBEIAIQdCACEDIAJCBFoEQCACQjyDIQVCACECA0AgCyADpyIAaiAAIAFqLQAAOgAAIAsgAEEBciINaiABIA1qLQAAOgAAIAsgAEECciINaiABIA1qLQAAOgAAIAsgAEEDciIAaiAAIAFqLQAAOgAAIANCBHwhAyACQgR8IgIgBVINAAsgBFANAQsDQCALIAOnIgBqIAAgAWotAAA6AAAgA0IBfCEDIAdCAXwiByAEUg0ACwsgDEGgAhAHDAELIAJCA4MhBUIAIQMgAkIEWgRAIAJCfIMhAgNAIAsgAyAEfKdqIAEgA6dqLQAAOgAAIAsgA0IBhCIGIAR8p2ogASAGp2otAAA6AAAgCyADQgKEIgYgBHynaiABIAanai0AADoAACALIANCA4QiBiAEfKdqIAEgBqdqLQAAOgAAIANCBHwhAyAJQgR8IgkgAlINAAsgBVANAQsDQCALIAMgBHynaiABIAOnai0AADoAACADQgF8IQMgB0IBfCIHIAVSDQALCyAMQaACaiQAQQAL6QMBAn9BfyEFAkAgAkHAAEsNACADQcEAayIEQUBJDQACQCABQQAgAhtFBEAgBEH/AXFBvwFNBEAQDAALIABBQGtBAEGlAvwLACAAQvnC+JuRo7Pw2wA3ADggAELr+obav7X2wR83ADAgAEKf2PnZwpHagpt/NwAoIABC0YWa7/rPlIfRADcAICAAQvHt9Pilp/2npX83ABggAEKr8NP0r+68tzw3ABAgAEK7zqqm2NDrs7t/NwAIIAAgA61CiJL3lf/M+YTqAIU3AAAMAQsCfyMAQYABayIEJAACQCADQcEAa0H/AXFBvwFNDQAgAUUNACACQcEAa0H/AXFBvwFNDQAgAEFAa0EAQaUC/AsAIABC+cL4m5Gjs/DbADcAOCAAQuv6htq/tfbBHzcAMCAAQp/Y+dnCkdqCm383ACggAELRhZrv+s+Uh9EANwAgIABC8e30+KWn/aelfzcAGCAAQqvw0/Sv7ry3PDcAECAAQrvOqqbY0Ouzu383AAggACADrSACrUIIhoRCiJL3lf/M+YTqAIU3AAAgBEEAQYAB/AsAIAIEQCAEIAEgAvwKAAALIABB4ABqIARBgAH8CgAAIABBgAE2AOACIARBgAEQByAEQYABaiQAQQAMAQsQDAALDQELQQAhBQsgBQsNACAAIAEgAhATGkEAC4MNAQp/IwBB4ANrIgIkACACIAEtAAAiA0EEdjoAoQIgAiADQQ9xOgCgAiACIAEtAAEiA0EEdjoAowIgAiADQQ9xOgCiAiACIAEtAAIiA0EEdjoApQIgAiADQQ9xOgCkAiACIAEtAAMiA0EEdjoApwIgAiADQQ9xOgCmAiACIAEtAAQiA0EEdjoAqQIgAiADQQ9xOgCoAiACIAEtAAUiA0EEdjoAqwIgAiADQQ9xOgCqAiACIAEtAAYiA0EEdjoArQIgAiADQQ9xOgCsAiACIAEtAAciA0EEdjoArwIgAiADQQ9xOgCuAiACIAEtAAgiA0EEdjoAsQIgAiADQQ9xOgCwAiACIAEtAAkiA0EEdjoAswIgAiADQQ9xOgCyAiACIAEtAAoiA0EEdjoAtQIgAiADQQ9xOgC0AiACIAEtAAsiA0EEdjoAtwIgAiADQQ9xOgC2AiACIAEtAAwiA0EEdjoAuQIgAiADQQ9xOgC4AiACIAEtAA0iA0EEdjoAuwIgAiADQQ9xOgC6AiACIAEtAA4iA0EEdjoAvQIgAiADQQ9xOgC8AiACIAEtAA8iA0EEdjoAvwIgAiADQQ9xOgC+AiACIAEtABAiA0EEdjoAwQIgAiADQQ9xOgDAAiACIAEtABEiA0EEdjoAwwIgAiADQQ9xOgDCAiACIAEtABIiA0EEdjoAxQIgAiADQQ9xOgDEAiACIAEtABMiA0EEdjoAxwIgAiADQQ9xOgDGAiACIAEtABQiA0EEdjoAyQIgAiADQQ9xOgDIAiACIAEtABUiA0EEdjoAywIgAiADQQ9xOgDKAiACIAEtABYiA0EEdjoAzQIgAiADQQ9xOgDMAiACIAEtABciA0EEdjoAzwIgAiADQQ9xOgDOAiACIAEtABgiA0EEdjoA0QIgAiADQQ9xOgDQAiACIAEtABkiA0EEdjoA0wIgAiADQQ9xOgDSAiACIAEtABoiA0EEdjoA1QIgAiADQQ9xOgDUAiACIAEtABsiA0EEdjoA1wIgAiADQQ9xOgDWAiACIAEtABwiA0EEdjoA2QIgAiADQQ9xOgDYAiACIAEtAB0iA0EEdjoA2wIgAiADQQ9xOgDaAiACIAEtAB4iA0EEdjoA3QIgAiADQQ9xOgDcAiACIAEtAB8iAUEEdjoA3wIgAiABQQ9xOgDeAkEAIQMDQCACQaACaiAEaiIBIAEtAAAgA2oiAyADQQhqIgNB8AFxazoAACABIAEtAAEgA8BBBHVqIgMgA0EIaiIDQfABcWs6AAEgASABLQACIAPAQQR1aiIBIAFBCGoiAUHwAXFrOgACIAHAQQR1IQMgBEEDaiIEQT9HDQALIAIgAi0A3wIgA2o6AN8CIABCADcCICAAQgA3AhggAEIANwIQIABCADcCCCAAQgA3AgAgAEIANwIsIABBKGoiCEEBNgIAIABCADcCNCAAQgA3AjwgAEIANwJEIABCgICAgBA3AkwgAEHUAGpBAEHMAPwLACAAQfgAaiELIABB0ABqIQkgAkHQAWohAyACQagBaiEHIAJB+AFqIQRBASEBA0AgAkEIaiIGIAFBAXYgAkGgAmogAWosAAAQqwEgAkGAAWoiBSAAIAYQhwEgACAFIAQQBSAIIAcgAxAFIAkgAyAEEAUgCyAFIAcQBSABQT5JIAFBAmohAQ0ACyACIAApAiA3A4gDIAIgACkCGDcDgAMgAiAAKQIQNwP4AiACIAApAgg3A/ACIAIgACkCADcD6AIgAiAIKQIANwOQAyACIAgpAgg3A5gDIAIgCCkCEDcDoAMgAiAIKQIYNwOoAyACIAgpAiA3A7ADIAIgCSkCADcDuAMgAiAJKQIINwPAAyACIAkpAhA3A8gDIAIgCSkCGDcD0AMgAiAJKQIgNwPYAyAFIAJB6AJqIgoQHCAKIAUgBBAFIAJBkANqIgEgByADEAUgAkG4A2oiBiADIAQQBSAFIAoQHCAKIAUgBBAFIAEgByADEAUgBiADIAQQBSAFIAoQHCAKIAUgBBAFIAEgByADEAUgBiADIAQQBSAFIAoQHCAAIAUgBBAFIAggByADEAUgCSADIAQQBSALIAUgBxAFQQAhAQNAIAJBCGoiBiABQQF2IAJBoAJqIAFqLAAAEKsBIAJBgAFqIgUgACAGEIcBIAAgBSAEEAUgCCAHIAMQBSAJIAMgBBAFIAsgBSAHEAUgAUE+SSABQQJqIQENAAsgAkHgA2okAAvlAQECfyACQQBHIQMCQAJAAkAgAEEDcUUNACACRQ0AIAFB/wFxIQQDQCAALQAAIARGDQIgAkEBayICQQBHIQMgAEEBaiIAQQNxRQ0BIAINAAsLIANFDQECQCABQf8BcSIDIAAtAABGDQAgAkEESQ0AIANBgYKECGwhAwNAQYCChAggACgCACADcyIEayAEckGAgYKEeHFBgIGChHhHDQIgAEEEaiEAIAJBBGsiAkEDSw0ACwsgAkUNAQsgAUH/AXEhAQNAIAEgAC0AAEYEQCAADwsgAEEBaiEAIAJBAWsiAg0ACwtBAAt1ACAAQgA3A0ggAEFAa0IANwMAIABB0LACKQMANwMAIABB2LACKQMANwMIIABB4LACKQMANwMQIABB6LACKQMANwMYIABB8LACKQMANwMgIABB+LACKQMANwMoIABBgLECKQMANwMwIABBiLECKQMANwM4QQALgwcBFH8gASgCBCEMIAAoAgQhAyABKAIIIQ0gACgCCCEEIAEoAgwhDiAAKAIMIQUgASgCECEPIAAoAhAhBiABKAIUIRAgACgCFCEHIAEoAhghESAAKAIYIQggASgCHCESIAAoAhwhCSABKAIgIRMgACgCICEKIAEoAiQhFCAAKAIkIQsgAEEAIAJrIgIgACgCACIVIAEoAgBzcSAVczYCACAAIAsgCyAUcyACcXM2AiQgACAKIAogE3MgAnFzNgIgIAAgCSAJIBJzIAJxczYCHCAAIAggCCARcyACcXM2AhggACAHIAcgEHMgAnFzNgIUIAAgBiAGIA9zIAJxczYCECAAIAUgBSAOcyACcXM2AgwgACAEIAQgDXMgAnFzNgIIIAAgAyADIAxzIAJxczYCBCAAKAIoIQMgASgCKCEMIAAoAiwhBCABKAIsIQ0gACgCMCEFIAEoAjAhDiAAKAI0IQYgASgCNCEPIAAoAjghByABKAI4IRAgACgCPCEIIAEoAjwhESAAQUBrIhIoAgAhCSABQUBrKAIAIRMgACgCRCEKIAEoAkQhFCAAKAJIIQsgASgCSCEVIAAgACgCTCIWIAEoAkxzIAJxIBZzNgJMIAAgCyALIBVzIAJxczYCSCAAIAogCiAUcyACcXM2AkQgEiAJIAkgE3MgAnFzNgIAIAAgCCAIIBFzIAJxczYCPCAAIAcgByAQcyACcXM2AjggACAGIAYgD3MgAnFzNgI0IAAgBSAFIA5zIAJxczYCMCAAIAQgBCANcyACcXM2AiwgACADIAMgDHMgAnFzNgIoIAAoAlAhAyABKAJQIQwgACgCVCEEIAEoAlQhDSAAKAJYIQUgASgCWCEOIAAoAlwhBiABKAJcIQ8gACgCYCEHIAEoAmAhECAAKAJkIQggASgCZCERIAAoAmghCSABKAJoIRIgACgCbCEKIAEoAmwhEyAAKAJwIQsgASgCcCEUIAAgACgCdCIVIAEoAnRzIAJxIBVzNgJ0IAAgCyALIBRzIAJxczYCcCAAIAogCiATcyACcXM2AmwgACAJIAkgEnMgAnFzNgJoIAAgCCAIIBFzIAJxczYCZCAAIAcgByAQcyACcXM2AmAgACAGIAYgD3MgAnFzNgJcIAAgBSAFIA5zIAJxczYCWCAAIAQgBCANcyACcXM2AlQgACADIAMgDHMgAnFzNgJQC8EJARR/IAEoAgQhDCAAKAIEIQMgASgCCCENIAAoAgghBCABKAIMIQ4gACgCDCEFIAEoAhAhDyAAKAIQIQYgASgCFCEQIAAoAhQhByABKAIYIREgACgCGCEIIAEoAhwhEiAAKAIcIQkgASgCICETIAAoAiAhCiABKAIkIRQgACgCJCELIABBACACayICIAAoAgAiFSABKAIAc3EgFXM2AgAgACALIAsgFHMgAnFzNgIkIAAgCiAKIBNzIAJxczYCICAAIAkgCSAScyACcXM2AhwgACAIIAggEXMgAnFzNgIYIAAgByAHIBBzIAJxczYCFCAAIAYgBiAPcyACcXM2AhAgACAFIAUgDnMgAnFzNgIMIAAgBCAEIA1zIAJxczYCCCAAIAMgAyAMcyACcXM2AgQgACgCKCEDIAEoAighDCAAKAIsIQQgASgCLCENIAAoAjAhBSABKAIwIQ4gACgCNCEGIAEoAjQhDyAAKAI4IQcgASgCOCEQIAAoAjwhCCABKAI8IREgAEFAayISKAIAIQkgAUFAaygCACETIAAoAkQhCiABKAJEIRQgACgCSCELIAEoAkghFSAAIAAoAkwiFiABKAJMcyACcSAWczYCTCAAIAsgCyAVcyACcXM2AkggACAKIAogFHMgAnFzNgJEIBIgCSAJIBNzIAJxczYCACAAIAggCCARcyACcXM2AjwgACAHIAcgEHMgAnFzNgI4IAAgBiAGIA9zIAJxczYCNCAAIAUgBSAOcyACcXM2AjAgACAEIAQgDXMgAnFzNgIsIAAgAyADIAxzIAJxczYCKCAAKAJQIQMgASgCUCEMIAAoAlQhBCABKAJUIQ0gACgCWCEFIAEoAlghDiAAKAJcIQYgASgCXCEPIAAoAmAhByABKAJgIRAgACgCZCEIIAEoAmQhESAAKAJoIQkgASgCaCESIAAoAmwhCiABKAJsIRMgACgCcCELIAEoAnAhFCAAIAAoAnQiFSABKAJ0cyACcSAVczYCdCAAIAsgCyAUcyACcXM2AnAgACAKIAogE3MgAnFzNgJsIAAgCSAJIBJzIAJxczYCaCAAIAggCCARcyACcXM2AmQgACAHIAcgEHMgAnFzNgJgIAAgBiAGIA9zIAJxczYCXCAAIAUgBSAOcyACcXM2AlggACAEIAQgDXMgAnFzNgJUIAAgAyADIAxzIAJxczYCUCAAKAJ4IQMgASgCeCEMIAAoAnwhBCABKAJ8IQ0gACgCgAEhBSABKAKAASEOIAAoAoQBIQYgASgChAEhDyAAKAKIASEHIAEoAogBIRAgACgCjAEhCCABKAKMASERIAAoApABIQkgASgCkAEhEiAAKAKUASEKIAEoApQBIRMgACgCmAEhCyABKAKYASEUIAAgACgCnAEiFSABKAKcAXMgAnEgFXM2ApwBIAAgCyALIBRzIAJxczYCmAEgACAKIAogE3MgAnFzNgKUASAAIAkgCSAScyACcXM2ApABIAAgCCAIIBFzIAJxczYCjAEgACAHIAcgEHMgAnFzNgKIASAAIAYgBiAPcyACcXM2AoQBIAAgBSAFIA5zIAJxczYCgAEgACAEIAQgDXMgAnFzNgJ8IAAgAyADIAxzIAJxczYCeAv0BAEZfiABMQAfIQIgATEAHiEGIAExAB0hDiABMQAGIQcgATEABSEIIAExAAQhAyABMQAJIQ8gATEACCEQIAExAAchESABMQAMIQkgATEACyEKIAExAAohCyABMQAPIQwgATEADiESIAExAA0hEyABMQAcIQQgATEAGyEUIAExABohFSABMQAZIQUgATEAGCEWIAExABchFyABNQAAIRggACABMQAVQg+GIAExABRCB4aEIAExABZCF4aEIAE1ABAiGUKAgIAIfCIaQhmIfCINIA1CgICAEHwiDUKAgIDgD4N9PgIYIAAgFkINhiAXQgWGhCAFQhWGhCIFIA1CGoh8IAVCgICACHwiBUKAgIDwA4N9PgIcIAAgFEIMhiAVQgSGhCAEQhSGhCAFQhmIfCIEIARCgICAEHwiBEKAgIDgD4N9PgIgIAAgGSAaQoCAgPAPg30gEkIKhiATQgKGhCAMQhKGhCAKQguGIAtCA4aEIAlCE4aEIglCgICACHwiCkIZiHwiC0KAgIAQfCIMQhqIfD4CFCAAIAsgDEKAgIDgD4N9PgIQIAAgEEINhiARQgWGhCAPQhWGhCAIQg6GIANCBoaEIAdCFoaEIgdCgICACHwiCEIZiHwiAyADQoCAgBB8IgNCgICA4A+DfT4CCCAAIAJCEoZCgIDwD4MgBkIKhiAOQgKGhIQiAiAEQhqIfCACQoCAgAh8IgJCgICAEIN9PgIkIAAgA0IaiCAJfCAKQoCAgPAAg30+AgwgACAHIAhCgICA8AeDfSAYIAJCGYhCE358IgJCgICAEHwiBkIaiHw+AgQgACACIAZCgICA4A+DfT4CAAvUBAETfwJ/IANFBEBB9MqB2QYhBEGy2ojLByEIQe7IgZkDIQlB5fDBiwYMAQsgAygADCEEIAMoAAghCCADKAAEIQkgAygAAAshAyABKAAMIQ8gASgACCEFIAEoAAQhBiACKAAcIRIgAigAGCEQQRQhESACKAAUIQ4gAigAECEKIAIoAAwhCyACKAAIIQwgAigABCENIAEoAAAhASACKAAAIQIDQCAQIA8gAiAJakEHd3MiByAJakEJd3MiEyADIA5qQQd3IAtzIgsgA2pBCXcgBXMiFCALakENdyAOcyIVIAQgCmpBB3cgDHMiDCAEakEJdyAGcyIGIAxqQQ13IApzIgogBmpBEncgBHMiBCASIAEgCGpBB3dzIgVqQQd3cyIOIARqQQl3cyIQIA5qQQ13IAVzIhIgEGpBEncgBHMhBCAFIAUgCGpBCXcgDXMiDWpBDXcgAXMiFiANakESdyAIcyIBIAdqQQd3IApzIgogAWpBCXcgFHMiBSAKakENdyAHcyIPIAVqQRJ3IAFzIQggEyAHIBNqQQ13IAJzIgdqQRJ3IAlzIgIgC2pBB3cgFnMiASACakEJdyAGcyIGIAFqQQ13IAtzIgsgBmpBEncgAnMhCSAUIBVqQRJ3IANzIgMgDGpBB3cgB3MiAiADakEJdyANcyINIAJqQQ13IAxzIgwgDWpBEncgA3MhAyARQQJLIBFBAmshEQ0ACyAAIAM2AAAgACAPNgAcIAAgBTYAGCAAIAY2ABQgACABNgAQIAAgBDYADCAAIAg2AAggACAJNgAEQQALBABBbwurBAIEfwF+IwBBoAJrIgQkACAAQShqIgIgACgCIEEDdkE/cSIDaiEFAkAgA0E4TwRAQcAAIANrIgMEQCAFQeC5AiAD/AoAAAsgACACIAQgBEGAAmoQdyACQgA3AzAgAkIANwMoIAJCADcDICACQgA3AxggAkIANwMQIAJCADcDCCACQgA3AwAMAQtBOCADayIDRQ0AIAVB4LkCIAP8CgAACyAAIAApAyAiBkI4hiAGQoD+A4NCKIaEIAZCgID8B4NCGIYgBkKAgID4D4NCCIaEhCAGQgiIQoCAgPgPgyAGQhiIQoCA/AeDhCAGQiiIQoD+A4MgBkI4iISEhDcDYCAAIAIgBCAEQYACahB3IAEgACgCACICQf+B/AdxQQh4IAJBGHhB/4H8B3FyNgAAIAEgACgCBCICQf+B/AdxQQh4IAJBGHhB/4H8B3FyNgAEIAEgACgCCCICQf+B/AdxQQh4IAJBGHhB/4H8B3FyNgAIIAEgACgCDCICQf+B/AdxQQh4IAJBGHhB/4H8B3FyNgAMIAEgACgCECICQf+B/AdxQQh4IAJBGHhB/4H8B3FyNgAQIAEgACgCFCICQf+B/AdxQQh4IAJBGHhB/4H8B3FyNgAUIAEgACgCGCICQf+B/AdxQQh4IAJBGHhB/4H8B3FyNgAYIAEgACgCHCIBQf+B/AdxQQh4IAFBGHhB/4H8B3FyNgAcIARBoAIQByAAQegAEAcgBEGgAmokAEEAC/IEAQl/IwBBwAFrIgQkAAJAAkAgAkGBAU8EQCAAEDIaIAAgASACrRATGiAAIAQQHhpBwAAhAiAEIQEMAQsgAQ0AIAINAQsgABAyGiAEQUBrQTZBgAH8CwACQCACRQ0AIAJBA3EhCSACQQRPBEAgAkH8AXEhBgNAIARBQGsiByADaiIFIAUtAAAgASADai0AAHM6AAAgByADQQFyIgVqIgsgCy0AACABIAVqLQAAczoAACAHIANBAnIiBWoiCyALLQAAIAEgBWotAABzOgAAIAcgA0EDciIFaiIHIActAAAgASAFai0AAHM6AAAgA0EEaiEDIAhBBGoiCCAGRw0ACyAJRQ0BCwNAIARBQGsgA2oiCCAILQAAIAEgA2otAABzOgAAIANBAWohAyAKQQFqIgogCUcNAAsLIAAgBEFAayIDQoABEBMaIABB0AFqIgkQMhogA0HcAEGAAfwLAAJAIAJFDQAgAkEDcSEHQQAhCkEAIQMgAkEETwRAIAJB/AFxIQJBACEIA0AgBEFAayIAIANqIgYgBi0AACABIANqLQAAczoAACAAIANBAXIiBmoiBSAFLQAAIAEgBmotAABzOgAAIAAgA0ECciIGaiIFIAUtAAAgASAGai0AAHM6AAAgACADQQNyIgZqIgAgAC0AACABIAZqLQAAczoAACADQQRqIQMgCEEEaiIIIAJHDQALIAdFDQELA0AgBEFAayADaiIAIAAtAAAgASADai0AAHM6AAAgA0EBaiEDIApBAWoiCiAHRw0ACwsgCSAEQUBrIgBCgAEQExogAEGAARAHIARBwAAQByAEQcABaiQAQQAPCxAMAAtVAQF/AkBB3MgCKAIADQBB8MgCQRI2AgBB6MgCQRM2AgBB5MgCQRQ2AgBB4MgCQRU2AgBB3MgCQeDIAjYCABA6QdzIAigCACgCCCIARQ0AIAARFAALC9QBAQN/IwBBEGsiAyAANgIMIAMgATYCCEEAIQAgA0EAOgAHAkAgAkUNACACQQFHBEAgAkEBcSACQX5xIQRBACECA0AgAyADLQAHIAMoAgwgAGotAAAgAygCCCAAai0AAHNyOgAHIAMgAy0AByAAQQFyIgUgAygCDGotAAAgAygCCCAFai0AAHNyOgAHIABBAmohACACQQJqIgIgBEcNAAtFDQELIAMgAy0AByADKAIMIABqLQAAIAMoAgggAGotAABzcjoABwsgAy0AB0EBa0EfdkEBawsFAEGAAguBAgEFfyMAQRBrIgUkACAALQDkAUUEQCAFAn8CQAJAAkAgACgC4AEiA0GnAWsOAgABAgsgAC0A5QFBgH9zDAILIAAQGkEAIQMgAEEANgLgAQsgACAAQeUBaiADQQEQGEGAAQs6AA8gACAFQQ9qQacBQQEQGCAAEBogAEEBOgDkASAAQQA2AuABCyACBEAgACgC4AEhAwNAIANBqAFGBEAgABAaIABBADYC4AFBACEDC0GoASADayIEIAIgBmsiByAEIAdJGyIEBEAgASAGaiAAIANqIAT8CgAACyAAIAAoAuABIARqIgM2AuABIAQgBmoiBiACSQ0ACwsgBUEQaiQAQQALzgYBCX8jAEHgAGsiAyQAAkACQCACQcEATwRAIAAQeBogACABIAKtEC0aIAAgAxA4GkEgIQIgAyEBDAELIAENACACDQELIAAQeBogA0K27Nix48aNmzY3A1ggA0K27Nix48aNmzY3A1AgA0K27Nix48aNmzY3A0ggA0K27Nix48aNmzY3A0AgA0K27Nix48aNmzY3AzggA0K27Nix48aNmzY3AzAgA0K27Nix48aNmzY3AyggA0K27Nix48aNmzY3AyACQCACRQ0AIAJBA3EhCSACQQRPBEAgAkH8AHEhBgNAIANBIGoiByAEaiIFIAUtAAAgASAEai0AAHM6AAAgByAEQQFyIgVqIgsgCy0AACABIAVqLQAAczoAACAHIARBAnIiBWoiCyALLQAAIAEgBWotAABzOgAAIAcgBEEDciIFaiIHIActAAAgASAFai0AAHM6AAAgBEEEaiEEIAhBBGoiCCAGRw0ACyAJRQ0BCwNAIANBIGogBGoiCCAILQAAIAEgBGotAABzOgAAIARBAWohBCAKQQFqIgogCUcNAAsLIAAgA0EgakLAABAtGiAAQegAaiIJEHgaIANC3Ljx4sWLl67cADcDWCADQty48eLFi5eu3AA3A1AgA0LcuPHixYuXrtwANwNIIANC3Ljx4sWLl67cADcDQCADQty48eLFi5eu3AA3AzggA0LcuPHixYuXrtwANwMwIANC3Ljx4sWLl67cADcDKCADQty48eLFi5eu3AA3AyACQCACRQ0AIAJBA3EhB0EAIQpBACEEIAJBBE8EQCACQfwAcSECQQAhCANAIANBIGoiACAEaiIGIAYtAAAgASAEai0AAHM6AAAgACAEQQFyIgZqIgUgBS0AACABIAZqLQAAczoAACAAIARBAnIiBmoiBSAFLQAAIAEgBmotAABzOgAAIAAgBEEDciIGaiIAIAAtAAAgASAGai0AAHM6AAAgBEEEaiEEIAhBBGoiCCACRw0ACyAHRQ0BCwNAIANBIGogBGoiACAALQAAIAEgBGotAABzOgAAIARBAWohBCAKQQFqIgogB0cNAAsLIAkgA0EgaiIAQsAAEC0aIABBwAAQByADQSAQByADQeAAaiQAQQAPCxAMAAs7AQF/IwBBQGoiAiQAIAAgAhAeGiAAQdABaiIAIAJCwAAQExogACABEB4aIAJBwAAQByACQUBrJABBAAuWAQEBfyMAQdABayIDJAAgA0IANwNIIANCADcDQCADQdCwAikDADcDACADQdiwAikDADcDCCADQeCwAikDADcDECADQeiwAikDADcDGCADQfCwAikDADcDICADQfiwAikDADcDKCADQYCxAikDADcDMCADQYixAikDADcDOCADIAEgAhATGiADIAAQHhogA0HQAWokAEEACyMAIAFCgICAgBBaBEAQDAALIAAgASACIANB3L0CKAIAERAAC+gCAQN/IAAgAigCACABKAIAIgRB/wFxQcCuAmotAAAgASgCBCIDQQh2Qf8BcUHArgJqLQAAQQh0ciABKAIIIgVBEHZB/wFxQcCuAmotAABBEHRyIAEoAgwiAUEYdkHArgJqLQAAQRh0cnM2AgAgACACKAIEIANB/wFxQcCuAmotAAAgBUEIdkH/AXFBwK4Cai0AAEEIdHIgAUEQdkH/AXFBwK4Cai0AAEEQdHIgBEEYdkHArgJqLQAAQRh0cnM2AgQgACACKAIIIAVB/wFxQcCuAmotAAAgAUEIdkH/AXFBwK4Cai0AAEEIdHIgBEEQdkH/AXFBwK4Cai0AAEEQdHIgA0EYdkHArgJqLQAAQRh0cnM2AgggACACKAIMIAFB/wFxQcCuAmotAAAgBEEIdkH/AXFBwK4Cai0AAEEIdHIgA0EQdkH/AXFBwK4Cai0AAEEQdHIgBUEYdkHArgJqLQAAQRh0cnM2AgwL+AEBCn8DQCAEIAAgA2otAAAiASADQZAVaiICLQAAc3IhBCAKIAEgAi0AwAFzciEKIAkgASACLQCgAXNyIQkgCCABIAItAIABc3IhCCAHIAEgAi0AYHNyIQcgBiABIAJBQGstAABzciEGIAUgASACLQAgc3IhBSADQQFqIgNBH0cNAAsgCiAALQAfQf8AcSIAQf8AcyIBckH/AXFBAWsgASAJckH/AXFBAWsgASAIckH/AXFBAWsgByAAQfoAc3JB/wFxQQFrIAYgAEEFc3JB/wFxQQFrIAAgBXJB/wFxQQFrIAAgBHJB/wFxQQFrcnJycnJyQQh2QQFxC+YIARh/IwBBwAJrIgIkACAAQShqIhcgARA1IABCADcCVCAAQQE2AlAgAEIANwJcIABCADcCZCAAQgA3AmwgAEEANgJ0IAJB8AFqIgQgFxAEIAJBwAFqIg4gBEHADBAFIAIgAigCwAFBAWo2AsABIAIgAigC8AFBAWsiAzYC8AEgAigC9AEhDSACKAL4ASEFIAIoAvwBIQYgAigCgAIhByACKAKEAiEIIAIoAogCIQkgAigCjAIhCiACKAKQAiELIAIoApQCIQwgACAEIA4QBSAAIAAQiAEgACAEIAAQBSACQZABaiIEIAAQBCAEIAQgDhAFIAIgAigCtAEiBCAMazYChAEgAiACKAKwASIOIAtrNgKAASACIAIoAqwBIg8gCms2AnwgAiACKAKoASIQIAlrNgJ4IAIgAigCpAEiESAIazYCdCACIAIoAqABIhIgB2s2AnAgAiACKAKcASITIAZrNgJsIAIgAigCmAEiFCAFazYCaCACIAIoApQBIhUgDWs2AmQgAiACKAKQASIWIANrNgJgIAIgBCAMajYCVCACIAsgDmo2AlAgAiAKIA9qNgJMIAIgCSAQajYCSCACIAggEWo2AkQgAiAHIBJqNgJAIAIgBiATajYCPCACIAUgFGo2AjggAiANIBVqNgI0IAIgAyAWajYCMCACIAJB4ABqEA8gAkEgEBshBCACIAJBMGoQDyACQSAQGyEPIAIgAEHwDBAFIAAoAgQhDCAAKAIIIQsgACgCDCEKIAAoAhAhCSAAKAIUIQggACgCGCEHIAAoAhwhBiAAKAIgIQUgACgCACEOIAIoAgAhECACKAIEIREgAigCCCESIAIoAgwhEyACKAIQIRQgAigCFCEVIAIoAhghFiACKAIcIRggAigCICEZIAAgBEEBayIDIAAoAiQiDSACKAIkc3EgDXMiDTYCJCAAIAUgBSAZcyADcXMiBTYCICAAIAYgBiAYcyADcXMiBjYCHCAAIAcgByAWcyADcXMiBzYCGCAAIAggCCAVcyADcXMiCDYCFCAAIAkgCSAUcyADcXMiCTYCECAAIAogCiATcyADcXMiCjYCDCAAIAsgCyAScyADcXMiCzYCCCAAIAwgDCARcyADcXMiDDYCBCAAIA4gDiAQcyADcXMiAzYCACACQaACaiAAEA8gAEEAIAItAKACQQFxIAEtAB9BB3ZzQdLIAi0AAEECdnNrIgEgDUEAIA1rc3EgDXM2AiQgACAFQQAgBWtzIAFxIAVzNgIgIAAgBkEAIAZrcyABcSAGczYCHCAAIAdBACAHa3MgAXEgB3M2AhggACAIQQAgCGtzIAFxIAhzNgIUIAAgCUEAIAlrcyABcSAJczYCECAAIApBACAKa3MgAXEgCnM2AgwgACALQQAgC2tzIAFxIAtzNgIIIAAgDEEAIAxrcyABcSAMczYCBCAAIANBACADa3MgAXEgA3M2AgAgAEH4AGogACAXEAUgAkHAAmokACAEIA9yQQFrC8oIAQN/IwBBwAFrIgIkACACQZABaiIEIAEQBCACQeAAaiIDIAQQBCADIAMQBCADIAEgAxAFIAQgBCADEAUgAkEwaiIBIAQQBCADIAMgARAFIAEgAxAEIAEgARAEIAEgARAEIAEgARAEIAEgARAEIAMgASADEAUgASADEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABIAMQBSACIAEQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCABIAIgARAFIAEgARAEIAEgARAEIAEgARAEIAEgARAEIAEgARAEIAEgARAEIAEgARAEIAEgARAEIAEgARAEIAEgARAEIAMgASADEAUgASADEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABEAQgASABIAMQBSACIAEQBEEBIQEDQCACIAIQBCABQQFqIgFB5ABHDQALIAJBMGoiASACIAEQBSABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCABIAEQBCACQeAAaiIDIAEgAxAFIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAAgAyACQZABahAFIAJBwAFqJAALsQEBAX8jAEEQayICIAA2AgwgAiABNgIIQQAhACACQQA7AQYDQCACIAIvAQYgAigCDCAAai0AACACKAIIIABqLQAAc3I7AQYgAiACLwEGIABBAXIiASACKAIMai0AACACKAIIIAFqLQAAc3I7AQYgAEECaiIAQSBHDQALIAIgAi8BBjsBBiACIAIvAQZBAWs7AQYgAkHQyAIvAQBBAnYgAi8BBkEPdnM7AQYgAi8BBkEBawuVBAEBfyMAQRBrIgIgADYCDCACIAE2AgggAkEAOwEGIAIgAi8BBiACKAIMLQAAIAIoAggtAABzcjsBBiACIAIvAQYgAigCDC0AASACKAIILQABc3I7AQYgAiACLwEGIAIoAgwtAAIgAigCCC0AAnNyOwEGIAIgAi8BBiACKAIMLQADIAIoAggtAANzcjsBBiACIAIvAQYgAigCDC0ABCACKAIILQAEc3I7AQYgAiACLwEGIAIoAgwtAAUgAigCCC0ABXNyOwEGIAIgAi8BBiACKAIMLQAGIAIoAggtAAZzcjsBBiACIAIvAQYgAigCDC0AByACKAIILQAHc3I7AQYgAiACLwEGIAIoAgwtAAggAigCCC0ACHNyOwEGIAIgAi8BBiACKAIMLQAJIAIoAggtAAlzcjsBBiACIAIvAQYgAigCDC0ACiACKAIILQAKc3I7AQYgAiACLwEGIAIoAgwtAAsgAigCCC0AC3NyOwEGIAIgAi8BBiACKAIMLQAMIAIoAggtAAxzcjsBBiACIAIvAQYgAigCDC0ADSACKAIILQANc3I7AQYgAiACLwEGIAIoAgwtAA4gAigCCC0ADnNyOwEGIAIgAi8BBiACKAIMLQAPIAIoAggtAA9zcjsBBiACIAIvAQY7AQYgAiACLwEGQQFrOwEGIAJB0MgCLwEAQQJ2IAIvAQZBD3ZzOwEGIAIvAQZBAWsLPwACQCAErUKAgICAECACQj98QgaIfVYNACACQoCAgIAQWg0AIAAgASACIAMgBCAFQeS9AigCABERAA8LEAwACycAIAJCgICAgBBaBEAQDAALIAAgASACIAMgBCAFQeC9AigCABEOAAuoCwEXfyMAQYAEayICJABBfyEDIAEtAB8iBEF/c0H/AHEgAS0AASABLQACIAEtAAMgAS0ABCABLQAFIAEtAAYgAS0AByABLQAIIAEtAAkgAS0ACiABLQALIAEtAAwgAS0ADSABLQAOIAEtAA8gAS0AECABLQARIAEtABIgAS0AEyABLQAUIAEtABUgAS0AFiABLQAXIAEtABggAS0AGSABLQAaIAEtABsgAS0AHCABLQAdIAEtAB5xcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcUF/c3JB/wFxQQFrQewBIAEtAAAiBWtxQQh2IAVB0sgCLQAAQQJ2IARBB3ZzcnJBAXFFBEAgAkHQAmoiDSABEDUgAkGgAmogDRAEIAJBACACKALEAiIBazYClAIgAkEAIAIoAsACIgNrNgKQAiACQQAgAigCvAIiBGs2AowCIAJBACACKAK4AiIFazYCiAIgAkEAIAIoArQCIgZrNgKEAiACQQAgAigCsAIiB2s2AoACIAJBACACKAKsAiIIazYC/AEgAkEAIAIoAqgCIglrNgL4ASACQQAgAigCpAIiCms2AvQBIAJBASACKAKgAiILazYC8AEgAkGQAWoiDCACQfABaiIREAQgAiABNgLkASACIAM2AuABIAIgBDYC3AEgAiAFNgLYASACIAY2AtQBIAIgBzYC0AEgAiAINgLMASACIAk2AsgBIAIgCjYCxAEgAiALQQFqNgLAASACQeAAaiISIAJBwAFqIhMQBCACQTBqIhBBwAwgDBAFIAIoAmAhASACKAIwIQMgAigCZCEEIAIoAjQhBSACKAJoIQYgAigCOCEHIAIoAmwhCCACKAI8IQkgAigCcCEKIAIoAkAhCyACKAJ0IQwgAigCRCEOIAIoAnghDyACKAJIIRQgAigCfCEVIAIoAkwhFiACKAKAASEXIAIoAlAhGCACQQAgAigCVCACKAKEAWprNgJUIAJBACAXIBhqazYCUCACQQAgFSAWams2AkwgAkEAIA8gFGprNgJIIAJBACAMIA5qazYCRCACQQAgCiALams2AkAgAkEAIAggCWprNgI8IAJBACAGIAdqazYCOCACQQAgBCAFams2AjQgAkEAIAEgA2prNgIwIAIgECASEAUgAkIANwKEAyACQQE2AoADIAJCADcCjAMgAkIANwKUAyACQgA3ApwDIAJBADYCpAMgAkGwA2oiASACQYADaiACEIMBIQ8gACABIBMQBSAAQShqIgMgASAAEAUgAyADIBAQBSAAIAAgDRAFIAAgACgCJEEBdCIENgIkIAAgACgCIEEBdCIFNgIgIAAgACgCHEEBdCIGNgIcIAAgACgCGEEBdCIHNgIYIAAgACgCFEEBdCIINgIUIAAgACgCEEEBdCIJNgIQIAAgACgCDEEBdCIKNgIMIAAgACgCCEEBdCILNgIIIAAgACgCBEEBdCIMNgIEIAAgACgCAEEBdCIONgIAIAJB4ANqIg0gABAPIABBACACLQDgA0EBcWsiASAEQQAgBGtzcSAEczYCJCAAIAVBACAFa3MgAXEgBXM2AiAgACAGQQAgBmtzIAFxIAZzNgIcIAAgB0EAIAdrcyABcSAHczYCGCAAIAhBACAIa3MgAXEgCHM2AhQgACAJQQAgCWtzIAFxIAlzNgIQIAAgCkEAIAprcyABcSAKczYCDCAAIAtBACALa3MgAXEgC3M2AgggACAMQQAgDGtzIAFxIAxzNgIEIAAgDkEAIA5rcyABcSAOczYCACADIBEgAxAFIABCADcCVCAAQQE2AlAgAEIANwJcIABCADcCZCAAQgA3AmwgAEEANgJ0IABB+ABqIgEgACADEAUgDSABEA8gAi0A4AMhACANIAMQD0EAIA1BIBAbQQEgD2sgAEEBcXJyayEDCyACQYAEaiQAIAMLPQECfyMAQSBrIgMkAEF/IQQgAyACIAEQIEUEQCAAQYC9AiADQQAQNhogA0EgEAdBACEECyADQSBqJAAgBAsWACABQSAQFiAAIAFBvL0CKAIAEQAAC4ACAQN/An8CQAJAAkAgASIDQf8BcSIBBEAgAEEDcQRAA0AgAC0AACICRQ0FIAEgAkYNBSAAQQFqIgBBA3ENAAsLQYCChAggACgCACICayACckGAgYKEeHFBgIGChHhHDQEgAUGBgoQIbCEEA0BBgIKECCACIARzIgFrIAFyQYCBgoR4cUGAgYKEeEcNAiAAKAIEIQIgAEEEaiIBIQAgAkGAgoQIIAJrckGAgYKEeHFBgIGChHhGDQALDAILIAAQJyAAagwDCyAAIQELA0AgASIALQAAIgJFDQEgAEEBaiEBIAIgA0H/AXFHDQALCyAACyIAQQAgAC0AACADQf8BcUYbC2ABAn8gAkUEQEEADwsgAC0AACIDBH8CQANAIAMgAS0AACIERw0BIARFDQEgAkEBayICRQ0BIAFBAWohASAALQABIQMgAEEBaiEAIAMNAAtBACEDCyADBUEACyABLQAAaws5AQF/IwBBIGsiAiQAIAAgAhA4GiAAQegAaiIAIAJCIBAtGiAAIAEQOBogAkEgEAcgAkEgaiQAQQALVwIBfwF+AkBBoL0CKAIAIgGtIACtQgd8Qvj///8fg3wiAkL/////D1gEQCACpyIAPwBBEHRNDQEgABADDQELQcDEAkEwNgIAQX8PC0GgvQIgADYCACABCwQAQQILEQAgACABIAIgA0EIEIIBQQALEQAgACABIAIgA0EMEIIBQQALEQAgACABIAIgA0EUEIIBQQALohECLH8FfiMAQaAGayICJAAgAUEoaiIDKAIAIRYgASgCUCEMIAEoAiwhDSABKAJUIQ4gASgCMCEPIAEoAlghECABKAI0IREgASgCXCESIAEoAjghEyABKAJgIRQgASgCPCEFIAEoAmQhBiABQUBrIhUoAgAhByABKAJoIQggASgCRCEJIAEoAmwhBCABKAJIIQogASgCcCELIAIgASgCTCIXIAEoAnQiGGo2AsQCIAIgCiALajYCwAIgAiAEIAlqNgK8AiACIAcgCGo2ArgCIAIgBSAGajYCtAIgAiATIBRqNgKwAiACIBEgEmo2AqwCIAIgDyAQajYCqAIgAiANIA5qNgKkAiACIAwgFmo2AqACIAIgGCAXazYCJCACIAsgCms2AiAgAiAEIAlrNgIcIAIgCCAHazYCGCACIAYgBWs2AhQgAiAUIBNrNgIQIAIgEiARazYCDCACIBAgD2s2AgggAiAOIA1rNgIEIAIgDCAWazYCACACQaACaiIEIAQgAhAFIAJB8AFqIgYgASADEAUgAkHAAWoiBSAGEAQgBSAEIAUQBSACQgA3ArQDIAJCADcCvAMgAkIANwLEAyACQgA3AswDIAJBADYC1AMgAkEBNgKwAyACQcAEaiIHIAJBsANqIAUQgwEaIAJB0AVqIgUgByAEEAUgAkGgBWoiHyAHIAYQBSACQTBqIhogBSAfEAUgGiAaIAFB+ABqIhYQBSACQZAEaiABQfAMEAUgAkHgA2ogA0HwDBAFIAJB8ARqIAVBkBcQBSACQdACaiIEIBYgGhAFIAJBgANqIhkgBBAPIAItAIADIQQgAiABKQIgIi43A7ABIAIgASkCGCIvNwOoASACIAEpAhAiMDcDoAEgAiABKQIIIjE3A5gBIAIgASkCACIyNwOQASADKAIAIRYgASgCLCEMIAEoAjAhDSABKAI0IQ4gASgCOCEPIAEoAjwhECAVKAIAIREgASgCRCESIAEoAkghEyABKAJMIRQgAigC5AMhCiACKAKUASEFIAIoAuwDIQsgAigCnAEhBiACKAL0AyEVIAIoAqQBIQcgAigC/AMhFyACKAKsASEIIAIoAoQEIRggAigCtAEhCSACKALgAyEbIAIoAugDIRwgAigC8AMhHSACKAL4AyEeIAJBACAEQQFxayIDIC6nIgQgAigCgARzcSAEczYCsAEgAiAeIC+nIgRzIANxIARzNgKoASACIB0gMKciBHMgA3EgBHM2AqABIAIgHCAxpyIEcyADcSAEczYCmAEgAiAbIDKnIgRzIANxIARzNgKQASACIAkgCSAYcyADcXM2ArQBIAIgCCAIIBdzIANxczYCrAEgAiAHIAcgFXMgA3FzNgKkASACIAYgBiALcyADcXM2ApwBIAIgBSAFIApzIANxczYClAEgAigCkAQhFyACKAKUBCEYIAIoApgEIRsgAigCnAQhHCACKAKgBCEdIAIoAqQEIR4gAigCqAQhICACKAKsBCEhIAIoArAEISIgAigCtAQhIyACKAKgBSEFIAIoAvAEISQgAigCpAUhBiACKAL0BCElIAIoAqgFIQcgAigC+AQhJiACKAKsBSEIIAIoAvwEIScgAigCsAUhCSACKAKABSEoIAIoArQFIQQgAigChAUhKSACKAK4BSEKIAIoAogFISogAigCvAUhCyACKAKMBSErIAIoAsAFIRUgAigCkAUhLCACIAIoAsQFIi0gAigClAVzIANxIC1zNgLEBSACIBUgFSAscyADcXM2AsAFIAIgCyALICtzIANxczYCvAUgAiAKIAogKnMgA3FzNgK4BSACIAQgBCApcyADcXM2ArQFIAIgCSAJIChzIANxczYCsAUgAiAIIAggJ3MgA3FzNgKsBSACIAcgByAmcyADcXM2AqgFIAIgBiAGICVzIANxczYCpAUgAiAFIAUgJHMgA3FzNgKgBSACQeAAaiIEIAJBkAFqIBoQBSAZIAQQDyABKAJQIQUgASgCVCEGIAEoAlghByABKAJcIQggASgCYCEJIAEoAmQhBCABKAJoIQogASgCbCELIAEoAnAhFSACIAEoAnRBACACLQCAA0EBcWsiASAUIBQgI3MgA3FzIhRBACAUa3NxIBRzazYCpAMgAiAVIBMgEyAicyADcXMiE0EAIBNrcyABcSATc2s2AqADIAIgCyASIBIgIXMgA3FzIhJBACASa3MgAXEgEnNrNgKcAyACIAogESARICBzIANxcyIRQQAgEWtzIAFxIBFzazYCmAMgAiAEIBAgECAecyADcXMiEEEAIBBrcyABcSAQc2s2ApQDIAIgCSAPIA8gHXMgA3FzIg9BACAPa3MgAXEgD3NrNgKQAyACIAggDiAOIBxzIANxcyIOQQAgDmtzIAFxIA5zazYCjAMgAiAHIA0gDSAbcyADcXMiDUEAIA1rcyABcSANc2s2AogDIAIgBiAMIAwgGHMgA3FzIgxBACAMa3MgAXEgDHNrNgKEAyACIAUgASAWIBYgF3MgA3FzIgFBACABa3NxIAFzazYCgAMgGSAfIBkQBSACQYAGaiAZEA8gAkEAIAItAIAGQQFxayIBIAIoAoADIgNBACADa3NxIANzNgKAAyACIAIoAoQDIgNBACADa3MgAXEgA3M2AoQDIAIgAigCiAMiA0EAIANrcyABcSADczYCiAMgAiACKAKMAyIDQQAgA2tzIAFxIANzNgKMAyACIAIoApADIgNBACADa3MgAXEgA3M2ApADIAIgAigClAMiA0EAIANrcyABcSADczYClAMgAiACKAKYAyIDQQAgA2tzIAFxIANzNgKYAyACIAIoApwDIgNBACADa3MgAXEgA3M2ApwDIAIgAigCoAMiA0EAIANrcyABcSADczYCoAMgAiABIAIoAqQDIgFBACABa3NxIAFzNgKkAyAAIBkQDyACQaAGaiQAC8EFARx/IwBBwAJrIgEkACABQfABaiIDIAAQBCABQcABaiIEIABBKGoQBCABQZABaiICIABB0ABqEAQgASgC8AEhACABKALAASEFIAEoAvQBIQYgASgCxAEhByABKAL4ASEIIAEoAsgBIQkgASgC/AEhCiABKALMASELIAEoAoACIQwgASgC0AEhDSABKAKEAiEOIAEoAtQBIQ8gASgCiAIhECABKALYASERIAEoAowCIRIgASgC3AEhEyABKAKQAiEUIAEoAuABIRUgASABKALkASABKAKUAms2AlQgASAVIBRrNgJQIAEgEyASazYCTCABIBEgEGs2AkggASAPIA5rNgJEIAEgDSAMazYCQCABIAsgCms2AjwgASAJIAhrNgI4IAEgByAGazYCNCABIAUgAGs2AjAgAUEwaiIWIBYgAhAFIAEgAyAEEAUgASABQcAMEAUgAUHgAGogAhAEIAEoAjAhACABKAJgIQUgASgCACEGIAEoAjQhByABKAJkIQggASgCBCEJIAEoAjghCiABKAJoIQsgASgCCCEMIAEoAjwhDSABKAJsIQ4gASgCDCEPIAEoAkAhECABKAJwIREgASgCECESIAEoAkQhEyABKAJ0IRQgASgCFCEVIAEoAkghAiABKAJ4IQMgASgCGCEEIAEoAkwhFyABKAJ8IRggASgCHCEZIAEoAlAhGiABKAKAASEbIAEoAiAhHCABIAEoAlQgASgChAEgASgCJGprNgJUIAEgGiAbIBxqazYCUCABIBcgGCAZams2AkwgASACIAMgBGprNgJIIAEgEyAUIBVqazYCRCABIBAgESASams2AkAgASANIA4gD2prNgI8IAEgCiALIAxqazYCOCABIAcgCCAJams2AjQgASAAIAUgBmprNgIwIAFBoAJqIgAgFhAPIABBIBAbIAFBwAJqJAALpQMCA38BfiMAQeACayIGJAAgBiAEIAVBABA2GgJ/AkACQCAAIAJLIAMgACACa61WcUUEQCAAIAJPDQEgAyACIABrrVgNAQsgA6ciBQRAIAAgAiAF/AoAAAsgBkIANwM4IAZCADcDMCAGQgA3AyggBkIANwMgQiAgAyADQiBaGyEJIANCIFYhBSAAIQIMAQsgBkIANwM4IAZCADcDMCAGQgA3AyggBkIANwMgQiAgAyADQiBaGyEJIANCIFYhBSADQgBSDQBBAQwBCyAJpyIHBEAgBkFAayACIAf8CgAAC0EACyEIIAZBIGoiByAHIAlCIHwgBEEQaiIEQgAgBkHEvQIoAgARDgAaIAZB4ABqIAdBrL0CKAIAEQAAGgJAIAgNACAJpyIHRQ0AIAAgBkFAayAH/AoAAAsgBkEgakHAABAHIAUEQCAAIAmnIgVqIAIgBWogAyAJfSAEQgEgBkHEvQIoAgARDgAaCyAGQSAQByAGQeAAaiICIAAgA0GwvQIoAgARAgAaIAIgAUG0vQIoAgARAAAaIAJBgAIQByAGQeACaiQAQQALkwMCA38BfiMAQeACayIGJAAgBiAEIAVBABAfGgJ/AkACQCAAIAJLIAMgACACa61WcUUEQCAAIAJPDQEgAyACIABrrVgNAQsgA6ciBQRAIAAgAiAF/AoAAAsgBkIANwM4IAZCADcDMCAGQgA3AyggBkIANwMgQiAgAyADQiBaGyEJIANCIFYhBSAAIQIMAQsgBkIANwM4IAZCADcDMCAGQgA3AyggBkIANwMgQiAgAyADQiBaGyEJIANCIFYhBSADQgBSDQBBAQwBCyAJpyIHBEAgBkFAayACIAf8CgAAC0EACyEIIAZBIGoiByAHIAlCIHwgBEEQaiIEIAYQfRogBkHgAGogB0GsvQIoAgARAAAaAkAgCA0AIAmnIgdFDQAgACAGQUBrIAf8CgAACyAGQSBqQcAAEAcgBQRAIAAgCaciBWogAiAFaiADIAl9IARCASAGEEkaCyAGQSAQByAGQeAAaiICIAAgA0GwvQIoAgARAgAaIAIgAUG0vQIoAgARAAAaIAJBgAIQByAGQeACaiQAQQALhxgBDn9B/wAhAgNAIAAgAUEBdGoiAyADLgEEIgQgAy4BACIGaiIFwUG/nQFsQRp1Qf9lbCAFajsBACADIAMuAQYiBSADLgECIglqIgjBQb+dAWxBGnVB/2VsIAhqOwECIAMgAkEBdEGgugJqLgEAIgggBCAGa2wiBEGAgISYf2xBEHVB/2VsIARqQRB2OwEEIAMgCCAFIAlrbCIDQYCAhJh/bEEQdUH/ZWwgA2pBEHY7AQYgAkEBayECIAFB/AFJIAFBBGohAQ0AC0E/IQEDQCAAIAdBAXRqIgMgAy4BCCIEIAMuAQAiBmoiAsFBv50BbEEadUH/ZWwgAmo7AQAgAyADLgEKIgUgAy4BAiIJaiICwUG/nQFsQRp1Qf9lbCACajsBAiADIAMuAQwiCCADLgEEIgpqIgLBQb+dAWxBGnVB/2VsIAJqOwEEIAMgAy4BDiILIAMuAQYiDGoiAsFBv50BbEEadUH/ZWwgAmo7AQYgAyABQQF0QaC6AmouAQAiAiAEIAZrbCIEQYCAhJh/bEEQdUH/ZWwgBGpBEHY7AQggAyACIAUgCWtsIgRBgICEmH9sQRB1Qf9lbCAEakEQdjsBCiADIAIgCCAKa2wiBEGAgISYf2xBEHVB/2VsIARqQRB2OwEMIAMgAiALIAxrbCIDQYCAhJh/bEEQdUH/ZWwgA2pBEHY7AQ4gAUEBayEBIAdB+AFJIAdBCGohBw0AC0EAIQcDQCAAIAdBAXRqIgIgAi4BECIEIAIuAQAiBmoiA8FBv50BbEEadUH/ZWwgA2o7AQAgAiACLgESIgUgAi4BAiIJaiIDwUG/nQFsQRp1Qf9lbCADajsBAiACIAIuARQiCCACLgEEIgpqIgPBQb+dAWxBGnVB/2VsIANqOwEEIAIgAi4BFiILIAIuAQYiDGoiA8FBv50BbEEadUH/ZWwgA2o7AQYgAiACLgEYIg0gAi4BCCIOaiIDwUG/nQFsQRp1Qf9lbCADajsBCCACIAEiA0EBdEGgugJqLgEAIgEgBCAGa2wiBEGAgISYf2xBEHVB/2VsIARqQRB2OwEQIAIgASAFIAlrbCIEQYCAhJh/bEEQdUH/ZWwgBGpBEHY7ARIgAiABIAggCmtsIgRBgICEmH9sQRB1Qf9lbCAEakEQdjsBFCACIAEgCyAMa2wiBEGAgISYf2xBEHVB/2VsIARqQRB2OwEWIAIgASANIA5rbCIEQYCAhJh/bEEQdUH/ZWwgBGpBEHY7ARggAiACLgEaIgQgAi4BCiIGaiIFwUG/nQFsQRp1Qf9lbCAFajsBCiACIAEgBCAGa2wiBEGAgISYf2xBEHVB/2VsIARqQRB2OwEaIAIgAi4BHCIEIAIuAQwiBmoiBcFBv50BbEEadUH/ZWwgBWo7AQwgAiABIAQgBmtsIgRBgICEmH9sQRB1Qf9lbCAEakEQdjsBHCACIAIuAR4iBCACLgEOIgZqIgXBQb+dAWxBGnVB/2VsIAVqOwEOIAIgASAEIAZrbCIBQYCAhJh/bEEQdUH/ZWwgAWpBEHY7AR4gA0EBayEBIAdB8AFJIAdBEGohBw0ACyABQQF0QaC6AmouAQAhB0EAIQIDQCAAIAJBAXRqIgEgAS4BICIEIAEuAQAiBmoiBcFBv50BbEEadUH/ZWwgBWo7AQAgASAEIAZrIAdsIgFBgICEmH9sQRB1Qf9lbCABakEQdjsBICACQQ9HIAJBAWohAg0ACyADQQF0QZy6AmouAQAhB0EgIQIDQCAAIAJBAXRqIgEgAS4BICIEIAEuAQAiBmoiBcFBv50BbEEadUH/ZWwgBWo7AQAgASAEIAZrIAdsIgFBgICEmH9sQRB1Qf9lbCABakEQdjsBICACQS9HIAJBAWohAg0ACyADQQF0QZq6AmouAQAhB0HAACECA0AgACACQQF0aiIBIAEuASAiBCABLgEAIgZqIgXBQb+dAWxBGnVB/2VsIAVqOwEAIAEgBCAGayAHbCIBQYCAhJh/bEEQdUH/ZWwgAWpBEHY7ASAgAkHPAEcgAkEBaiECDQALIANBAXRBmLoCai4BACEHQeAAIQIDQCAAIAJBAXRqIgEgAS4BICIEIAEuAQAiBmoiBcFBv50BbEEadUH/ZWwgBWo7AQAgASAEIAZrIAdsIgFBgICEmH9sQRB1Qf9lbCABakEQdjsBICACQe8ARyACQQFqIQINAAsgA0EBdEGWugJqLgEAIQdBgAEhAgNAIAAgAkEBdGoiASABLgEgIgQgAS4BACIGaiIFwUG/nQFsQRp1Qf9lbCAFajsBACABIAQgBmsgB2wiAUGAgISYf2xBEHVB/2VsIAFqQRB2OwEgIAJBjwFHIAJBAWohAg0ACyADQQF0QZS6AmouAQAhB0GgASECA0AgACACQQF0aiIBIAEuASAiBCABLgEAIgZqIgXBQb+dAWxBGnVB/2VsIAVqOwEAIAEgBCAGayAHbCIBQYCAhJh/bEEQdUH/ZWwgAWpBEHY7ASAgAkGvAUcgAkEBaiECDQALIANBAXRBkroCai4BACEHQcABIQIDQCAAIAJBAXRqIgEgAS4BICIEIAEuAQAiBmoiBcFBv50BbEEadUH/ZWwgBWo7AQAgASAEIAZrIAdsIgFBgICEmH9sQRB1Qf9lbCABakEQdjsBICACQc8BRyACQQFqIQINAAsgA0EBdEGQugJqLgEAIQdB4AEhAgNAIAAgAkEBdGoiASABLgEgIgQgAS4BACIGaiIFwUG/nQFsQRp1Qf9lbCAFajsBACABIAQgBmsgB2wiAUGAgISYf2xBEHVB/2VsIAFqQRB2OwEgIAJB7wFHIAJBAWohAg0ACyADQQF0QY66AmouAQAhB0EAIQIDQCAAIAJBAXRqIgEgAUFAayIELgEAIgYgAS4BACIBaiIFwUG/nQFsQRp1Qf9lbCAFajsBACAEIAYgAWsgB2wiAUGAgISYf2xBEHVB/2VsIAFqQRB2OwEAIAJBH0cgAkEBaiECDQALIANBAXRBjLoCai4BACEHQcAAIQIDQCAAIAJBAXRqIgEgAUFAayIELgEAIgYgAS4BACIBaiIFwUG/nQFsQRp1Qf9lbCAFajsBACAEIAYgAWsgB2wiAUGAgISYf2xBEHVB/2VsIAFqQRB2OwEAIAJB3wBHIAJBAWohAg0ACyADQQF0QYq6AmouAQAhB0GAASECA0AgACACQQF0aiIBIAFBQGsiBC4BACIGIAEuAQAiAWoiBcFBv50BbEEadUH/ZWwgBWo7AQAgBCAGIAFrIAdsIgFBgICEmH9sQRB1Qf9lbCABakEQdjsBACACQZ8BRyACQQFqIQINAAsgA0EBdEGIugJqLgEAIQdBwAEhAgNAIAAgAkEBdGoiASABQUBrIgQuAQAiBiABLgEAIgFqIgXBQb+dAWxBGnVB/2VsIAVqOwEAIAQgBiABayAHbCIBQYCAhJh/bEEQdUH/ZWwgAWpBEHY7AQAgAkHfAUcgAkEBaiECDQALIANBAXRBhroCai4BACEHQQAhAgNAIAAgAkEBdGoiASABLgGAASIEIAEuAQAiBmoiBcFBv50BbEEadUH/ZWwgBWo7AQAgASAEIAZrIAdsIgFBgICEmH9sQRB1Qf9lbCABakEQdjsBgAEgAkE/RyACQQFqIQINAAsgA0EBdEGEugJqLgEAIQdBgAEhAgNAIAAgAkEBdGoiASABLgGAASIEIAEuAQAiBmoiBcFBv50BbEEadUH/ZWwgBWo7AQAgASAEIAZrIAdsIgFBgICEmH9sQRB1Qf9lbCABakEQdjsBgAEgAkG/AUcgAkEBaiECDQALIANBAXRBgroCai4BACEHQQAhAkEAIQEDQCAAIAFBAXRqIgMgAy4BgAIiBCADLgEAIgZqIgXBQb+dAWxBGnVB/2VsIAVqOwEAIAMgBCAGayAHbCIDQYCAhJh/bEEQdUH/ZWwgA2pBEHY7AYACIAFBAWoiAUGAAUcNAAsDQCAAIAJBAXRqIgEgAS4BACIDQYCAhMV9bEEQdUH/ZWwgA0GhC2xqQRB2OwEAIAEgAS4BAiIBQYCAhMV9bEEQdUH/ZWwgAUGhC2xqQRB2OwECIAJBAmoiAkGAAkcNAAsLjyQBDn8jAEHwzABrIggkACAIIAIpABg3AxggCCACKQAQNwMQIAggAikACDcDCCAIIAIpAAA3AwAgCEEDOgAgIAhBMGoiAyAIQiEQcBogCEHwJGoiCSADQQAQhgIgCEHwAGoiCiAIQdAAaiIDQQAQJCAIQfAEaiIMIANBARAkIAhB8AhqIg0gA0ECECQgCEHwGGoiBiADQQMQJCAIQfAcaiIHIANBBBAkIAhB8CBqIgUgA0EFECQgChBuIAYQbiAIQfAMaiAJIAoQFSAIQfDIAGogCEHwKGogDBAVA0AgBEEBdCIDIAhB8AxqIgpqIgYgCEHwyABqIgkgA2ovAQAgBi8BAGo7AQAgCiADQQJyIgZqIgsgBiAJai8BACALLwEAajsBACAKIANBBHIiBmoiCyAGIAlqLwEAIAsvAQBqOwEAIAogA0EGciIDaiIKIAMgCWovAQAgCi8BAGo7AQAgBEEEaiIEQYACRw0ACyAJIAhB8CxqIA0QFUEAIQRBACEDA0AgA0EBdCIKIAhB8AxqIglqIgYgCEHwyABqIg8iCyAKai8BACAGLwEAajsBACAJIApBAnIiBmoiDiAGIAtqLwEAIA4vAQBqOwEAIAkgCkEEciIGaiILIAYgD2ovAQAgCy8BAGo7AQAgCSAKQQZyIgpqIgkgCiAPai8BACAJLwEAajsBACADQQRqIgNBgAJHDQALA0AgCEHwDGogBEEBdGoiAyADLgEAIgpBv50BbEEadUH/ZWwgCmo7AQAgAyADLgECIgNBv50BbEEadUH/ZWwgA2o7AQIgBEECaiIEQYACRw0AC0EAIQMDQCAIQfAMaiADQQF0aiIEIAQuAQAiCkGAgKSCBWxBEHVB/2VsIApByQpsakEQdjsBACAEIAQuAQIiBEGAgKSCBWxBEHVB/2VsIARByQpsakEQdjsBAiADQQJqIgNBgAJHDQALIAhB8BBqIgogCEHwMGogCEHwAGoQFSAIQfDIAGogCEHwNGogDBAVQQAhAwNAIAogA0EBdCIEaiIGIAhB8MgAaiIJIARqLwEAIAYvAQBqOwEAIAogBEECciIGaiILIAYgCWovAQAgCy8BAGo7AQAgCiAEQQRyIgZqIgsgBiAJai8BACALLwEAajsBACAKIARBBnIiBGoiBiAEIAlqLwEAIAYvAQBqOwEAIANBBGoiA0GAAkcNAAsgCSAIQfA4aiANEBVBACEDQQAhBANAIAogBEEBdCIJaiIGIAhB8MgAaiIPIgsgCWovAQAgBi8BAGo7AQAgCiAJQQJyIgZqIg4gBiALai8BACAOLwEAajsBACAKIAlBBHIiBmoiCyAGIA9qLwEAIAsvAQBqOwEAIAogCUEGciIJaiIGIAkgD2ovAQAgBi8BAGo7AQAgBEEEaiIEQYACRw0ACwNAIAogA0EBdGoiBCAELgEAIglBv50BbEEadUH/ZWwgCWo7AQAgBCAELgECIgRBv50BbEEadUH/ZWwgBGo7AQIgA0ECaiIDQYACRw0AC0EAIQQDQCAKIARBAXRqIgMgAy4BACIJQYCApIIFbEEQdUH/ZWwgCUHJCmxqQRB2OwEAIAMgAy4BAiIDQYCApIIFbEEQdUH/ZWwgA0HJCmxqQRB2OwECIARBAmoiBEGAAkcNAAsgCEHwFGoiCSAIQfA8aiAIQfAAahAVIAhB8MgAaiAIQfDAAGogDBAVQQAhBANAIAkgBEEBdCIDaiILIAhB8MgAaiIGIANqLwEAIAsvAQBqOwEAIAkgA0ECciILaiIOIAYgC2ovAQAgDi8BAGo7AQAgCSADQQRyIgtqIg4gBiALai8BACAOLwEAajsBACAJIANBBnIiA2oiCyADIAZqLwEAIAsvAQBqOwEAIARBBGoiBEGAAkcNAAsgBiAIQfDEAGogDRAVQQAhBEEAIQYDQCAJIAZBAXQiA2oiCyAIQfDIAGoiECIOIANqLwEAIAsvAQBqOwEAIAkgA0ECciILaiIPIAsgDmovAQAgDy8BAGo7AQAgCSADQQRyIgtqIg4gCyAQai8BACAOLwEAajsBACAJIANBBnIiA2oiCyADIBBqLwEAIAsvAQBqOwEAIAZBBGoiBkGAAkcNAAsDQCAJIARBAXRqIgMgAy4BACIGQb+dAWxBGnVB/2VsIAZqOwEAIAMgAy4BAiIDQb+dAWxBGnVB/2VsIANqOwECIARBAmoiBEGAAkcNAAtBACEEQQAhAwNAIAkgA0EBdGoiBiAGLgEAIgtBgICkggVsQRB1Qf9lbCALQckKbGpBEHY7AQAgBiAGLgECIgZBgICkggVsQRB1Qf9lbCAGQckKbGpBEHY7AQIgA0ECaiIDQYACRw0ACwNAIARBAXQiAyAIQfAMaiIGaiILIAhB8BhqIhAiDiADai8BACALLwEAajsBACAGIANBAnIiC2oiDyALIA5qLwEAIA8vAQBqOwEAIAYgA0EEciILaiIOIAsgEGovAQAgDi8BAGo7AQAgBiADQQZyIgNqIgYgAyAQai8BACAGLwEAajsBACAEQQRqIgRBgAJHDQALQQAhBANAIAogBEEBdCIDaiIGIAMgB2ovAQAgBi8BAGo7AQAgCiADQQJyIgZqIgsgBiAHai8BACALLwEAajsBACAKIANBBHIiBmoiCyAGIAdqLwEAIAsvAQBqOwEAIAogA0EGciIDaiIGIAMgB2ovAQAgBi8BAGo7AQAgBEEEaiIEQYACRw0AC0EAIQQDQCAJIARBAXQiA2oiByADIAVqLwEAIAcvAQBqOwEAIAkgA0ECciIHaiIGIAUgB2ovAQAgBi8BAGo7AQAgCSADQQRyIgdqIgYgBSAHai8BACAGLwEAajsBACAJIANBBnIiA2oiByADIAVqLwEAIAcvAQBqOwEAIARBBGoiBEGAAkcNAAtBACEDA0AgCEHwDGogA0EBdGoiBCAELgEAIgdBv50BbEEadUH/ZWwgB2o7AQAgBCAELgECIgRBv50BbEEadUH/ZWwgBGo7AQIgA0ECaiIDQYACRw0AC0EAIQMDQCAKIANBAXRqIgQgBC4BACIHQb+dAWxBGnVB/2VsIAdqOwEAIAQgBC4BAiIEQb+dAWxBGnVB/2VsIARqOwECIANBAmoiA0GAAkcNAAtBACEDA0AgCSADQQF0aiIEIAQuAQAiB0G/nQFsQRp1Qf9lbCAHajsBACAEIAQuAQIiBEG/nQFsQRp1Qf9lbCAEajsBAiADQQJqIgNBgAJHDQALQQAhBwNAQQAhBCAIQfAMaiAHQQF0aiIDIAMvAQAiBSAFQYEaayIFIAXBQQBIGzsBACADIAMvAQIiBSAFQYEaayIFIAXBQQBIGzsBAiADIAMvAQQiBSAFQYEaayIFIAXBQQBIGzsBBCADIAMvAQYiAyADQYEaayIDIAPBQQBIGzsBBiAHQQRqIgdBgAJHDQALA0BBACEHIAogBEEBdGoiAyADLwEAIgUgBUGBGmsiBSAFwUEASBs7AQAgAyADLwECIgUgBUGBGmsiBSAFwUEASBs7AQIgAyADLwEEIgUgBUGBGmsiBSAFwUEASBs7AQQgAyADLwEGIgMgA0GBGmsiAyADwUEASBs7AQYgBEEEaiIEQYACRw0ACwNAQQAhBCAJIAdBAXRqIgMgAy8BACIFIAVBgRprIgUgBcFBAEgbOwEAIAMgAy8BAiIFIAVBgRprIgUgBcFBAEgbOwECIAMgAy8BBCIFIAVBgRprIgUgBcFBAEgbOwEEIAMgAy8BBiIDIANBgRprIgMgA8FBAEgbOwEGIAdBBGoiB0GAAkcNAAsDQCAIQfAAaiAEQQF0aiIDIAMuAQAiB0G/nQFsQRp1Qf9lbCAHajsBACADIAMuAQIiA0G/nQFsQRp1Qf9lbCADajsBAiAEQQJqIgRBgAJHDQALQQAhAwNAIAwgA0EBdGoiBCAELgEAIgdBv50BbEEadUH/ZWwgB2o7AQAgBCAELgECIgRBv50BbEEadUH/ZWwgBGo7AQIgA0ECaiIDQYACRw0AC0EAIQMDQCANIANBAXRqIgQgBC4BACIHQb+dAWxBGnVB/2VsIAdqOwEAIAQgBC4BAiIEQb+dAWxBGnVB/2VsIARqOwECIANBAmoiA0GAAkcNAAtBACEHA0BBACEEIAhB8ABqIAdBAXRqIgMgAy8BACIFIAVBgRprIgUgBcFBAEgbOwEAIAMgAy8BAiIFIAVBgRprIgUgBcFBAEgbOwECIAMgAy8BBCIFIAVBgRprIgUgBcFBAEgbOwEEIAMgAy8BBiIDIANBgRprIgMgA8FBAEgbOwEGIAdBBGoiB0GAAkcNAAsDQEEAIQcgDCAEQQF0aiIDIAMvAQAiBSAFQYEaayIFIAXBQQBIGzsBACADIAMvAQIiBSAFQYEaayIFIAXBQQBIGzsBAiADIAMvAQQiBSAFQYEaayIFIAXBQQBIGzsBBCADIAMvAQYiAyADQYEaayIDIAPBQQBIGzsBBiAEQQRqIgRBgAJHDQALA0BBACEDIA0gB0EBdGoiBCAELwEAIgUgBUGBGmsiBSAFwUEASBs7AQAgBCAELwECIgUgBUGBGmsiBSAFwUEASBs7AQIgBCAELwEEIgUgBUGBGmsiBSAFwUEASBs7AQQgBCAELwEGIgQgBEGBGmsiBCAEwUEASBs7AQYgB0EEaiIHQYACRw0ACwNAIAhB8ABqIgUgA0ECdGoiBi8BAiEEIAEgA0EDbGoiByAGLwEAIgY6AAAgByAEQQR2OgACIAcgBEEEdCAGQQh2cjoAASADQQFyIgdBAnQgBWoiBS8BAiEEIAEgB0EDbGoiByAFLwEAIgU6AAAgByAEQQR2OgACIAcgBEEEdCAFQQh2cjoAASADQQJqIgNBgAFHDQALIAFBgANqIQRBACEDA0AgDCADQQJ0aiIGLwECIQcgBCADQQNsaiIFIAYvAQAiBjoAACAFIAdBBHY6AAIgBSAHQQR0IAZBCHZyOgABIAwgA0EBciIFQQJ0aiIGLwECIQcgBCAFQQNsaiIFIAYvAQAiBjoAACAFIAdBBHY6AAIgBSAHQQR0IAZBCHZyOgABIANBAmoiA0GAAUcNAAsgAUGABmohB0EAIQNBACEEA0AgDSAEQQJ0aiIGLwECIQwgByAEQQNsaiIFIAYvAQAiBjoAACAFIAxBBHY6AAIgBSAMQQR0IAZBCHZyOgABIA0gBEEBciIFQQJ0aiIGLwECIQwgByAFQQNsaiIFIAYvAQAiBjoAACAFIAxBBHY6AAIgBSAMQQR0IAZBCHZyOgABIARBAmoiBEGAAUcNAAsDQCAIQfAMaiIMIANBAnRqIg0vAQIhBCAAIANBA2xqIgcgDS8BACINOgAAIAcgBEEEdjoAAiAHIARBBHQgDUEIdnI6AAEgA0EBciIHQQJ0IAxqIgwvAQIhBCAAIAdBA2xqIgcgDC8BACIMOgAAIAcgBEEEdjoAAiAHIARBBHQgDEEIdnI6AAEgA0ECaiIDQYABRw0ACyAAQYADaiEEQQAhAwNAIAogA0ECdGoiDS8BAiEHIAQgA0EDbGoiDCANLwEAIg06AAAgDCAHQQR2OgACIAwgB0EEdCANQQh2cjoAASAKIANBAXIiDEECdGoiDS8BAiEHIAQgDEEDbGoiDCANLwEAIg06AAAgDCAHQQR2OgACIAwgB0EEdCANQQh2cjoAASADQQJqIgNBgAFHDQALIABBgAZqIQRBACEDA0AgCSADQQJ0aiIMLwECIQogBCADQQNsaiIHIAwvAQAiDDoAACAHIApBBHY6AAIgByAKQQR0IAxBCHZyOgABIAkgA0EBciIHQQJ0aiIMLwECIQogBCAHQQNsaiIHIAwvAQAiDDoAACAHIApBBHY6AAIgByAKQQR0IAxBCHZyOgABIANBAmoiA0GAAUcNAAsgAEGYCWogCCkDSDcAACAAQZAJaiAIKQNANwAAIABBiAlqIAgpAzg3AAAgAEGACWogCCkDMDcAACAIQTBqQcAAEAcgCEHwAGpBgAwQByAIQfAYakGADBAHIAhBIRAHIAFBgAlqIABBoAn8CgAAIAFBoBJqIABCoAkQngEaIAFB2BJqIAIpADg3AAAgAUHQEmogAikAMDcAACABQcgSaiACKQAoNwAAIAFBwBJqIAIpACA3AAAgCEHwzABqJABBAAvLAQEDfyMAQRBrIgMkAAJ/IAAtAOwBBEAgABAaQX8MAQsgACgC4AEiAiAAKALkASIERgRAIAAQGiAAQQA2AuABIAAoAuQBIQRBACECCwJAIARBAWsgAkYEQCADQYYBOgAPDAELIANBBjoADyAAIANBD2ogAkEBEBggA0GAAToADyAAKALkAUEBayECCyAAIANBD2ogAkEBEBggABAaQQALIAAoAugBIgQEQCABIAAgBPwKAAALIABBAToA7AEgAEEANgLgASADQRBqJAALBQBB0AELBABBAQuLLgElfiAAIAEpACgiICABKQBoIhggASkAQCIaIAEpACAiGSAYIAEpAHgiHCABKQBYIiEgASkAUCIbICAgACkAECAZIAApADAiHXx8IhV8IB0gACkAUCAVhULr+obav7X2wR+FQiCJIhVCq/DT9K/uvLc8fCIehUIoiSIdfCIWIBWFQjCJIgYgHnwiBCAdhUIBiSIXIAEpABgiHSAAKQAIIiUgASkAECIVIAApACgiHnx8IiJ8IAApAEggIoVCn9j52cKR2oKbf4VCIIkiA0LFsdXZp6+UzMQAfSIFIB6FQiiJIgJ8Igd8fCIjfCAXICMgASkACCIeIAApAAAiJiABKQAAIiIgACkAICIkfHwiH3wgJCAAQUBrKQAAIB+FQtGFmu/6z5SH0QCFQiCJIh9CiJLznf/M+YTqAHwiCIVCKIkiC3wiDCAfhUIwiSIJhUIgiSIfIAEpADgiIyAAKQAYIAEpADAiJCAAKQA4Igp8fCINfCAKIAApAFggDYVC+cL4m5Gjs/DbAIVCIIkiDUKPkouH2tiC2NoAfSIOhUIoiSIKfCIQIA2FQjCJIg0gDnwiDnwiEYVCKIkiF3wiEiAfhUIwiSITIBF8IhEgF4VCAYkiFCABKQBIIhd8IBggASkAYCIfIBYgCiAOhUIBiSIKfHwiFnwgFiADIAeFQjCJIgOFQiCJIgcgCCAJfCIIfCIJIAqFQiiJIgp8Ig58Ig98IA8gHCABKQBwIhYgECAIIAuFQgGJIgh8fCILfCAGIAuFQiCJIgYgAyAFfCIDfCIFIAiFQiiJIgh8IgsgBoVCMIkiBoVCIIkiECAXIBogAiADhUIBiSIDIAx8fCICfCADIAQgAiANhUIgiSICfCIEhUIoiSIDfCIMIAKFQjCJIgIgBHwiBHwiDSAUhUIoiSIUfCIPICF8IAsgGCAHIA6FQjCJIgcgCXwiCSAKhUIBiSIKfHwiCyAkfCAKIAIgC4VCIIkiAiARfCILhUIoiSIKfCIOIAKFQjCJIgIgC3wiCyAKhUIBiSIKfCIRICN8IAogBSAGfCIGIAiFQgGJIgUgDCAWfHwiCCAbfCAFIAggE4VCIIkiCCAJfCIMhUIoiSIFfCIJIAiFQjCJIgggDHwiDCARIBogGSADIASFQgGJIgR8IBJ8IgN8IAQgBiADIAeFQiCJIgN8IgaFQiiJIgR8IgcgA4VCMIkiA4VCIIkiEXwiEoVCKIkiCnwiEyARhUIwiSIRIBJ8IhIgCoVCAYkiCiAcfCAdICAgBSAMhUIBiSIFIA58fCIMfCAFIAwgDyAQhUIwiSIOhUIgiSIMIAMgBnwiBnwiA4VCKIkiBXwiEHwiDyAEIAaFQgGJIgYgHnwgCXwiBCAffCAGIAIgBIVCIIkiBCANIA58IgJ8IgmFQiiJIgZ8Ig0gBIVCMIkiBIVCIIkiDiAVIAIgFIVCAYkiAiAHfCAifCIHfCACIAcgCIVCIIkiByALfCIIhUIoiSICfCILIAeFQjCJIgcgCHwiCHwiFCAKhUIoiSIKIA98fCIPIBogBSADIAwgEIVCMIkiBXwiA4VCAYkiDCANICF8fCINfCAMIAcgDYVCIIkiByASfCIMhUIoiSINfCIQIAeFQjCJIgcgDHwiDCANhUIBiSINfCAXfCISfCANIBIgICACIAiFQgGJIgIgE3x8IgggFXwgAiAFIAiFQiCJIgUgBCAJfCIEfCIIhUIoiSICfCIJIAWFQjCJIgWFQiCJIhIgBCAGhUIBiSIGIB98IAt8IgQgInwgBiADIAQgEYVCIIkiBHwiA4VCKIkiBnwiCyAEhUIwiSIEIAN8IgN8IhGFQiiJIg18IhMgHiAJIAogDiAPhUIwiSIKIBR8Ig6FQgGJIhR8ICN8Igl8IAQgCYVCIIkiBCAMfCIMIBSFQiiJIgl8IhQgBIVCMIkiBCAMfCIMIAmFQgGJIgl8ICF8Ig8gFnwgCSAPIBYgECADIAaFQgGJIgZ8IBt8IgN8IAYgAyAKhUIgiSIGIAUgCHwiA3wiBYVCKIkiCHwiCSAGhUIwiSIGhUIgiSIKIA4gByACIAOFQgGJIgMgCyAdfHwiAoVCIIkiB3wiCyADhUIoiSIDIAJ8ICR8IgIgB4VCMIkiByALfCILfCIOhUIoiSIQfCIPIA0gESASIBOFQjCJIg18IhGFQgGJIhIgCSAjfHwiCSAXfCAHIAmFQiCJIgcgDHwiDCAShUIoiSIJfCISIAeFQjCJIgcgDHwiDCAJhUIBiSIJfCAcfCITfCAJIBMgDSAYIAMgC4VCAYkiA3wgFHwiC4VCIIkiDSAFIAZ8IgZ8IgUgA4VCKIkiAyALfCAffCILIA2FQjCJIg2FQiCJIhMgHiAGIAiFQgGJIgYgHXwgAnwiAnwgBiARIAIgBIVCIIkiBHwiAoVCKIkiBnwiCCAEhUIwiSIEIAJ8IgJ8IhGFQiiJIgl8IhQgDCAEIAogD4VCMIkiCiAOfCIOIBCFQgGJIhAgCyAZfHwiC4VCIIkiBHwiDCAQhUIoiSIQIAt8ICJ8IgsgBIVCMIkiBCAMfCIMIBCFQgGJIhB8IBt8Ig8gHHwgECAPIBIgAiAGhUIBiSIGfCAVfCICICR8IAYgAiAKhUIgiSICIAUgDXwiBXwiCoVCKIkiBnwiDSAChUIwiSIChUIgiSISICAgAyAFhUIBiSIDIAh8fCIFIBt8IAMgBSAHhUIgiSIFIA58IgeFQiiJIgN8IgggBYVCMIkiBSAHfCIHfCIOhUIoiSIQfCIPIAkgEyAUhUIwiSIJIBF8IhGFQgGJIhMgDSAXfHwiDSAifCAFIA2FQiCJIgUgDHwiDCAThUIoiSINfCITIAWFQjCJIgUgDHwiDCANhUIBiSINfCAdfCIUfCANIBQgAyAHhUIBiSIDIBV8IAt8IgcgGXwgAyAHIAmFQiCJIgcgAiAKfCICfCILhUIoiSIDfCIJIAeFQjCJIgeFQiCJIgogICACIAaFQgGJIgZ8IAh8IgIgI3wgBiARIAIgBIVCIIkiBHwiAoVCKIkiBnwiCCAEhUIwiSIEIAJ8IgJ8Ig2FQiiJIhF8IhQgCoVCMIkiCiADIAcgC3wiA4VCAYkiByAIICF8fCIIIB98IAcgDyAShUIwiSILIA58Ig4gBSAIhUIgiSIFfCIIhUIoiSIHfCISIAWFQjCJIgUgCHwiCCAHhUIBiSIHICJ8IAkgDiAQhUIBiSIJfCAkfCIOIBp8IAkgBCAOhUIgiSIEIAx8IgyFQiiJIgl8Ig58IhCFQiCJIg8gHiATIAIgBoVCAYkiBnwgFnwiAnwgBiADIAIgC4VCIIkiBnwiA4VCKIkiAnwiCyAGhUIwiSIGIAN8IgN8IhMgB4VCKIkiByAQfCAhfCIQIA+FQjCJIg8gE3wiEyAHhUIBiSIHIAIgA4VCAYkiAyASfCAkfCICIBt8IAMgCiANfCIKIAQgDoVCMIkiBCAChUIgiSICfCINhUIoiSIDfCIOfCAjfCISfCAHIBIgCiARhUIBiSIKIAsgFXx8IgsgH3wgCiAFIAuFQiCJIgUgBCAMfCIEfCILhUIoiSIMfCIKIAWFQjCJIgWFQiCJIhEgBCAJhUIBiSIEIBp8IBR8IgkgHXwgBCAGIAmFQiCJIgYgCHwiCIVCKIkiBHwiCSAGhUIwiSIGIAh8Igh8IhKFQiiJIgd8IhQgEYVCMIkiESASfCISIAeFQgGJIgcgCiADIAIgDoVCMIkiAyANfCIChUIBiSINfCAZfCIKIBh8IAYgCoVCIIkiBiATfCIKIA2FQiiJIg18Ig4gBoVCMIkiBiAKfCIKIAIgDyAFIAt8IgUgDIVCAYkiAiAJIB58fCILhUIgiSIMfCIJIAKFQiiJIgIgC3wgF3wiCyAMhUIwiSIMIBAgBCAIhUIBiSIEfCAcfCIIIBZ8IAQgBSADIAiFQiCJIgN8IgWFQiiJIgR8IgggByAWfHwiB4VCIIkiEHwiE4VCKIkiDyATIBAgDyAYfCAHfCIHhUIwiSIQfCIThUIBiSIPIBIgBiAZIAQgAyAIhUIwiSIEIAV8IgOFQgGJIgV8IAt8IgiFQiCJIgZ8IgsgBiAFIAuFQiiJIgUgG3wgCHwiCIVCMIkiBnwiCyACIAkgDHwiDIVCAYkiAiAOIB98fCIJIBGFQiCJIg4gAyAOfCIDIAKFQiiJIgIgIHwgCXwiCYVCMIkiDiAKIA2FQgGJIgogDCAEIAogHnwgFHwiCoVCIIkiBHwiDIVCKIkiDSAcfCAKfCIKIA8gJHx8IhGFQiCJIhJ8IhSFQiiJIg8gFCASIA8gHXwgEXwiEYVCMIkiEnwiFIVCAYkiDyATIAYgCSAiIA0gDCAEIAqFQjCJIgR8IgyFQgGJIgl8fCIKhUIgiSIGfCINIAYgCSANhUIoiSIJICN8IAp8IgqFQjCJIgZ8Ig0gECAIIBogAiADIA58IgOFQgGJIgJ8fCIIhUIgiSIOIAggAiAMIA58IgiFQiiJIgIgIXx8IgyFQjCJIg4gBSALhUIBiSIFIAMgBCAFIBd8IAd8IgWFQiCJIgR8IgOFQiiJIgcgFXwgBXwiBSAPIB98fCILhUIgiSIQfCIThUIoiSIPIBMgECAPIB58IAt8IguFQjCJIhB8IhOFQgGJIg8gFCAGIB0gByADIAQgBYVCMIkiBHwiA4VCAYkiBXwgDHwiB4VCIIkiBnwiDCAGIAUgDIVCKIkiBSAXfCAHfCIHhUIwiSIGfCIMIBIgAiAIIA58IgiFQgGJIgIgGHwgCnwiCoVCIIkiDiACIAMgDnwiA4VCKIkiAiAhfCAKfCIKhUIwiSIOIAkgDYVCAYkiCSAIIAQgCSAjfCARfCIJhUIgiSIEfCIIhUIoiSINIBZ8IAl8IgkgDyAcfHwiEYVCIIkiEnwiFIVCKIkiDyAUIBIgDyAZfCARfCIRhUIwiSISfCIUhUIBiSIPIBMgBiAgIA0gCCAEIAmFQjCJIgR8IgiFQgGJIgl8IAp8IgqFQiCJIgZ8Ig0gBiAJIA2FQiiJIgkgInwgCnwiCoVCMIkiBnwiDSAQIBUgAiADIA58IgOFQgGJIgJ8IAd8IgeFQiCJIg4gByACIAggDnwiB4VCKIkiAiAbfHwiCIVCMIkiDiAFIAyFQgGJIgUgAyAEIAUgGnwgC3wiBYVCIIkiBHwiA4VCKIkiCyAkfCAFfCIFIA8gIXx8IgyFQiCJIhB8IhOFQiiJIg8gEyAQIA8gHXwgDHwiDIVCMIkiEHwiE4VCAYkiDyAUIAYgIiALIAMgBCAFhUIwiSIEfCIDhUIBiSIFfCAIfCIIhUIgiSIGfCILIAYgBSALhUIoiSIFIBp8IAh8IgiFQjCJIgZ8IgsgEiACIAcgDnwiB4VCAYkiAiAkfCAKfCIKhUIgiSIOIAIgAyAOfCIDhUIoiSICIBx8IAp8IgqFQjCJIg4gCSANhUIBiSIJIAcgBCAJIBZ8IBF8IgmFQiCJIgR8IgeFQiiJIg0gF3wgCXwiCSAPIBh8fCIRhUIgiSISfCIUhUIoiSIPIBQgEiAPICN8IBF8IhGFQjCJIhJ8IhSFQgGJIg8gEyAGIB8gDSAHIAQgCYVCMIkiBHwiB4VCAYkiCXwgCnwiCoVCIIkiBnwiDSAGIAkgDYVCKIkiCSAVfCAKfCIKhUIwiSIGfCINIBAgGyACIAMgDnwiA4VCAYkiAnwgCHwiCIVCIIkiDiACIAcgDnwiB4VCKIkiAiAgfCAIfCIIhUIwiSIOIAUgC4VCAYkiBSADIAQgBSAefCAMfCIFhUIgiSIEfCIDhUIoiSILIBl8IAV8IgUgDyAjfHwiDIVCIIkiEHwiE4VCKIkiDyATIBAgDyAkfCAMfCIMhUIwiSIQfCIThUIBiSIPIBQgBiAeIAsgAyAEIAWFQjCJIgR8IgOFQgGJIgV8IAh8IgiFQiCJIgZ8IgsgBiAFIAuFQiiJIgUgIHwgCHwiCIVCMIkiBnwiCyASIAIgByAOfCIHhUIBiSICIBt8IAp8IgqFQiCJIg4gAiADIA58IgOFQiiJIgIgFXwgCnwiCoVCMIkiDiAJIA2FQgGJIgkgByAEIAkgGnwgEXwiCYVCIIkiBHwiB4VCKIkiDSAZfCAJfCIJIA8gF3x8IhGFQiCJIhJ8IhSFQiiJIg8gFCASIA8gFnwgEXwiEYVCMIkiEnwiFIVCAYkiDyATIAYgHCANIAcgBCAJhUIwiSIEfCIHhUIBiSIJfCAKfCIKhUIgiSIGfCINIAYgCSANhUIoiSIJICF8IAp8IgqFQjCJIgZ8Ig0gECAYIAIgAyAOfCIDhUIBiSICfCAIfCIIhUIgiSIOIAIgByAOfCIHhUIoiSICICJ8IAh8IgiFQjCJIg4gBSALhUIBiSIFIAMgBCAFIB18IAx8IgWFQiCJIgR8IgOFQiiJIgsgH3wgBXwiBSAPIBl8fCIMhUIgiSIQfCIThUIoiSIPIBMgECAPICB8IAx8IgyFQjCJIhB8IhOFQgGJIg8gFCAGICQgCyADIAQgBYVCMIkiBHwiA4VCAYkiBXwgCHwiCIVCIIkiBnwiCyAGIAUgC4VCKIkiBSAjfCAIfCIIhUIwiSIGfCILIBIgAiAHIA58IgeFQgGJIgIgInwgCnwiCoVCIIkiDiACIAMgDnwiA4VCKIkiAiAefCAKfCIKhUIwiSIOIAkgDYVCAYkiCSAHIAQgCSAVfCARfCIJhUIgiSIEfCIHhUIoiSINIB18IAl8IgkgDyAbfHwiEYVCIIkiEnwiFIVCKIkiDyAUIBIgDyAhfCARfCIRhUIwiSISfCIUhUIBiSIPIBMgBiAaIA0gByAEIAmFQjCJIgR8IgeFQgGJIgl8IAp8IgqFQiCJIgZ8Ig0gBiAJIA2FQiiJIgkgF3wgCnwiCoVCMIkiBnwiDSAQIBYgAiADIA58IgOFQgGJIgJ8IAh8IgiFQiCJIg4gAiAHIA58IgeFQiiJIgIgHHwgCHwiCIVCMIkiDiAFIAuFQgGJIgUgAyAEIAUgH3wgDHwiBYVCIIkiBHwiA4VCKIkiCyAYfCAFfCIFIA8gF3x8IheFQiCJIgx8IhCFQiiJIhMgECAMIBMgHHwgF3wiHIVCMIkiF3wiDIVCAYkiECAUIAYgGCALIAMgBCAFhUIwiSIEfCIDhUIBiSIFfCAIfCIYhUIgiSIGfCIIIAYgGCAkIAUgCIVCKIkiJHx8IhiFQjCJIgZ8IgUgEiAWIAIgByAOfCIHhUIBiSICfCAKfCIWhUIgiSIIIBYgGyACIAMgCHwiFoVCKIkiA3x8IhuFQjCJIgIgGiAJIA2FQgGJIgggByAEIAggGXwgEXwiGYVCIIkiBHwiB4VCKIkiCHwgGXwiGiAQICJ8fCIZhUIgiSIifCILhUIoiSIJIBV8IBl8IhkgJYUgByAEIBqFQjCJIhp8IhUgFyAYICAgAyACIBZ8IhiFQgGJIhZ8fCIghUIgiSIXfCIEIBcgICAdIAQgFoVCKIkiHXx8IiCFQjCJIhd8IhaFNwAIIAAgGCAaIBwgISAFICSFQgGJIhx8fCIhhUIgiSIafCIYIBogIyAYIByFQiiJIhh8ICF8IhyFQjCJIhp8IiEgJiAfIAggFYVCAYkiFSAMIAYgFSAefCAbfCIbhUIgiSIVfCIehUIoiSIjfCAbfCIbhYU3AAAgACAeIBUgG4VCMIkiG3wiFSAcIAApABCFhTcAECAAIBkgIoVCMIkiGSAAKQAgIBYgHYVCAYmFhTcAICAAIAsgGXwiGSAgIAApABiFhTcAGCAAIAApACggFSAjhUIBiYUgGoU3ACggACAAKQA4IBggIYVCAYmFIBuFNwA4IAAgACkAMCAJIBmFQgGJhSAXhTcAMAsjACABQoCAgIAQWgRAEAwACyAAIAEgAiADQdi9AigCABEQAAvwCQEefyABKAIoIQMgASgCBCEEIAEoAiwhBSABKAIIIQYgASgCMCEHIAEoAgwhCCABKAI0IQkgASgCECEKIAEoAjghCyABKAIUIQwgASgCPCENIAEoAhghDiABQUBrIg8oAgAhECABKAIcIREgASgCRCESIAEoAiAhEyABKAJIIRQgASgCACEVIAAgASgCJCABKAJMajYCJCAAIBMgFGo2AiAgACARIBJqNgIcIAAgDiAQajYCGCAAIAwgDWo2AhQgACAKIAtqNgIQIAAgCCAJajYCDCAAIAYgB2o2AgggACAEIAVqNgIEIAAgAyAVajYCACABKAIoIQUgASgCBCEDIAEoAiwhBiABKAIIIQcgASgCMCEIIAEoAgwhCSABKAI0IQogASgCECELIAEoAjghDCABKAIUIQ0gASgCPCEOIAEoAhghECAPKAIAIQ8gASgCHCEEIAEoAkQhESABKAIgIRIgASgCSCETIAEoAgAhFCAAIAEoAkwgASgCJGs2AkwgACATIBJrNgJIIAAgESAEazYCRCAAQUBrIgQgDyAQazYCACAAIA4gDWs2AjwgACAMIAtrNgI4IAAgCiAJazYCNCAAIAggB2s2AjAgACAGIANrNgIsIABBKGoiAyAFIBRrNgIAIABB0ABqIAAgAkEoahAFIAMgAyACEAUgAEH4AGogAkH4AGogAUH4AGoQBSAAIAFB0ABqIAJB0ABqEAUgACgCBCEVIAAoAgghFiAAKAIMIRcgACgCECEYIAAoAhQhGSAAKAIYIRogACgCHCEbIAAoAiAhHCAAKAIkIR0gAygCACEBIAAoAlAhAiAAKAIsIQUgACgCVCEGIAAoAjAhByAAKAJYIQggACgCNCEJIAAoAlwhCiAAKAI4IQsgACgCYCEMIAAoAjwhDSAAKAJkIQ4gBCgCACEPIAAoAmghECAAKAJEIREgACgCbCESIAAoAkghEyAAKAJwIRQgACgCACEeIAAgACgCTCIfIAAoAnQiIGo2AkwgACATIBRqNgJIIAAgESASajYCRCAEIA8gEGo2AgAgACANIA5qNgI8IAAgCyAMajYCOCAAIAkgCmo2AjQgACAHIAhqNgIwIAAgBSAGajYCLCADIAEgAmo2AgAgACAgIB9rNgIkIAAgFCATazYCICAAIBIgEWs2AhwgACAQIA9rNgIYIAAgDiANazYCFCAAIAwgC2s2AhAgACAKIAlrNgIMIAAgCCAHazYCCCAAIAYgBWs2AgQgACACIAFrNgIAIAAgACgCnAEiASAdQQF0IgJqNgKcASAAIAAoApgBIgMgHEEBdCIEajYCmAEgACAAKAKUASIFIBtBAXQiBmo2ApQBIAAgACgCkAEiByAaQQF0IghqNgKQASAAIAAoAowBIgkgGUEBdCIKajYCjAEgACAAKAKIASILIBhBAXQiDGo2AogBIAAgACgChAEiDSAXQQF0Ig5qNgKEASAAIAAoAoABIg8gFkEBdCIQajYCgAEgACAAKAJ8IhEgFUEBdCISajYCfCAAIAAoAngiEyAeQQF0IhRqNgJ4IAAgBCADazYCcCAAIAYgBWs2AmwgACAIIAdrNgJoIAAgCiAJazYCZCAAIAwgC2s2AmAgACAOIA1rNgJcIAAgECAPazYCWCAAIBIgEWs2AlQgACAUIBNrNgJQIAAgAiABazYCdAtAAQN/IAAgASABQfgAaiICEAUgAEEoaiABQShqIgMgAUHQAGoiBBAFIABB0ABqIAQgAhAFIABB+ABqIAEgAxAFC4oGARd/IwBBwAJrIgIkACAAQShqIgYgARA1IABCADcCVCAAQQE2AlAgAEIANwJcIABCADcCZCAAQgA3AmwgAEEANgJ0IAJB8AFqIgUgBhAEIAJBwAFqIgQgBUHADBAFQX8hByACIAIoAvABQQFrIgg2AvABIAIgAigCwAFBAWo2AsABIAIoAvQBIQkgAigC+AEhCiACKAL8ASELIAIoAoACIQwgAigChAIhDSACKAKIAiEOIAIoAowCIQ8gAigCkAIhECACKAKUAiERIAJBkAFqIgMgBBAEIAMgAyAEEAUgACADEAQgACAAIAQQBSAAIAAgBRAFIAAgABCIASAAIAAgAxAFIAAgACAFEAUgAkHgAGoiAyAAEAQgAyADIAQQBSACIAIoAoQBIgQgEWs2AlQgAiACKAKAASIDIBBrNgJQIAIgAigCfCIFIA9rNgJMIAIgAigCeCISIA5rNgJIIAIgAigCdCITIA1rNgJEIAIgAigCcCIUIAxrNgJAIAIgAigCbCIVIAtrNgI8IAIgAigCaCIWIAprNgI4IAIgAigCZCIXIAlrNgI0IAIgAigCYCIYIAhrNgIwIAIgAkEwahAPAkAgAkEgEBtFBEAgAiAEIBFqNgIkIAIgAyAQajYCICACIAUgD2o2AhwgAiAOIBJqNgIYIAIgDSATajYCFCACIAwgFGo2AhAgAiALIBVqNgIMIAIgCiAWajYCCCACIAkgF2o2AgQgAiAIIBhqNgIAIAJBoAJqIgQgAhAPIARBIBAbRQ0BIAAgAEHwDBAFCyACQaACaiAAEA8gAi0AoAJBAXEgAS0AH0EHdkYEQCAAQQAgACgCAGs2AgAgAEEAIAAoAiRrNgIkIABBACAAKAIgazYCICAAQQAgACgCHGs2AhwgAEEAIAAoAhhrNgIYIABBACAAKAIUazYCFCAAQQAgACgCEGs2AhAgAEEAIAAoAgxrNgIMIABBACAAKAIIazYCCCAAQQAgACgCBGs2AgQLIABB+ABqIAAgBhAFQQAhBwsgAkHAAmokACAHCxcAIAAgASACrSADrUIghoQgBCAFENsBCxcAIAAgASACrSADrUIghoQgBCAFENwBC6MBAQV/AkBBgAggAS0AAEHBABAxIgJFDQBBgAggAS0AAUHBABAxIgNFDQBBgAggAS0AAkHBABAxIgRFDQBBgAggAS0AA0HBABAxIgVFDQBBgAggAS0ABEHBABAxIgZFDQAgACACQYAIayADQYAIa0EGdHIgBEGACGtBDHRyIAVBgAhrQRJ0ciAGQYAIa0EYdHI2AgAgAUEFag8LIABBADYCAEEAC74GAQR/IAIgACADQQd0akFAaiIEKQI4NwI4IAIgBCkCMDcCMCACIAQpAig3AiggAiAEKQIgNwIgIAIgBCkCGDcCGCACIAQpAhA3AhAgAiAEKQIINwIIIAIgBCkCADcCACADQQZ0IQYgA0EBdCEHA0AgAiACKAIAIAAgBUEGdGoiAygCAHM2AgAgAiACKAIEIAMoAgRzNgIEIAIgAigCCCADKAIIczYCCCACIAIoAgwgAygCDHM2AgwgAiACKAIQIAMoAhBzNgIQIAIgAigCFCADKAIUczYCFCACIAIoAhggAygCGHM2AhggAiACKAIcIAMoAhxzNgIcIAIgAigCICADKAIgczYCICACIAIoAiQgAygCJHM2AiQgAiACKAIoIAMoAihzNgIoIAIgAigCLCADKAIsczYCLCACIAIoAjAgAygCMHM2AjAgAiACKAI0IAMoAjRzNgI0IAIgAigCOCADKAI4czYCOCACIAIoAjwgAygCPHM2AjwgAhDYASABIAVBBXRqIgQgAikCODcCOCAEIAIpAjA3AjAgBCACKQIoNwIoIAQgAikCIDcCICAEIAIpAhg3AhggBCACKQIQNwIQIAQgAikCCDcCCCAEIAIpAgA3AgAgAiACKAIAIANBQGsoAgBzNgIAIAIgAigCBCADKAJEczYCBCACIAIoAgggAygCSHM2AgggAiACKAIMIAMoAkxzNgIMIAIgAigCECADKAJQczYCECACIAIoAhQgAygCVHM2AhQgAiACKAIYIAMoAlhzNgIYIAIgAigCHCADKAJcczYCHCACIAIoAiAgAygCYHM2AiAgAiACKAIkIAMoAmRzNgIkIAIgAigCKCADKAJoczYCKCACIAIoAiwgAygCbHM2AiwgAiACKAIwIAMoAnBzNgIwIAIgAigCNCADKAJ0czYCNCACIAIoAjggAygCeHM2AjggAiACKAI8IAMoAnxzNgI8IAIQ2AEgBCAGaiIDIAIpAjg3AjggAyACKQIwNwIwIAMgAikCKDcCKCADIAIpAiA3AiAgAyACKQIYNwIYIAMgAikCEDcCECADIAIpAgg3AgggAyACKQIANwIAIAVBAmoiBSAHSQ0ACwsiAQF/IAAoAgAiAQRAIAEQFwsgAEIANwIAIABBADYCCEEAC5ECAQR/IwBBQGoiBCQAAkAgABAnIgZBgAFJIAFC/////w9YcUUEQEHAxAJBHDYCAEF/IQAMAQsgBEEANgI8IARCADcCNCAEQgA3AiwCQAJ/QQAgBkUNABogBiIFIAZBAXJBgIAESQ0AGiAFCyIHECMiBUUNACAFQQRrLQAAQQNxRQ0AIAUgBxAHCyAFRQRAQX8hAAwBCyAEIAU2AgwgBCAFNgIUIAQgBjYCGCAEIAU2AgQgBCAGNgIQIARCADcCHCAEIAY2AgggBEIANwIkAn8gBEEEaiAAIAMQ9gEEQEHAxAJBHDYCAEF/DAELIAQoAiwgAadHIAQoAjAgAkEKdkdyCyEAIAUQFwsgBEFAayQAIAALBABBBAuHDwEMfyMAQTBrIgYkAAJAIAAQlwEiAw0AQWYhAyABQQNrQX5JDQAgACgCLCECIAAoAjAhAyAGQQA2AgQgACgCKCEEIAYgAzYCICAGQX82AhAgBiAENgIMIAYgAiADQQN0IgQgAiAESxsgA0ECdCICbiIDNgIYIAYgA0ECdDYCHCAGIAIgA2w2AhQgACgCNCEDIAYgATYCKCAGIAM2AiQCfyMAIgEhCyABQYAJa0FAcSIBJABBZyECAkAgBkEEaiIDRQ0AIABFDQAgAyADKAIUQQN0ECMiBDYCBEFqIQIgBEUNAAJAAkAgAygCECICRQ0AIAJBCnQiBCACbkGACEcNACADQQwQIyICNgIAIAJFDQAgAkIANwIAQcDEAiABQYABaiAEELkBIgI2AgACQCACBEAgAUEANgKAAQwBCyABKAKAASICDQILIAMoAgAQFyADQQA2AgALIAMgACgCOBD8ASALJABBagwCCyADKAIAIAI2AgAgAygCACACNgIEIAMoAgAgBDYCCCADKAIkIQcgAUGAAWoiAkEAQQBBwAAQLhogASAAKAIwNgJ8IAIgAUH8AGoiBEIEEA0aIAEgACgCBDYCfCACIARCBBANGiABIAAoAiw2AnwgAiAEQgQQDRogASAAKAIoNgJ8IAIgBEIEEA0aIAFBEzYCfCACIARCBBANGiABIAc2AnwgAiAEQgQQDRogASAAKAIMNgJ8IAIgBEIEEA0aAkAgACgCCCIERQ0AIAIgBCAANQIMEA0aIAAtADhBAXFFDQAgACgCCCAAKAIMEAcgAEEANgIMCyABIAAoAhQ2AnwgAUGAAWoiAiABQfwAakIEEA0aIAAoAhAiBARAIAIgBCAANQIUEA0aCyABIAAoAhw2AnwgAUGAAWoiAiABQfwAakIEEA0aAkAgACgCGCIERQ0AIAIgBCAANQIcEA0aIAAtADhBAnFFDQAgACgCGCAAKAIcEAcgAEEANgIcCyABIAAoAiQ2AnwgAUGAAWoiAiABQfwAakIEEA0aIAAoAiAiBARAIAIgBCAANQIkEA0aCyABQYABaiABQTBqQcAAECsaIAFB8ABqQQgQByADKAIcBEBBACECA0AgAUEANgJwIAEgAjYCdCABQYABakGACCABQTBqQcgAEJ0BIAMoAgAoAgQgAygCGCACbEEKdGohB0EAIQQDQCAHIARBA3QiBWogAUGAAWoiCCAFaikDADcDACAHIAVBCHIiCWogCCAJaikDADcDACAHIAVBEHIiCWogCCAJaikDADcDACAHIAVBGHIiBWogBSAIaikDADcDACAEQQRqIgRBgAFHDQALIAFBATYCcCAIQYAIIAFBMGpByAAQnQEgAygCACgCBCADKAIYIAJsQQp0akGACGohB0EAIQQDQCAHIARBA3QiBWogAUGAAWoiCCAFaikDADcDACAHIAVBCHIiCWogCCAJaikDADcDACAHIAVBEHIiCWogCCAJaikDADcDACAHIAVBGHIiBWogBSAIaikDADcDACAEQQRqIgRBgAFHDQALIAJBAWoiAiADKAIcSQ0ACwsgAUGAAWpBgAgQByABQTBqQcgAEAdBACECCyALJAAgAgsiAw0AIAYoAgwEQANAIwBB0ABrIgEkAAJAIAZBBGoiAkUNACACKAIcRQ0AIAFBADoASCABIAw2AkBBACEDA0AgAUEANgJMIAEgAzYCRCABIAEpAkA3AzAgASABKQJINwM4IAIgAUEwahBtIANBAWoiAyACKAIcIgRJDQALIAFBAToASCAERQ0AQQAhAwNAIAFBADYCTCABIAM2AkQgASABKQJANwMgIAEgASkCSDcDKCACIAFBIGoQbSADQQFqIgMgAigCHCIESQ0ACyABQQI6AEggBEUNAEEAIQMDQCABQQA2AkwgASADNgJEIAEgASkCQDcDECABIAEpAkg3AxggAiABQRBqEG0gA0EBaiIDIAIoAhwiBEkNAAsgAUEDOgBIIARFDQBBACEDA0AgAUEANgJMIAEgAzYCRCABIAEpAkA3AwAgASABKQJINwMIIAIgARBtIANBAWoiAyACKAIcSQ0ACwsgAUHQAGokACAMQQFqIgwgBigCDEkNAAsLIAZBBGohAyMAQYAQayIBJAACQCAARQ0AIANFDQAgAUGACGogAygCACgCBCADKAIYIgtBCnRqIgxBgAhrQYAI/AoAACADKAIcIglBAk8EQEEBIQcDQCAMIAcgC2xBCnRqQYAIayECQQAhBQNAIAVBA3QiBCABQYAIaiIIaiIKIAopAwAgAiAEaikDAIU3AwAgCCAEQQhyIgpqIg0gDSkDACACIApqKQMAhTcDACAIIARBEHIiCmoiDSANKQMAIAIgCmopAwCFNwMAIAggBEEYciIEaiIIIAgpAwAgAiAEaikDAIU3AwAgBUEEaiIFQYABRw0ACyAHQQFqIgcgCUcNAAsLIAEgAUGACGoiAkGACPwKAAAgACgCACAAKAIEIAFBgAgQnQEgAkGACBAHIAFBgAgQByADIAAoAjgQ/AELIAFBgBBqJABBACEDCyAGQTBqJAAgAwv/AgIDfwF+IwBB4ABrIgYkACAGIAQgBUEAEDYaIAZBIGoiBUIgIARBEGoiBCAGQcC9AigCABEQABoCfyACIAEgAyAFQai9AigCABESAARAIAZBIBAHQX8MAQsCQCAARQRAIAZBIBAHIAZBIGpBwAAQBwwBCwJAAkACQAJAIAAgAUkgAyABIABrrVZxRQRAIAAgAU0NASADIAAgAWutWA0BCyADpyICBEAgACABIAL8CgAACyAAIQEMAQsgA1ANAQsgBkFAayEFQiAgAyADQiBaGyIJpyICRSIHRQRAIAUgASAC/AoAAAsgBkEgaiIIIAggCUIgfCAEQgAgBkHEvQIoAgARDgAaIAdFBEAgACAFIAL8CgAACyAGQSBqQcAAEAcgA0IhVA0BIAAgAmogASACaiADIAl9IARCASAGQcS9AigCABEOABoMAQsgBkEgaiIAIABCICAEQgAgBkHEvQIoAgARDgAaIABBwAAQBwsgBkEgEAcLQQALIAZB4ABqJAALygICA38BfiMAQeAAayIGJAAgBiAEIAVBABAfGiAGQSBqIgVCICAEQRBqIgQgBhBfGgJ/IAIgASADIAVBqL0CKAIAERIABEAgBkEgEAdBfwwBCwJAIABFBEAgBkEgEAcgBkEgakHAABAHDAELAkACQAJAAkAgACABSSADIAEgAGutVnFFBEAgACABTQ0BIAMgACABa61YDQELIAOnIgIEQCAAIAEgAvwKAAALIAAhAQwBCyADUA0BCyAGQUBrIQVCICADIANCIFobIgmnIgJFIgdFBEAgBSABIAL8CgAACyAGQSBqIgggCCAJQiB8IAQgBhB9GiAHRQRAIAAgBSAC/AoAAAsgA0IhVA0BIAAgAmogASACaiADIAl9IARCASAGEEkaDAELIAZBIGoiACAAQiAgBCAGEH0aCyAGQSAQBwtBAAsgBkHgAGokAAupHgIRfxR+IwBBgCBrIgQkAAJAIABFDQACQAJAAn8gACgCJCICQQJHBEAgACgCBCENIAEtAAghBSABKAIADAELIAAoAgQhDSABLQAIIQUgASgCACILDQEgBUH/AXFBAk8NAUEACyELIARBgBhqQQBBgAj8CwAgBEG4EGpBAEHIB/wLACAEIAutNwOAECABNQIEIRMgBCAFrUL/AYM3A5AQIAQgEzcDiBAgBCAANQIQNwOYECAANQIIIRMgBCACrTcDqBAgBCATNwOgEEEAIQIgACgCFEUNAUIAIRMDQCADQf8AcSICRQRAIAQgE0IBfCITNwOwECAEQQBBgAj8CwAgBEGACGoiBkEAQYAI/AsAIARBgBhqIgcgBEGAEGogBBCaASAHIAQgBhCaAQsgDSADQQN0aiAEQYAIaiACQQN0aikDADcDACADQQFqIgMgACgCFCICSQ0ACwwBCyAAKAIUIQJBASEQC0EAQQIgCyAFQf8BcSIMciIDGyIIIAJPDQAgA0UhEUF/IAAoAhgiA0EBayAIIAMgASgCBCIFbGogAiAMbGoiCSADcBsgCWohAyAMQQFqIRIgBa0hJgNAIAlBAWsgAyAJIAAoAhgiBXBBAUYbIQ4gACgCHCEHIBAEfyAAKAIAKAIEIA5BCnRqBSANIAhBA3RqCykDACEVIAEgCDYCDCAmIBVCIIinIAdwrSARGyEWAn4gC0UEQCAMRQRAIAhBAWshA0IADAILIAIgDGwhAiAWICZRBEAgAiAIakEBayEDQgAMAgsgAiAIRWshA0IADAELIBYgJlEEfyAIIAJBf3NqBUEAQX8gCBsgAmsLIAVqIQNCACAMQQNGDQAaIAIgEmytCyETIAAoAgAoAgQiByAFIBanbEEKdGogEyADQQFrrXwgA60gFUL/////D4MiEyATfkIgiH5CIIh9IAWtgqdBCnRqIQMgByAOQQp0aiECIAcgCUEKdGohBwJAIAsEQCACIAMgBxCaAQwBCyAEQYAYaiADQYAI/AoAAEEAIQUDQCAFQQN0IgMgBEGAGGoiCmoiBiAGKQMAIAIgA2opAwCFNwMAIAogA0EIciIGaiIPIA8pAwAgAiAGaikDAIU3AwAgCiADQRByIgZqIg8gDykDACACIAZqKQMAhTcDACAKIANBGHIiA2oiBiAGKQMAIAIgA2opAwCFNwMAIAVBBGoiBUGAAUcNAAsgBEGAEGogCkGACPwKAABBACEDQQAhBQNAIARBgBhqIAVBB3RqIgIgAikDOCITIAIpAxgiFnwgFkIBhkL+////H4MgE0L/////D4N+fCIWIAIpA3iFQiCJIhUgAikDWCIYfCAVQv////8PgyAYQgGGQv7///8fg358IhggE4VCKIkiEyAWfCATQv////8PgyAWQgGGQv7///8fg358IhYgFYVCMIkiFSACKQMoIhQgAikDCCIXfCAXQgGGQv7///8fgyAUQv////8Pg358IhcgAikDaIVCIIkiGyACKQNIIhx8IBtC/////w+DIBxCAYZC/v///x+DfnwiHCAUhUIoiSIUIBd8IBRC/////w+DIBdCAYZC/v///x+DfnwiFyAbhUIwiSIbIBx8IBtC/////w+DIBxCAYZC/v///x+DfnwiHCAUhUIBiSIUIAIpAyAiHyACKQMAIhp8IBpCAYZC/v///x+DIB9C/////w+DfnwiGiACKQNghUIgiSIgIAJBQGsiBikDACIjfCAgQv////8PgyAjQgGGQv7///8fg358IiMgH4VCKIkiHyAafCAfQv////8PgyAaQgGGQv7///8fg358Ihp8IBRC/////w+DIBpCAYZC/v///x+DfnwiGYVCIIkiJCACKQMwIiEgAikDECIdfCAdQgGGQv7///8fgyAhQv////8Pg358Ih0gAikDcIVCIIkiIiACKQNQIh58ICJC/////w+DIB5CAYZC/v///x+DfnwiHiAhhUIoiSIhIB18ICFC/////w+DIB1CAYZC/v///x+DfnwiHSAihUIwiSIiIB58ICJC/////w+DIB5CAYZC/v///x+DfnwiHnwgJEL/////D4MgHkIBhkL+////H4N+fCIlIBSFQiiJIhQgGXwgFEL/////D4MgGUIBhkL+////H4N+fCIZNwMAIAIgGSAkhUIwiSIZNwN4IAIgGSAlfCAZQv////8PgyAlQgGGQv7///8fg358Ihk3A1AgAiAUIBmFQgGJNwMoIAIgHiAhhUIBiSIUIBd8IBRC/////w+DIBdCAYZC/v///x+DfnwiFyAaICCFQjCJIhqFQiCJIiAgFSAYfCAVQv////8PgyAYQgGGQv7///8fg358IhV8ICBC/////w+DIBVCAYZC/v///x+DfnwiGCAUhUIoiSIUIBd8IBRC/////w+DIBdCAYZC/v///x+DfnwiGSAghUIwiSIXNwNgIAIgGTcDCCACIBcgGHwgF0L/////D4MgGEIBhkL+////H4N+fCIYNwNYIAIgFCAYhUIBiTcDMCACIBMgFYVCAYkiEyAdfCATQv////8PgyAdQgGGQv7///8fg358IhUgG4VCIIkiGCAaICN8IBpC/////w+DICNCAYZC/v///x+DfnwiFHwgGEL/////D4MgFEIBhkL+////H4N+fCIXIBOFQiiJIhMgFXwgE0L/////D4MgFUIBhkL+////H4N+fCIbIBiFQjCJIhU3A2ggAiAbNwMQIAYgFSAXfCAVQv////8PgyAXQgGGQv7///8fg358IhU3AwAgAiATIBWFQgGJNwM4IAIgFiAUIB+FQgGJIhN8IBZCAYZC/v///x+DIBNC/////w+DfnwiFiAihUIgiSIVIBx8IBVC/////w+DIBxCAYZC/v///x+DfnwiGCAThUIoiSITIBZ8IBNC/////w+DIBZCAYZC/v///x+DfnwiFCAVhUIwiSIWNwNwIAIgFDcDGCACIBYgGHwgFkL/////D4MgGEIBhkL+////H4N+fCIWNwNIIAIgEyAWhUIBiTcDICAFQQFqIgVBCEcNAAsDQCAEQYAYaiADQQR0aiICIAIpA4gDIhMgAikDiAEiFnwgFkIBhkL+////H4MgE0L/////D4N+fCIWIAIpA4gHhUIgiSIVIAIpA4gFIhh8IBVC/////w+DIBhCAYZC/v///x+DfnwiGCAThUIoiSITIBZ8IBNC/////w+DIBZCAYZC/v///x+DfnwiFiAVhUIwiSIVIAIpA4gCIhQgAikDCCIXfCAXQgGGQv7///8fgyAUQv////8Pg358IhcgAikDiAaFQiCJIhsgAikDiAQiHHwgG0L/////D4MgHEIBhkL+////H4N+fCIcIBSFQiiJIhQgF3wgFEL/////D4MgF0IBhkL+////H4N+fCIXIBuFQjCJIhsgHHwgG0L/////D4MgHEIBhkL+////H4N+fCIcIBSFQgGJIhQgAikDgAIiHyACKQMAIhp8IBpCAYZC/v///x+DIB9C/////w+DfnwiGiACKQOABoVCIIkiICACKQOABCIjfCAgQv////8PgyAjQgGGQv7///8fg358IiMgH4VCKIkiHyAafCAfQv////8PgyAaQgGGQv7///8fg358Ihp8IBRC/////w+DIBpCAYZC/v///x+DfnwiGYVCIIkiJCACKQOAAyIhIAIpA4ABIh18IB1CAYZC/v///x+DICFC/////w+DfnwiHSACKQOAB4VCIIkiIiACKQOABSIefCAiQv////8PgyAeQgGGQv7///8fg358Ih4gIYVCKIkiISAdfCAhQv////8PgyAdQgGGQv7///8fg358Ih0gIoVCMIkiIiAefCAiQv////8PgyAeQgGGQv7///8fg358Ih58ICRC/////w+DIB5CAYZC/v///x+DfnwiJSAUhUIoiSIUIBl8IBRC/////w+DIBlCAYZC/v///x+DfnwiGTcDACACIBkgJIVCMIkiGTcDiAcgAiAZICV8IBlC/////w+DICVCAYZC/v///x+DfnwiGTcDgAUgAiAUIBmFQgGJNwOIAiACIB4gIYVCAYkiFCAXfCAUQv////8PgyAXQgGGQv7///8fg358IhcgGiAghUIwiSIahUIgiSIgIBUgGHwgFUL/////D4MgGEIBhkL+////H4N+fCIVfCAgQv////8PgyAVQgGGQv7///8fg358IhggFIVCKIkiFCAXfCAUQv////8PgyAXQgGGQv7///8fg358IhkgIIVCMIkiFzcDgAYgAiAZNwMIIAIgFyAYfCAXQv////8PgyAYQgGGQv7///8fg358Ihg3A4gFIAIgFCAYhUIBiTcDgAMgAiATIBWFQgGJIhMgHXwgE0L/////D4MgHUIBhkL+////H4N+fCIVIBuFQiCJIhggGiAjfCAaQv////8PgyAjQgGGQv7///8fg358IhR8IBhC/////w+DIBRCAYZC/v///x+DfnwiFyAThUIoiSITIBV8IBNC/////w+DIBVCAYZC/v///x+DfnwiGyAYhUIwiSIVNwOIBiACIBs3A4ABIAIgFSAXfCAVQv////8PgyAXQgGGQv7///8fg358IhU3A4AEIAIgEyAVhUIBiTcDiAMgAiAWIBQgH4VCAYkiE3wgFkIBhkL+////H4MgE0L/////D4N+fCIWICKFQiCJIhUgHHwgFUL/////D4MgHEIBhkL+////H4N+fCIYIBOFQiiJIhMgFnwgE0L/////D4MgFkIBhkL+////H4N+fCIUIBWFQjCJIhY3A4AHIAIgFDcDiAEgAiAWIBh8IBZC/////w+DIBhCAYZC/v///x+DfnwiFjcDiAQgAiATIBaFQgGJNwOAAiADQQFqIgNBCEcNAAsgByAEQYAQakGACPwKAABBACEDA0AgByADQQN0IgJqIgUgBSkDACAEQYAYaiIKIAJqKQMAhTcDACAHIAJBCHIiBWoiBiAGKQMAIAUgCmopAwCFNwMAIAcgAkEQciIFaiIGIAYpAwAgBEGAGGogBWopAwCFNwMAIAcgAkEYciICaiIFIAUpAwAgBEGAGGogAmopAwCFNwMAIANBBGoiA0GAAUcNAAsLIA5BAWohAyAJQQFqIQkgCEEBaiIIIAAoAhQiAkkNAAsLIARBgCBqJAAL8xYBCn8DQCAAIApBCXRqIQlBACEBA0AgCSABQQF0aiIDQYACaiADLwEAIgIgAy4BgAIiBEGAgKzYB2xBEHVB/2VsIARBixRsakEQdiIEazsBACADIAIgBGo7AQAgAyADLwECIgIgAy4BggIiBEGAgKzYB2xBEHVB/2VsIARBixRsakEQdiIEazsBggIgAyACIARqOwECIAFBAmoiAUGAAUcNAAtBACEDA0BBgAEhASAJIANBAXRqIgJBgAFqIAIvAQAiBCACLgGAASIIQYCA6MwDbEEQdUH/ZWwgCEGaF2xqQRB2IghrOwEAIAIgBCAIajsBACACIAIvAQIiBCACLgGCASIIQYCA6MwDbEEQdUH/ZWwgCEGaF2xqQRB2IghrOwGCASACIAQgCGo7AQIgA0E+RyADQQJqIQMNAAsDQCAJIAFBAXRqIgNBgAFqIAMvAQAiAiADLgGAASIEQYCA0BhsQRB1Qf9lbCAEQZQObGpBEHYiBGs7AQAgAyACIARqOwEAIAMgAy8BAiICIAMuAYIBIgRBgIDQGGxBEHVB/2VsIARBlA5sakEQdiIEazsBggEgAyACIARqOwECIAFBvgFHIAFBAmohAQ0AC0EAIQMDQEHAACEBIAkgA0EBdGoiAkFAayIEIAIvAQAiCCAELgEAIgRBgIDUpgNsQRB1Qf9lbCAEQdULbGpBEHYiBGs7AQAgAiAEIAhqOwEAIAIgAi8BAiIEIAIuAUIiCEGAgNSmA2xBEHVB/2VsIAhB1QtsakEQdiIIazsBQiACIAQgCGo7AQIgA0EeRyADQQJqIQMNAAsDQCAJIAFBAXRqIgNBQGsiAiADLwEAIgQgAi4BACICQYCAuPx8bEEQdUH/ZWwgAkGOC2xqQRB2IgJrOwEAIAMgAiAEajsBACADIAMvAQIiAiADLgFCIgRBgIC4/HxsQRB1Qf9lbCAEQY4LbGpBEHYiBGs7AUIgAyACIARqOwECIAFB3gBHIAFBAmohAQ0AC0GAASEBA0AgCSABQQF0aiIDQUBrIgIgAy8BACIEIAIuAQAiAkGAgPzwBmxBEHVB/2VsIAJBnwJsakEQdiICazsBACADIAIgBGo7AQAgAyADLwECIgIgAy4BQiIEQYCA/PAGbEEQdUH/ZWwgBEGfAmxqQRB2IgRrOwFCIAMgAiAEajsBAiABQZ4BRyABQQJqIQENAAtBwAEhAQNAIAkgAUEBdGoiA0FAayICIAMvAQAiBCACLgEAIgJBgICo9ntsQRB1Qf9lbCACQcoBbGpBEHYiAms7AQAgAyACIARqOwEAIAMgAy8BAiICIAMuAUIiBEGAgKj2e2xBEHVB/2VsIARBygFsakEQdiIEazsBQiADIAIgBGo7AQIgAUHeAUcgAUECaiEBDQALQQghBEEAIQhBACEGA0BBECEDIAkgBkEBdGoiAUEgaiABLwEAIgcgBEEBdEGgugJqLgEAIgIgAS4BIGwiBUGAgISYf2xBEHVB/2VsIAVqQRB2IgVrOwEAIAEgBSAHajsBACABIAEvAQIiByACIAEuASJsIgVBgICEmH9sQRB1Qf9lbCAFakEQdiIFazsBIiABIAUgB2o7AQIgASABLwEEIgcgAiABLgEkbCIFQYCAhJh/bEEQdUH/ZWwgBWpBEHYiBWs7ASQgASAFIAdqOwEEIAEgAS8BBiIHIAIgAS4BJmwiBUGAgISYf2xBEHVB/2VsIAVqQRB2IgVrOwEmIAEgBSAHajsBBiABIAEvAQgiByACIAEuAShsIgVBgICEmH9sQRB1Qf9lbCAFakEQdiIFazsBKCABIAUgB2o7AQggASABLwEKIgcgAiABLgEqbCIFQYCAhJh/bEEQdUH/ZWwgBWpBEHYiBWs7ASogASAFIAdqOwEKIAEgAS8BDCIHIAIgAS4BLGwiBUGAgISYf2xBEHVB/2VsIAVqQRB2IgVrOwEsIAEgBSAHajsBDCABIAEvAQ4iByACIAEuAS5sIgVBgICEmH9sQRB1Qf9lbCAFakEQdiIFazsBLiABIAUgB2o7AQ4gASABLwEQIgcgAiABLgEwbCIFQYCAhJh/bEEQdUH/ZWwgBWpBEHYiBWs7ATAgASAFIAdqOwEQIAEgAS8BEiIHIAIgAS4BMmwiBUGAgISYf2xBEHVB/2VsIAVqQRB2IgVrOwEyIAEgBSAHajsBEiABIAEvARQiByACIAEuATRsIgVBgICEmH9sQRB1Qf9lbCAFakEQdiIFazsBNCABIAUgB2o7ARQgASABLwEWIgcgAiABLgE2bCIFQYCAhJh/bEEQdUH/ZWwgBWpBEHYiBWs7ATYgASAFIAdqOwEWIAEgAS8BGCIHIAIgAS4BOGwiBUGAgISYf2xBEHVB/2VsIAVqQRB2IgVrOwE4IAEgBSAHajsBGCABIAEvARoiByACIAEuATpsIgVBgICEmH9sQRB1Qf9lbCAFakEQdiIFazsBOiABIAUgB2o7ARogASABLwEcIgcgAiABLgE8bCIFQYCAhJh/bEEQdUH/ZWwgBWpBEHYiBWs7ATwgASAFIAdqOwEcIAEgAS8BHiIHIAIgAS4BPmwiAkGAgISYf2xBEHVB/2VsIAJqQRB2IgJrOwE+IAEgAiAHajsBHiAGQSBqIQYgBEEBaiIEQRBHDQALA0AgCSAIQQF0aiIBQRBqIAEvAQAiBCADQQF0QaC6AmouAQAiAiABLgEQbCIGQYCAhJh/bEEQdUH/ZWwgBmpBEHYiBms7AQAgASAEIAZqOwEAIAEgAS8BAiIEIAIgAS4BEmwiBkGAgISYf2xBEHVB/2VsIAZqQRB2IgZrOwESIAEgBCAGajsBAiABIAEvAQQiBCACIAEuARRsIgZBgICEmH9sQRB1Qf9lbCAGakEQdiIGazsBFCABIAQgBmo7AQQgASABLwEGIgQgAiABLgEWbCIGQYCAhJh/bEEQdUH/ZWwgBmpBEHYiBms7ARYgASAEIAZqOwEGIAEgAS8BCCIEIAIgAS4BGGwiBkGAgISYf2xBEHVB/2VsIAZqQRB2IgZrOwEYIAEgBCAGajsBCCABIAEvAQoiBCACIAEuARpsIgZBgICEmH9sQRB1Qf9lbCAGakEQdiIGazsBGiABIAQgBmo7AQogASABLwEMIgQgAiABLgEcbCIGQYCAhJh/bEEQdUH/ZWwgBmpBEHYiBms7ARwgASAEIAZqOwEMIAEgAS8BDiIEIAIgAS4BHmwiAkGAgISYf2xBEHVB/2VsIAJqQRB2IgJrOwEeIAEgAiAEajsBDiAIQRBqIQhBICEBQQAhBCADQQFqIgNBIEcNAAtBACEIA0AgCSAIQQF0aiIDQQhqIAMvAQAiBiABQQF0QaC6AmouAQAiAiADLgEIbCIHQYCAhJh/bEEQdUH/ZWwgB2pBEHYiB2s7AQAgAyAGIAdqOwEAIAMgAy8BAiIGIAIgAy4BCmwiB0GAgISYf2xBEHVB/2VsIAdqQRB2IgdrOwEKIAMgBiAHajsBAiADIAMvAQQiBiACIAMuAQxsIgdBgICEmH9sQRB1Qf9lbCAHakEQdiIHazsBDCADIAYgB2o7AQQgAyADLwEGIgYgAiADLgEObCICQYCAhJh/bEEQdUH/ZWwgAmpBEHYiAms7AQ4gAyACIAZqOwEGIAhBCGohCEHAACEDIAFBAWoiAUHAAEcNAAsDQCAJIARBAXRqIgFBBGogAS8BACICIANBAXRBoLoCai4BACIIIAEuAQRsIgZBgICEmH9sQRB1Qf9lbCAGakEQdiIGazsBACABIAIgBmo7AQAgASABLwECIgIgCCABLgEGbCIIQYCAhJh/bEEQdUH/ZWwgCGpBEHYiCGs7AQYgASACIAhqOwECIARBBGohBCADQQFqIgNBgAFHDQALIApBAWoiCkEDRw0ACwuTAQEFfyACpyEGIAAtAOQBBH8gABAaIABBADYC4AEgAEEAOgDkAUF/BUEACyAGBEAgACgC4AEhAwNAIANBqAFGBEAgABAaIABBADYC4AFBACEDCyAAIAEgBGogA0GoASADayIDIAYgBGsiBSADIAVJGyIFEBggACAAKALgASAFaiIDNgLgASAEIAVqIgQgBkkNAAsLC70BAQV/IwBBgAJrIgMkACADQQBByAH8CwAgA0EAOgDsASADQcAANgLoASADQoCAgICACTcD4AEgAqciBwRAA0AgAygC5AEiBCAFRgRAIAMQGiADQQA2AuABIAMoAuQBIQRBACEFCyADIAEgBmogBSAEIAVrIgUgByAGayIEIAQgBUsbIgQQGCADIAMoAuABIARqIgU2AuABIAQgBmoiBiAHSQ0ACwsgAyAAEFsaIANBgAIQByADQYACaiQAQQALkwEBBX8gAqchBiAALQDkAQR/IAAQGiAAQQA2AuABIABBADoA5AFBfwVBAAsgBgRAIAAoAuABIQMDQCADQYgBRgRAIAAQGiAAQQA2AuABQQAhAwsgACABIARqIANBiAEgA2siAyAGIARrIgUgAyAFSRsiBRAYIAAgACgC4AEgBWoiAzYC4AEgBCAFaiIEIAZJDQALCwsmACAAQQBByAH8CwAgACABOgDlASAAQQA6AOQBIABBADYC4AFBAAsfACAAQQBByAH8CwAgAEGAPjsB5AEgAEEANgLgAUEAC58BAQV/IwBB8AFrIgQkACAEQQBByAH8CwAgBEGAPjsB5AEgBEEANgLgASADpyIIBEADQCAFQYgBRgRAIAQQGiAEQQA2AuABQQAhBQsgBCACIAZqIAVBiAEgBWsiBSAIIAZrIgcgBSAHSRsiBxAYIAQgBCgC4AEgB2oiBTYC4AEgBiAHaiIGIAhJDQALCyAEIAAgARB2GiAEQfABaiQAQQALBABBHwuBAgEFfyMAQRBrIgUkACAALQDkAUUEQCAFAn8CQAJAAkAgACgC4AEiA0GHAWsOAgABAgsgAC0A5QFBgH9zDAILIAAQGkEAIQMgAEEANgLgAQsgACAAQeUBaiADQQEQGEGAAQs6AA8gACAFQQ9qQYcBQQEQGCAAEBogAEEBOgDkASAAQQA2AuABCyACBEAgACgC4AEhAwNAIANBiAFGBEAgABAaIABBADYC4AFBACEDC0GIASADayIEIAIgBmsiByAEIAdJGyIEBEAgASAGaiAAIANqIAT8CgAACyAAIAAoAuABIARqIgM2AuABIAQgBmoiBiACSQ0ACwsgBUEQaiQAQQAL2RoBF38gAiABKAAAIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AgAgAiABKAAEIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AgQgAiABKAAIIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AgggAiABKAAMIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AgwgAiABKAAQIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AhAgAiABKAAUIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AhQgAiABKAAYIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AhggAiABKAAcIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AhwgAiABKAAgIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AiAgAiABKAAkIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AiQgAiABKAAoIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AiggAiABKAAsIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AiwgAiABKAAwIgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AjAgAiABKAA0IgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AjQgAiABKAA4IgRB/4H8B3FBCHggBEEYeEH/gfwHcXI2AjggAiABKAA8IgFB/4H8B3FBCHggAUEYeEH/gfwHcXI2AjwgAyAAKQIYNwIYIAMgACkCEDcCECADIAApAgg3AgggAyAAKQIANwIAA0AgAyADKAIcIAIgEkECdCIEaiIBKAIAIAMoAhAiC0EadyALQRV3cyALQQd3c2ogBEHgtwJqKAIAaiALIAMoAhgiBSADKAIUIgpzcSAFc2pqIgYgAygCDGoiCDYCDCADIAMoAgAiDEEedyAMQRN3cyAMQQp3cyAGaiADKAIIIgkgAygCBCIHciAMcSAHIAlxcmoiBjYCHCADIAkgAiAEQQRyIg1qIg8oAgAgBSAKIAggCiALc3FzaiAIQRp3IAhBFXdzIAhBB3dzamogDUHgtwJqKAIAaiIFaiIJNgIIIAMgBiAHIAxycSAHIAxxciAFaiAGQR53IAZBE3dzIAZBCndzaiIFNgIYIAMgByAKIAIgBEEIciINaigCAGogDUHgtwJqKAIAaiALIAkgCCALc3FzaiAJQRp3IAlBFXdzIAlBB3dzaiINaiIKNgIEIAMgBSAGIAxycSAGIAxxciAFQR53IAVBE3dzIAVBCndzaiANaiIHNgIUIAMgDCALIAIgBEEMciINaigCAGogDUHgtwJqKAIAaiAKIAggCXNxIAhzaiAKQRp3IApBFXdzIApBB3dzaiINaiILNgIAIAMgByAFIAZycSAFIAZxciAHQR53IAdBE3dzIAdBCndzaiANaiIMNgIQIAMgCCACIARBEHIiCGooAgBqIAhB4LcCaigCAGogCyAJIApzcSAJc2ogC0EadyALQRV3cyALQQd3c2oiDSAMIAUgB3JxIAUgB3FyIAxBHncgDEETd3MgDEEKd3NqaiIINgIMIAMgBiANaiINNgIcIAMgAiAEQRRyIgZqKAIAIAlqIAZB4LcCaigCAGogDSAKIAtzcSAKc2ogDUEadyANQRV3cyANQQd3c2oiCSAIIAcgDHJxIAcgDHFyIAhBHncgCEETd3MgCEEKd3NqaiIGNgIIIAMgBSAJaiIJNgIYIAMgAiAEQRhyIgVqKAIAIApqIAVB4LcCaigCAGogCSALIA1zcSALc2ogCUEadyAJQRV3cyAJQQd3c2oiCiAGIAggDHJxIAggDHFyIAZBHncgBkETd3MgBkEKd3NqaiIFNgIEIAMgByAKaiIKNgIUIAMgAiAEQRxyIgdqKAIAIAtqIAdB4LcCaigCAGogCiAJIA1zcSANc2ogCkEadyAKQRV3cyAKQQd3c2oiCyAFIAYgCHJxIAYgCHFyIAVBHncgBUETd3MgBUEKd3NqaiIHNgIAIAMgCyAMaiILNgIQIAMgAiAEQSByIgxqKAIAIA1qIAxB4LcCaigCAGogCyAJIApzcSAJc2ogC0EadyALQRV3cyALQQd3c2oiDSAHIAUgBnJxIAUgBnFyIAdBHncgB0ETd3MgB0EKd3NqaiIMNgIcIAMgCCANaiINNgIMIAMgAiAEQSRyIghqIhAoAgAgCWogCEHgtwJqKAIAaiANIAogC3NxIApzaiANQRp3IA1BFXdzIA1BB3dzaiIJIAwgBSAHcnEgBSAHcXIgDEEedyAMQRN3cyAMQQp3c2pqIgg2AhggAyAGIAlqIgk2AgggAyAKIAIgBEEociIGaiIVKAIAaiAGQeC3AmooAgBqIAkgCyANc3EgC3NqIAlBGncgCUEVd3MgCUEHd3NqIgogCCAHIAxycSAHIAxxciAIQR53IAhBE3dzIAhBCndzamoiBjYCFCADIAUgCmoiCjYCBCADIARBLHIiBUHgtwJqKAIAIAIgBWoiFigCAGogC2ogCiAJIA1zcSANc2ogCkEadyAKQRV3cyAKQQd3c2oiCyAGIAggDHJxIAggDHFyIAZBHncgBkETd3MgBkEKd3NqaiIFNgIQIAMgByALaiIHNgIAIAMgBEEwciILQeC3AmooAgAgAiALaiIXKAIAaiANaiAHIAkgCnNxIAlzaiAHQRp3IAdBFXdzIAdBB3dzaiINIAUgBiAIcnEgBiAIcXIgBUEedyAFQRN3cyAFQQp3c2pqIgs2AgwgAyAMIA1qIgw2AhwgAyAJIARBNHIiCUHgtwJqKAIAIAIgCWoiGCgCAGpqIAwgByAKc3EgCnNqIAxBGncgDEEVd3MgDEEHd3NqIg0gCyAFIAZycSAFIAZxciALQR53IAtBE3dzIAtBCndzamoiCTYCCCADIAggDWoiCDYCGCADIAogBEE4ciIKQeC3AmooAgAgAiAKaiINKAIAamogCCAHIAxzcSAHc2ogCEEadyAIQRV3cyAIQQd3c2oiESAJIAUgC3JxIAUgC3FyIAlBHncgCUETd3MgCUEKd3NqaiIKNgIEIAMgBiARaiIGNgIUIAMgBEE8ciIEQeC3AmooAgAgAiAEaiIZKAIAaiAHaiAGIAggDHNxIAxzaiAGQRp3IAZBFXdzIAZBB3dzaiIEIAogCSALcnEgCSALcXIgCkEedyAKQRN3cyAKQQp3c2pqIgY2AgAgAyAEIAVqNgIQIBJBMEZFBEAgAiASQRBqIhJBAnRqIAEoAgAgECgCACIaIA0oAgAiDUEPdyANQQ13cyANQQp2c2pqIA8oAgAiBkEZdyAGQQ53cyAGQQN2c2oiBDYCACABIAEoAggiByABKAIsIg8gBEEPdyAEQQ13cyAEQQp2c2pqIAEoAgwiCEEZdyAIQQ53cyAIQQN2c2oiBTYCSCABIAYgASgCKCIQaiABKAI8IgZBD3cgBkENd3MgBkEKdnNqIAdBGXcgB0EOd3MgB0EDdnNqIgc2AkQgASABKAIQIgkgASgCNCIRIAVBD3cgBUENd3MgBUEKdnNqaiABKAIUIgpBGXcgCkEOd3MgCkEDdnNqIgw2AlAgASAIIAEoAjAiEyAHQQ93IAdBDXdzIAdBCnZzamogCUEZdyAJQQ53cyAJQQN2c2oiCDYCTCABIAEoAhgiCyAGIAxBD3cgDEENd3MgDEEKdnNqaiABKAIcIg5BGXcgDkEOd3MgDkEDdnNqIgk2AlggASAKIAEoAjgiFCAIQQ93IAhBDXdzIAhBCnZzamogC0EZdyALQQ53cyALQQN2c2oiCjYCVCABIAQgDmogCkEPdyAKQQ13cyAKQQp2c2ogASgCICIOQRl3IA5BDndzIA5BA3ZzaiILNgJcIAEgByAOaiAJQQ93IAlBDXdzIAlBCnZzaiABKAIkIgdBGXcgB0EOd3MgB0EDdnNqIgc2AmAgASAaIBBBGXcgEEEOd3MgEEEDdnNqIAVqIAtBD3cgC0ENd3MgC0EKdnNqIgU2AmQgASAVKAIAIAggD0EZdyAPQQ53cyAPQQN2c2pqIAdBD3cgB0ENd3MgB0EKdnNqIgg2AmggASAWKAIAIAwgE0EZdyATQQ53cyATQQN2c2pqIAVBD3cgBUENd3MgBUEKdnNqIgU2AmwgASAXKAIAIAogEUEZdyARQQ53cyARQQN2c2pqIAhBD3cgCEENd3MgCEEKdnNqIgw2AnAgASAYKAIAIAkgFEEZdyAUQQ53cyAUQQN2c2pqIAVBD3cgBUENd3MgBUEKdnNqIgU2AnQgASANIAZBGXcgBkEOd3MgBkEDdnNqIAtqIAxBD3cgDEENd3MgDEEKdnNqNgJ4IAEgGSgCACAHIARBGXcgBEEOd3MgBEEDdnNqaiAFQQ93IAVBDXdzIAVBCnZzajYCfAwBCwsgACAAKAIAIAZqNgIAIAAgACgCBCADKAIEajYCBCAAIAAoAgggAygCCGo2AgggACAAKAIMIAMoAgxqNgIMIAAgACgCECADKAIQajYCECAAIAAoAhQgAygCFGo2AhQgACAAKAIYIAMoAhhqNgIYIAAgACgCHCADKAIcajYCHAs7ACAAQgA3AyAgAEHAtwIpAwA3AwAgAEHItwIpAwA3AwggAEHQtwIpAwA3AxAgAEHYtwIpAwA3AxhBAAsEAEEDC+cFAgV/An5BfyEGAkAgAUHBAGsiB0FASQ0AIAVBwABLDQACfyMAIgYhCSAGQYAEa0FAcSIGJAACQCACRSADQgBScQ0AIABFDQAgB0H/AXFBvwFNDQAgBEUiB0EAIAUbDQAgBUHBAE8NAAJAIAUEQCAHDQIgBkFAa0EAQaUC/AsAIAZC+cL4m5Gjs/DbADcDOCAGQuv6htq/tfbBHzcDMCAGQp/Y+dnCkdqCm383AyggBkLRhZrv+s+Uh9EANwMgIAZC8e30+KWn/aelfzcDGCAGQqvw0/Sv7ry3PDcDECAGQrvOqqbY0Ouzu383AwggBiABrSAFrUIIhoRCiJL3lf/M+YTqAIU3AwBBgAEhB0GAASAFayIIBEAgBkGAA2ogBWpBACAI/AsACyAFBEAgBkGAA2ogBCAF/AoAAAsgBkHgAGogBkGAA2oiBEGAAfwKAAAgBkGAATYC4AIgBEGAARAHDAELQQAhByAGQUBrQQBBpQL8CwAgBkL5wvibkaOz8NsANwM4IAZC6/qG2r+19sEfNwMwIAZCn9j52cKR2oKbfzcDKCAGQtGFmu/6z5SH0QA3AyAgBkLx7fT4paf9p6V/NwMYIAZCq/DT9K/uvLc8NwMQIAZCu86qptjQ67O7fzcDCCAGIAGtQoiS95X/zPmE6gCFNwMACyADQgBSBEAgBkHgAGohBUGAAiAHayIErSILIANUBEAgBkHgAWohCANAIAQEQCAFIAdqIAIgBPwKAAALIAYgBigC4AIgBGo2AuACIAYgBikDQCIMQoABfDcDQCAGIAYpA0ggDEL/flatfDcDSCAGIAUQXiAFIAhBgAH8CgAAIAYgBigC4AIiCkGAAWsiBzYC4AIgAiAEaiECIAMgC30iA0GAAyAKayIErSILVg0ACwsgA6ciBARAIAUgB2ogAiAE/AoAAAsgBiAGKALgAiAEajYC4AILIAYgACABEJ8BGiAJJABBAAwBCxAMAAshBgsgBguJGAIRfgl/A0AgAiAVQQN0IhdqIAEgF2opAAAiBEI4hiAEQoD+A4NCKIaEIARCgID8B4NCGIYgBEKAgID4D4NCCIaEhCAEQgiIQoCAgPgPgyAEQhiIQoCA/AeDhCAEQiiIQoD+A4MgBEI4iISEhDcDACAVQQFqIhVBEEcNAAsgAyAAKQM4NwM4IAMgACkDMDcDMCADIAApAyg3AyggAyAAKQMgNwMgIAMgACkDGDcDGCADIAApAxA3AxAgAyAAKQMINwMIIAMgACkDADcDAEEAIRcDQCADIAMpAzggAiAXQQN0IhVqIgEpAwAgAykDICIJQjKJIAlCLomFIAlCF4mFfCAVQZCxAmopAwB8IAkgAykDMCIKIAMpAygiCIWDIAqFfHwiBCADKQMYfCILNwMYIAMgAykDACIFQiSJIAVCHomFIAVCGYmFIAR8IAMpAxAiBiADKQMIIgeEIAWDIAYgB4OEfCIENwM4IAMgBiACIBVBCHIiFmoiGykDACAKIAggCyAIIAmFg4V8IAtCMokgC0IuiYUgC0IXiYV8fCAWQZCxAmopAwB8Igp8IgY3AxAgAyAEIAUgB4SDIAUgB4OEIAp8IARCJIkgBEIeiYUgBEIZiYV8Igo3AzAgAyAHIAggAiAVQRByIhZqKQMAfCAWQZCxAmopAwB8IAkgBiAJIAuFg4V8IAZCMokgBkIuiYUgBkIXiYV8Igx8Igg3AwggAyAKIAQgBYSDIAQgBYOEIApCJIkgCkIeiYUgCkIZiYV8IAx8Igc3AyggAyAFIAkgAiAVQRhyIhZqKQMAfCAWQZCxAmopAwB8IAggBiALhYMgC4V8IAhCMokgCEIuiYUgCEIXiYV8Igx8Igk3AwAgAyAHIAQgCoSDIAQgCoOEIAdCJIkgB0IeiYUgB0IZiYV8IAx8IgU3AyAgAyACIBVBIHIiFmopAwAgC3wgFkGQsQJqKQMAfCAJIAYgCIWDIAaFfCAJQjKJIAlCLomFIAlCF4mFfCIMIAUgByAKhIMgByAKg4QgBUIkiSAFQh6JhSAFQhmJhXx8Igs3AxggAyAEIAx8Igw3AzggAyACIBVBKHIiFmopAwAgBnwgFkGQsQJqKQMAfCAMIAggCYWDIAiFfCAMQjKJIAxCLomFIAxCF4mFfCIGIAsgBSAHhIMgBSAHg4QgC0IkiSALQh6JhSALQhmJhXx8IgQ3AxAgAyAGIAp8IgY3AzAgAyACIBVBMHIiFmopAwAgCHwgFkGQsQJqKQMAfCAGIAkgDIWDIAmFfCAGQjKJIAZCLomFIAZCF4mFfCIIIAQgBSALhIMgBSALg4QgBEIkiSAEQh6JhSAEQhmJhXx8Igo3AwggAyAHIAh8Igg3AyggAyACIBVBOHIiFmopAwAgCXwgFkGQsQJqKQMAfCAIIAYgDIWDIAyFfCAIQjKJIAhCLomFIAhCF4mFfCIJIAogBCALhIMgBCALg4QgCkIkiSAKQh6JhSAKQhmJhXx8Igc3AwAgAyAFIAl8Igk3AyAgAyACIBVBwAByIhZqKQMAIAx8IBZBkLECaikDAHwgCSAGIAiFgyAGhXwgCUIyiSAJQi6JhSAJQheJhXwiDCAHIAQgCoSDIAQgCoOEIAdCJIkgB0IeiYUgB0IZiYV8fCIFNwM4IAMgCyAMfCIMNwMYIAMgAiAVQcgAciIWaiIcKQMAIAZ8IBZBkLECaikDAHwgDCAIIAmFgyAIhXwgDEIyiSAMQi6JhSAMQheJhXwiBiAFIAcgCoSDIAcgCoOEIAVCJIkgBUIeiYUgBUIZiYV8fCILNwMwIAMgBCAGfCIGNwMQIAMgCCACIBVB0AByIhZqIh0pAwB8IBZBkLECaikDAHwgBiAJIAyFgyAJhXwgBkIyiSAGQi6JhSAGQheJhXwiCCALIAUgB4SDIAUgB4OEIAtCJIkgC0IeiYUgC0IZiYV8fCIENwMoIAMgCCAKfCIINwMIIAMgFUHYAHIiFkGQsQJqKQMAIAIgFmoiFikDAHwgCXwgCCAGIAyFgyAMhXwgCEIyiSAIQi6JhSAIQheJhXwiCSAEIAUgC4SDIAUgC4OEIARCJIkgBEIeiYUgBEIZiYV8fCIKNwMgIAMgByAJfCIHNwMAIAMgFUHgAHIiGEGQsQJqKQMAIAIgGGoiGCkDAHwgDHwgByAGIAiFgyAGhXwgB0IyiSAHQi6JhSAHQheJhXwiDCAKIAQgC4SDIAQgC4OEIApCJIkgCkIeiYUgCkIZiYV8fCIJNwMYIAMgBSAMfCIFNwM4IAMgFUHoAHIiGUGQsQJqKQMAIAIgGWoiGSkDAHwgBnwgBSAHIAiFgyAIhXwgBUIyiSAFQi6JhSAFQheJhXwiDCAJIAQgCoSDIAQgCoOEIAlCJIkgCUIeiYUgCUIZiYV8fCIGNwMQIAMgCyAMfCILNwMwIAMgFUHwAHIiGkGQsQJqKQMAIAIgGmoiGikDAHwgCHwgCyAFIAeFgyAHhXwgC0IyiSALQi6JhSALQheJhXwiDCAGIAkgCoSDIAkgCoOEIAZCJIkgBkIeiYUgBkIZiYV8fCIINwMIIAMgBCAMfCIENwMoIAMgFUH4AHIiFUGQsQJqKQMAIAIgFWoiFSkDAHwgB3wgBCAFIAuFgyAFhXwgBEIyiSAEQi6JhSAEQheJhXwiBCAIIAYgCYSDIAYgCYOEIAhCJIkgCEIeiYUgCEIZiYV8fCIHNwMAIAMgBCAKfDcDICAXQcAARkUEQCACIBdBEGoiF0EDdGogASkDACAcKQMAIhQgGikDACIOQi2JIA5CA4mFIA5CBoiFfHwgGykDACIKQj+JIApCOImFIApCB4iFfCIENwMAIAEgASkDECIFIAEpA1giDyAEQi2JIARCA4mFIARCBoiFfHwgASkDGCIGQj+JIAZCOImFIAZCB4iFfCIHNwOQASABIAogASkDUCIQfCABKQN4IgpCLYkgCkIDiYUgCkIGiIV8IAVCP4kgBUI4iYUgBUIHiIV8IgU3A4gBIAEgASkDICIIIAEpA2giESAHQi2JIAdCA4mFIAdCBoiFfHwgASkDKCIJQj+JIAlCOImFIAlCB4iFfCILNwOgASABIAYgASkDYCISIAVCLYkgBUIDiYUgBUIGiIV8fCAIQj+JIAhCOImFIAhCB4iFfCIGNwOYASABIAEpAzAiDCAKIAtCLYkgC0IDiYUgC0IGiIV8fCABKQM4Ig1CP4kgDUI4iYUgDUIHiIV8Igg3A7ABIAEgCSABKQNwIhMgBkItiSAGQgOJhSAGQgaIhXx8IAxCP4kgDEI4iYUgDEIHiIV8Igk3A6gBIAEgBCANfCAJQi2JIAlCA4mFIAlCBoiFfCABQUBrKQMAIg1CP4kgDUI4iYUgDUIHiIV8Igw3A7gBIAEgBSANfCAIQi2JIAhCA4mFIAhCBoiFfCABKQNIIgVCP4kgBUI4iYUgBUIHiIV8IgU3A8ABIAEgFCAQQj+JIBBCOImFIBBCB4iFfCAHfCAMQi2JIAxCA4mFIAxCBoiFfCIHNwPIASABIB0pAwAgBiAPQj+JIA9COImFIA9CB4iFfHwgBUItiSAFQgOJhSAFQgaIhXwiBjcD0AEgASAWKQMAIAsgEkI/iSASQjiJhSASQgeIhXx8IAdCLYkgB0IDiYUgB0IGiIV8Igc3A9gBIAEgGCkDACAJIBFCP4kgEUI4iYUgEUIHiIV8fCAGQi2JIAZCA4mFIAZCBoiFfCILNwPgASABIBkpAwAgCCATQj+JIBNCOImFIBNCB4iFfHwgB0ItiSAHQgOJhSAHQgaIhXwiBzcD6AEgASAOIApCP4kgCkI4iYUgCkIHiIV8IAx8IAtCLYkgC0IDiYUgC0IGiIV8NwPwASABIBUpAwAgBSAEQj+JIARCOImFIARCB4iFfHwgB0ItiSAHQgOJhSAHQgaIhXw3A/gBDAELCyAAIAApAwAgB3w3AwAgACAAKQMIIAMpAwh8NwMIIAAgACkDECADKQMQfDcDECAAIAApAxggAykDGHw3AxggACAAKQMgIAMpAyB8NwMgIAAgACkDKCADKQMofDcDKCAAIAApAzAgAykDMHw3AzAgACAAKQM4IAMpAzh8NwM4CycAIAJCgICAgBBaBEAQDAALIAAgASACIANBACAEQeS9AigCABERAAsnACACQoCAgIAQWgRAEAwACyAAIAEgAiADQgAgBEHgvQIoAgARDgALlQkBMX8jAEFAaiEJIAAoAjwhHSAAKAI4IR4gACgCNCESIAAoAjAhEyAAKAIsIR8gACgCKCEgIAAoAiQhISAAKAIgISIgACgCHCEjIAAoAhghJCAAKAIUISUgACgCECEmIAAoAgwhJyAAKAIIISggACgCBCEpIAAoAgAhKgNAAkAgA0I/VgRAIAIhBQwBCyAJQgA3AzggCUIANwMwIAlCADcDKCAJQgA3AyAgCUIANwMYIAlCADcDECAJQgA3AwggCUIANwMAQQAhBANAIAQgCWogASAEai0AADoAACADIARBAWoiBK1WDQALIAkiBSEBIAIhKwtBFCEWICohCCApIQogKCEOICchFCAmIQQgJSECICQhBiAjIQcgIiELICEhDyAgIQwgHSEQIB4hFyASIRggEyENIB8hEQNAIAQgBCAIaiIEIA1zQRB3IgggC2oiC3NBDHciDSAEaiIVIAhzQQh3IgggC2oiCyANc0EHdyIEIAcgByAUaiIHIBBzQRB3IhAgEWoiDXNBDHciESAHaiIHaiIUIAYgBiAOaiIGIBdzQRB3Ig4gDGoiDHNBDHciGSAGaiIGIA5zQQh3IhpzQRB3Ig4gAiACIApqIgIgGHNBEHciCiAPaiIPc0EMdyIbIAJqIgIgCnNBCHciCiAPaiIcaiIPIARzQQx3IgQgFGoiFCAOc0EIdyIXIA9qIg8gBHNBB3chBCALIAogBiAHIBBzQQh3IhAgDWoiBiARc0EHdyIHaiIKc0EQdyILaiINIAdzQQx3IgcgCmoiDiALc0EIdyIYIA1qIgsgB3NBB3chByAGIAggAiAMIBpqIgIgGXNBB3ciBmoiCHNBEHciDGoiESAGc0EMdyIGIAhqIgogDHNBCHciDSARaiIRIAZzQQd3IQYgAiAbIBxzQQd3IgIgFWoiCCAQc0EQdyIMaiIVIAJzQQx3IgIgCGoiCCAMc0EIdyIQIBVqIgwgAnNBB3chAiAWQQJrIhYNAAsgASgABCEWIAEoAAghFSABKAAMIRkgASgAECEaIAEoABQhGyABKAAYIRwgASgAHCEsIAEoACAhLSABKAAkIS4gASgAKCEvIAEoACwhMCABKAAwITEgASgANCEyIAEoADghMyABKAA8ITQgBSABKAAAIAggKmpzNgAAIAUgNCAQIB1qczYAPCAFIDMgFyAeanM2ADggBSAyIBIgGGpzNgA0IAUgMSANIBNqczYAMCAFIDAgESAfanM2ACwgBSAvIAwgIGpzNgAoIAUgLiAPICFqczYAJCAFIC0gCyAianM2ACAgBSAsIAcgI2pzNgAcIAUgHCAGICRqczYAGCAFIBsgAiAlanM2ABQgBSAaIAQgJmpzNgAQIAUgGSAUICdqczYADCAFIBUgDiAoanM2AAggBSAWIAogKWpzNgAEIBIgE0EBaiITRWohEiADQsAAWARAIANCP1gEQCADpyEBQQAhBANAIAQgK2ogBCAFai0AADoAACAEQQFqIgQgAUkNAAsLIAAgEjYCNCAAIBM2AjAFIAFBQGshASAFQUBrIQIgA0JAfCEDDAELCwsIACAAQRAQFgvRBgEKfyMAQaACayICJAAgACgAHCEEIAAoABghBSAAKAAUIQYgACgAECEHIAAoAAQhCCAAKAAIIQkgACgADCEKIAAoAAAhCyACIAEpAng3A5gCIAIgASkCcDcDkAIgAiABKQJgNwPwASACIAEpAmg3A/gBIAIgASkCcDcD4AEgAiABKQJ4NwPoASACQYACaiIDIAJB8AFqIAJB4AFqEAYgASACKQKIAjcCeCABIAIpAoACNwJwIAIgASkCUDcD0AEgAiABKQJYNwPYASACIAEpAmA3A8ABIAIgASkCaDcDyAEgAyACQdABaiACQcABahAGIAEgAikCiAI3AmggASACKQKAAjcCYCACIAFBQGsiACkCADcDsAEgAiABKQJINwO4ASACIAEpAlA3A6ABIAIgASkCWDcDqAEgAyACQbABaiACQaABahAGIAEgAikCiAI3AlggASACKQKAAjcCUCACIAEpAjA3A5ABIAIgASkCODcDmAEgAiAAKQIANwOAASACIAEpAkg3A4gBIAMgAkGQAWogAkGAAWoQBiABIAIpAogCNwJIIAAgAikCgAI3AgAgAiABKQIgNwNwIAIgASkCKDcDeCACIAEpAjA3A2AgAiABKQI4NwNoIAMgAkHwAGogAkHgAGoQBiABIAIpAogCNwI4IAEgAikCgAI3AjAgAiABKQIQNwNQIAIgASkCGDcDWCACIAEpAiA3A0AgAiABKQIoNwNIIAMgAkHQAGogAkFAaxAGIAEgAikCiAI3AiggASACKQKAAjcCICACIAEpAgA3AzAgAiABKQIINwM4IAIgASkCEDcDICACIAEpAhg3AyggAyACQTBqIAJBIGoQBiABIAIpAogCNwIYIAEgAikCgAI3AhAgAiACKQOQAjcDECACIAIpA5gCNwMYIAIgASkCADcDACACIAEpAgg3AwggAyACQRBqIAIQBiABIAIpAogCNwIIIAEgAikCgAI3AgAgASAKIAEoAgxzNgIMIAEgCSABKAIIczYCCCABIAggASgCBHM2AgQgASALIAEoAgBzNgIAIAAgByAAKAIAczYCACABIAYgASgCRHM2AkQgASAFIAEoAkhzNgJIIAEgBCABKAJMczYCTCACQaACaiQAC7UEAQR/IAAoAhAQCyEBIAAoAhQQCyECIAAoAhgQCyEDIAAgACgCHBALNgIcIAAgAzYCGCAAIAI2AhQgACABNgIQIAAoAiAQCyEBIAAoAiQQCyECIAAoAigQCyEDIAAgACgCLBALNgIsIAAgAzYCKCAAIAI2AiQgACABNgIgIAAoAjAQCyEBIAAoAjQQCyECIAAoAjgQCyEDIAAgACgCPBALNgI8IAAgAzYCOCAAIAI2AjQgACABNgIwIABBQGsiASgCABALIQIgACgCRBALIQMgACgCSBALIQQgACAAKAJMEAs2AkwgACAENgJIIAAgAzYCRCABIAI2AgAgACgCUBALIQEgACgCVBALIQIgACgCWBALIQMgACAAKAJcEAs2AlwgACADNgJYIAAgAjYCVCAAIAE2AlAgACgCYBALIQEgACgCZBALIQIgACgCaBALIQMgACAAKAJsEAs2AmwgACADNgJoIAAgAjYCZCAAIAE2AmAgACgCcBALIQEgACgCdBALIQIgACgCeBALIQMgACAAKAJ8EAs2AnwgACADNgJ4IAAgAjYCdCAAIAE2AnAgACgCgAEQCyEBIAAoAoQBEAshAiAAKAKIARALIQMgACAAKAKMARALNgKMASAAIAM2AogBIAAgAjYChAEgACABNgKAASAAKAKQARALIQEgACgClAEQCyECIAAoApgBEAshAyAAIAAoApwBEAs2ApwBIAAgAzYCmAEgACACNgKUASAAIAE2ApABC9wFASJ/An8gA0UEQEHl8MGLBiEQQbLaiMsHIRFB7siBmQMhEkH0yoHZBgwBCyADKAAIIREgAygABCESIAMoAAAhECADKAAMCyEWIBAhAyACKAAAIhohCCACKAAEIhshCSACKAAIIhwhCiACKAAMIh0hCyASIQYgASgAACIeIQwgASgABCIfIQ0gASgACCIgIQ4gASgADCIhIRMgESEBIAIoABAiIiEFIBYhByACKAAcIiMhFCACKAAYIiQhDyACKAAUIiUhAgNAIAYgCGpBB3cgE3MiFSAGakEJdyAPcyIYIAIgA2pBB3cgC3MiCyADakEJdyAOcyIZIAtqQQ13IAJzIiYgCiAFIAdqQQd3cyIKIAdqQQl3IA1zIg0gCmpBDXcgBXMiDiANakESdyAHcyIHIAEgDGpBB3cgFHMiBWpBB3dzIgIgB2pBCXdzIg8gAmpBDXcgBXMiFCAPakESdyAHcyEHIAUgASAFakEJdyAJcyIJakENdyAMcyIMIAlqQRJ3IAFzIgEgFWpBB3cgDnMiBSABakEJdyAZcyIOIAVqQQ13IBVzIhMgDmpBEncgAXMhASAYIBUgGGpBDXcgCHMiCGpBEncgBnMiBiALakEHdyAMcyIMIAZqQQl3IA1zIg0gDGpBDXcgC3MiCyANakESdyAGcyEGIBkgJmpBEncgA3MiAyAKakEHdyAIcyIIIANqQQl3IAlzIgkgCGpBDXcgCnMiCiAJakESdyADcyEDIBdBAmoiFyAESQ0ACyAAIAcgFmo2ADwgACAUICNqNgA4IAAgDyAkajYANCAAIAIgJWo2ADAgACAFICJqNgAsIAAgASARajYAKCAAIBMgIWo2ACQgACAOICBqNgAgIAAgDSAfajYAHCAAIAwgHmo2ABggACAGIBJqNgAUIAAgCyAdajYAECAAIAogHGo2AAwgACAJIBtqNgAIIAAgCCAaajYABCAAIAMgEGo2AAALtwkBFX8jAEHAAmsiAyQAIANB8AFqIgQgAhAEIAQgBCACEAUgACAEEAQgACAAIAIQBSAAIAAgARAFIAAgABCIASAAIAAgBBAFIAAgACABEAUgA0HAAWoiBCAAEAQgBCAEIAIQBSABKAIEIQUgASgCCCENIAEoAgwhDiABKAIQIQ8gASgCFCEQIAEoAhghESABKAIcIRIgASgCICETIAEoAgAhFCADKALAASECIAMoAsQBIQQgAygCyAEhBiADKALMASEHIAMoAtABIQggAygC1AEhCSADKALYASEKIAMoAtwBIQsgAygC4AEhDCADIAMoAuQBIhUgASgCJCIWazYCtAEgAyAMIBNrNgKwASADIAsgEms2AqwBIAMgCiARazYCqAEgAyAJIBBrNgKkASADIAggD2s2AqABIAMgByAOazYCnAEgAyAGIA1rNgKYASADIAQgBWs2ApQBIAMgAiAUazYCkAEgAyAVIBZqNgKEASADIAwgE2o2AoABIAMgCyASajYCfCADIAogEWo2AnggAyAJIBBqNgJ0IAMgCCAPajYCcCADIAcgDmo2AmwgAyAGIA1qNgJoIAMgBCAFajYCZCADIAIgFGo2AmAgA0EwaiIFIAFB8AwQBSADIBUgAygCVGo2AlQgAyAMIAMoAlBqNgJQIAMgCyADKAJMajYCTCADIAogAygCSGo2AkggAyAJIAMoAkRqNgJEIAMgCCADKAJAajYCQCADIAcgAygCPGo2AjwgAyAGIAMoAjhqNgI4IAMgBCADKAI0ajYCNCADIAIgAygCMGo2AjAgAyADQZABahAPIANBIBAbIQ4gAyADQeAAahAPIANBIBAbIQ0gAyAFEA8gA0EgEBshASADIABB8AwQBSAAKAIEIQwgACgCCCELIAAoAgwhCiAAKAIQIQkgACgCFCEIIAAoAhghByAAKAIcIQYgACgCICEEIAAoAgAhBSADKAIAIQ8gAygCBCEQIAMoAgghESADKAIMIRIgAygCECETIAMoAhQhFCADKAIYIRUgAygCHCEWIAMoAiAhFyAAQQAgASANcmsiASAAKAIkIgIgAygCJHNxIAJzIgI2AiQgACAEIAQgF3MgAXFzIgQ2AiAgACAGIAYgFnMgAXFzIgY2AhwgACAHIAcgFXMgAXFzIgc2AhggACAIIAggFHMgAXFzIgg2AhQgACAJIAkgE3MgAXFzIgk2AhAgACAKIAogEnMgAXFzIgo2AgwgACALIAsgEXMgAXFzIgs2AgggACAMIAwgEHMgAXFzIgw2AgQgACAFIAUgD3MgAXFzIgU2AgAgA0GgAmogABAPIABBACADLQCgAkEBcWsiASACQQAgAmtzcSACczYCJCAAIARBACAEa3MgAXEgBHM2AiAgACAGQQAgBmtzIAFxIAZzNgIcIAAgB0EAIAdrcyABcSAHczYCGCAAIAhBACAIa3MgAXEgCHM2AhQgACAJQQAgCWtzIAFxIAlzNgIQIAAgCkEAIAprcyABcSAKczYCDCAAIAtBACALa3MgAXEgC3M2AgggACAMQQAgDGtzIAFxIAxzNgIEIAAgBUEAIAVrcyABcSAFczYCACADQcACaiQAIA0gDnIL3AEAIAAtAB9Bf3NB/wBxIAAtAAEgAC0AAiAALQADIAAtAAQgAC0ABSAALQAGIAAtAAcgAC0ACCAALQAJIAAtAAogAC0ACyAALQAMIAAtAA0gAC0ADiAALQAPIAAtABAgAC0AESAALQASIAAtABMgAC0AFCAALQAVIAAtABYgAC0AFyAALQAYIAAtABkgAC0AGiAALQAbIAAtABwgAC0AHiAALQAdcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFB/wFzckEBa0HsASAALQAAa3FBf3NBCHZBAXELwAsBE38jAEGAEGsiASQAIAFBgAVqIgggABAOIAEgACkCIDcD4AIgASAAKQIYNwPYAiABIAApAhA3A9ACIAEgACkCCDcDyAIgASAAKQIANwPAAiABIAApAig3A+gCIAEgACkCMDcD8AIgASAAKQI4NwP4AiABIABBQGspAgA3A4ADIAEgACkCSDcDiAMgASAAKQJQNwOQAyABIAApAlg3A5gDIAEgACkCYDcDoAMgASAAKQJoNwOoAyABIAApAnA3A7ADIAFB4ANqIgIgAUHAAmoiAxAcIAFBoAFqIgcgAiABQdgEaiIEEAUgAUHIAWogAUGIBGoiBSABQbAEaiIGEAUgAUHwAWogBiAEEAUgAUGYAmogAiAFEAUgAiAHIAgQEiADIAIgBBAFIAFB6AJqIgggBSAGEAUgAUGQA2oiCiAGIAQQBSABQbgDaiILIAIgBRAFIAFBoAZqIgAgAxAOIAIgByAAEBIgAyACIAQQBSAIIAUgBhAFIAogBiAEEAUgCyACIAUQBSABQcAHaiIAIAMQDiACIAcgABASIAMgAiAEEAUgCCAFIAYQBSAKIAYgBBAFIAsgAiAFEAUgAUHgCGoiACADEA4gAiAHIAAQEiADIAIgBBAFIAggBSAGEAUgCiAGIAQQBSALIAIgBRAFIAFBgApqIgAgAxAOIAIgByAAEBIgAyACIAQQBSAIIAUgBhAFIAogBiAEEAUgCyACIAUQBSABQaALaiIAIAMQDiACIAcgABASIAMgAiAEEAUgCCAFIAYQBSAKIAYgBBAFIAsgAiAFEAUgAUHADGoiACADEA4gAiAHIAAQEiADIAIgBBAFIAggBSAGEAUgCiAGIAQQBSALIAIgBRAFIAFB4A1qIAMQDiABQgA3AyAgAUIANwMYIAFCADcDECABQgA3AwggAUIANwMAIAFCADcCLCABQQE2AiggAUIANwI0IAFCADcCPCABQgA3AkQgAUKAgICAEDcCTCABQdQAakEAQcwA/AsAIAFB+ABqIQ8gAUHYD2ohDCABQbAPaiENIAFB0ABqIQMgAUEoaiEHQfwBIQADQCABIAEpAyA3A6gPIAEgASkDGDcDoA8gASABKQMQNwOYDyABIAEpAwg3A5APIAEgASkDADcDiA8gDSAHKQIgNwIgIA0gBykCGDcCGCANIAcpAhA3AhAgDSAHKQIINwIIIA0gBykCADcCACAMIAMpAiA3AiAgDCADKQIYNwIYIAwgAykCEDcCECAMIAMpAgg3AgggDCADKQIANwIAIAAiAkHAhwJqLAAAIQAgAUHgA2oiCSABQYgPahAcAkAgAEEASgRAIAFBwAJqIg4gCSAEEAUgCCAFIAYQBSAKIAYgBBAFIAsgCSAFEAUgCSAOIAFBgAVqIABB/gFxQQF2QaABbGoQEgwBCyAAQQBODQAgAUHAAmoiDiABQeADaiIJIAQQBSAIIAUgBhAFIAogBiAEEAUgCyAJIAUQBSAJIA4gAUGABWpBACAAa0H+AXFBAXZBoAFsahBgCyABIAFB4ANqIgkgBBAFIAcgBSAGEAUgAyAGIAQQBSAPIAkgBRAFIAJBAWshACACDQALIAEoAighACABKAJQIQIgASgCLCEEIAEoAlQhBSABKAIwIQYgASgCWCEIIAEoAjQhCiABKAJcIQsgASgCOCEDIAEoAmAhByABKAI8IQwgASgCZCENIAEoAkAhDyABKAJoIQ4gASgCRCEQIAEoAmwhESABKAJIIRIgASgCcCETIAEgASgCTCABKAJ0azYCpAUgASASIBNrNgKgBSABIBAgEWs2ApwFIAEgDyAOazYCmAUgASAMIA1rNgKUBSABIAMgB2s2ApAFIAEgCiALazYCjAUgASAGIAhrNgKIBSABIAQgBWs2AoQFIAEgACACazYCgAUgCSABEA8gCUEgEBsgCSABQYAFahAPIAlBIBAbIAFBgBBqJABxC4IWAQt/IwBBwB9rIgMkACADQaABaiACEA4gAyACKQIgNwOAHiADIAIpAhg3A/gdIAMgAikCEDcD8B0gAyACKQIINwPoHSADIAIpAgA3A+AdIAMgAikCKDcDiB4gAyACKQIwNwOQHiADIAIpAjg3A5geIAMgAkFAaykCADcDoB4gAyACKQJINwOoHiADIAIpAlA3A7AeIAMgAikCWDcDuB4gAyACKQJgNwPAHiADIAIpAmg3A8geIAMgAikCcDcD0B4gA0HIG2oiBSADQeAdaiIHEBwgA0HoEmoiCSAFIANBwBxqIgQQBSADQZATaiADQfAbaiIIIANBmBxqIgYQBSADQbgTaiAGIAQQBSADQeATaiAFIAgQBSADQcACaiIEIAkQDiADQagaaiIFIAIgBBASIANByBFqIgkgBSADQaAbaiIEEAUgA0HwEWogA0HQGmoiCCADQfgaaiIGEAUgA0GYEmogBiAEEAUgA0HAEmogBSAIEAUgA0HgA2ogCRAOIAMgAykCiBM3A4AeIAMgAykCgBM3A/gdIAMgAykC+BI3A/AdIAMgAykC8BI3A+gdIAMgAykC6BI3A+AdIAMgAykCkBM3A4geIAMgAykCmBM3A5AeIAMgAykCoBM3A5geIAMgAykCqBM3A6AeIAMgAykCsBM3A6geIAMgAykC2BM3A9AeIAMgAykC0BM3A8geIAMgAykCyBM3A8AeIAMgAykCwBM3A7geIAMgAykCuBM3A7AeIANBiBlqIgUgBxAcIANBqBBqIgkgBSADQYAaaiIEEAUgA0HQEGogA0GwGWoiCCADQdgZaiIGEAUgA0H4EGogBiAEEAUgA0GgEWogBSAIEAUgA0GABWoiBCAJEA4gA0HoF2oiBSACIAQQEiADQYgPaiIJIAUgA0HgGGoiBBAFIANBsA9qIANBkBhqIgggA0G4GGoiBhAFIANB2A9qIAYgBBAFIANBgBBqIAUgCBAFIANBoAZqIAkQDiADIAMpAugRNwOAHiADIAMpAuARNwP4HSADIAMpAtgRNwPwHSADIAMpAtARNwPoHSADIAMpAsgRNwPgHSADIAMpAvARNwOIHiADIAMpAvgRNwOQHiADIAMpAoASNwOYHiADIAMpAogSNwOgHiADIAMpApASNwOoHiADIAMpArgSNwPQHiADIAMpArASNwPIHiADIAMpAqgSNwPAHiADIAMpAqASNwO4HiADIAMpApgSNwOwHiADQcgWaiIFIAcQHCADQegNaiIJIAUgA0HAF2oiBBAFIANBkA5qIANB8BZqIgggA0GYF2oiBhAFIANBuA5qIAYgBBAFIANB4A5qIAUgCBAFIANBwAdqIgQgCRAOIANBqBVqIgYgAiAEEBIgA0HIDGoiBSAGIANBoBZqIgIQBSADQfAMaiADQdAVaiIEIANB+BVqIggQBSADQZgNaiAIIAIQBSADQcANaiAGIAQQBSADQeAIaiAFEA4gAyADKQLIEDcDgB4gAyADKQLAEDcD+B0gAyADKQK4EDcD8B0gAyADKQKwEDcD6B0gAyADKQKoEDcD4B0gAyADKQLQEDcDiB4gAyADKQLYEDcDkB4gAyADKQLgEDcDmB4gAyADKQLoEDcDoB4gAyADKQLwEDcDqB4gAyADKQKYETcD0B4gAyADKQKQETcDyB4gAyADKQKIETcDwB4gAyADKQKAETcDuB4gAyADKQL4EDcDsB4gA0GIFGoiBiAHEBwgA0GoC2oiByAGIANBgBVqIgIQBSADQdALaiADQbAUaiIEIANB2BRqIggQBSADQfgLaiAIIAIQBSADQaAMaiAGIAQQBSADQYAKaiAHEA4gAyABLQAAIgJBBHY6AIEfIAMgAkEPcToAgB8gAyABLQABIgJBBHY6AIMfIAMgAkEPcToAgh8gAyABLQACIgJBBHY6AIUfIAMgAkEPcToAhB8gAyABLQADIgJBBHY6AIcfIAMgAkEPcToAhh8gAyABLQAEIgJBBHY6AIkfIAMgAkEPcToAiB8gAyABLQAFIgJBBHY6AIsfIAMgAkEPcToAih8gAyABLQAGIgJBBHY6AI0fIAMgAkEPcToAjB8gAyABLQAHIgJBBHY6AI8fIAMgAkEPcToAjh8gAyABLQAIIgJBBHY6AJEfIAMgAkEPcToAkB8gAyABLQAJIgJBBHY6AJMfIAMgAkEPcToAkh8gAyABLQAKIgJBBHY6AJUfIAMgAkEPcToAlB8gAyABLQALIgJBBHY6AJcfIAMgAkEPcToAlh8gAyABLQAMIgJBBHY6AJkfIAMgAkEPcToAmB8gAyABLQANIgJBBHY6AJsfIAMgAkEPcToAmh8gAyABLQAOIgJBBHY6AJ0fIAMgAkEPcToAnB8gAyABLQAPIgJBBHY6AJ8fIAMgAkEPcToAnh8gAyABLQAQIgJBBHY6AKEfIAMgAkEPcToAoB8gAyABLQARIgJBBHY6AKMfIAMgAkEPcToAoh8gAyABLQASIgJBBHY6AKUfIAMgAkEPcToApB8gAyABLQATIgJBBHY6AKcfIAMgAkEPcToAph8gAyABLQAUIgJBBHY6AKkfIAMgAkEPcToAqB8gAyABLQAVIgJBBHY6AKsfIAMgAkEPcToAqh8gAyABLQAWIgJBBHY6AK0fIAMgAkEPcToArB8gAyABLQAXIgJBBHY6AK8fIAMgAkEPcToArh8gAyABLQAYIgJBBHY6ALEfIAMgAkEPcToAsB8gAyABLQAZIgJBBHY6ALMfIAMgAkEPcToAsh8gAyABLQAaIgJBBHY6ALUfIAMgAkEPcToAtB8gAyABLQAbIgJBBHY6ALcfIAMgAkEPcToAth8gAyABLQAcIgJBBHY6ALkfIAMgAkEPcToAuB8gAyABLQAdIgJBBHY6ALsfIAMgAkEPcToAuh8gAyABLQAeIgJBBHY6AL0fIAMgAkEPcToAvB8gAyABLQAfIgFBBHY6AL8fIAMgAUEPcToAvh9BACEEQQAhAgNAIANBgB9qIAJqIgEgAS0AACAEaiIEIARBCGoiBEHwAXFrOgAAIAEgAS0AASAEwEEEdWoiBCAEQQhqIgRB8AFxazoAASABIAEtAAIgBMBBBHVqIgEgAUEIaiIBQfABcWs6AAIgAcBBBHUhBCACQQNqIgJBP0cNAAsgAyADLQC/HyAEajoAvx8gAEIANwIgIABCADcCGCAAQgA3AhAgAEIANwIIIABCADcCACAAQgA3AiwgAEEoaiIKQQE2AgAgAEIANwI0IABCADcCPCAAQgA3AkQgAEKAgICAEDcCTCAAQdQAakEAQcwA/AsAIABB+ABqIQsgAEHQAGohDCADQbgdaiEIIANBsB5qIQEgA0GIHmohBCADQZAdaiEGIANB2B5qIQJBPyEJA0AgAyADQaABaiINIANBgB9qIAlqLAAAEKwBIANB4B1qIgcgACADEBIgA0HoHGoiBSAHIAIQBSAGIAQgARAFIAggASACEAUgByAFEBwgBSAHIAIQBSAGIAQgARAFIAggASACEAUgByAFEBwgBSAHIAIQBSAGIAQgARAFIAggASACEAUgByAFEBwgBSAHIAIQBSAGIAQgARAFIAggASACEAUgByAFEBwgACAHIAIQBSAKIAQgARAFIAwgASACEAUgCyAHIAQQBSAJQQFrIgkNAAsgAyANIAMsAIAfEKwBIAcgACADEBIgACAHIAIQBSAKIAQgARAFIAwgASACEAUgCyAHIAQQBSADQcAfaiQAC+AJAR5/IAEoAighAyABKAIEIQQgASgCLCEFIAEoAgghBiABKAIwIQcgASgCDCEIIAEoAjQhCSABKAIQIQogASgCOCELIAEoAhQhDCABKAI8IQ0gASgCGCEOIAFBQGsiDygCACEQIAEoAhwhESABKAJEIRIgASgCICETIAEoAkghFCABKAIAIRUgACABKAIkIAEoAkxqNgIkIAAgEyAUajYCICAAIBEgEmo2AhwgACAOIBBqNgIYIAAgDCANajYCFCAAIAogC2o2AhAgACAIIAlqNgIMIAAgBiAHajYCCCAAIAQgBWo2AgQgACADIBVqNgIAIAEoAighBSABKAIEIQMgASgCLCEGIAEoAgghByABKAIwIQggASgCDCEJIAEoAjQhCiABKAIQIQsgASgCOCEMIAEoAhQhDSABKAI8IQ4gASgCGCEQIA8oAgAhDyABKAIcIQQgASgCRCERIAEoAiAhEiABKAJIIRMgASgCACEUIAAgASgCTCABKAIkazYCTCAAIBMgEms2AkggACARIARrNgJEIABBQGsiBCAPIBBrNgIAIAAgDiANazYCPCAAIAwgC2s2AjggACAKIAlrNgI0IAAgCCAHazYCMCAAIAYgA2s2AiwgAEEoaiIDIAUgFGs2AgAgAEHQAGogACACEAUgAyADIAJBKGoQBSAAQfgAaiACQdAAaiABQfgAahAFIAEoAlAhFSABKAJUIRYgASgCWCEXIAEoAlwhGCABKAJgIRkgASgCZCEaIAEoAmghGyABKAJsIRwgASgCcCEdIAEoAnQhHiADKAIAIQEgACgCUCECIAAoAiwhBSAAKAJUIQYgACgCMCEHIAAoAlghCCAAKAI0IQkgACgCXCEKIAAoAjghCyAAKAJgIQwgACgCPCENIAAoAmQhDiAEKAIAIQ8gACgCaCEQIAAoAkQhESAAKAJsIRIgACgCSCETIAAoAnAhFCAAIAAoAkwiHyAAKAJ0IiBqNgJMIAAgEyAUajYCSCAAIBEgEmo2AkQgBCAPIBBqNgIAIAAgDSAOajYCPCAAIAsgDGo2AjggACAJIApqNgI0IAAgByAIajYCMCAAIAUgBmo2AiwgAyABIAJqNgIAIAAgICAfazYCJCAAIBQgE2s2AiAgACASIBFrNgIcIAAgECAPazYCGCAAIA4gDWs2AhQgACAMIAtrNgIQIAAgCiAJazYCDCAAIAggB2s2AgggACAGIAVrNgIEIAAgAiABazYCACAAIB5BAXQiASAAKAKcASICazYCnAEgACAdQQF0IgMgACgCmAEiBGs2ApgBIAAgHEEBdCIFIAAoApQBIgZrNgKUASAAIBtBAXQiByAAKAKQASIIazYCkAEgACAaQQF0IgkgACgCjAEiCms2AowBIAAgGUEBdCILIAAoAogBIgxrNgKIASAAIBhBAXQiDSAAKAKEASIOazYChAEgACAXQQF0Ig8gACgCgAEiEGs2AoABIAAgFkEBdCIRIAAoAnwiEms2AnwgACAVQQF0IhMgACgCeCIUazYCeCAAIAMgBGo2AnAgACAFIAZqNgJsIAAgByAIajYCaCAAIAkgCmo2AmQgACALIAxqNgJgIAAgDSAOajYCXCAAIA8gEGo2AlggACARIBJqNgJUIAAgEyAUajYCUCAAIAEgAmo2AnQLrggBA38jAEGQAWsiAyQAIANB4ABqIgQgARAEIANBMGoiAiAEEAQgAiACEAQgAiABIAIQBSAEIAQgAhAFIAQgBBAEIAQgAiAEEAUgAiAEEAQgAiACEAQgAiACEAQgAiACEAQgAiACEAQgBCACIAQQBSACIAQQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIgBBAFIAMgAhAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAIgAyACEAUgAiACEAQgAiACEAQgAiACEAQgAiACEAQgAiACEAQgAiACEAQgAiACEAQgAiACEAQgAiACEAQgAiACEAQgBCACIAQQBSACIAQQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIQBCACIAIgBBAFIAMgAhAEQQEhAgNAIAMgAxAEIAJBAWoiAkHkAEcNAAsgA0EwaiICIAMgAhAFIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIAIgAhAEIANB4ABqIgQgAiAEEAUgBCAEEAQgBCAEEAQgACAEIAEQBSADQZABaiQACxIAIAAgASACrSADrUIghoQQEwuiBAIOfgp/QQBBgICACCAALQBQGyEWIAAoAiQhEiAAKAIgIRMgACgCHCEUIAAoAhghFSAAKAIUIREgACgCECIXrSEPIAAoAgwiGK0hDSAAKAIIIhmtIQsgACgCBCIarSEJIBpBBWytIRAgGUEFbK0hDiAYQQVsrSEMIBdBBWytIQogADUCACEIA0AgASgAA0ECdkH///8fcSAVaq0iAyANfiABKAAAQf///x9xIBFqrSIEIA9+fCABKAAGQQR2Qf///x9xIBRqrSIFIAt+fCABKAAJQQZ2IBNqrSIGIAl+fCASIBZqIAEoAAxBCHZqrSIHIAh+fCADIAt+IAQgDX58IAUgCX58IAYgCH58IAcgCn58IAMgCX4gBCALfnwgBSAIfnwgBiAKfnwgByAMfnwgAyAIfiAEIAl+fCAFIAp+fCAGIAx+fCAHIA5+fCADIAp+IAQgCH58IAUgDH58IAYgDn58IAcgEH58IgNCGohC/////w+DfCIEQhqIQv////8Pg3wiBUIaiEL/////D4N8IgZCGohC/////w+DfCIHQhqIp0EFbCADp0H///8fcWoiEUEadiAEp0H///8fcWohFSAFp0H///8fcSEUIAanQf///x9xIRMgB6dB////H3EhEiARQf///x9xIREgAUEQaiEBIAJCEH0iAkIPVg0ACyAAIBI2AiQgACATNgIgIAAgFDYCHCAAIBU2AhggACARNgIUC5oGACAEQQg2AgAgAgJ/AkAgAgJ/AkBCgIACIAAgAEKAgAJYGyIAIAFBBXatWgRAIAFBgCBPDQFBAQwCCyADQQE2AgBBASAApyAEKAIAQQJ0biIDQQRJDQMaQQIgA0EISQ0DGiADQRBJBEAgAkEDNgIADwsgA0EgSQRAIAJBBDYCAA8LIANBwABJBEAgAkEFNgIADwsgA0GAAUkEQCACQQY2AgAPCyADQYACSQRAIAJBBzYCAA8LIANBgARJBEAgAkEINgIADwsgA0GACEkEQCACQQk2AgAPCyADQYAQSQRAIAJBCjYCAA8LIANBgCBJBEAgAkELNgIADwsgA0GAwABJBEAgAkEMNgIADwsgA0GAgAFJBEAgAkENNgIADwsgA0GAgAJJBEAgAkEONgIADwsgA0GAgARJBEAgAkEPNgIADwsgA0GAgAhJBEAgAkEQNgIADwsgA0GAgBBJBEAgAkERNgIADwsgA0GAgCBJBEAgAkESNgIADwsgA0GAgMAASQRAIAJBEzYCAA8LIANBgICAAUkEQCACQRQ2AgAPCyADQYCAgAJJBEAgAkEVNgIADwsgA0GAgIAESQRAIAJBFjYCAA8LIANBgICACEkEQCACQRc2AgAPCyADQYCAgBBPDQIgAkEYNgIADwtBAiABQYDAAEkNABpBAyABQYCAAUkNABpBBCABQYCAAkkNABpBBSABQYCABEkNABpBBiABQYCACEkNABpBByABQYCAEEkNABpBCCABQYCAIEkNABpBCSABQYCAwABJDQAaQQogAUGAgIABSQ0AGkELIAFBgICAAkkNABpBDCABQYCAgARJDQAaQQ0gAUGAgIAISQ0AGkEOIAFBgICAEEkNABpBDyABQYCAgCBJDQAaQRAgAUGAgIDAAEkNABpBESABQYCAgIABSQ0AGkESIAFBgICAgAJJDQAaQRMgAUGAgICABEkNABpBFEEVIAFBAE4bCyIBNgIAIANC/////wMgAEICiCABrYgiACAAQv////8DWhunIAQoAgBuNgIADwtBGUEaIANBgICAIEkbCzYCAAu3AwIMfwN+IAApAzgiDkIAUgRAIABBQGsiAiAOpyIDakEBOgAAAkAgDkIBfEIPVg0AQQ8gA2siBkUNACAAIANqQcEAakEAIAb8CwALIABBAToAUCAAIAJCEBCKAQsgADUCNCEOIAA1AjAhDyAANQIsIRAgASAAKAIUIAAoAiQgACgCICAAKAIcIAAoAhgiA0EadmoiAkEadmoiB0EadmoiBkEadkEFbGoiBEH///8fcSIFQQVqIghBGnYgA0H///8fcSAEQRp2aiIEaiIJQRp2IAJB////H3EiCmoiC0EadiAHQf///x9xIgdqIgxBGnYgBkH///8fcWoiDUGAgIAgayICQR91IgMgBHEgAkEfdkEBayIEQf///x9xIgIgCXFyIglBGnQgAiAIcSADIAVxcnIiBSAAKAIoaiIINgAAIAEgBSAIS60gECADIApxIAIgC3FyIgVBFHQgCUEGdnKtfHwiED4ABCABIA8gAyAHcSACIAxxciICQQ50IAVBDHZyrXwgEEIgiHwiDz4ACCABIA4gBCANcSADIAZxckEIdCACQRJ2cq18IA9CIIh8PgAMIABB2AAQBwvfBAIHfgF/AkAgACkDOCIDQgBSBEAgAEIQIAN9IgQgAiACIARWGyIEQgBSBH4gBEIDgyEJIABBQGshCkIAIQMCQCAEQgRaBEAgBEJ8gyEFA0AgCiAAKQM4IAN8p2ogASADp2otAAA6AAAgCiADQgGEIgggACkDOHynaiABIAinai0AADoAACAKIANCAoQiCCAAKQM4fKdqIAEgCKdqLQAAOgAAIAogA0IDhCIIIAApAzh8p2ogASAIp2otAAA6AAAgA0IEfCEDIAdCBHwiByAFUg0ACyAJUA0BCwNAIAogACkDOCADfKdqIAEgA6dqLQAAOgAAIANCAXwhAyAGQgF8IgYgCVINAAsLIAApAzgFIAMLIAR8IgM3AzggA0IQVA0BIAAgAEFAa0IQEIoBIABCADcDOCACIAR9IQIgASAEp2ohAQsgAkIQWgRAIAAgASACQnCDIgMQigEgAkIPgyECIAEgA6dqIQELIAJQDQAgAkIDgyEEIABBQGshCkIAIQZCACEDAkAgAkIEWgRAIAJCDIMhCUIAIQcDQCAKIAApAzggA3ynaiABIAOnai0AADoAACAKIANCAYQiBSAAKQM4fKdqIAEgBadqLQAAOgAAIAogA0IChCIFIAApAzh8p2ogASAFp2otAAA6AAAgCiADQgOEIgUgACkDOHynaiABIAWnai0AADoAACADQgR8IQMgB0IEfCIHIAlSDQALIARQDQELA0AgCiAAKQM4IAN8p2ogASADp2otAAA6AAAgA0IBfCEDIAZCAXwiBiAEUg0ACwsgACAAKQM4IAJ8NwM4Cws+AQF/IwBBIGsiBSQAIAUgAyAEQQAQNhogACABIAIgA0EQakIAIAVBxL0CKAIAEQ4AIAVBIBAHIAVBIGokAAtaAQF/IwBBQGoiAyQAIAMgAkIgEEAaIAEgAykDGDcAGCABIAMpAxA3ABAgASADKQMINwAIIAEgAykDADcAACADQcAAEAcgACABQby9AigCABEAACADQUBrJAALCABBgICAgAQLCABBgICAgHgLBgBBgMAACwUAQYABC44BAQZ/AkAgAC0AACIGQTprQf8BcUH2AUkNACAGIQMgACECA0AgAiEHIARBmbPmzAFLDQEgA0H/AXFBMGsiAiAEQQpsIgNBf3NLDQEgAiADaiEEIAdBAWoiAi0AACIDQTprQf8BcUH1AUsNAAsgACACRg0AIAZBMEYgACAHR3ENACABIAQ2AgAgAiEFCyAFC/4IAQh/IAdBeXFBAUYEQAJAAkACQAJAAkACQAJAIAMEfwJAAkAgB0EDTQRAA0AgCCELAkACQAJAAkADQCACIAtqLQAAIglB0P8Ac0EBakF/c0EIdkE/cSAJQdT/AHNBAWpBf3NBCHZBPnFyIAlBuQFqIAlB+wBrIAlBn/8DakF/c3FBCHZxQf8BcXIgCUEEaiAJQTprIAlB0P8DakF/c3FBCHZxQf8BcXIgCUHbAGsgCUHBAGsiCkF/c3FBCHYgCnFB/wFxciIKQQFrIAlBvv8Dc0EBanFBCHZB/wFxIApyIgpB/wFHDQFBACEKIARFDQggBCAJwBBNBEAgC0EBaiILIANPDQMMAQsLIAshCAwHCyAKIA5BBnRqIQ4gDEEBSw0BIAxBBmohDAwCCyADIAhBAWoiACAAIANJGyEIDAULIAxBAmshDCABIA1NDQMgACANaiAOIAx2OgAAIA1BAWohDQtBACEKIAtBAWoiCCADSQ0ACwwCCwNAAkAgAiALai0AACIJQaD/AHNBAWpBf3NBCHZBP3EgCUHS/wBzQQFqQX9zQQh2QT5xciAJQbkBaiAJQfsAayAJQZ//A2pBf3NxQQh2cUH/AXFyIAlBBGogCUE6ayAJQdD/A2pBf3NxQQh2cUH/AXFyIAlB2wBrIAlBwQBrIgpBf3NxQQh2IApxQf8BcXIiCkEBayAJQb7/A3NBAWpxQQh2Qf8BcSAKciIKQf8BRgRAQQAhCiAERQ0EIAQgCcAQTQRAIAtBAWoiCyADTw0CDAMLIAshCAwECyAKIA5BBnRqIQ4CQCAMQQJJBEAgDEEGaiEMDAELIAxBAmshDCABIA1NDQMgACANaiAOIAx2OgAAIA1BAWohDQtBACEKIAtBAWoiCCADTw0DIAghCwwBCwsgAyAIQQFqIgAgACADSRshCAwBCyALIQhBwMQCQcQANgIAQQEhCgsgDEEESw0BIAgFQQALIQBBfyELIAoEQCAAIQgMBwsgDkF/IAx0QX9zcQRAIAAhCAwHCwJAIAdBAnENACAMQQF2IgpFDQACQCAEBEAgACADIAAgA0sbIQhBxAAhByAAIANPDQUMAQtBxAAhByAAIANPBEAgACEIDAULQRwhByAAIAJqLQAAQT1HBEAgACEIDAULIABBAWohCCAKQQFGBEBBACELDAgLIAMgCEcNAyAAIAMgACADSxshCEHEACEHDAQLA0ACQCAAIAJqLAAAIgFBPUYEQCAKQQFrIQoMAQsgBCABEE0NAEEcIQcgACEIDAULIABBAWohACAKRQ0BIAAgCEcNAAsMAwtBACELIARFDQQgACADTw0EA0AgBCAAIAJqLAAAEE1FDQUgAEEBaiIAIANHDQALIAMhCAwFC0F/IQsMBQsgAiAIai0AAEE9Rg0BC0HAxAIgBzYCAAwDCyAAQQJqIQhBACELDAELIAAhCAsgDSEPCwJAIAYEQCAGIAIgCGo2AgAMAQsgAyAIRg0AQcDEAkEcNgIAQX8hCwsgBQRAIAUgDzYCAAsgCw8LEAwAC6AGAQd/AkACQAJAAn8CQAJAIARBeXFBAUcNACADQf3///97Tw0AIANBA24iBUECdCEHAkAgBUF9bCADaiIFRQ0AIARBAnFFBEAgB0EEaiEHDAELIAVBAXYgB2pBAmohBwsgASAHTQ0AAkAgBEEETwRAIANFBEBBACEEDAcLQQAhBUEAIQQMAQsgA0UEQEEAIQQMBgtBACEFQQAhBAwCCwNAIAIgCWotAAAgCEEIdHIhCCAFQQhyIQUDQCAAIARqIAggBUEGayIFdkE/cSIGQccAaiAGQeb/A2pBCHYiCkF/c3EgBkHM/wNqQQh2IgtxIAogBkHBAGpxciAGQcH/AWpBf3NBCHZB3wBxciAGQfwBaiAGQcL/A2pBCHZxIAtBf3NxciAGQcH/AHNBAWpBf3NBCHZBLXFyOgAAIARBAWohBCAFQQVLDQALIAlBAWoiCSADRw0ACyAFRQ0DQcH/ASEGQS0hCUHfAAwCCxAMAAsDQCACIAlqLQAAIAhBCHRyIQggBUEIciEFA0AgACAEaiAIIAVBBmsiBXZBP3EiBkHHAGogBkHm/wNqQQh2IgpBf3NxIAZBzP8DakEIdiILcSAKIAZBwQBqcXIgBkHB/wBqQX9zQQh2QS9xciAGQfwBaiAGQcL/A2pBCHZxIAtBf3NxciAGQcH/AHNBAWpBf3NBCHZBK3FyOgAAIARBAWohBCAFQQVLDQALIAlBAWoiCSADRw0ACyAFRQ0BQcH/ACEGQSshCUEvCyEDIAAgBGogCEEGIAVrdEE/cSICQccAaiACQeb/A2pBCHYiBUF/c3EgAkHM/wNqQQh2IghxIAUgAkHBAGpxciADIAIgBmpBf3NBCHZxciACQfwBaiACQcL/A2pBCHZxIAhBf3NxciAJIAJBwf8Ac0EBakF/c0EIdnFyOgAAIARBAWohBAsgBCAHSw0BCwJAIAQgB08EQCAEIQcMAQsgByAEayICRQ0AIAAgBGpBPSAC/AsACyABIAdBAWoiAiABIAJLGyAHayIBBEAgACAHakEAIAH8CwALIAAPC0HQCEHICUHvAUHlCxAAAAv7AQEDfyAARQRAQWcPCyAAKAIARQRAQX8PCyAAKAIEQRBJBEBBfg8LAkAgACgCCA0AIAAoAgxFDQBBbg8LIAAoAhQhASAAKAIQRQRAQW1BeiABGw8LIAFBCEkEQEF6DwsCQCAAKAIYDQAgACgCHEUNAEFsDwsCQCAAKAIgDQAgACgCJEUNAEFrDwsgACgCMCIBRQRAQXAPCyABQf///wdLBEBBbw8LQXIhAgJAIAAoAiwiA0EISQ0AIANBgICAAUsEQEFxDwsgAyABQQN0SQ0AIAAoAihFBEBBdA8LIAAoAjQiAEUEQEFkDwtBY0EAIABB////B0sbIQILIAILqSQBJ38jAEHQBGsiHSQAQX8hCgJAIABBIGoiCBCoAUUNACAAEEMNACADEIQBRQ0AIAMQQw0AIB1BgAFqIgsgAxBiDQAgHUGAA2oiChAyGiAEBEAgCkGwvAJCIhATGgsgCiAAQiAQExogCiADQiAQExogCiABIAIQExogCiAdQcACaiIBEB4aIAEQJiAdQQhqIQ4gASEEIAghCkEAIQNBACEBIwBB4BFrIgUkAANAIAVB4A9qIgggA2ogBCADQQN2ai0AACIJIANBBnF2QQFxOgAAIAggA0EBciIHaiAJIAdBB3F2QQFxOgAAIANBAmoiA0GAAkcNAAtB/gEhBANAIAEiCEEBaiEBAkAgCCAFQeAPaiIDaiIJLQAARQ0AIAhB/gFLDQACQCABIANqIgMsAAAiB0UNACAHQQF0IgcgCSwAACIGaiIMQQ9MBEAgCSAMOgAAIANBADoAAAwBCyAGIAdrIgNBcUgNASAJIAM6AAAgASEDA0AgBUHgD2ogA2oiBy0AAEUEQCAHQQE6AAAMAgsgB0EAOgAAIANBAWoiA0GAAkcNAAsLIARFDQACQCAIQQJqIgMgBUHgD2pqIgcsAAAiBkUNACAGQQJ0IgYgCSwAACIMaiINQRBOBEAgDCAGayIHQXFIDQIgCSAHOgAAA0AgBUHgD2ogA2oiBy0AAARAIAdBADoAACADQQFqIgNBgAJHDQEMAwsLIAdBAToAAAwBCyAJIA06AAAgB0EAOgAAC0EFIAQgBEEFTxtBAWoiB0ECRg0AAkAgCEEDaiIDIAVB4A9qaiIGLAAAIgxFDQAgDEEDdCIMIAksAAAiDWoiD0EQTgRAIA0gDGsiBkFxSA0CIAkgBjoAAANAIAVB4A9qIANqIgYtAAAEQCAGQQA6AAAgA0EBaiIDQYACRw0BDAMLCyAGQQE6AAAMAQsgCSAPOgAAIAZBADoAAAsgB0EDRg0AAkAgCEEEaiIDIAVB4A9qaiIGLAAAIgxFDQAgDEEEdCIMIAksAAAiDWoiD0EQTgRAIA0gDGsiBkFxSA0CIAkgBjoAAANAIAVB4A9qIANqIgYtAAAEQCAGQQA6AAAgA0EBaiIDQYACRw0BDAMLCyAGQQE6AAAMAQsgCSAPOgAAIAZBADoAAAsgB0EERg0AAkAgCEEFaiIDIAVB4A9qaiIGLAAAIgxFDQAgDEEFdCIMIAksAAAiDWoiD0EQTgRAIA0gDGsiBkFxSA0CIAkgBjoAAANAIAVB4A9qIANqIgYtAAAEQCAGQQA6AAAgA0EBaiIDQYACRw0BDAMLCyAGQQE6AAAMAQsgCSAPOgAAIAZBADoAAAsgB0EFRg0AIAhBBmoiAyAFQeAPamoiCCwAACIHRQ0AIAdBBnQiByAJLAAAIgZqIgxBEE4EQCAGIAdrIghBcUgNASAJIAg6AAADQCAFQeAPaiADaiIILQAABEAgCEEAOgAAIANBAWoiA0GAAkcNAQwDCwsgCEEBOgAADAELIAkgDDoAACAIQQA6AAALIARBAWshBCABQYACRw0AC0EAIQMDQCAFQeANaiIBIANqIAogA0EDdmotAAAiBCADQQZxdkEBcToAACABIANBAXIiCGogBCAIQQdxdkEBcToAACADQQJqIgNBgAJHDQALQQAhAUH+ASEEA0AgASIIQQFqIQECQCAIIAVB4A1qIgNqIgotAABFDQAgCEH+AUsNAAJAIAEgA2oiAywAACIJRQ0AIAlBAXQiCSAKLAAAIgdqIgZBD0wEQCAKIAY6AAAgA0EAOgAADAELIAcgCWsiA0FxSA0BIAogAzoAACABIQMDQCAFQeANaiADaiIJLQAARQRAIAlBAToAAAwCCyAJQQA6AAAgA0EBaiIDQYACRw0ACwsgBEUNAAJAIAhBAmoiAyAFQeANamoiCSwAACIHRQ0AIAdBAnQiByAKLAAAIgZqIgxBEE4EQCAGIAdrIglBcUgNAiAKIAk6AAADQCAFQeANaiADaiIJLQAABEAgCUEAOgAAIANBAWoiA0GAAkcNAQwDCwsgCUEBOgAADAELIAogDDoAACAJQQA6AAALQQUgBCAEQQVPG0EBaiIJQQJGDQACQCAIQQNqIgMgBUHgDWpqIgcsAAAiBkUNACAGQQN0IgYgCiwAACIMaiINQRBOBEAgDCAGayIHQXFIDQIgCiAHOgAAA0AgBUHgDWogA2oiBy0AAARAIAdBADoAACADQQFqIgNBgAJHDQEMAwsLIAdBAToAAAwBCyAKIA06AAAgB0EAOgAACyAJQQNGDQACQCAIQQRqIgMgBUHgDWpqIgcsAAAiBkUNACAGQQR0IgYgCiwAACIMaiINQRBOBEAgDCAGayIHQXFIDQIgCiAHOgAAA0AgBUHgDWogA2oiBy0AAARAIAdBADoAACADQQFqIgNBgAJHDQEMAwsLIAdBAToAAAwBCyAKIA06AAAgB0EAOgAACyAJQQRGDQACQCAIQQVqIgMgBUHgDWpqIgcsAAAiBkUNACAGQQV0IgYgCiwAACIMaiINQRBOBEAgDCAGayIHQXFIDQIgCiAHOgAAA0AgBUHgDWogA2oiBy0AAARAIAdBADoAACADQQFqIgNBgAJHDQEMAwsLIAdBAToAAAwBCyAKIA06AAAgB0EAOgAACyAJQQVGDQAgCEEGaiIDIAVB4A1qaiIILAAAIglFDQAgCUEGdCIJIAosAAAiB2oiBkEQTgRAIAcgCWsiCEFxSA0BIAogCDoAAANAIAVB4A1qIANqIggtAAAEQCAIQQA6AAAgA0EBaiIDQYACRw0BDAMLCyAIQQE6AAAMAQsgCiAGOgAAIAhBADoAAAsgBEEBayEEIAFBgAJHDQALIAVB4ANqIgogCxAOIAUgCykCIDcDwAEgBSALKQIYNwO4ASAFIAspAhA3A7ABIAUgCykCCDcDqAEgBSALKQIANwOgASAFIAspAig3A8gBIAUgCykCMDcD0AEgBSALKQI4NwPYASAFIAtBQGspAgA3A+ABIAUgCykCSDcD6AEgBSALKQJQNwPwASAFIAspAlg3A/gBIAUgCykCYDcDgAIgBSALKQJoNwOIAiAFIAspAnA3A5ACIAVBwAJqIgEgBUGgAWoiBBAcIAUgASAFQbgDaiIDEAUgBUEoaiAFQegCaiILIAVBkANqIggQBSAFQdAAaiAIIAMQBSAFQfgAaiABIAsQBSABIAUgChASIAQgASADEAUgBUHIAWoiCSALIAgQBSAFQfABaiIHIAggAxAFIAVBmAJqIgogASALEAUgBUGABWoiBiAEEA4gASAFIAYQEiAEIAEgAxAFIAkgCyAIEAUgByAIIAMQBSAKIAEgCxAFIAVBoAZqIgYgBBAOIAEgBSAGEBIgBCABIAMQBSAJIAsgCBAFIAcgCCADEAUgCiABIAsQBSAFQcAHaiIGIAQQDiABIAUgBhASIAQgASADEAUgCSALIAgQBSAHIAggAxAFIAogASALEAUgBUHgCGoiBiAEEA4gASAFIAYQEiAEIAEgAxAFIAkgCyAIEAUgByAIIAMQBSAKIAEgCxAFIAVBgApqIgYgBBAOIAEgBSAGEBIgBCABIAMQBSAJIAsgCBAFIAcgCCADEAUgCiABIAsQBSAFQaALaiIGIAQQDiABIAUgBhASIAQgASADEAUgCSALIAgQBSAHIAggAxAFIAogASALEAUgBUHADGogBBAOIA5CADcCICAOQgA3AhggDkIANwIQIA5CADcCCCAOQgA3AgAgDkIANwIsIA5BKGoiIkEBNgIAIA5CADcCNCAOQgA3AjwgDkIANwJEIA5CADcCVCAOQoCAgIAQNwJMIA5CADcCXCAOQgA3AmQgDkIANwJsIA5BADYCdCAOQdAAaiEjQf8BIQQDQAJAAkACQCAFQeAPaiIGIARqLQAADQAgBUHgDWoiDCAEai0AAA0AIAYgBEEBayIBai0AAEUEQCABIAxqLQAARQ0CCyABIQQLIARBAEgNAQNAIAVBwAJqIgYgDhAcAkAgBCIBIAVB4A9qaiwAACIEQQBKBEAgBUGgAWoiDCAGIAMQBSAJIAsgCBAFIAcgCCADEAUgCiAGIAsQBSAGIAwgBUHgA2ogBEH+AXFBAXZBoAFsahASDAELIARBAE4NACAFQaABaiIMIAVBwAJqIgYgAxAFIAkgCyAIEAUgByAIIAMQBSAKIAYgCxAFIAYgDCAFQeADakEAIARrQf4BcUEBdkGgAWxqEGALAkAgBUHgDWogAWosAAAiBEEASgRAIAVBoAFqIgwgBUHAAmoiBiADEAUgCSALIAgQBSAHIAggAxAFIAogBiALEAUgBiAMIARB/gFxQQF2QfgAbEHQDWoQhwEMAQsgBEEATg0AIAVBoAFqIAVBwAJqIgYgAxAFIAkgCyAIEAUgByAIIAMQBSAKIAYgCxAFIAUoAqABIQwgBSgCyAEhDSAFKAKkASEPIAUoAswBIRAgBSgCqAEhESAFKALQASESIAUoAqwBIRMgBSgC1AEhFCAFKAKwASEVIAUoAtgBIRYgBSgCtAEhFyAFKALcASEYIAUoArgBIRkgBSgC4AEhGiAFKAK8ASEbIAUoAuQBIRwgBSgCwAEhHiAFKALoASEfIAUgBSgC7AEiICAFKALEASIhazYCjAMgBSAfIB5rNgKIAyAFIBwgG2s2AoQDIAUgGiAZazYCgAMgBSAYIBdrNgL8AiAFIBYgFWs2AvgCIAUgFCATazYC9AIgBSASIBFrNgLwAiAFIBAgD2s2AuwCIAUgDSAMazYC6AIgBSAgICFqNgLkAiAFIB4gH2o2AuACIAUgGyAcajYC3AIgBSAZIBpqNgLYAiAFIBcgGGo2AtQCIAUgFSAWajYC0AIgBSATIBRqNgLMAiAFIBEgEmo2AsgCIAUgDyAQajYCxAIgBSAMIA1qNgLAAiAIIAZBACAEa0H+AXFBAXZB+ABsQdANaiIEQShqEAUgCyALIAQQBSADIARB0ABqIAoQBSAFKAKUAiEeIAUoApACIR8gBSgCjAIhICAFKAKIAiEhIAUoAoQCISQgBSgCgAIhJSAFKAL8ASEmIAUoAvgBIScgBSgC9AEhKCAFKALwASEpIAUoAugCIQQgBSgCkAMhBiAFKALsAiEMIAUoApQDIQ0gBSgC8AIhDyAFKAKYAyEQIAUoAvQCIREgBSgCnAMhEiAFKAL4AiETIAUoAqADIRQgBSgC/AIhFSAFKAKkAyEWIAUoAoADIRcgBSgCqAMhGCAFKAKEAyEZIAUoAqwDIRogBSgCiAMhGyAFKAKwAyEcIAUgBSgCjAMiKiAFKAK0AyIrajYCjAMgBSAbIBxqNgKIAyAFIBkgGmo2AoQDIAUgFyAYajYCgAMgBSAVIBZqNgL8AiAFIBMgFGo2AvgCIAUgESASajYC9AIgBSAPIBBqNgLwAiAFIAwgDWo2AuwCIAUgBCAGajYC6AIgBSArICprNgLkAiAFIBwgG2s2AuACIAUgGiAZazYC3AIgBSAYIBdrNgLYAiAFIBYgFWs2AtQCIAUgFCATazYC0AIgBSASIBFrNgLMAiAFIBAgD2s2AsgCIAUgDSAMazYCxAIgBSAGIARrNgLAAiAFIClBAXQiBCAFKAK4AyIGazYCkAMgBSAoQQF0IgwgBSgCvAMiDWs2ApQDIAUgJ0EBdCIPIAUoAsADIhBrNgKYAyAFICZBAXQiESAFKALEAyISazYCnAMgBSAlQQF0IhMgBSgCyAMiFGs2AqADIAUgJEEBdCIVIAUoAswDIhZrNgKkAyAFICFBAXQiFyAFKALQAyIYazYCqAMgBSAgQQF0IhkgBSgC1AMiGms2AqwDIAUgH0EBdCIbIAUoAtgDIhxrNgKwAyAFIB5BAXQiHiAFKALcAyIfazYCtAMgBSAEIAZqNgK4AyAFIAwgDWo2ArwDIAUgDyAQajYCwAMgBSARIBJqNgLEAyAFIBMgFGo2AsgDIAUgFSAWajYCzAMgBSAXIBhqNgLQAyAFIBkgGmo2AtQDIAUgGyAcajYC2AMgBSAeIB9qNgLcAwsgDiAFQcACaiADEAUgIiALIAgQBSAjIAggAxAFIAFBAWshBCABQQBKDQALDAELIARBAmshBCABDQELCyAFQeARaiQAIB1BoAJqIgEgDhAiQX8gASAAEEYgACABRhsgACABQSAQO3IhCgsgHUHQBGokACAKC8gCAgN/A34jAEGwBGsiBiQAIAZB4AJqIgcQMhogBQRAIAdBsLwCQiIQExoLIAZBoAJqIARCIBBAGiAGQeACaiIIIAZBwAJqQiAQExogCCACIAMQExogCCAGQeABaiIHEB4aIAQpACAhCSAEKQAoIQogBCkAMCELIAAgBCkAODcAOCAAIAs3ADAgACAKNwAoIABBIGoiBCAJNwAAIAcQJiAGIAcQMCAAIAYQIiAIEDIaIAUEQCAIQbC8AkIiEBMaCyAGQeACaiIFIABCwAAQExogBSACIAMQExogBSAGQaABaiIAEB4aIAAQJiAGIAYtAKACQfgBcToAoAIgBiAGLQC/AkE/cUHAAHI6AL8CIAQgACAGQaACaiICIAZB4AFqIgAQqQEgAkHAABAHIABBwAAQByABBEAgAULAADcDAAsgBkGwBGokAEEAC6gZAhN+BX8jAEGAEGsiGCQAIBhBgAhqIAFBgAj8CgAAQQAhAQNAIAFBA3QiFiAYQYAIaiIaaiIXIBcpAwAgACAWaikDAIU3AwAgGiAWQQhyIhdqIhkgGSkDACAAIBdqKQMAhTcDACAaIBZBEHIiF2oiGSAZKQMAIAAgF2opAwCFNwMAIBogFkEYciIWaiIXIBcpAwAgACAWaikDAIU3AwAgAUEEaiIBQYABRw0ACyAYIBpBgAj8CgAAQQAhAEEAIQEDQCAYIAFBA3QiFmoiFyAXKQMAIAIgFmopAwCFNwMAIBggFkEIciIXaiIZIBkpAwAgAiAXaikDAIU3AwAgGCAWQRByIhdqIhkgGSkDACACIBdqKQMAhTcDACAYIBZBGHIiFmoiFyAXKQMAIAIgFmopAwCFNwMAIAFBBGoiAUGAAUcNAAsDQCAYQYAIaiAAQQd0aiIBIAEpAzgiBSABKQMYIgd8IAdCAYZC/v///x+DIAVC/////w+DfnwiByABKQN4hUIgiSIEIAEpA1giBnwgBkIBhkL+////H4MgBEL/////D4N+fCIGIAWFQiiJIgUgB3wgBUL/////D4MgB0IBhkL+////H4N+fCIHIASFQjCJIgQgASkDKCIDIAEpAwgiCHwgCEIBhkL+////H4MgA0L/////D4N+fCIIIAEpA2iFQiCJIgsgASkDSCIMfCAMQgGGQv7///8fgyALQv////8Pg358IgwgA4VCKIkiAyAIfCADQv////8PgyAIQgGGQv7///8fg358IgggC4VCMIkiCyAMfCALQv////8PgyAMQgGGQv7///8fg358IgwgA4VCAYkiAyABKQMgIg8gASkDACIKfCAKQgGGQv7///8fgyAPQv////8Pg358IgogASkDYIVCIIkiECABQUBrIhYpAwAiE3wgE0IBhkL+////H4MgEEL/////D4N+fCITIA+FQiiJIg8gCnwgD0L/////D4MgCkIBhkL+////H4N+fCIKfCADQv////8PgyAKQgGGQv7///8fg358IgmFQiCJIhQgASkDMCIRIAEpAxAiDXwgDUIBhkL+////H4MgEUL/////D4N+fCINIAEpA3CFQiCJIhIgASkDUCIOfCAOQgGGQv7///8fgyASQv////8Pg358Ig4gEYVCKIkiESANfCARQv////8PgyANQgGGQv7///8fg358Ig0gEoVCMIkiEiAOfCASQv////8PgyAOQgGGQv7///8fg358Ig58IBRC/////w+DIA5CAYZC/v///x+DfnwiFSADhUIoiSIDIAl8IANC/////w+DIAlCAYZC/v///x+DfnwiCTcDACABIAkgFIVCMIkiCTcDeCABIAkgFXwgCUL/////D4MgFUIBhkL+////H4N+fCIJNwNQIAEgAyAJhUIBiTcDKCABIAQgBnwgBEL/////D4MgBkIBhkL+////H4N+fCIEIA4gEYVCAYkiBiAIfCAGQv////8PgyAIQgGGQv7///8fg358IgMgCiAQhUIwiSIIhUIgiSIKfCAEQgGGQv7///8fgyAKQv////8Pg358IhAgBoVCKIkiBiADfCAGQv////8PgyADQgGGQv7///8fg358IgkgCoVCMIkiAzcDYCABIAk3AwggASADIBB8IANC/////w+DIBBCAYZC/v///x+DfnwiAzcDWCABIAMgBoVCAYk3AzAgASAEIAWFQgGJIgUgDXwgBUL/////D4MgDUIBhkL+////H4N+fCIEIAuFQiCJIgYgCCATfCAIQv////8PgyATQgGGQv7///8fg358IgN8IAZC/////w+DIANCAYZC/v///x+DfnwiCCAFhUIoiSIFIAR8IAVC/////w+DIARCAYZC/v///x+DfnwiCyAGhUIwiSIENwNoIAEgCzcDECAWIAQgCHwgBEL/////D4MgCEIBhkL+////H4N+fCIENwMAIAEgBCAFhUIBiTcDOCABIAcgAyAPhUIBiSIFfCAHQgGGQv7///8fgyAFQv////8Pg358IgcgEoVCIIkiBCAMfCAEQv////8PgyAMQgGGQv7///8fg358IgYgBYVCKIkiBSAHfCAFQv////8PgyAHQgGGQv7///8fg358IgMgBIVCMIkiBzcDcCABIAM3AxggASAGIAd8IAdC/////w+DIAZCAYZC/v///x+DfnwiBzcDSCABIAUgB4VCAYk3AyAgAEEBaiIAQQhHDQALQQAhAANAIBhBgAhqIABBBHRqIgEgASkDiAMiBSABKQOIASIHfCAHQgGGQv7///8fgyAFQv////8Pg358IgcgASkDiAeFQiCJIgQgASkDiAUiBnwgBkIBhkL+////H4MgBEL/////D4N+fCIGIAWFQiiJIgUgB3wgBUL/////D4MgB0IBhkL+////H4N+fCIHIASFQjCJIgQgASkDiAIiAyABKQMIIgh8IAhCAYZC/v///x+DIANC/////w+DfnwiCCABKQOIBoVCIIkiCyABKQOIBCIMfCAMQgGGQv7///8fgyALQv////8Pg358IgwgA4VCKIkiAyAIfCADQv////8PgyAIQgGGQv7///8fg358IgggC4VCMIkiCyAMfCALQv////8PgyAMQgGGQv7///8fg358IgwgA4VCAYkiAyABKQOAAiIPIAEpAwAiCnwgCkIBhkL+////H4MgD0L/////D4N+fCIKIAEpA4AGhUIgiSIQIAEpA4AEIhN8IBNCAYZC/v///x+DIBBC/////w+DfnwiEyAPhUIoiSIPIAp8IA9C/////w+DIApCAYZC/v///x+DfnwiCnwgA0L/////D4MgCkIBhkL+////H4N+fCIJhUIgiSIUIAEpA4ADIhEgASkDgAEiDXwgDUIBhkL+////H4MgEUL/////D4N+fCINIAEpA4AHhUIgiSISIAEpA4AFIg58IA5CAYZC/v///x+DIBJC/////w+DfnwiDiARhUIoiSIRIA18IBFC/////w+DIA1CAYZC/v///x+DfnwiDSAShUIwiSISIA58IBJC/////w+DIA5CAYZC/v///x+DfnwiDnwgFEL/////D4MgDkIBhkL+////H4N+fCIVIAOFQiiJIgMgCXwgA0L/////D4MgCUIBhkL+////H4N+fCIJNwMAIAEgCSAUhUIwiSIJNwOIByABIAkgFXwgCUL/////D4MgFUIBhkL+////H4N+fCIJNwOABSABIAMgCYVCAYk3A4gCIAEgBCAGfCAEQv////8PgyAGQgGGQv7///8fg358IgQgDiARhUIBiSIGIAh8IAZC/////w+DIAhCAYZC/v///x+DfnwiAyAKIBCFQjCJIgiFQiCJIgp8IARCAYZC/v///x+DIApC/////w+DfnwiECAGhUIoiSIGIAN8IAZC/////w+DIANCAYZC/v///x+DfnwiCSAKhUIwiSIDNwOABiABIAk3AwggASADIBB8IANC/////w+DIBBCAYZC/v///x+DfnwiAzcDiAUgASADIAaFQgGJNwOAAyABIAQgBYVCAYkiBSANfCAFQv////8PgyANQgGGQv7///8fg358IgQgC4VCIIkiBiAIIBN8IAhC/////w+DIBNCAYZC/v///x+DfnwiA3wgBkL/////D4MgA0IBhkL+////H4N+fCIIIAWFQiiJIgUgBHwgBUL/////D4MgBEIBhkL+////H4N+fCILIAaFQjCJIgQ3A4gGIAEgCzcDgAEgASAEIAh8IARC/////w+DIAhCAYZC/v///x+DfnwiBDcDgAQgASAEIAWFQgGJNwOIAyABIAcgAyAPhUIBiSIFfCAHQgGGQv7///8fgyAFQv////8Pg358IgcgEoVCIIkiBCAMfCAEQv////8PgyAMQgGGQv7///8fg358IgYgBYVCKIkiBSAHfCAFQv////8PgyAHQgGGQv7///8fg358IgMgBIVCMIkiBzcDgAcgASADNwOIASABIAYgB3wgB0L/////D4MgBkIBhkL+////H4N+fCIHNwOIBCABIAUgB4VCAYk3A4ACIABBAWoiAEEIRw0ACyACIBhBgAj8CgAAQQAhAANAIAIgAEEDdCIBaiIWIBYpAwAgGEGACGoiGSABaikDAIU3AwAgAiABQQhyIhZqIhcgFykDACAWIBlqKQMAhTcDACACIAFBEHIiFmoiFyAXKQMAIBhBgAhqIBZqKQMAhTcDACACIAFBGHIiAWoiFiAWKQMAIBhBgAhqIAFqKQMAhTcDACAAQQRqIgBBgAFHDQALIBhBgBBqJAALnAIBBX8DQCAAIAJBAnRqIgQgASACQQNsaiIDQQFqLQAAQQh0QYAecSADLQAAcjsBACAEIAMtAAJBBHQgAy0AAUEEdnI7AQIgAkEBaiICQYABRw0ACyABQYADaiEEIABBgARqIQVBACECA0AgBSACQQJ0aiIGIAQgAkEDbGoiA0EBai0AAEEIdEGAHnEgAy0AAHI7AQAgBiADLQACQQR0IAMtAAFBBHZyOwECIAJBAWoiAkGAAUcNAAsgAUGABmohASAAQYAIaiEDQQAhAgNAIAMgAkECdGoiBCABIAJBA2xqIgBBAWotAABBCHRBgB5xIAAtAAByOwEAIAQgAC0AAkEEdCAALQABQQR2cjsBAiACQQFqIgJBgAFHDQALC6ADAQV/IwBBgA1rIgQkACAEQYABaiACEJsBAkADQEF/IQggBEGAAWogBkEBdGoiBS8BAEGAGksNASAFLwECQYAaSw0BIAUvAQRBgBpLDQEgBS8BBkGAGksNASAGQQRqIgZBgAJHDQALIARBgAVqIQdBACEGA0AgByAGQQF0aiIFLwEAQYAaSw0BIAUvAQJBgBpLDQEgBS8BBEGAGksNASAFLwEGQYAaSw0BIAZBBGoiBkGAAkcNAAsgBEGACWohB0EAIQYDQCAHIAZBAXRqIgUvAQBBgBpLDQEgBS8BAkGAGksNASAFLwEEQYAaSw0BIAUvAQZBgBpLDQEgBkEEaiIGQYACRw0ACyAEIAMpABg3A1ggBCADKQAQNwNQIAQgAykACDcDSCAEIAMpAAA3A0AgBEHgAGogAkKgCRCeARogBCAEQUBrIgNCwAAQcBogACADIAIgBEEgahCFAiABIAQpAxg3ABggASAEKQMQNwAQIAEgBCkDCDcACCABIAQpAwA3AAAgA0HAABAHIARBwAAQB0EAIQgLIARBgA1qJAAgCAuwBAEDfyMAIgQgBEHABGtBQHEiBCQAIAQgATYCvAECQCABQcAATQRAIARBwAFqIgVBAEEAIAEQLkEASA0BIAUgBEG8AWpCBBANQQBIDQEgBSACIAOtEA1BAEgNASAFIAAgARArGgwBCyAEQcABaiIFQQBBAEHAABAuQQBIDQAgBSAEQbwBakIEEA1BAEgNACAFIAIgA60QDUEASA0AIAUgBEHwAGpBwAAQK0EASA0AIAAgBCkDiAE3ABggACAEKQOAATcAECAAIAQpA3g3AAggACAEKQNwNwAAIABBIGohACABQSBrIgFBwQBPBEADQCAEIAQpA6gBNwNoIAQgBCkDoAE3A2AgBCAEKQOYATcDWCAEIAQpA5ABNwNQIAQgBCkDiAE3A0ggBCAEKQOAATcDQCAEIAQpA3g3AzggBCAEKQNwNwMwIARB8ABqQcAAIARBMGpCwABBAEEAEHpBAEgNAiAAIAQpA4gBNwAYIAAgBCkDgAE3ABAgACAEKQN4NwAIIAAgBCkDcDcAACAAQSBqIQAgAUEgayIBQcAASw0ACwsgBCAEKQOoATcDaCAEIAQpA6ABNwNgIAQgBCkDmAE3A1ggBCAEKQOQATcDUCAEIAQpA4gBNwNIIAQgBCkDgAE3A0AgBCAEKQN4NwM4IAQgBCkDcDcDMCAEQfAAaiICIAEgBEEwakLAAEEAQQAQekEASA0AIAFFDQAgACACIAH8CgAACyAEQcABakGAAxAHJAALvAEBBX8jAEGAAmsiAyQAIANBAEHIAfwLACADQQA6AOwBIANBIDYC6AEgA0KAgICAgBE3A+ABIAKnIgcEQANAIAMoAuQBIgQgBUYEQCADEBogA0EANgLgASADKALkASEEQQAhBQsgAyABIAZqIAUgBCAFayIFIAcgBmsiBCAEIAVLGyIEEBggAyADKALgASAEaiIFNgLgASAEIAZqIgYgB0kNAAsLIAMgABBbGiADQYACEAcgA0GAAmokAEEAC5gDAgV/An4jAEFAaiIEJAACQCACQcEAa0H/AXFBvwFLBEBBfyEGIAApAFBQBEAgACgA4AIiA0GBAU8EQCAAQUBrIgMgAykAACIIQoABfDcAACAAIAApAEggCEL/flatfDcASCAAIABB4ABqIgUQXiAAIAAoAOACQYABayIDNgDgAiADQYEBTw0DIAMEQCAFIABB4AFqIAP8CgAACyAAKADgAiEDCyAAQUBrIgUgBSkAACIIIAOtfCIJNwAAIAAgACkASCAIIAlWrXw3AEggAC0A5AIEQCAAQn83AFgLIABCfzcAUCAAQeAAaiEFQQAhBkGAAiADayIHBEAgAyAFakEAIAf8CwALIAAgBRBeIAQgACkAADcDACAEIAApAAg3AwggBCAAKQAQNwMQIAQgACkAGDcDGCAEIAApACA3AyAgBCAAKQAoNwMoIAQgACkAMDcDMCAEIAApADg3AzggAgRAIAEgBCAC/AoAAAsgAEHAABAHIAVBgAIQBwsgBEFAayQAIAYPCxAMAAtB8ApB2AlBsgJB9ggQAAALBQBBoAMLagEFfwNAIAAgA2oiAiACLQAAIAQgASADai0AAGprIgI6AAAgACADQQFyIgRqIgYgBi0AACABIARqLQAAIAJBCHZBAXFqayICOgAAIAJBCHZBAXEhBCADQQJqIQMgBUECaiIFQcAARw0ACwvoAgEDfyAAIAIoAgAgASgCACIEQf8BcUHArAJqLQAAIAEoAgwiA0EIdkH/AXFBwKwCai0AAEEIdHIgASgCCCIFQRB2Qf8BcUHArAJqLQAAQRB0ciABKAIEIgFBGHZBwKwCai0AAEEYdHJzNgIAIAAgAigCBCABQf8BcUHArAJqLQAAIARBCHZB/wFxQcCsAmotAABBCHRyIANBEHZB/wFxQcCsAmotAABBEHRyIAVBGHZBwKwCai0AAEEYdHJzNgIEIAAgAigCCCAFQf8BcUHArAJqLQAAIAFBCHZB/wFxQcCsAmotAABBCHRyIARBEHZB/wFxQcCsAmotAABBEHRyIANBGHZBwKwCai0AAEEYdHJzNgIIIAAgAigCDCADQf8BcUHArAJqLQAAIAVBCHZB/wFxQcCsAmotAABBCHRyIAFBEHZB/wFxQcCsAmotAABBEHRyIARBGHZBwKwCai0AAEEYdHJzNgIMCxAAIAAgAUG8vQIoAgARAAAL0w8BJH8jAEHwBGsiAiQAIAJB4ANqIgMgARAEIANB8AwgAxAFIAIgAigChAQiBzYClAIgAiACKAKABCIINgKQAiACIAIoAvwDIgk2AowCIAIgAigC+AMiCjYCiAIgAiACKAL0AyILNgKEAiACIAIoAvADIgw2AoACIAIgAigC7AMiDTYC/AEgAiACKALoAyIONgL4ASACIAIoAuQDIgU2AvQBIAIgAigC4AMiBkEBajYC8AEgAkHwAWoiBCAEQcCJAhAFIAIgB0HM5N8FazYC1AMgAiAIQYCS9QhrNgLQAyACIAlB55zGAWs2AswDIAIgCkHEhv8CazYCyAMgAiALQeiumARrNgLEAyACIAxBqYAHajYCwAMgAiANQY+UqANqNgK8AyACIA5Bw6KqB2s2ArgDIAIgBUGF5c0GajYCtAMgAiAGQcqOmgVrNgKwAyACQcABaiIZIANBwAwQBSACQQAgAigC5AFrNgLkASACQQAgAigC4AFrNgLgASACQQAgAigC3AFrNgLcASACQQAgAigC2AFrNgLYASACQQAgAigC1AFrNgLUASACQQAgAigC0AFrNgLQASACQQAgAigCzAFrNgLMASACQQAgAigCyAFrNgLIASACQQAgAigCxAFrNgLEASACIAIoAsABQX9zNgLAASAZIBkgAkGwA2oQBSACQYADaiIiIAQgGRCDASEDIAJB0AJqIgQgIiABEAUgAkHABGoiJCAEEA8gAi0AwAQhJSACKAKkAyEaIAIoAvQCIQQgAigCoAMhGyACKALwAiEQIAIoApwDIRwgAigC7AIhESACKAKYAyEdIAIoAugCIRIgAigClAMhHiACKALkAiETIAIoApADIR8gAigC4AIhFCACKAKMAyEgIAIoAtwCIRUgAigCiAMhISACKALYAiEWIAIoAoQDIQ8gAigC1AIhFyACKAKAAyEjIAIoAtACIRggAiAHIANBAWsiAXE2AuQEIAIgASAIcTYC4AQgAiABIAlxNgLcBCACIAEgCnE2AtgEIAIgASALcTYC1AQgAiABIAxxNgLQBCACIAEgDXE2AswEIAIgASAOcTYCyAQgAiABIAVxNgLEBCACIAZBACADa3I2AsAEIAIgIyAjQQAgGEEAICVBAXFrIgMgGEEAIBhrc3Fza3MgAXFzIhg2AoADIAIgDyAPQQAgFyAXQQAgF2tzIANxc2tzIAFxcyIXNgKEAyACICEgIUEAIBYgFkEAIBZrcyADcXNrcyABcXMiFjYCiAMgAiAgICBBACAVIBVBACAVa3MgA3Fza3MgAXFzIhU2AowDIAIgHyAfQQAgFCAUQQAgFGtzIANxc2tzIAFxcyIUNgKQAyACIB4gHkEAIBMgE0EAIBNrcyADcXNrcyABcXMiEzYClAMgAiAdIB1BACASIBJBACASa3MgA3Fza3MgAXFzIhI2ApgDIAIgHCAcQQAgESARQQAgEWtzIANxc2tzIAFxcyIRNgKcAyACIBsgG0EAIBAgEEEAIBBrcyADcXNrcyABcXMiEDYCoAMgAiAaIBpBACAEIARBACAEa3MgA3Fza3MgAXFzIgE2AqQDIAIgBzYCtAQgAiAINgKwBCACIAk2AqwEIAIgCjYCqAQgAiALNgKkBCACIAw2AqAEIAIgDTYCnAQgAiAONgKYBCACIAU2ApQEIAIgBkEBazYCkAQgAkGQBGoiDyAPICQQBSAPIA9B8IkCEAUgAigCwAEhAyACKAKQBCEHIAIoAsQBIQggAigClAQhCSACKALIASEKIAIoApgEIQsgAigCzAEhDCACKAKcBCENIAIoAtABIQ4gAigCoAQhBSACKALUASEGIAIoAqQEIQQgAigC2AEhGiACKAKoBCEbIAIoAtwBIRwgAigCrAQhHSACKALgASEeIAIoArAEIR8gAigC5AEhICACKAK0BCEhIAIgAUEBdDYCtAEgAiAQQQF0NgKwASACIBFBAXQ2AqwBIAIgEkEBdDYCqAEgAiATQQF0NgKkASACIBRBAXQ2AqABIAIgFUEBdDYCnAEgAiAWQQF0NgKYASACIBdBAXQ2ApQBIAIgGEEBdDYCkAEgAiAhICBrNgK0BCACIB8gHms2ArAEIAIgHSAcazYCrAQgAiAbIBprNgKoBCACIAQgBms2AqQEIAIgBSAOazYCoAQgAiANIAxrNgKcBCACIAsgCms2ApgEIAIgCSAIazYClAQgAiAHIANrNgKQBCACQZABaiIFIAUgGRAFIAJB4ABqIgYgD0GgigIQBSACQaACaiAiEAQgAkEAIAIoAsQCIgFrNgJUIAJBACACKALAAiIDazYCUCACQQAgAigCvAIiB2s2AkwgAkEAIAIoArgCIghrNgJIIAJBACACKAK0AiIJazYCRCACQQAgAigCsAIiCms2AkAgAkEAIAIoAqwCIgtrNgI8IAJBACACKAKoAiIMazYCOCACQQAgAigCpAIiDWs2AjQgAkEBIAIoAqACIg5rNgIwIAIgATYCJCACIAM2AiAgAiAHNgIcIAIgCDYCGCACIAk2AhQgAiAKNgIQIAIgCzYCDCACIAw2AgggAiANNgIEIAIgDkEBajYCACAAIAUgAhAFIABBKGogAkEwaiIBIAYQBSAAQdAAaiAGIAIQBSAAQfgAaiAFIAEQBSACQfAEaiQAC6gBAQR/IwBBgAdrIgIkACACQdAGaiIDIAEQNSACQaAGaiIEIAFBIGoQNSACQcACaiIBIAMQpAEgAkGgAWoiAyAEEKQBIAJBgAVqIgQgAxAOIAJB4ANqIgMgASAEEBIgAiADIAJB2ARqIgEQBSACQShqIAJBiARqIgQgAkGwBGoiBRAFIAJB0ABqIAUgARAFIAJB+ABqIAMgBBAFIAAgAhBVIAJBgAdqJAALzhkCIH8MfiMAQcAHayIEJAAgBEGwAmoiAyABEK0BIAQgBCgCsAJBAWo2ArACIAMgAxBFQQAhASAEQQAgBDQC1AJChtodfiInICdCgICACHwiJ0KAgIDwD4N9IAQ0AtACQobaHX4gBDQCzAJChtodfiIjQoCAgAh8IiZCGYd8IiRCgICAEHwiJUIaiHynIgZrIgc2AqQCIARBACAkICVCgICA4A+DfaciCGsiCTYCoAIgBEEAICMgJkKAgIDwD4N9IAQ0AsgCQobaHX4gBDQCxAJChtodfiIjQoCAgAh8IiZCGYd8IiRCgICAEHwiJUIaiHynIgprIgs2ApwCIARBACAkICVCgICA4A+DfaciDGsiDTYCmAIgBEEAICMgJkKAgIDwD4N9IAQ0AsACQobaHX4gBDQCvAJChtodfiIjQoCAgAh8IiZCGYd8IiRCgICAEHwiJUIaiHynIg5rIhA2ApQCIARBACAkICVCgICA4A+DfaciEWsiEjYCkAIgBEEAICMgJkKAgIDwD4N9IAQ0ArgCQobaHX4gBDQCtAJChtodfiIjQoCAgAh8IiZCGYd8IiRCgICAEHwiJUIaiHynIhNrIhQ2AowCIARBACAkICVCgICA4A+DfaciFWsiFjYCiAIgBEEAICMgJkKAgIDwD4N9ICdCGYdCE34gBDQCsAJChtodfnwiJ0KAgIAQfCIjQhqIfKciF2siGDYChAIgBEEAICcgI0KAgIDgD4N9pyIZayIaNgKAAiAEQdABaiIDIARBgAJqIgUQBCAEQaABaiAFIAMQBSAEKALEASEDIAQoAqABIQUgBDQC0AEhJyAEKAKkASEPIAQoAqgBIRsgBDQC1AEhIyAENALYASEmIAQoAqwBIRwgBCgCsAEhHSAENALcASEkIAQ0AuABISUgBCgCtAEhHiAEKAK4ASEfIAQ0AuQBISggBDQC6AEhKSAEKAK8ASEgIAQoAsABISEgBCAENAL0AUKG2h1+IiogKkKAgIAIfCIqQoCAgPAPg30gBDQC8AFChtodfiAENALsAUKG2h1+IitCgICACHwiLEIZh3wiLUKAgIAQfCIuQhqIfKciIjYC9AEgBCADIAZrICJqNgKEAyAEIC0gLkKAgIDgD4N9pyIDNgLwASAEICEgCGsgA2o2AoADIAQgKyAsQoCAgPAPg30gKUKG2h1+IChChtodfiIoQoCAgAh8IilCGYd8IitCgICAEHwiLEIaiHynIgM2AuwBIAQgICAKayADajYC/AIgBCArICxCgICA4A+DfaciAzYC6AEgBCAfIAxrIANqNgL4AiAEICggKUKAgIDwD4N9ICVChtodfiAkQobaHX4iJEKAgIAIfCIlQhmHfCIoQoCAgBB8IilCGoh8pyIDNgLkASAEIB4gDmsgA2o2AvQCIAQgKCApQoCAgOAPg32nIgM2AuABIAQgHSARayADajYC8AIgBCAkICVCgICA8A+DfSAmQobaHX4gI0KG2h1+IiNCgICACHwiJkIZh3wiJEKAgIAQfCIlQhqIfKciAzYC3AEgBCAcIBNrIANqNgLsAiAEICQgJUKAgIDgD4N9pyIDNgLYASAEIBsgFWsgA2o2AugCIAQgIyAmQoCAgPAPg30gKkIZh0ITfiAnQobaHX58IidCgICAEHwiI0IaiHynIgM2AtQBIAQgDyAXayADajYC5AIgBCAnICNCgICA4A+DfaciAzYC0AEgBCAFIBlrIANqNgLgAiAEQfAEaiIFIARB4AJqIgMgAxAFIAQgAyAFEAUgBEGQBmoiAyAEEAQgAyADEAQgBEGQB2oiDyAEIAMQBSAEQcAEaiIFIA8QBCAFIAUQBCAFIAUQBCAFIAUQBCAEQZAEaiIDIA8gBRAFIAMgAxAEIAMgAxAEIAMgAyAEEAUgBCAEKQOwBDcDgAQgBCAEKQOoBDcD+AMgBCAEKQOgBDcD8AMgBCAEKQOYBDcD6AMgBCAEKQOQBDcD4AMgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADIARB4ANqIgUQBSADIAMQBCADIAMQBCADIAMQBCADIAMQBCADIAMQBCADIAMQBCADIAMQBCADIAMQBCADIAMQBCADIAMQBCADIAMgBRAFIAQgBCkDsAQ3A9ADIAQgBCkDqAQ3A8gDIAQgBCkDoAQ3A8ADIAQgBCkDmAQ3A7gDIAQgBCkDkAQ3A7ADIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAxAEIAMgAyAEQbADaiIFEAUgBCAEKQOwBDcD0AMgBCAEKQOoBDcDyAMgBCAEKQOgBDcDwAMgBCAEKQOYBDcDuAMgBCAEKQOQBDcDsAMgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADIAUQBSAEIAQpA7AENwPQAyAEIAQpA6gENwPIAyAEIAQpA6AENwPAAyAEIAQpA5gENwO4AyAEIAQpA5AENwOwAwNAIARBkARqIgMgAxAEIAFBAWoiAUH4AEcNAAsgAyADIARBsANqEAUgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADEAQgAyADIARB4ANqEAUgAyADEAQgAyADEAQgAyADEAQgAyADIAQQBSADIAMQBCAEQZADaiADEA8gBEEAIAQtAJEDQQFxayIBIAYgB3NxIAdzIgY2ApQFIAQgCCAJcyABcSAJcyIHNgKQBSAEIAogC3MgAXEgC3MiCDYCjAUgBCAMIA1zIAFxIA1zIgk2AogFIAQgDiAQcyABcSAQcyIKNgKEBSAEIBEgEnMgAXEgEnMiCzYCgAUgBCATIBRzIAFxIBRzIgw2AvwEIAQgFSAWcyABcSAWcyINNgL4BCAEIBcgGHMgAXEgGHMiDjYC9AQgBCAZIBpzIAFxIBpzIAFBhtodcWsiAUEBajYC8AQgBCAGNgK0BiAEIAc2ArAGIAQgCDYCrAYgBCAJNgKoBiAEIAo2AqQGIAQgCzYCoAYgBCAMNgKcBiAEIA02ApgGIAQgDjYClAYgBCABQQFrNgKQBiAEIARB8ARqEEUgBEGQB2oiASAEQZAGaiAEEAUgACABEA8gACAALQAfIAJyOgAfIAQgABBEBEAQqgEACyAEIAQpAiA3A7AGIAQgBCkCGDcDqAYgBCAEKQIQNwOgBiAEIAQpAgg3A5gGIAQgBCkCADcDkAYgBCAEKQIoNwO4BiAEIAQpAjA3A8AGIAQgBCkCODcDyAYgBCAEKQJANwPQBiAEIAQpAkg3A9gGIAQgBCkCcDcDgAcgBCAEKQJoNwP4BiAEIAQpAmA3A/AGIAQgBCkCWDcD6AYgBCAEKQJQNwPgBiAEQfAEaiIDIARBkAZqIgUQHCAFIAMgBEHoBWoiARAFIARBuAZqIgcgBEGYBWoiBiAEQcAFaiICEAUgBEHgBmoiCCACIAEQBSADIAUQHCAFIAMgARAFIAcgBiACEAUgCCACIAEQBSADIAUQHCAEIAMgARAFIARBKGoiByAGIAIQBSAEQdAAaiIIIAIgARAFIARB+ABqIAMgBhAFIAMgCBBFIAUgBCADEAUgBEGQB2oiASAHIAMQBSAAIAEQDyAEQcAEaiAFEA8gACAALQAfIAQtAMAEQQd0czoAHyAEQcAHaiQAC18BAX8jAEEwayICJAAgACABKQAYNwAYIAAgASkAEDcAECAAIAEpAAg3AAggACABKQAANwAAIAAgAC0AHyIBQf8AcToAHyACIAAQNSAAIAIgAUGAAXEQpgEgAkEwaiQAC4ABAQh/QSAhAUEBIQIDQCAAIAFBAmsiBGotAAAiBSAEQfAWai0AACIGa0EIdSABQQFrIgFB8BZqLQAAIgcgACABai0AACIIc0EBa0EIdSACcSIBcSAIIAdrQQh1IAJxIANyciEDIAUgBnNBAWtBCHUgAXEhAiAEIgENAAsgA0EARwv4HwI2fgR/IAAgAjMAFSACMQAXQhCGQoCA/ACDhCIFIAEoABxBB3atIgR+IAEoABciOkEYdq0gATEAG0IIhoQgATEAHEIQhoRCAohC////AIMiBiACKAAXIjtBBXZB////AHGtIgd+fCABMwAVIAExABdCEIZCgID8AIOEIhAgAigAHEEHdq0iCH58IDtBGHatIAIxABtCCIaEIAIxABxCEIaEQgKIQv///wCDIgkgOkEFdkH///8Aca0iCn58IAcgCn4gAigADyI6QRh2rSACMQATQgiGhCACMQAUQhCGhEIDiCILIAR+fCAFIAZ+fCABKAAPIjtBGHatIAExABNCCIaEIAExABRCEIaEQgOIIgwgCH58IAkgEH58Ig1CgIBAfSIOQhWIfCIRQoCAQH0iEkIViCAIIAp+IAQgB358IAYgCX58Ig8gD0KAgEB9Ig9CgICA/////wCDfXwiIUKY2hx+IAQgCX4gBiAIfnwgD0IViHwiDyAPQoCAQH0iHkKAgID/////AIN9IiJCk9gofnwgESASQoCAgH+DfSIjQuf2J358IA0gDkKAgIB/g30gBiALfiA6QQZ2Qf///wBxrSINIAR+fCAHIBB+fCAFIAp+fCAIIDtBBnZB////AHGtIg5+fCAJIAx+fCACKAAKIjpBGHatIAIxAA5CCIaEIAIxAA9CEIaEQgGIQv///wCDIhEgBH4gBiANfnwgCiALfnwgByAMfnwgBSAQfnwgASgACiI7QRh2rSABMQAOQgiGhCABMQAPQhCGhEIBiEL///8AgyISIAh+fCAJIA5+fCIfQoCAQH0iHUIViHwiIEKAgEB9IhNCFYh8IiRC04xDfnwgAygAFyI8QQV2Qf///wBxrSACMwAAIAIxAAJCEIZCgID8AIOEIg8gCn4gECACKAACIj1BBXZB////AHGtIhR+fCACNQAHQgeIQv///wCDIhUgDn58IBIgOkEEdkH///8Aca0iFn58ID1BGHatIAIxAAZCCIaEIAIxAAdCEIaEQgKIQv///wCDIhcgDH58IA0gATUAB0IHiEL///8AgyIYfnwgESA7QQR2Qf///wBxrSIZfnwgCyABKAACIgJBGHatIAExAAZCCIaEIAExAAdCEIaEQgKIQv///wCDIhp+fCABMwAAIAExAAJCEIZCgID8AIOEIhsgB358IAUgAkEFdkH///8Aca0iHH58fCADMwAVIA8gEH4gDCAUfnwgEiAVfnwgFiAZfnwgDiAXfnwgDSAafnwgESAYfnwgCyAcfnwgBSAbfnx8IAMxABdCEIZCgID8AIN8IiVCgIBAfSImQhWIfCInfCAnQoCAQH0iJ0KAgIB/g30gJSAjQpjaHH4gIUKT2Ch+fCAkQuf2J358IAwgD34gDiAUfnwgFSAZfnwgFiAYfnwgEiAXfnwgDSAcfnwgESAafnwgCyAbfnwgAygADyIBQRh2rSADMQATQgiGhCADMQAUQhCGhEIDiHwgAUEGdkH///8Aca0gDiAPfiASIBR+fCAVIBh+fCAWIBp+fCAXIBl+fCANIBt+fCARIBx+fHwiJUKAgEB9IilCFYh8IipCgIBAfSIrQhWIfHwgJkKAgIB/g30iJkKAgEB9IixCFYd8Ii1CgIBAfSIuQhWHICAgE0KAgIB/g30gHyAEIAh+IhNCgIBAfSIvQhWIIiBCg6FWfnwgHUKAgIB/g30gCiANfiAEIBZ+fCAGIBF+fCALIBB+fCAHIA5+fCAFIAx+fCAIIBl+fCAJIBJ+fCAGIBZ+IAQgFX58IA0gEH58IAogEX58IAsgDH58IAcgEn58IAUgDn58IAggGH58IAkgGX58Ih1CgIBAfSIwQhWIfCIxQoCAQH0iMkIViHwiM0KAgEB9IjRCFYd8Ih9Cg6FWfnwgBiAPfiAKIBR+fCAMIBV+fCAOIBZ+fCAQIBd+fCANIBl+fCARIBJ+fCALIBh+fCAHIBx+fCAFIBp+fCAJIBt+fCA8QRh2rSADMQAbQgiGhCADMQAcQhCGhEICiEL///8Ag3wiKCAiQpjaHH4gEyAvQoCAgP////8Dg30gHkIViHwiHkKT2Ch+fCAhQuf2J358ICNC04xDfnwgJELRqwh+fCAnQhWIfHwgKEKAgEB9IidCgICAf4N9IhN8IBNCgIBAfSIvQoCAgH+DfSIoIC0gMyA0QoCAgH+DfSAeQoOhVn4gIELRqwh+fCAxfCAyQoCAgH+DfSAdICBC04xDfnwgHkLRqwh+fCAiQoOhVn58IDBCgICAf4N9IAogFn4gBiAVfnwgBCAXfnwgDCANfnwgECARfnwgCyAOfnwgByAZfnwgBSASfnwgCCAafnwgCSAYfnwgCiAVfiAEIBR+fCAQIBZ+fCAGIBd+fCANIA5+fCAMIBF+fCALIBJ+fCAHIBh+fCAFIBl+fCAIIBx+fCAJIBp+fCItQoCAQH0iMEIViHwiMUKAgEB9IjJCFYh8IjNCgIBAfSI0QhWHfCITQoCAQH0iNUIVh3wiHUKDoVZ+IB9C0asIfnx8IC5CgICAf4N9ICYgHULRqwh+IB9C04xDfnwgEyA1QoCAgH+DfSITQoOhVn58ICRCmNocfiAjQpPYKH58ICp8ICUgJEKT2Ch+fCApQoCAgH+DfSAPIBJ+IBQgGX58IBUgGn58IBYgHH58IBcgGH58IBEgG358IAMoAAoiAUEYdq0gAzEADkIIhoQgAzEAD0IQhoRCAYhC////AIN8IAFBBHZB////AHGtIA8gGX4gFCAYfnwgFSAcfnwgFiAbfnwgFyAafnx8IiVCgIBAfSImQhWIfCIpQoCAQH0iKkIViHwiLkKAgEB9IjVCFYd8ICtCgICAf4N9IitCgIBAfSI2QhWHfHwgLEKAgIB/g30iLEKAgEB9IjdCFYd8IjhCgIBAfSI5QhWHfCAoQoCAQH0iKEKAgIB/g30gOCA5QoCAgH+DfSAsIDdCgICAf4N9IB1C04xDfiAfQuf2J358IBNC0asIfnwgK3wgNkKAgIB/g30gMyA0QoCAgH+DfSAeQtOMQ34gIELn9id+fCAiQtGrCH58ICFCg6FWfnwgMXwgMkKAgIB/g30gHkLn9id+ICBCmNocfnwgIkLTjEN+fCAtfCAhQtGrCH58ICNCg6FWfnwgMEKAgIB/g30gAygAHEEHdq0gBCAPfiAGIBR+fCAQIBV+fCAMIBZ+fCAKIBd+fCANIBJ+fCAOIBF+fCALIBl+fCAHIBp+fCAFIBh+fCAIIBt+fCAJIBx+fHwgJ0IViHwiBkKAgEB9IgdCFYh8IhBCgIBAfSIIQhWHfCIEQoCAQH0iCUIVh3wiBUKDoVZ+fCAuIB9CmNocfnwgNUKAgIB/g30gHULn9id+fCATQtOMQ358IAVC0asIfnwgBCAJQoCAgH+DfSIEQoOhVn58IglCgIBAfSIKQhWHfCILQoCAQH0iDEIVh3wgCyAMQoCAgH+DfSAJIApCgICAf4N9IB9Ck9gofiApfCAqQoCAgH+DfSAdQpjaHH58IBNC5/YnfnwgECAIQoCAgH+DfSAeQpjaHH4gIEKT2Ch+fCAiQuf2J358ICFC04xDfnwgI0LRqwh+fCAkQoOhVn58IAZ8IAdCgICAf4N9IC9CFYd8IgdCgIBAfSIQQhWHfCIGQoOhVn58IAVC04xDfnwgBELRqwh+fCAlICZCgICAf4N9IA8gGH4gFCAafnwgFSAbfnwgFyAcfnwgAzUAB0IHiEL///8Ag3wgDyAafiAUIBx+fCAXIBt+fCADKAACIgFBGHatIAMxAAZCCIaEIAMxAAdCEIaEQgKIQv///wCDfCIIQoCAQH0iCUIViHwiCkKAgEB9IgtCFYh8IB1Ck9gofnwgE0KY2hx+fCAGQtGrCH58IAVC5/YnfnwgBELTjEN+fCIMQoCAQH0iDUIVh3wiDkKAgEB9IhFCFYd8IA4gByAQQoCAgH+DfSAoQhWHfCIQQoCAQH0iEkIVhyIHQoOhVn58IBFCgICAf4N9IAwgB0LRqwh+fCANQoCAgH+DfSAKIAtCgICAf4N9IBNCk9gofnwgBkLTjEN+fCAFQpjaHH58IARC5/YnfnwgCCABQQV2Qf///wBxrSAPIBx+IBQgG358fCAPIBt+IAMzAAAgAzEAAkIQhkKAgPwAg4R8IgpCgIBAfSILQhWIfCIMQoCAQH0iDUIViHwgCUKAgIB/g30gBkLn9id+fCAFQpPYKH58IARCmNocfnwiBUKAgEB9IghCFYd8IglCgIBAfSIOQhWHfCAJIAdC04xDfnwgDkKAgIB/g30gBSAHQuf2J358IAhCgICAf4N9IAwgDUKAgIB/g30gBkKY2hx+fCAEQpPYKH58IAogC0KAgID///8Dg30gBkKT2Ch+fCIFQoCAQH0iBEIVh3wiBkKAgEB9IghCFYd8IAYgB0KY2hx+fCAIQoCAgH+DfSAFIARCgICAf4N9IAdCk9gofnwiBEIVh3wiCEIVh3wiCUIVh3wiCkIVh3wiC0IVh3wiDEIVh3wiDUIVh3wiDkIVh3wiEUIVh3wiD0IVh3wiFEIVhyAQIBJCgICAf4N9fCIHQhWHIgVCk9gofiAEQv///wCDfCIGPAAAIAAgBkIIiDwAASAAIAVCmNocfiAIQv///wCDfCAGQhWHfCIEQguIPAAEIAAgBEIDiDwAAyAAIAZCEIhCH4MgBEIFhoQ8AAIgACAFQuf2J34gCUL///8Ag3wgBEIVh3wiBkIGiDwABiAAIAZCAoYgBEKAgOAAg0ITiIQ8AAUgACAFQtOMQ34gCkL///8Ag3wgBkIVh3wiBEIJiDwACSAAIARCAYg8AAggACAEQgeGIAZCgID/AINCDoiEPAAHIAAgBULRqwh+IAtC////AIN8IARCFYd8IgZCDIg8AAwgACAGQgSIPAALIAAgBkIEhiAEQoCA+ACDQhGIhDwACiAAIAVCg6FWfiAMQv///wCDfCAGQhWHfCIEQgeIPAAOIAAgBEIBhiAGQoCAwACDQhSIhDwADSAAIA1C////AIMgBEIVh3wiBUIKiDwAESAAIAVCAog8ABAgACAFQgaGIARCgID+AINCD4iEPAAPIAAgDkL///8AgyAFQhWHfCIEQg2IPAAUIAAgBEIFiDwAEyAAIBFC////AIMgBEIVh3wiBjwAFSAAIARCA4YgBUKAgPAAg0ISiIQ8ABIgACAGQgiIPAAWIAAgD0L///8AgyAGQhWHfCIFQguIPAAZIAAgBUIDiDwAGCAAIAZCEIhCH4MgBUIFhoQ8ABcgACAUQv///wCDIAVCFYd8IgRCBog8ABsgACAEQgKGIAVCgIDgAINCE4iEPAAaIAAgBEIVhyIGIAdC////AIN8IgVCEYg8AB8gACAFQgmIPAAeIAAgBUIHhiAEQoCA/wCDQg6IhDwAHCAAIAanIAenakEBdq08AB0LBQAQAgALtQUBCX8jAEGAAWsiAyQAQdLIAi0AACEEIABCADcCBCAAQQE2AgAgAEIANwIMIABCADcCFCAAQgA3AhwgAEKAgICAEDcCJCAAQSxqQQBBzAD8CwAgACABQcAHbEHAF2oiAUHSyAItAABBAnYgAiACQQAgBEECdiACQYABcUEHdnMiBGtxQQF0ayICQQFzQf8BcUEBa0EfdnMQMyAAIAFB+ABqQdLIAi0AAEECdiACQQJzQf8BcUEBa0EfdnMQMyAAIAFB8AFqQdLIAi0AAEECdiACQQNzQf8BcUEBa0EfdnMQMyAAIAFB6AJqQdLIAi0AAEECdiACQQRzQf8BcUEBa0EfdnMQMyAAIAFB4ANqQdLIAi0AAEECdiACQQVzQf8BcUEBa0EfdnMQMyAAIAFB2ARqQdLIAi0AAEECdiACQQZzQf8BcUEBa0EfdnMQMyAAIAFB0AVqQdLIAi0AAEECdiACQQdzQf8BcUEBa0EfdnMQMyAAIAFByAZqQdLIAi0AAEECdiACQQhzQf8BcUEBa0EfdnMQMyADIAApAkg3AyggAyAAQUBrKQIANwMgIAMgACkCODcDGCADIAApAjA3AxAgAyAAKQIoNwMIIAMgACkCADcDMCADIAApAgg3AzggAyAAKQIQNwNAIAMgACkCGDcDSCADIAApAiA3A1AgACgCUCEBIAAoAlQhAiAAKAJYIQUgACgCXCEGIAAoAmAhByAAKAJkIQggACgCaCEJIAAoAmwhCiAAKAJwIQsgA0EAIAAoAnRrNgJ8IANBACALazYCeCADQQAgCms2AnQgA0EAIAlrNgJwIANBACAIazYCbCADQQAgB2s2AmggA0EAIAZrNgJkIANBACAFazYCYCADQQAgAms2AlwgA0EAIAFrNgJYIAAgA0EIaiAEEDMgA0GAAWokAAuSBgEJfyMAQaABayIDJABB0sgCLQAAIQQgAEIANwIEIABBATYCACAAQgA3AgwgAEIANwIUIABCADcCHCAAQgA3AiwgAEKAgICAEDcCJCAAQgA3AjQgAEIANwI8IABCADcCRCAAQoCAgIAQNwJMIABB1ABqQQBBzAD8CwAgACABQdLIAi0AAEECdiACIAJBACAEQQJ2IAJBgAFxQQd2cyIEa3FBAXRrIgJBAXNB/wFxQQFrQR92cxA0IAAgAUGgAWpB0sgCLQAAQQJ2IAJBAnNB/wFxQQFrQR92cxA0IAAgAUHAAmpB0sgCLQAAQQJ2IAJBA3NB/wFxQQFrQR92cxA0IAAgAUHgA2pB0sgCLQAAQQJ2IAJBBHNB/wFxQQFrQR92cxA0IAAgAUGABWpB0sgCLQAAQQJ2IAJBBXNB/wFxQQFrQR92cxA0IAAgAUGgBmpB0sgCLQAAQQJ2IAJBBnNB/wFxQQFrQR92cxA0IAAgAUHAB2pB0sgCLQAAQQJ2IAJBB3NB/wFxQQFrQR92cxA0IAAgAUHgCGpB0sgCLQAAQQJ2IAJBCHNB/wFxQQFrQR92cxA0IAMgACkCSDcDICADIABBQGspAgA3AxggAyAAKQI4NwMQIAMgACkCMDcDCCADIAApAig3AwAgAyAAKQIgNwNIIAMgACkCGDcDQCADIAApAhA3AzggAyAAKQIINwMwIAMgACkCADcDKCADIAApAlg3A1ggAyAAKQJQNwNQIAMgACkCYDcDYCADIAApAmg3A2ggAyAAKQJwNwNwIAAoAnghASAAKAJ8IQIgACgCgAEhBSAAKAKEASEGIAAoAogBIQcgACgCjAEhCCAAKAKQASEJIAAoApQBIQogACgCmAEhCyADQQAgACgCnAFrNgKcASADQQAgC2s2ApgBIANBACAKazYClAEgA0EAIAlrNgKQASADQQAgCGs2AowBIANBACAHazYCiAEgA0EAIAZrNgKEASADQQAgBWs2AoABIANBACACazYCfCADQQAgAWs2AnggACADIAQQNCADQaABaiQAC+kGAhx+CX8gACABKAIMIiBBAXSsIgggASgCBCIhQQF0rCICfiABKAIIIiKsIg0gDX58IAEoAhAiI6wiByABKAIAIiRBAXSsIgV+fCABKAIcIh5BJmysIg4gHqwiEX58IAEoAiAiJUETbKwiAyABKAIYIh9BAXSsfnwgASgCJCImQSZsrCIEIAEoAhQiAUEBdKwiCX58QgGGIhVCgICAEHwiFkIahyACIAd+ICJBAXSsIgsgIKwiEn58IAGsIg8gBX58IAMgHkEBdKwiE358IAQgH6wiCn58QgGGfCIXQoCAgAh8IhhCGYcgCCASfiAHIAt+fCACIAl+fCAFIAp+fCADICWsIhB+fCAEIBN+fEIBhnwiBiAGQoCAgBB8IgxCgICA4A+DfT4CGCAAIAFBJmysIA9+ICSsIgYgBn58IB9BE2ysIgYgI0EBdKwiFH58IAggDn58IAMgC358IAIgBH58QgGGIhlCgICAEHwiGkIahyAGIAl+IAUgIawiG358IAcgDn58IAMgCH58IAQgDX58QgGGfCIcQoCAgAh8Ih1CGYcgBSANfiACIBt+fCAGIAp+fCAJIA5+fCADIBR+fCAEIAh+fEIBhnwiBiAGQoCAgBB8IgZCgICA4A+DfT4CCCAAIAsgD34gByAIfnwgAiAKfnwgBSARfnwgBCAQfnxCAYYgDEIah3wiDCAMQoCAgAh8IgxCgICA8A+DfT4CHCAAIAUgEn4gAiANfnwgCiAOfnwgAyAJfnwgBCAHfnxCAYYgBkIah3wiAyADQoCAgAh8IgNCgICA8A+DfT4CDCAAIAogC34gByAHfnwgCCAJfnwgAiATfnwgBSAQfnwgBCAmrCIHfnxCAYYgDEIZh3wiBCAEQoCAgBB8IgRCgICA4A+DfT4CICAAIBcgGEKAgIDwD4N9IBUgFkKAgIBgg30gA0IZh3wiA0KAgIAQfCIJQhqIfD4CFCAAIAMgCUKAgIDgD4N9PgIQIAAgCCAKfiAPIBR+fCALIBF+fCACIBB+fCAFIAd+fEIBhiAEQhqHfCICIAJCgICACHwiAkKAgIDwD4N9PgIkIAAgHCAdQoCAgPAPg30gGSAaQoCAgGCDfSACQhmHQhN+fCICQoCAgBB8IgVCGoh8PgIEIAAgAiAFQoCAgOAPg30+AgALrQsBB38gACABaiEFAkACQCAAKAIEIgJBAXENACACQQJxRQ0BIAAoAgAiAiABaiEBAkACQAJAIAAgAmsiAEHYxAIoAgBHBEAgACgCDCEDIAJB/wFNBEAgAyAAKAIIIgRHDQJBxMQCQcTEAigCAEF+IAJBA3Z3cTYCAAwFCyAAKAIYIQYgACADRwRAIAAoAggiAiADNgIMIAMgAjYCCAwECyAAKAIUIgQEfyAAQRRqBSAAKAIQIgRFDQMgAEEQagshAgNAIAIhByAEIgNBFGohAiADKAIUIgQNACADQRBqIQIgAygCECIEDQALIAdBADYCAAwDCyAFKAIEIgJBA3FBA0cNA0HMxAIgATYCACAFIAJBfnE2AgQgACABQQFyNgIEIAUgATYCAA8LIAQgAzYCDCADIAQ2AggMAgtBACEDCyAGRQ0AAkAgACgCHCICQQJ0IgQoAvTGAiAARgRAIARB9MYCaiADNgIAIAMNAUHIxAJByMQCKAIAQX4gAndxNgIADAILAkAgACAGKAIQRgRAIAYgAzYCEAwBCyAGIAM2AhQLIANFDQELIAMgBjYCGCAAKAIQIgIEQCADIAI2AhAgAiADNgIYCyAAKAIUIgJFDQAgAyACNgIUIAIgAzYCGAsCQAJAAkACQCAFKAIEIgJBAnFFBEBB3MQCKAIAIAVGBEBB3MQCIAA2AgBB0MQCQdDEAigCACABaiIBNgIAIAAgAUEBcjYCBCAAQdjEAigCAEcNBkHMxAJBADYCAEHYxAJBADYCAA8LQdjEAigCACIIIAVGBEBB2MQCIAA2AgBBzMQCQczEAigCACABaiIBNgIAIAAgAUEBcjYCBCAAIAFqIAE2AgAPCyACQXhxIAFqIQEgBSgCDCEDIAJB/wFNBEAgBSgCCCIEIANGBEBBxMQCQcTEAigCAEF+IAJBA3Z3cTYCAAwFCyAEIAM2AgwgAyAENgIIDAQLIAUoAhghBiADIAVHBEAgBSgCCCICIAM2AgwgAyACNgIIDAMLIAUoAhQiBAR/IAVBFGoFIAUoAhAiBEUNAiAFQRBqCyECA0AgAiEHIAQiA0EUaiECIAMoAhQiBA0AIANBEGohAiADKAIQIgQNAAsgB0EANgIADAILIAUgAkF+cTYCBCAAIAFBAXI2AgQgACABaiABNgIADAMLQQAhAwsgBkUNAAJAIAUoAhwiAkECdCIEKAL0xgIgBUYEQCAEQfTGAmogAzYCACADDQFByMQCQcjEAigCAEF+IAJ3cTYCAAwCCwJAIAUgBigCEEYEQCAGIAM2AhAMAQsgBiADNgIUCyADRQ0BCyADIAY2AhggBSgCECICBEAgAyACNgIQIAIgAzYCGAsgBSgCFCICRQ0AIAMgAjYCFCACIAM2AhgLIAAgAUEBcjYCBCAAIAFqIAE2AgAgACAIRw0AQczEAiABNgIADwsgAUH/AU0EQCABQfgBcUHsxAJqIQICf0HExAIoAgAiA0EBIAFBA3Z0IgFxRQRAQcTEAiABIANyNgIAIAIMAQsgAigCCAshASACIAA2AgggASAANgIMIAAgAjYCDCAAIAE2AggPC0EfIQMgAUH///8HTQRAIAFBJiABQQh2ZyICa3ZBAXEgAkEBdHJBPnMhAwsgACADNgIcIABCADcCECADQQJ0QfTGAmohAgJAAkBByMQCKAIAIgRBASADdCIHcUUEQEHIxAIgBCAHcjYCACACIAA2AgAgACACNgIYDAELIAFBGSADQQF2a0EAIANBH0cbdCEDIAIoAgAhAgNAIAIiBCgCBEF4cSABRg0CIANBHXYhAiADQQF0IQMgBCACQQRxaiIHKAIQIgINAAsgByAANgIQIAAgBDYCGAsgACAANgIMIAAgADYCCA8LIAQoAggiASAANgIMIAQgADYCCCAAQQA2AhggACAENgIMIAAgATYCCAsLLQEBfiACrSADrUIghoQiBkIQWgR/IAAgAUEQaiABIAZCEH0gBCAFEGwFQX8LCxgAIAAgASACIAOtIAStQiCGhCAFIAYQbAsYACAAIAEgAiADrSAErUIghoQgBSAGEFgLFwAgACABIAKtIAOtQiCGhCAEIAUQjgELFQAgACABrSACrUIghoQgAyAEEOYBCxcAIAAgASACrSADrUIghoQgBEEAEJgBCxcAIAAgASACIAOtIAStQiCGhCAFEOADCxcAIAAgASACIAOtIAStQiCGhCAFEN4DCxcAIAAgASACIAOtIAStQiCGhCAFEN8DCxUAIAAgASACrSADrUIghoQgBBChAwv+AgEGfyABQYB/SwRAQTAPCwJ/IAFBgH9PBEBBwMQCQTA2AgBBAAwBC0EAQRAgAUELakF4cSABQQtJGyIFQcwAahAjIgFFDQAaIAFBCGshAgJAIAFBP3FFBEAgAiEBDAELIAFBBGsiBigCACIHQXhxIAFBP2pBQHFBCGsiAUHAAEEAIAEgAmtBD00baiIBIAJrIgNrIQQgB0EDcUUEQCACKAIAIQIgASAENgIEIAEgAiADajYCAAwBCyABIAQgASgCBEEBcXJBAnI2AgQgASAEaiIEIAQoAgRBAXI2AgQgBiADIAYoAgBBAXFyQQJyNgIAIAIgA2oiBCAEKAIEQQFyNgIEIAIgAxCuAQsCQCABKAIEIgJBA3FFDQAgAkF4cSIDIAVBEGpNDQAgASAFIAJBAXFyQQJyNgIEIAEgBWoiAiADIAVrIgVBA3I2AgQgASADaiIDIAMoAgRBAXI2AgQgAiAFEK4BCyABQQhqCyIBRQRAQTAPCyAAIAE2AgBBAAsfACAAIAEgAq0gA61CIIaEIAStIAWtQiCGhCAGEOsBCxoAIAAgASACrSADrUIghoRBsL0CKAIAEQIACxwAIAAgASACrSADrUIghoQgBEGovQIoAgAREgALHAAgACABIAKtIAOtQiCGhCAEQaS9AigCABESAAsXACAAIAEgAq0gA61CIIaEIAQgBRCiAwsSACAAIAEgAq0gA61CIIaEECoLEgAgACABIAKtIAOtQiCGhBBACxIAIAAgASACrSADrUIghoQQDQsYACAAIAEgAiADrSAErUIghoQgBSAGEHoLLQEBfiACrSADrUIghoQiBkIQWgR/IAAgAUEQaiABIAZCEH0gBCAFEGsFQX8LCxgAIAAgASACIAOtIAStQiCGhCAFIAYQawsYACAAIAEgAiADrSAErUIghoQgBSAGEFcLGQAgACABIAKtIAOtQiCGhCAEIAUgBhDBAwsZACAAIAEgAq0gA61CIIaEIAQgBSAGEMIDCxIAIAAgASACrSADrUIghoQQLwsVACAAIAEgAq0gA61CIIaEIAQQkwMLFQAgACABIAKtIAOtQiCGhCAEEJUDCxAAIAAgAUG0vQIoAgARAAALEAAgACABQay9AigCABEAAAvhAgECfyMAQZADayIIJAAgCEEANgIEIAhBEGoiCSAGIAdBABAfGiAIIAYpABA3AgggCEHQAGoiB0LAACAIQQRqIAkQQRogCEGQAWoiBiAHQay9AigCABEAABogB0HAABAHIAYgBCAFQbC9AigCABECABogBkGQvQJCACAFfUIPg0GwvQIoAgARAgAaIAYgASACQbC9AigCABECABogBkGQvQJCACACfUIPg0GwvQIoAgARAgAaIAggBTcDSCAGIAhByABqIgRCCEGwvQIoAgARAgAaIAggAjcDSCAGIARCCEGwvQIoAgARAgAaIAYgCEEwaiIEQbS9AigCABEAABogBkGAAhAHIAQgAxBHIQYgBEEQEAcCQCAARQ0AIAYEQCACpyIBBEAgAEEAIAH8CwALQX8hBgwBCyAAIAEgAiAIQQRqIAhBEGoQlgJBACEGCyAIQRBqQSAQByAIQZADaiQAIAYLrAIBA38jAEGAA2siCSQAIAlBADYCBCAJQRBqIgogByAIQQAQHxogCSAHKQAQNwIIIAlBQGsiCELAACAJQQRqIgsgChBBGiAJQYABaiIHIAhBrL0CKAIAEQAAGiAIQcAAEAcgByAFIAZBsL0CKAIAEQIAGiAHQZC9AkIAIAZ9Qg+DQbC9AigCABECABogACADIAQgCyAKEJYCIAcgACAEQbC9AigCABECABogB0GQvQJCACAEfUIPg0GwvQIoAgARAgAaIAkgBjcDOCAHIAlBOGoiAEIIQbC9AigCABECABogCSAENwM4IAcgAEIIQbC9AigCABECABogByABQbS9AigCABEAABogB0GAAhAHIAIEQCACQhA3AwALIAlBEGpBIBAHIAlBgANqJABBAAuBAgEFfyMAQRBrIgUkACAALQDkAUUEQCAFAn8CQAJAAkAgACgC4AEiA0GnAWsOAgABAgsgAC0A5QFBgH9zDAILIAAQJUEAIQMgAEEANgLgAQsgACAAQeUBaiADQQEQGEGAAQs6AA8gACAFQQ9qQacBQQEQGCAAECUgAEEBOgDkASAAQQA2AuABCyACBEAgACgC4AEhAwNAIANBqAFGBEAgABAlIABBADYC4AFBACEDC0GoASADayIEIAIgBmsiByAEIAdJGyIEBEAgASAGaiAAIANqIAT8CgAACyAAIAAoAuABIARqIgM2AuABIAQgBmoiBiACSQ0ACwsgBUEQaiQAQQALSgECfyMAQSBrIgYkAEF/IQcCQCACQhBUDQAgBiAEIAUQSw0AIAAgAUEQaiABIAJCEH0gAyAGEGshByAGQSAQBwsgBkEgaiQAIAcLTwECfyMAQSBrIgYkACACQvD///8PVARAQX8hByAGIAQgBRBLRQRAIABBEGogACABIAIgAyAGEFchByAGQSAQBwsgBkEgaiQAIAcPCxAMAAuZBwEHfyMAQdACayIDJAAgASgABCEEIAEoAAghBSABKAAMIQYgAigCBCEHIAIoAgghCCACKAIMIQkgACACKAIAIAEoAABzNgIAIAAgBiAJczYCDCAAIAUgCHM2AgggACAEIAdzNgIEIAMgACkCADcDsAIgAyAAKQIINwO4AiADIAIpAhA3A6ACIAMgAikCGDcDqAIgA0HAAmoiASADQbACaiADQaACahAGIAAgAykCyAI3AgggACADKQLAAjcCACADIAApAgA3A5ACIAMgACkCCDcDmAIgAyACKQIgNwOAAiADIAIpAig3A4gCIAEgA0GQAmogA0GAAmoQBiAAIAMpAsgCNwIIIAAgAykCwAI3AgAgAyAAKQIANwPwASADIAApAgg3A/gBIAMgAikCMDcD4AEgAyACKQI4NwPoASABIANB8AFqIANB4AFqEAYgACADKQLIAjcCCCAAIAMpAsACNwIAIAMgACkCADcD0AEgAyAAKQIINwPYASADIAJBQGspAgA3A8ABIAMgAikCSDcDyAEgASADQdABaiADQcABahAGIAAgAykCyAI3AgggACADKQLAAjcCACADIAApAgA3A7ABIAMgACkCCDcDuAEgAyACKQJQNwOgASADIAIpAlg3A6gBIAEgA0GwAWogA0GgAWoQBiAAIAMpAsgCNwIIIAAgAykCwAI3AgAgAyAAKQIANwOQASADIAApAgg3A5gBIAMgAikCYDcDgAEgAyACKQJoNwOIASABIANBkAFqIANBgAFqEAYgACADKQLIAjcCCCAAIAMpAsACNwIAIAMgACkCADcDcCADIAApAgg3A3ggAyACKQJwNwNgIAMgAikCeDcDaCABIANB8ABqIANB4ABqEAYgACADKQLIAjcCCCAAIAMpAsACNwIAIAMgACkCADcDUCADIAApAgg3A1ggAyACKQKAATcDQCADIAIpAogBNwNIIAEgA0HQAGogA0FAaxAGIAAgAykCyAI3AgggACADKQLAAjcCACADIAApAgA3AzAgAyAAKQIINwM4IAMgAikCkAE3AyAgAyACKQKYATcDKCABIANBMGogA0EgahAGIAAgAykCyAI3AgggACADKQLAAjcCACADIAApAgA3AxAgAyAAKQIINwMYIAMgAikCoAE3AwAgAyACKQKoATcDCCABIANBEGogAxBCIAAgAykCyAI3AgggACADKQLAAjcCACADQdACaiQAC+gEAQJ/IwBBoAFrIgQkACAAIAEtAAA6AAAgACABLQABOgABIAAgAS0AAjoAAiAAIAEtAAM6AAMgACABLQAEOgAEIAAgAS0ABToABSAAIAEtAAY6AAYgACABLQAHOgAHIAAgAS0ACDoACCAAIAEtAAk6AAkgACABLQAKOgAKIAAgAS0ACzoACyAAIAEtAAw6AAwgACABLQANOgANIAAgAS0ADjoADiAAIAEtAA86AA8gACABLQAQOgAQIAAgAS0AEToAESAAIAEtABI6ABIgACABLQATOgATIAAgAS0AFDoAFCAAIAEtABU6ABUgACABLQAWOgAWIAAgAS0AFzoAFyAAIAEtABg6ABggACABLQAZOgAZIAAgAS0AGjoAGiAAIAEtABs6ABsgACABLQAcOgAcIAAgAS0AHToAHSAAIAEtAB46AB4gAS0AHyEDIAAgAgR/IAAgAC0AAEH4AXE6AAAgA0HAAHIFIAMLQf8AcToAHyAEIAAQMCAAIAQQIkF/IQMgAC0AH0H/AHEgAC0AHiAALQAdIAAtABwgAC0AGyAALQAaIAAtABkgAC0AGCAALQAXIAAtABYgAC0AFSAALQAUIAAtABMgAC0AEiAALQARIAAtABAgAC0ADyAALQAOIAAtAA0gAC0ADCAALQALIAAtAAogAC0ACSAALQAIIAAtAAcgAC0ABiAALQAFIAAtAAQgAC0AAyAALQACIAAtAAEgAC0AAEEBc3JycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJBAWtBgAJxRQRAQX9BACABQSAQGxshAwsgBEGgAWokACADC5AFAQJ/IwBBwAJrIgQkAEF/IQUCQCACEIQBRQ0AIAIQQw0AIAQgAhBEDQAgBBCFAUUNACAAIAEtAAA6AAAgACABLQABOgABIAAgAS0AAjoAAiAAIAEtAAM6AAMgACABLQAEOgAEIAAgAS0ABToABSAAIAEtAAY6AAYgACABLQAHOgAHIAAgAS0ACDoACCAAIAEtAAk6AAkgACABLQAKOgAKIAAgAS0ACzoACyAAIAEtAAw6AAwgACABLQANOgANIAAgAS0ADjoADiAAIAEtAA86AA8gACABLQAQOgAQIAAgAS0AEToAESAAIAEtABI6ABIgACABLQATOgATIAAgAS0AFDoAFCAAIAEtABU6ABUgACABLQAWOgAWIAAgAS0AFzoAFyAAIAEtABg6ABggACABLQAZOgAZIAAgAS0AGjoAGiAAIAEtABs6ABsgACABLQAcOgAcIAAgAS0AHToAHSAAIAEtAB46AB4gAS0AHyECIAAgAwR/IAAgAC0AAEH4AXE6AAAgAkHAAHIFIAILQf8AcToAHyAEQaABaiICIAAgBBCGASAAIAIQIiAALQAfQf8AcSAALQAeIAAtAB0gAC0AHCAALQAbIAAtABogAC0AGSAALQAYIAAtABcgAC0AFiAALQAVIAAtABQgAC0AEyAALQASIAAtABEgAC0AECAALQAPIAAtAA4gAC0ADSAALQAMIAAtAAsgAC0ACiAALQAJIAAtAAggAC0AByAALQAGIAAtAAUgAC0ABCAALQADIAAtAAIgAC0AASAALQAAQQFzcnJycnJycnJycnJycnJycnJycnJycnJycnJycnJyckEBa0GAAnENAEF/QQAgAUEgEBsbIQULIARBwAJqJAAgBQsHAEGAgIAIC0kBA38jAEEQayILJABBfyEJIAtBBGoiCkIANwIAIApBADYCCEF/IAogACABIAIgAyAEIAUgBiAHIAgQ2QEgChBnGyALQRBqJAAL+gQBB38jAEEwayIHJAAgBARAIARB5gAQFgsCQCADLQAAQSRHDQAgAy0AAUE3Rw0AIAMtAAJBJEcNAEGACCADLQADQcEAEDEiCkUNACAHQQxqIANBBGoQZSIGRQ0AIAdBCGogBhBlIgZFDQACfwJ/AkAgBhAnQQFqIgVFDQADQCAGIAVBAWsiBWoiCC0AAEEkRwRAIAUNAQwCCwsgCAwBC0EACyIFBEAgBSAGawwBCyAGECcLIQggBEUNACAIIAYgA2tqIgVBLWoiC0HmAEsNACAIIAtLDQAgACABIAIgBiAIQgEgCkGACGuthiAHKAIMIAcoAgggB0EQakEgENkBDQAgBQRAIAQgAyAF/AoAAAsgBCAFaiIAQSQ6AAAgBUF/c0HmAGohASAAQQFqIQNBACEAAkADQCAAQQFqIgVBAiAAQR9zIgIgAkECTxsiCWohBiAHQRBqIgggAGotAAAhAgJ/QQAgCUUNABogBSAIai0AAEEIdCACciECQQAgBiAAQQJqIgBGDQAaIAAgCGotAABBEHQgAnIhAkEBCyEAQQAhCQJAIAFFDQAgAyACQT9xQYAIai0AADoAACABQQFGDQAgAyACQQZ2QT9xQYAIai0AADoAAQJ/IANBAmogBSAGRg0AGiABQQJGDQEgAyACQQx2QT9xQYAIai0AADoAAiADQQNqIABFDQAaIAFBA0YNASADIAJBEnZBgAhqLQAAOgADIANBBGoLIgJFDQAgASADaiACayEBIAIhAyAGIgBBH0sNAgwBCwtBACECCyAHQRBqQSAQByACRQ0AIAIgBEHmAGpPDQAgAkEAOgAAIAQhCQsgB0EwaiQAIAkLvQUBFX8gACgCPCECIAAoAjghECAAKAI0IQ8gACgCMCENIAAoAiwhASAAKAIoIQMgACgCJCERIAAoAiAhDCAAKAIcIQYgACgCGCEHIAAoAhQhBCAAKAIQIQggACgCDCEJIAAoAgghCiAAKAIEIQsgACgCACEFA0AgBCALakEHdyARcyIOIARqQQl3IA9zIhMgBSANakEHdyAIcyIIIAVqQQl3IAxzIhQgCGpBDXcgDXMiFSABIAJqQQd3IAlzIgkgAmpBCXcgBnMiBiAJakENdyABcyIMIAZqQRJ3IAJzIgIgAyAHakEHdyAQcyIBakEHd3MiDSACakEJd3MiDyANakENdyABcyIQIA9qQRJ3IAJzIQIgDCABIAEgA2pBCXcgCnMiCmpBDXcgB3MiByAKakESdyADcyIDIA5qQQd3cyIBIANqQQl3IBRzIgwgAWpBDXcgDnMiESAMakESdyADcyEDIAYgByATIA4gE2pBDXcgC3MiC2pBEncgBHMiBCAIakEHd3MiByAEakEJd3MiBiAHakENdyAIcyIIIAZqQRJ3IARzIQQgCSAUIBVqQRJ3IAVzIgVqQQd3IAtzIgsgBWpBCXcgCnMiCiALakENdyAJcyIJIApqQRJ3IAVzIQUgEkEGSSASQQJqIRINAAsgACAAKAIAIAVqNgIAIAAgACgCBCALajYCBCAAIAAoAgggCmo2AgggACAAKAIMIAlqNgIMIAAgACgCECAIajYCECAAIAAoAhQgBGo2AhQgACAAKAIYIAdqNgIYIAAgACgCHCAGajYCHCAAIAAoAiAgDGo2AiAgACAAKAIkIBFqNgIkIAAgACgCKCADajYCKCAAIAAoAiwgAWo2AiwgACAAKAIwIA1qNgIwIAAgACgCNCAPajYCNCAAIAAoAjggEGo2AjggACAAKAI8IAJqNgI8C8YIAg5/A34gB60gBq1+QoCAgIAEWgRAQcDEAkEWNgIAQX8PCyAFQoCAgIAQWgRAQcDEAkEWNgIAQX8PCyAFe0ICVCAFQgJacUUEQEHAxAJBHDYCAEF/DwsgBkEAIAcbRQRAQcDEAkEcNgIAQX8PC0H///8PIAduIQwCQCAGQf///wdLDQAgBiAMSw0AQf///w8gBm6tIAVUDQAgBkEHdCIQIAdsIhMgECAFp2wiC2oiDCATSQ0AIAwgBkEIdCIRakFAayIMIBFNDQACQCAMIAAoAghLBEBBfyEKIAAQZw0BIwBBEGsiDiQAQcDEAiAOQQxqIAwQuQEiDzYCACAAQQAgDigCDCAPGyIPNgIEIAAgDzYCACAAIAxBACAPGzYCCCAOQRBqJAAgD0UNAQsgASACIAMgBCAAKAIEIhQgExDaASATIBRqIg8gC2oiACAGQQd0aiIEIBBqQUBqIRYgBUIBfSEZIAZBBXQhDCAAIBFqIREgACAQakFAaiEXA0AgFCAQIBVsaiEOQQAhAwNAIAAgA0ECdCIKaiAKIA5qKAAANgIAIAAgCkEEciILaiALIA5qKAAANgIAIAAgCkEIciILaiALIA5qKAAANgIAIAAgCkEMciIKaiAKIA5qKAAANgIAIANBBGoiAyAMRw0AC0IAIRgDQCAYpyEDIBBFIgpFBEAgDyADIAxsQQJ0aiAAIBD8CgAACyAAIAQgESAGEGYgCkUEQCAPIANBAXIgDGxBAnRqIAQgEPwKAAALIAQgACARIAYQZkIAIRogGEICfCIYIAVUDQALA0AgDyAMIBcpAgAgGYOnbEECdGohCkEAIQMDQCAAIANBAnQiC2oiDSANKAIAIAogC2ooAgBzNgIAIAAgC0EEciINaiISIBIoAgAgCiANaigCAHM2AgAgACALQQhyIg1qIhIgEigCACAKIA1qKAIAczYCACAAIAtBDHIiC2oiDSANKAIAIAogC2ooAgBzNgIAIANBBGoiAyAMRw0ACyAAIAQgESAGEGYgDyAMIBYpAgAgGYOnbEECdGohCkEAIQMDQCAEIANBAnQiC2oiDSANKAIAIAogC2ooAgBzNgIAIAQgC0EEciINaiISIBIoAgAgCiANaigCAHM2AgAgBCALQQhyIg1qIhIgEigCACAKIA1qKAIAczYCACAEIAtBDHIiC2oiDSANKAIAIAogC2ooAgBzNgIAIANBBGoiAyAMRw0ACyAEIAAgESAGEGZBACEDIBpCAnwiGiAFVA0ACwNAIA4gA0ECdCIKaiAAIApqKAIANgAAIA4gCkEEciILaiAAIAtqKAIANgAAIA4gCkEIciILaiAAIAtqKAIANgAAIA4gCkEMciIKaiAAIApqKAIANgAAIANBBGoiAyAMRw0ACyAVQQFqIhUgB0cNAAsgASACIBQgEyAIIAkQ2gFBACEKCyAKDwtBwMQCQTA2AgBBfwvsAQECfyMAQfADayIGJAAgBkGgAmoiByAAIAEQPhogByACIAOtECwaIAUEQEEAIQBBACEBA0AgBiABQQFqIgFB/4H8B3FBCHggAUEYeEH/gfwHcXI2AEwgBkHQAGoiAiAGQaACakHQAfwKAAAgAiAGQcwAakIEECwaIAIgBkEgahBPGiAGIAYpAzg3AxggBiAGKQMwNwMQIAYgBikDKDcDCCAGIAYpAyA3AwBBICAFIABrIgIgAkEgTxsiAgRAIAAgBGogBiAC/AoAAAsgAUEFdCIAIAVJDQALCyAGQaACakHQARAHIAZB8ANqJAALewECfyMAQSBrIgUkAEF/IQYCQCACQiBUDQAgBUIgIAMgBBDmARogAUEQaiABQSBqIAJCIH0gBUGovQIoAgAREgANACAAIAEgAiADIAQQjgEaIABCADcAGCAAQgA3ABAgAEIANwAIIABCADcAAEEAIQYLIAVBIGokACAGC0cAIAJCIFoEfyAAIAEgAiADIAQQjgEaIABBEGogAEEgaiACQiB9IABBpL0CKAIAERIAGiAAQgA3AAggAEIANwAAQQAFQX8LCwQAQTALBQBBwAoLqQIBA38jAEHgAmsiCCQAIAhBIGoiCkLAACAGIAcQQRogCEHgAGoiCSAKQay9AigCABEAABogCkHAABAHIAkgBCAFQbC9AigCABECABogCUHwvAJCACAFfUIPg0GwvQIoAgARAgAaIAkgASACQbC9AigCABECABogCUHwvAJCACACfUIPg0GwvQIoAgARAgAaIAggBTcDGCAJIAhBGGoiBEIIQbC9AigCABECABogCCACNwMYIAkgBEIIQbC9AigCABECABogCSAIQbS9AigCABEAABogCUGAAhAHIAggAxBHIQQgCEEQEAcCQCAARQ0AIAQEQCACpyIBBEAgAEEAIAH8CwALQX8hBAwBCyAAIAEgAiAGQQEgBxBIGkEAIQQLIAhB4AJqJAAgBAv3AQEDfyMAQeACayIIJAAgCEEgaiIKQsAAIAYgBxBfGiAIQeAAaiIJIApBrL0CKAIAEQAAGiAKQcAAEAcgCSAEIAVBsL0CKAIAEQIAGiAIIAU3AxggCSAIQRhqIgRCCEGwvQIoAgARAgAaIAkgASACQbC9AigCABECABogCCACNwMYIAkgBEIIQbC9AigCABECABogCSAIQbS9AigCABEAABogCUGAAhAHIAggAxBHIQQgCEEQEAcCQCAARQ0AIAQEQCACpyIBBEAgAEEAIAH8CwALQX8hBAwBCyAAIAEgAiAGQgEgBxBJGkEAIQQLIAhB4AJqJAAgBAv/AQEDfyMAQdACayIKJAAgCkEQaiILQsAAIAcgCBBBGiAKQdAAaiIJIAtBrL0CKAIAEQAAGiALQcAAEAcgCSAFIAZBsL0CKAIAEQIAGiAJQfC8AkIAIAZ9Qg+DQbC9AigCABECABogACADIAQgB0EBIAgQSBogCSAAIARBsL0CKAIAEQIAGiAJQfC8AkIAIAR9Qg+DQbC9AigCABECABogCiAGNwMIIAkgCkEIaiIAQghBsL0CKAIAEQIAGiAKIAQ3AwggCSAAQghBsL0CKAIAEQIAGiAJIAFBtL0CKAIAEQAAGiAJQYACEAcgAgRAIAJCEDcDAAsgCkHQAmokAEEAC80BAQN/IwBB0AJrIgkkACAJQRBqIgtCwAAgByAIEF8aIAlB0ABqIgogC0GsvQIoAgARAAAaIAtBwAAQByAKIAUgBkGwvQIoAgARAgAaIAkgBjcDCCAKIAlBCGoiBUIIQbC9AigCABECABogACADIAQgB0IBIAgQSRogCiAAIARBsL0CKAIAEQIAGiAJIAQ3AwggCiAFQghBsL0CKAIAEQIAGiAKIAFBtL0CKAIAEQAAGiAKQYACEAcgAgRAIAJCEDcDAAsgCUHQAmokAEEAC7IBAQF/IwBBEGsiAiAANgIMIAIgATYCCEEAIQAgAkEAOwEGA0AgAiACLwEGIAIoAgwgAGotAAAgAigCCCAAai0AAHNyOwEGIAIgAi8BBiAAQQFyIgEgAigCDGotAAAgAigCCCABai0AAHNyOwEGIABBAmoiAEHAAEcNAAsgAiACLwEGOwEGIAIgAi8BBkEBazsBBiACQdDIAi8BAEECdiACLwEGQQ92czsBBiACLwEGQQFrC7sBAgJ/A34jAEHAAWsiAiQAIAJBIBAWIAEgAkIgEEAaIAEgAS0AAEH4AXE6AAAgASABLQAfQT9xQcAAcjoAHyACQSBqIgMgARAwIAAgAxAiIAEgAikDGDcAGCABIAIpAxA3ABAgASACKQMINwAIIAEgAikDADcAACAAKQAAIQQgACkACCEFIAApABAhBiABIAApABg3ADggASAGNwAwIAEgBTcAKCABIAQ3ACAgAkEgEAcgAkHAAWokAEEAC7YBAgF/A34jAEGgAWsiAyQAIAEgAkIgEEAaIAEgAS0AAEH4AXE6AAAgASABLQAfQT9xQcAAcjoAHyADIAEQMCAAIAMQIiACKQAAIQQgAikACCEFIAIpABAhBiABIAIpABg3ABggASAGNwAQIAEgBTcACCABIAQ3AAAgACkAACEEIAApAAghBSAAKQAQIQYgASAAKQAYNwA4IAEgBjcAMCABIAU3ACggASAENwAgIANBoAFqJABBAAs6AQF/IwBBIGsiBCQAIAQgAiADQQAQNhogACABIAJBEGogBEHAvQIoAgAREAAgBEEgEAcgBEEgaiQAC4ECAQV/IwBBEGsiBSQAIAAtAOQBRQRAIAUCfwJAAkACQCAAKALgASIDQYcBaw4CAAECCyAALQDlAUGAf3MMAgsgABAlQQAhAyAAQQA2AuABCyAAIABB5QFqIANBARAYQYABCzoADyAAIAVBD2pBhwFBARAYIAAQJSAAQQE6AOQBIABBADYC4AELIAIEQCAAKALgASEDA0AgA0GIAUYEQCAAECUgAEEANgLgAUEAIQMLQYgBIANrIgQgAiAGayIHIAQgB0kbIgQEQCABIAZqIAAgA2ogBPwKAAALIAAgACgC4AEgBGoiAzYC4AEgBCAGaiIGIAJJDQALCyAFQRBqJABBAAtkAQN/IwBBQGoiBiQAQX8hBwJAIAJCEFQNACAGQSBqIgggBSAEECANACAGQeC8AiAIIgRBABAfGiAEQSAQByAAIAFBEGogASACQhB9IAMgBhBsIQcgBkEgEAcLIAZBQGskACAHC24BAX8jAEFAaiIGJAAgAkLw////D1QEQAJAIAZBIGogBSAEECAEQEF/IQUMAQsgBkHgvAIgBkEgaiIEQQAQHxogBEEgEAcgAEEQaiAAIAEgAiADIAYQWCEFIAZBIBAHCyAGQUBrJAAgBQ8LEAwAC0YAAkACQCACQoCAgIAQWgRAQcDEAkEWNgIADAELIAAgASACp0ECEPQBIgFFDQEgAUFdRw0AQcDEAkEcNgIAC0F/IQELIAELhgEBAX8jAEEQayIFJAAgAEEAQYAB/AsAAn8gBEGBgICAeEkgAiADhEL/////D1hxRQRAQcDEAkEWNgIAQX8MAQsgBEH/P0sgA0IAUnFFBEBBwMQCQRw2AgBBfwwBCyAFQRAQFkF/QQAgA6cgBEEKdiABIAKnIAUgAEECEPUBGwsgBUEQaiQAC+ICAQR/IAGnIggEQCAAQQAgCPwLAAsgAUKAgICAEFoEQEHAxAJBFjYCAEF/DwsCQCABQg9YDQAgBkGBgICAeEkgAyAFhEL/////D1hxRQRAQcDEAkEWNgIAQX8PCyAGQf8/SyAFQgBScUUNACAAIAJGDQAgB0ECRgRAIwBBQGoiByQAIAAEQCAAIAgQFgsgBachCSAGQQp2IQogA6chCwJAIAgQIyIGRQRAQWohAgwBCyAHQgA3AhwgB0EQNgIYIAcgBDYCFCAHIAs2AhAgByACNgIMIAcgCDYCCCAHIAY2AgQgB0IANwIkIAdBADYCPCAHQQE2AjggB0EBNgI0IAcgCjYCMCAHIAk2AiwCQCAHQQRqQQIQaiICDQAgAEUNACAIRQ0AIAAgBiAI/AoAAAsgBiAIEAcgBhAXCyAHQUBrJABBf0EAIAIbDwtBwMQCQRw2AgBBfw8LQcDEAkEcNgIAQX8LCABBgICAgAELBwBBgICAIAsFAEGiDAtGAAJAAkAgAkKAgICAEFoEQEHAxAJBFjYCAAwBCyAAIAEgAqdBARD0ASIBRQ0BIAFBXUcNAEHAxAJBHDYCAAtBfyEBCyABC4YBAQF/IwBBEGsiBSQAIABBAEGAAfwLAAJ/IARBgYCAgHhJIAIgA4RC/////w9YcUUEQEHAxAJBFjYCAEF/DAELIARB/z9LIANCA1pxRQRAQcDEAkEcNgIAQX8MAQsgBUEQEBZBf0EAIAOnIARBCnYgASACpyAFIABBARD1ARsLIAVBEGokAAviAgEEfyABpyIIBEAgAEEAIAj8CwALIAFCgICAgBBaBEBBwMQCQRY2AgBBfw8LAkAgAUIPWA0AIAZBgYCAgHhJIAMgBYRC/////w9YcUUEQEHAxAJBFjYCAEF/DwsgBkH/P0sgBUIDWnFFDQAgACACRg0AIAdBAUYEQCMAQUBqIgckACAABEAgACAIEBYLIAWnIQkgBkEKdiEKIAOnIQsCQCAIECMiBkUEQEFqIQIMAQsgB0IANwIcIAdBEDYCGCAHIAQ2AhQgByALNgIQIAcgAjYCDCAHIAg2AgggByAGNgIEIAdCADcCJCAHQQA2AjwgB0EBNgI4IAdBATYCNCAHIAo2AjAgByAJNgIsAkAgB0EEakEBEGoiAg0AIABFDQAgCEUNACAAIAYgCPwKAAALIAYgCBAHIAYQFwsgB0FAayQAQX9BACACGw8LQcDEAkEcNgIAQX8PC0HAxAJBHDYCAEF/CwcAQYCAgBAL2QMBCH8jAEGAAWsiBCQAIARBADYCQCAEQgA3AjggBEIANwIwIARCADcCKCAEQgA3AiAgBEIANwIYIARCADcCECAEIAAQJyIFNgIcIAQgBTYCLCAEIAU2AgwgBCAFECMiBjYCKCAEIAUQIyIHNgIYIAQgBRAjIgg2AggCQAJAIAZFDQAgB0UNACAIRQ0AIAUQIyIFRQ0AIARBCGogACADEPYBIgAEQCAEKAIoEBcgBCgCGBAXIAQoAggQFyAFEBcMAgsgBCgCHCEIIAQoAhghCSAEKAI8IQAgBCgCNCEKIAQoAjAhCyAFIAQoAgwiBhAWAkAgBhAjIgdFBEBBaiEADAELIARCADcCXCAEIAg2AlggBCAJNgJUIAQgAjYCUCAEIAE2AkwgBCAGNgJIIAQgBzYCRCAEQgA3AmQgBEEANgJ8IAQgADYCeCAEIAA2AnQgBCAKNgJwIAQgCzYCbAJAIARBxABqIAMQaiIADQAgBkUNACAFIAcgBvwKAAALIAcgBhAHIAcQFwsgBCgCKBAXIAQoAhgQFyAARQRAQV1BACAFIAQoAgggBCgCDBA7GyEACyAFEBcgBCgCCBAXDAELIAYQFyAHEBcgCBAXQWohAAsgBEGAAWokACAAC88IAQV/IwBBQGoiByQAAkBBIBAjIglFBEBBaiEADAELIAdCADcCHCAHQRA2AhggByAENgIUIAcgAzYCECAHIAI2AgwgB0EgNgIIIAcgCTYCBCAHQgA3AiQgB0EANgI8IAdBATYCOCAHQQE2AjQgByABNgIwIAcgADYCLAJAIAdBBGogBhBqIgAEQCAJQSAQBwwBCwJAIAVFDQAgB0EEaiEIIwBBIGsiBCQAQWEhAAJAAn8CQAJAIAZBAWsOAgEAAwsgBUGhCykAADcABSAFQZwLKQAANwAAQQwhAUF0DAELIAVBmAsoAAA2AAggBUGQCykAADcAAEELIQFBdQsgCBCXASIADQAgBEEAOgANIARBsfIAOwALQYABaiICIARBC2oQJyIATQRAQWEhAAwBCyABIAVqIQEgAEEBaiIDBEAgASAEQQtqIAP8CgAACyACIABrIgZBBEkEQEFhIQAMAQsgACABaiIKQaTa9QE2AAAgCCgCLCEAQQohAQNAAkAgASICQQFrIgEgBEEWamoiCyAAIABBCm4iA0EKbGtBMHI6AAAgAEEKSQ0AIAMhACABDQELC0ELIAJrIgAEQCAEQQtqIAsgAPwKAAALIAAgBEELaiIBakEAOgAAIAZBA2siAiABECciAE0EQEFhIQAMAQsgCkEDaiEBIABBAWoiAwRAIAEgBEELaiAD/AoAAAsgAiAAayIGQQRJBEBBYSEADAELIAAgAWoiCkGs6PUBNgAAIAgoAighAEEKIQEDQAJAIAEiAkEBayIBIARBFmpqIgsgACAAQQpuIgNBCmxrQTByOgAAIABBCkkNACADIQAgAQ0BCwtBCyACayIABEAgBEELaiALIAD8CgAACyAAIARBC2oiAWpBADoAACAGQQNrIgIgARAnIgBNBEBBYSEADAELIApBA2ohASAAQQFqIgMEQCABIARBC2ogA/wKAAALIAIgAGsiBkEESQRAQWEhAAwBCyAAIAFqIgpBrOD1ATYAACAIKAIwIQBBCiEBA0ACQCABIgJBAWsiASAEQRZqaiILIAAgAEEKbiIDQQpsa0EwcjoAACAAQQpJDQAgAyEAIAENAQsLQQsgAmsiAARAIARBC2ogCyAA/AoAAAsgACAEQQtqIgFqQQA6AAAgBkEDayICIAEQJyIATQRAQWEhAAwBCyAKQQNqIQEgAEEBaiIDBEAgASAEQQtqIAP8CgAACyACIABrIgJBAkkEQEFhIQAMAQsgACABaiIAQSQ7AAAgAEEBaiIBIAJBAWsiAiAIKAIQIAgoAhRBAxCWAUUEQEFhIQAMAQtBYSEAIAIgARAnIgJrIgNBAkkNACABIAJqIgBBJDsAAEEAQWEgAEEBaiADQQFrIAgoAgAgCCgCBEEDEJYBGyEACyAEQSBqJAAgAEUNACAJQSAQByAFQYABEAdBYSEADAELIAlBIBAHQQAhAAsgCRAXCyAHQUBrJAAgAAvxBAEIfyMAQRBrIgMkACAAKAIUIQggAEEANgIUIAAoAgQhCSAAQQA2AgRBZiEFAkACQAJ/AkACQCACQQFrDgIBAAQLIAFBpAlBCRBODQIgAUEJagwBCyABQZUJQQgQTg0BIAFBCGoLIgEtAABBJEcNACABLQABQfYARw0AIAEtAAJBPUcNACABQQNqIgYtAAAiCkE6a0H/AXFB9gFJDQBBACEBIAohByAGIQIDQCACIQQgAUGZs+bMAUsNASAHQf8BcUEwayICIAFBCmwiAUF/c0sNASABIAJqIQEgBEEBaiICLQAAIgdBOmtB/wFxQfUBSw0ACyACIAZGDQAgCkEwRiAEIAZHcQ0AIAFBE0cNASAHQf8BcUEkRw0AIAQtAAJB7QBHDQAgBC0AA0E9Rw0AIARBBGogA0EMaiIEEJQBIgFFDQAgACADKAIMNgIsIAEtAABBLEcNACABLQABQfQARw0AIAEtAAJBPUcNACABQQNqIAQQlAEiAUUNACAAIAMoAgw2AiggAS0AAEEsRw0AIAEtAAFB8ABHDQAgAS0AAkE9Rw0AIAFBA2ogBBCUASIBRQ0AIAAgAygCDCICNgIwIAAgAjYCNCABLQAAQSRHDQAgAyAINgIMIAAoAhAgCCABQQFqIgEgARAnQQAgBCADQQhqIgJBAxCVAQ0AIAAgAygCDDYCFCADKAIIIgEtAABBJEcNACADIAk2AgwgACgCACAJIAFBAWoiASABECdBACAEIAJBAxCVAQ0AIAAgAygCDDYCBCADKAIIIQEgABCXASIFDQFBYEEAIAEtAAAbIQUMAQtBYCEFCyADQRBqJAAgBQunCAEFfwJAIAAgAU8NACAARQ0AIAFFDQAgAkUNAAJAAkAgAC0AAEEwa0H/AXEiA0EJSyIGBEBBACEDIAAhBAwBCyAAQQFqIQQCQCABIABrIgVBAUYNACAELQAAQTBrQf8BcSIHQQlLDQEgA0EKbCAHaiIDQf8BSw0DIABBAmohBCAFQQJGDQAgBC0AAEEwa0H/AXEiB0EJSw0BIANBCmwgB2oiA0H/AUsNAyAAQQNqIQQgBUEDRg0AIAQtAABBMGtB/wFxQQpPDQEMAwsgASEADAELIAQhACAGDQELIAIgAzoAACABIARNDQAgAC0AAEEuRw0AIAEgAEEBaiIEayIDQQAgASADTxshBgJAIAEgBE0EQEEAIQUgBiEDDAELQQAhBUEAIQMgBC0AAEEwa0H/AXEiB0EKTw0AIABBAmohBEEBIQMgBkEBRgRAIAchBSAGIQMMAQsgBC0AAEEwa0H/AXEiBUEJSwRAIAchBQwBCyAHQQpsIAVqIgVB/wFLDQEgAEEDaiEEQQIhAyAGQQJGBEAgBiEDDAELIAQtAABBMGtB/wFxIgdBCUsNACAFQQpsIAdqIgVB/wFLDQEgAEEEaiEEQQMhAyAGQQNGBEAgBiEDDAELIAQtAABBMGtB/wFxQQpJDQELIANFBEBBAA8LIAIgBToAASABIARNBEBBAA8LIAQtAABBLkcNACABIARBAWoiAGsiA0EAIAEgA08bIQYCQCAAIAFPBEBBACEFIAYhAwwBC0EAIQVBACEDIAAtAABBMGtB/wFxIgdBCk8NACAEQQJqIQBBASEDIAZBAUYEQCAHIQUgBiEDDAELIAAtAABBMGtB/wFxIgVBCUsEQCAHIQUMAQsgB0EKbCAFaiIFQf8BSw0BIARBA2ohAEECIQMgBkECRgRAIAYhAwwBCyAALQAAQTBrQf8BcSIHQQlLDQAgBUEKbCAHaiIFQf8BSw0BIARBBGohAEEDIQMgBkEDRgRAIAYhAwwBCyAALQAAQTBrQf8BcUEKSQ0BCyADRQRAQQAPCyACIAU6AAIgACABTwRAQQAPCyAALQAAQS5HDQBBACEGIAEgAEEBaiIEayIDQQAgASADTxshBQJAIAEgBE0EQCAFIQMMAQtBACEDIAQtAABBMGtB/wFxIgdBCk8NACAAQQJqIQRBASEDIAVBAUYEQCAHIQYgBSEDDAELIAQtAABBMGtB/wFxIgZBCUsEQCAHIQYMAQsgB0EKbCAGaiIGQf8BSw0BIABBA2ohBEECIQMgBUECRgRAIAUhAwwBCyAELQAAQTBrQf8BcSIHQQlLDQAgBkEKbCAHaiIGQf8BSw0BIABBBGohBEEDIQMgBUEDRgRAIAUhAwwBCyAELQAAQTBrQf8BcUEKSQ0BCyADRQ0AIAIgBjoAAyABIARGDwtBAAspAQF/IwBBQGoiAyQAIAAgAxAeGiABIANCwAAgAkEBEJgBIANBQGskAAsrAQF/IwBBQGoiBCQAIAAgBBAeGiABIAIgBELAACADQQEQmQEgBEFAayQACwkAIAAQMhpBAAsFAEG/fwtyAQF/AkAgAUEEcUUNACAAKAIAIgEEQCABKAIEIAAoAhBBCnQQBwsgACgCBCIBRQ0AIAEgACgCFEEDdBAHCyAAKAIEEBcgAEEANgIEAkAgACgCACIBRQ0AIAEoAgAiAkUNACACEBcLIAEQFyAAQQA2AgALsAMBBX8jAEGgH2siAyQAIANBoB1qIgRB4AAgAkIgEHQaIAMgAykD2B03A5gdIAMgAykD0B03A5AdIAMgAykDyB03A4gdIAMgAykDwB03A4AdIAMgAykDuB03A/gcIAMgAykDsB03A/AcIAMgAykDqB03A+gcIAMgAykDoB03A+AcIAMgAykD4B03AyAgAyADKQPoHTcDKCADIAMpA/AdNwMwIAMgAykD+B03AzggA0HAE2ogA0HgAGoiBiADQeAcaiIFEFoaIANBQGsgA0EgaiIHQby9AigCABEAABogBEHgABAHIAVBwAAQB0F/IQIgBSABIAYQhAJFBEAgAyAHIAFBwAhqIgQQIAR/IAUFIANBoB1qIgFBAEHIAfwLACABQQA6AOwBIAFBIDYC6AEgAUKAgICAgBE3A+ABIAEgA0HgHGoiAkIgECoaIAEgA0IgECoaIAEgBEIgECoaIAEgA0FAa0IgECoaIAFBoLwCQgYQKhogASAAEFsaIAFBgAIQByACQSAQB0EAIQIgAwtBIBAHCyADQeAAakHgEhAHIANBIGpBIBAHIANBoB9qJAAgAgs2AQF/IwBBQGoiAyQAIANBwAAQFiAAIAEgAiADEP8BIQAgA0HAABAHIANBQGskAEF/QQAgABsLqAIBA38jAEGgC2siBCQAQX8hBSAEQeAAaiAEQUBrIgYgAiADEJwBRQRAIARBIGogA0EgaiIDQby9AigCABEAABogBCADIAJBoAlqIgIQIAR/IAYFIAAgBEHgAGpBwAj8CgAAIABB2AhqIAQpAzg3AAAgAEHQCGogBCkDMDcAACAAQcgIaiAEKQMoNwAAIABBwAhqIAQpAyA3AAAgBEGgCWoiAEEAQcgB/AsAIABBADoA7AEgAEEgNgLoASAAQoCAgICAETcD4AEgACAEQUBrIgNCIBAqGiAAIARCIBAqGiAAIARBIGpCIBAqGiAAIAJCIBAqGiAAQaC8AkIGECoaIAAgARBbGiAAQYACEAcgA0EgEAdBACEFIAQLQSAQBwsgBEGgC2okACAFC/oCAQZ/IwBBgB5rIgIkACACQSAQFiACQaAdaiIDQeAAIAJCIBB0GiACIAIpA9gdNwOYHSACIAIpA9AdNwOQHSACIAIpA8gdNwOIHSACIAIpA8AdNwOAHSACIAIpA7gdNwP4HCACIAIpA7AdNwPwHCACIAIpA6gdNwPoHCACIAIpA6AdNwPgHCACIAIpA+AdNwMgIAIgAikD6B03AyggAiACKQPwHTcDMCACIAIpA/gdNwM4IAJBwBNqIgQgAkHgAGoiBSACQeAcaiIGEFoaIAJBQGsgAkEgaiIHQby9AigCABEAABogA0HgABAHIAZBwAAQByAAIARBoAn8CgAAIABBuAlqIAIpA1g3AAAgAEGwCWogAikDUDcAACAAQagJaiACKQNINwAAIABBoAlqIAIpA0A3AAAgASACKQMYNwAYIAEgAikDEDcAECABIAIpAwg3AAggASACKQMANwAAIAVB4BIQByAHQSAQByACQSAQByACQYAeaiQAQQAL6AIBBX8jAEHgHWsiAyQAIANBgB1qIgRB4AAgAkIgEHQaIAMgAykDuB03A/gcIAMgAykDsB03A/AcIAMgAykDqB03A+gcIAMgAykDoB03A+AcIAMgAykDmB03A9gcIAMgAykDkB03A9AcIAMgAykDiB03A8gcIAMgAykDgB03A8AcIAMgAykDwB03AwAgAyADKQPIHTcDCCADIAMpA9AdNwMQIAMgAykD2B03AxggA0GgE2oiBSADQUBrIgYgA0HAHGoiBxBaGiADQSBqIANBvL0CKAIAEQAAGiAEQeAAEAcgB0HAABAHIAAgBUGgCfwKAAAgAEG4CWogAykDODcAACAAQbAJaiADKQMwNwAAIABBqAlqIAMpAyg3AAAgAEGgCWogAykDIDcAACABIAIpABg3ABggASACKQAQNwAQIAEgAikACDcACCABIAIpAAA3AAAgBkHgEhAHIANBIBAHIANB4B1qJABBAAsFAEHgCAsFAEHACQvZGAEKfyMAQYAkayIDJAADQCABIAVBBWxqIgQtAAAhCSAELQABIQcgBC0AAiEGIANBgBRqIAVBA3RqIgggBC0ABEECdCAELQADIgRBBnZyQYEabEGABGpBCnY7AQYgCCAEQQR0QfAHcSAGQQR2ckGBGmxBgARqQQp2OwEEIAggBkEGdEHAB3EgB0ECdnJBgRpsQYAEakEKdjsBAiAIIAkgB0EIdEGABnFyQYEabEGABGpBCnY7AQAgBUEBaiIFQcAARw0ACyABQcACaiEKIANBgBhqIQhBACEFA0AgCiAFQQVsaiIELQAAIQsgBC0AASEGIAQtAAIhCSAIIAVBA3RqIgcgBC0ABEECdCAELQADIgRBBnZyQYEabEGABGpBCnY7AQYgByAEQQR0QfAHcSAJQQR2ckGBGmxBgARqQQp2OwEEIAcgCUEGdEHAB3EgBkECdnJBgRpsQYAEakEKdjsBAiAHIAsgBkEIdEGABnFyQYEabEGABGpBCnY7AQAgBUEBaiIFQcAARw0ACyABQYAFaiELIANBgBxqIQdBACEFA0AgCyAFQQVsaiIELQAAIQwgBC0AASEJIAQtAAIhCiAHIAVBA3RqIgYgBC0ABEECdCAELQADIgRBBnZyQYEabEGABGpBCnY7AQYgBiAEQQR0QfAHcSAKQQR2ckGBGmxBgARqQQp2OwEEIAYgCkEGdEHAB3EgCUECdnJBgRpsQYAEakEKdjsBAiAGIAwgCUEIdEGABnFyQYEabEGABGpBCnY7AQAgBUEBaiIFQcAARw0ACyABQcAHaiEFQQAhBANAIANBgARqIARBAnRqIgYgBCAFai0AACIJQQR2QYEabEEIakEEdjsBAiAGIAlBD3FBgRpsQQhqQQR2OwEAIARBAWoiBEGAAUcNAAsgA0GACGogAhCbASADQYAUahBuQQAhBEEAIQUDQCADQYAUaiAFQQF0aiIGIAYuAQAiCUG/nQFsQRp1Qf9lbCAJajsBACAGIAYuAQIiBkG/nQFsQRp1Qf9lbCAGajsBAiAFQQJqIgVBgAJHDQALA0AgCCAEQQF0aiIFIAUuAQAiBkG/nQFsQRp1Qf9lbCAGajsBACAFIAUuAQIiBUG/nQFsQRp1Qf9lbCAFajsBAiAEQQJqIgRBgAJHDQALQQAhBANAIAcgBEEBdGoiBSAFLgEAIgZBv50BbEEadUH/ZWwgBmo7AQAgBSAFLgECIgVBv50BbEEadUH/ZWwgBWo7AQIgBEECaiIEQYACRw0ACyADIANBgAhqIANBgBRqEBUgA0GAIGogA0GADGogCBAVQQAhBQNAIAMgBUEBdCIEaiIGIANBgCBqIgggBGovAQAgBi8BAGo7AQAgAyAEQQJyIgZqIgkgBiAIai8BACAJLwEAajsBACADIARBBHIiBmoiCSAGIAhqLwEAIAkvAQBqOwEAIAMgBEEGciIEaiIGIAQgCGovAQAgBi8BAGo7AQAgBUEEaiIFQYACRw0ACyAIIANBgBBqIAcQFUEAIQVBACEEA0AgAyAEQQF0IghqIgYgA0GAIGoiByAIai8BACAGLwEAajsBACADIAhBAnIiBmoiCSAGIAdqLwEAIAkvAQBqOwEAIAMgCEEEciIGaiIJIAYgB2ovAQAgCS8BAGo7AQAgAyAIQQZyIghqIgYgByAIai8BACAGLwEAajsBACAEQQRqIgRBgAJHDQALA0AgAyAFQQF0aiIEIAQuAQAiCEG/nQFsQRp1Qf9lbCAIajsBACAEIAQuAQIiBEG/nQFsQRp1Qf9lbCAEajsBAiAFQQJqIgVBgAJHDQALIAMQWUEAIQVBACEEA0AgAyAEQQF0IghqIgYgA0GABGoiByAIai8BACAGLwEAazsBACADIAhBAnIiBmoiCSAGIAdqLwEAIAkvAQBrOwEAIAMgCEEEciIGaiIJIAYgB2ovAQAgCS8BAGs7AQAgAyAIQQZyIghqIgYgByAIai8BACAGLwEAazsBACAEQQRqIgRBgAJHDQALA0AgAyAFQQF0aiIEIAQuAQAiCEG/nQFsQRp1Qf9lbCAIajsBACAEIAQuAQIiBEG/nQFsQRp1Qf9lbCAEajsBAiAFQQJqIgVBgAJHDQALQQAhBANAQQAhBSADIARBAXRqIgggCC8BACIHIAdBgRprIgcgB8FBAEgbOwEAIAggCC8BAiIHIAdBgRprIgcgB8FBAEgbOwECIAggCC8BBCIHIAdBgRprIgcgB8FBAEgbOwEEIAggCC8BBiIIIAhBgRprIgggCMFBAEgbOwEGIARBBGoiBEGAAkcNAAsDQCADQYAgaiIIIAVqIAMgBUEEdGoiBC4BAiIHQQ92QYEacSAHakH26wlsQYC//T9qQRt2QQJxIAQuAQAiB0EPdkGBGnEgB2pB9usJbEGAv/0/akEcdkEBcXIgBC4BBCIHQQ92QYEacSAHakH26wlsQYC//T9qQRp2QQRxciAELgEGIgdBD3ZBgRpxIAdqQfbrCWxBgL/9P2pBGXZBCHFyIAQuAQgiB0EPdkGBGnEgB2pB9usJbEGAv/0/akEYdkEQcXIgBC4BCiIHQQ92QYEacSAHakH26wlsQYC//T9qQRd2QSBxciAELgEMIgdBD3ZBgRpxIAdqQfbrCWxBgL/9P2pBFnZBwABxciAELgEOIgRBD3ZBgRpxIARqQfbrCWxBgL/9P2pBFXZBgAFxcjoAACAFQQFqIgVBIEcNAAsgA0GACGoiBUGADBAHIANBgAQQByADIAJBoBJqKQAANwOgICADIAJBqBJqKQAANwOoICADIAJBsBJqKQAANwOwICADIAJBuBJqKQAANwO4ICADQYAEaiIHIAhCwAAQcBogA0GAFGoiBCAIIAJBgAlqIANBoARqEIUCIAEgBEHACBA7IQYgBUEAQcgB/AsAIAVBgD47AeQBIAVBADYC4AEgBSACQcASakIgEHEaIAUgAULACBBxGiAFIANBIBB2GiADIAZBH3UiASADLQCABCICIAMtAABzcSACczoAgAQgAyADLQCBBCICIAMtAAFzIAFxIAJzOgCBBCADIAMtAIIEIgIgAy0AAnMgAXEgAnM6AIIEIAMgAy0AgwQiAiADLQADcyABcSACczoAgwQgAyADLQCEBCICIAMtAARzIAFxIAJzOgCEBCADIAMtAIUEIgIgAy0ABXMgAXEgAnM6AIUEIAMgAy0AhgQiAiADLQAGcyABcSACczoAhgQgAyADLQCHBCICIAMtAAdzIAFxIAJzOgCHBCADIAMtAIgEIgIgAy0ACHMgAXEgAnM6AIgEIAMgAy0AiQQiAiADLQAJcyABcSACczoAiQQgAyADLQCKBCICIAMtAApzIAFxIAJzOgCKBCADIAMtAIsEIgIgAy0AC3MgAXEgAnM6AIsEIAMgAy0AjAQiAiADLQAMcyABcSACczoAjAQgAyADLQCNBCICIAMtAA1zIAFxIAJzOgCNBCADIAMtAI4EIgIgAy0ADnMgAXEgAnM6AI4EIAMgAy0AjwQiAiADLQAPcyABcSACczoAjwQgAyADLQCQBCICIAMtABBzIAFxIAJzOgCQBCADIAMtAJEEIgIgAy0AEXMgAXEgAnM6AJEEIAMgAy0AkgQiAiADLQAScyABcSACczoAkgQgAyADLQCTBCICIAMtABNzIAFxIAJzOgCTBCADIAMtAJQEIgIgAy0AFHMgAXEgAnM6AJQEIAMgAy0AlQQiAiADLQAVcyABcSACczoAlQQgAyADLQCWBCICIAMtABZzIAFxIAJzOgCWBCADIAMtAJcEIgIgAy0AF3MgAXEgAnM6AJcEIAMgAy0AmAQiAiADLQAYcyABcSACczoAmAQgAyADLQCZBCICIAMtABlzIAFxIAJzOgCZBCADIAMtAJoEIgIgAy0AGnMgAXEgAnM6AJoEIAMgAy0AmwQiAiADLQAbcyABcSACczoAmwQgAyADLQCcBCICIAMtABxzIAFxIAJzOgCcBCADIAMtAJ0EIgIgAy0AHXMgAXEgAnM6AJ0EIAMgAy0AngQiAiADLQAecyABcSACczoAngQgAyABIAMtAJ8EIgIgAy0AH3NxIAJzOgCfBCAAIAMpA5gENwAYIAAgAykDkAQ3ABAgACADKQOIBDcACCAAIAMpA4AENwAAIAhBwAAQByAHQcAAEAcgA0EgEAcgBEHACBAHIAVBgAIQByADQYAkaiQAQQAL5CkCC38HfiMAQaDkAGsiBSQAIAUgAkGYCWopAAA3AxggBSACQZAJaikAADcDECAFIAJBiAlqKQAANwMIIAUgAkGACWopAAA3AwAgBUGgyABqIAIQmwFBACECA0AgBUGgBGogAkEEdGoiCEGBDUEAIAEgAmosAAAiBkEASBs7AQ4gCCAGQRl0QR91QYENcTsBDCAIIAZBGnRBH3VBgQ1xOwEKIAggBkEbdEEfdUGBDXE7AQggCCAGQRx0QR91QYENcTsBBiAIIAZBHXRBH3VBgQ1xOwEEIAggBkEedEEfdUGBDXE7AQIgCEEAIAZBAXFrQYENcTsBACACQQFqIgJBIEcNAAsgBUGgGGogBUEBEIYCQQAhAiAFQaDUAGoiASADQQAQJCAFQaDYAGoiBCADQQEQJCAFQaDcAGoiCSADQQIQJCAFQaA8aiADQQMQJCAFQaDAAGoiDCADQQQQJCAFQaDEAGoiDSADQQUQJCAFQSBqIANBBhAkIAEQbkEAIQEDQCAFQaDUAGogAUEBdGoiAyADLgEAIghBv50BbEEadUH/ZWwgCGo7AQAgAyADLgECIgNBv50BbEEadUH/ZWwgA2o7AQIgAUECaiIBQYACRw0ACwNAIAQgAkEBdGoiASABLgEAIgNBv50BbEEadUH/ZWwgA2o7AQAgASABLgECIgFBv50BbEEadUH/ZWwgAWo7AQIgAkECaiICQYACRw0AC0EAIQIDQCAJIAJBAXRqIgEgAS4BACIDQb+dAWxBGnVB/2VsIANqOwEAIAEgAS4BAiIBQb+dAWxBGnVB/2VsIAFqOwECIAJBAmoiAkGAAkcNAAsgBUGgDGogBUGgGGogBUGg1ABqEBUgBUGg4ABqIAVBoBxqIAQQFUEAIQEDQCABQQF0IgIgBUGgDGoiA2oiBiAFQaDgAGoiCCACai8BACAGLwEAajsBACADIAJBAnIiBmoiByAGIAhqLwEAIAcvAQBqOwEAIAMgAkEEciIGaiIHIAYgCGovAQAgBy8BAGo7AQAgAyACQQZyIgJqIgMgAiAIai8BACADLwEAajsBACABQQRqIgFBgAJHDQALIAggBUGgIGogCRAVQQAhAUEAIQIDQCACQQF0IgMgBUGgDGoiCGoiBiAFQaDgAGoiCyIHIANqLwEAIAYvAQBqOwEAIAggA0ECciIGaiIKIAYgB2ovAQAgCi8BAGo7AQAgCCADQQRyIgZqIgcgBiALai8BACAHLwEAajsBACAIIANBBnIiA2oiCCADIAtqLwEAIAgvAQBqOwEAIAJBBGoiAkGAAkcNAAsDQCAFQaAMaiABQQF0aiICIAIuAQAiA0G/nQFsQRp1Qf9lbCADajsBACACIAIuAQIiAkG/nQFsQRp1Qf9lbCACajsBAiABQQJqIgFBgAJHDQALIAVBoBBqIgggBUGgJGogBUGg1ABqEBUgBUGg4ABqIAVBoChqIAQQFUEAIQIDQCAIIAJBAXQiAWoiBiAFQaDgAGoiAyABai8BACAGLwEAajsBACAIIAFBAnIiBmoiByADIAZqLwEAIAcvAQBqOwEAIAggAUEEciIGaiIHIAMgBmovAQAgBy8BAGo7AQAgCCABQQZyIgFqIgYgASADai8BACAGLwEAajsBACACQQRqIgJBgAJHDQALIAMgBUGgLGogCRAVQQAhAkEAIQMDQCAIIANBAXQiAWoiBiAFQaDgAGoiCyIHIAFqLwEAIAYvAQBqOwEAIAggAUECciIGaiIKIAYgB2ovAQAgCi8BAGo7AQAgCCABQQRyIgZqIgcgBiALai8BACAHLwEAajsBACAIIAFBBnIiAWoiBiABIAtqLwEAIAYvAQBqOwEAIANBBGoiA0GAAkcNAAsDQCAIIAJBAXRqIgEgAS4BACIDQb+dAWxBGnVB/2VsIANqOwEAIAEgAS4BAiIBQb+dAWxBGnVB/2VsIAFqOwECIAJBAmoiAkGAAkcNAAsgBUGgFGoiBiAFQaAwaiAFQaDUAGoQFSAFQaDgAGogBUGgNGogBBAVQQAhAwNAIAYgA0EBdCIBaiIHIAVBoOAAaiICIAFqLwEAIAcvAQBqOwEAIAYgAUECciIHaiIKIAIgB2ovAQAgCi8BAGo7AQAgBiABQQRyIgdqIgogAiAHai8BACAKLwEAajsBACAGIAFBBnIiAWoiByABIAJqLwEAIAcvAQBqOwEAIANBBGoiA0GAAkcNAAsgAiAFQaA4aiAJEBVBACEDQQAhAQNAIAYgAUEBdCICaiIHIAVBoOAAaiILIgogAmovAQAgBy8BAGo7AQAgBiACQQJyIgdqIg4gByAKai8BACAOLwEAajsBACAGIAJBBHIiB2oiCiAHIAtqLwEAIAovAQBqOwEAIAYgAkEGciICaiIHIAIgC2ovAQAgBy8BAGo7AQAgAUEEaiIBQYACRw0ACwNAIAYgA0EBdGoiASABLgEAIgJBv50BbEEadUH/ZWwgAmo7AQAgASABLgECIgFBv50BbEEadUH/ZWwgAWo7AQIgA0ECaiIDQYACRw0ACyAFQaAIaiAFQaDIAGogBUGg1ABqEBUgBUGg4ABqIAVBoMwAaiAEEBVBACEDA0AgA0EBdCIBIAVBoAhqIgJqIgcgBUGg4ABqIgQgAWovAQAgBy8BAGo7AQAgAiABQQJyIgdqIgogBCAHai8BACAKLwEAajsBACACIAFBBHIiB2oiCiAEIAdqLwEAIAovAQBqOwEAIAIgAUEGciIBaiICIAEgBGovAQAgAi8BAGo7AQAgA0EEaiIDQYACRw0ACyAEIAVBoNAAaiAJEBVBACEDQQAhAQNAIAFBAXQiAiAFQaAIaiIEaiIJIAVBoOAAaiILIgcgAmovAQAgCS8BAGo7AQAgBCACQQJyIglqIgogByAJai8BACAKLwEAajsBACAEIAJBBHIiCWoiByAJIAtqLwEAIAcvAQBqOwEAIAQgAkEGciICaiIEIAIgC2ovAQAgBC8BAGo7AQAgAUEEaiIBQYACRw0ACwNAIAVBoAhqIgIgA0EBdGoiASABLgEAIgRBv50BbEEadUH/ZWwgBGo7AQAgASABLgECIgFBv50BbEEadUH/ZWwgAWo7AQIgA0ECaiIDQYACRw0ACyAFQaAMahBZIAgQWSAGEFkgAhBZQQAhA0EAIQEDQCABQQF0IgIgBUGgDGoiBGoiCSAFQaA8aiILIgcgAmovAQAgCS8BAGo7AQAgBCACQQJyIglqIgogByAJai8BACAKLwEAajsBACAEIAJBBHIiCWoiByAJIAtqLwEAIAcvAQBqOwEAIAQgAkEGciICaiIEIAIgC2ovAQAgBC8BAGo7AQAgAUEEaiIBQYACRw0ACwNAIAggA0EBdCIBaiICIAEgDGovAQAgAi8BAGo7AQAgCCABQQJyIgJqIgQgAiAMai8BACAELwEAajsBACAIIAFBBHIiAmoiBCACIAxqLwEAIAQvAQBqOwEAIAggAUEGciIBaiICIAEgDGovAQAgAi8BAGo7AQAgA0EEaiIDQYACRw0AC0EAIQEDQCAGIAFBAXQiAmoiAyACIA1qLwEAIAMvAQBqOwEAIAYgAkECciIDaiIEIAMgDWovAQAgBC8BAGo7AQAgBiACQQRyIgNqIgQgAyANai8BACAELwEAajsBACAGIAJBBnIiAmoiAyACIA1qLwEAIAMvAQBqOwEAIAFBBGoiAUGAAkcNAAtBACEBA0AgAUEBdCICIAVBoAhqIgNqIgQgBUEgaiIHIgkgAmovAQAgBC8BAGo7AQAgAyACQQJyIgRqIgwgBCAJai8BACAMLwEAajsBACADIAJBBHIiBGoiCSAEIAdqLwEAIAkvAQBqOwEAIAMgAkEGciICaiIDIAIgB2ovAQAgAy8BAGo7AQAgAUEEaiIBQYACRw0AC0EAIQEDQCABQQF0IgIgBUGgCGoiA2oiBCAFQaAEaiIHIgkgAmovAQAgBC8BAGo7AQAgAyACQQJyIgRqIgwgBCAJai8BACAMLwEAajsBACADIAJBBHIiBGoiCSAEIAdqLwEAIAkvAQBqOwEAIAMgAkEGciICaiIDIAIgB2ovAQAgAy8BAGo7AQAgAUEEaiIBQYACRw0AC0EAIQIDQCAFQaAMaiACQQF0aiIBIAEuAQAiA0G/nQFsQRp1Qf9lbCADajsBACABIAEuAQIiAUG/nQFsQRp1Qf9lbCABajsBAiACQQJqIgJBgAJHDQALQQAhAgNAIAggAkEBdGoiASABLgEAIgNBv50BbEEadUH/ZWwgA2o7AQAgASABLgECIgFBv50BbEEadUH/ZWwgAWo7AQIgAkECaiICQYACRw0AC0EAIQIDQCAGIAJBAXRqIgEgAS4BACIDQb+dAWxBGnVB/2VsIANqOwEAIAEgAS4BAiIBQb+dAWxBGnVB/2VsIAFqOwECIAJBAmoiAkGAAkcNAAtBACECA0AgBUGgCGogAkEBdGoiASABLgEAIgNBv50BbEEadUH/ZWwgA2o7AQAgASABLgECIgFBv50BbEEadUH/ZWwgAWo7AQIgAkECaiICQYACRw0AC0EAIQIDQEEAIQEgBUGgDGogAkEBdGoiAyADLwEAIgQgBEGBGmsiBCAEwUEASBs7AQAgAyADLwECIgQgBEGBGmsiBCAEwUEASBs7AQIgAyADLwEEIgQgBEGBGmsiBCAEwUEASBs7AQQgAyADLwEGIgMgA0GBGmsiAyADwUEASBs7AQYgAkEEaiICQYACRw0ACwNAQQAhAiAIIAFBAXRqIgMgAy8BACIEIARBgRprIgQgBMFBAEgbOwEAIAMgAy8BAiIEIARBgRprIgQgBMFBAEgbOwECIAMgAy8BBCIEIARBgRprIgQgBMFBAEgbOwEEIAMgAy8BBiIDIANBgRprIgMgA8FBAEgbOwEGIAFBBGoiAUGAAkcNAAsDQEEAIQMgBiACQQF0aiIBIAEvAQAiBCAEQYEaayIEIATBQQBIGzsBACABIAEvAQIiBCAEQYEaayIEIATBQQBIGzsBAiABIAEvAQQiBCAEQYEaayIEIATBQQBIGzsBBCABIAEvAQYiASABQYEaayIBIAHBQQBIGzsBBiACQQRqIgJBgAJHDQALA0BBACECIAVBoAhqIANBAXRqIgEgAS8BACIEIARBgRprIgQgBMFBAEgbOwEAIAEgAS8BAiIEIARBgRprIgQgBMFBAEgbOwECIAEgAS8BBCIEIARBgRprIgQgBMFBAEgbOwEEIAEgAS8BBiIBIAFBgRprIgEgAcFBAEgbOwEGIANBBGoiA0GAAkcNAAsDQCAFQaAMaiACQQN0aiIDMgEEIREgAzIBAiESIAMyAQYhDyAAIAJBBWxqIgEgAzIBACIQQj+HQoEagyAQfEL/////D4NCgLjfzgB+QoCI+/8AfEIdiCIQPAAAIAEgDyAPQj+HQoEag3xC/////w+DQoC4384AfkKAiPv/AHwiD0IfiDwABCABIBCnQQh2QQNxIBIgEkI/h0KBGoN8Qv////8Pg0KAuN/OAH5CgIj7/wB8Qh2IpyIDQQJ0cjoAASABIA+nQRd2QcABcSARIBFCP4dCgRqDfEL/////D4NCgLjfzgB+QoCI+/8AfEIdiKciBEHwB3FBBHZyOgADIAEgBEEEdCADQcAHcUEGdnI6AAIgAkEBaiICQcAARw0ACyAAQcACaiEEQQAhAQNAIAggAUEDdGoiAzIBBCERIAMyAQIhEiADMgEGIQ8gBCABQQVsaiICIAMyAQAiEEI/h0KBGoMgEHxC/////w+DQoC4384AfkKAiPv/AHxCHYgiEDwAACACIA8gD0I/h0KBGoN8Qv////8Pg0KAuN/OAH5CgIj7/wB8Ig9CH4g8AAQgAiAQp0EIdkEDcSASIBJCP4dCgRqDfEL/////D4NCgLjfzgB+QoCI+/8AfEIdiKciA0ECdHI6AAEgAiAPp0EXdkHAAXEgESARQj+HQoEag3xC/////w+DQoC4384AfkKAiPv/AHxCHYinIglB8AdxQQR2cjoAAyACIAlBBHQgA0HAB3FBBnZyOgACIAFBAWoiAUHAAEcNAAsgAEGABWohCEEAIQIDQCAGIAJBA3RqIgMyAQQhESADMgECIRIgAzIBBiEPIAggAkEFbGoiASADMgEAIhBCP4dCgRqDIBB8Qv////8Pg0KAuN/OAH5CgIj7/wB8Qh2IIhA8AAAgASAPIA9CP4dCgRqDfEL/////D4NCgLjfzgB+QoCI+/8AfCIPQh+IPAAEIAEgEKdBCHZBA3EgEiASQj+HQoEag3xC/////w+DQoC4384AfkKAiPv/AHxCHYinIgNBAnRyOgABIAEgD6dBF3ZBwAFxIBEgEUI/h0KBGoN8Qv////8Pg0KAuN/OAH5CgIj7/wB8Qh2IpyIEQfAHcUEEdnI6AAMgASAEQQR0IANBwAdxQQZ2cjoAAiACQQFqIgJBwABHDQALIABBwAdqIQNBACEBA0AgBUGgCGogAUEEdGoiADIBAiERIAAyAQAhEiAAMgEGIQ8gADIBBCEQIAAyAQohFCAAMgEIIRUgAyABQQJ0aiICIAAyAQ4iE0I/h0KBGoMgE3xC/////w+DQvC+nQF+QoCL+/8AfEIZiKdB8AFxIAAyAQwiE0I/h0KBGoMgE3xC/////w+DQvC+nQF+QoCL+/8AfEIdiKdBD3FyOgADIAIgFCAUQj+HQoEag3xC/////w+DQvC+nQF+QoCL+/8AfEIZiKdB8AFxIBUgFUI/h0KBGoN8Qv////8Pg0Lwvp0BfkKAi/v/AHxCHYinQQ9xcjoAAiACIA8gD0I/h0KBGoN8Qv////8Pg0Lwvp0BfkKAi/v/AHxCGYinQfABcSAQIBBCP4dCgRqDfEL/////D4NC8L6dAX5CgIv7/wB8Qh2Ip0EPcXI6AAEgAiARIBFCP4dCgRqDfEL/////D4NC8L6dAX5CgIv7/wB8QhmIp0HwAXEgEiASQj+HQoEag3xC/////w+DQvC+nQF+QoCL+/8AfEIdiKdBD3FyOgAAIAFBAWoiAUEgRw0ACyAFQaDUAGpBgAwQByAFQaA8akGADBAHIAVBIGpBgAQQByAFQaAEakGABBAHIAVBoOQAaiQAC6ULAQt/IwBBsAZrIgUkACAFIAEpABg3AxggBSABKQAQNwMQIAUgASkACDcDCCAFIAEpAAA3AwADQCAFQQAgCiACGzoAISAFIApBACACGzoAICAFQbAEaiIBQQBByAH8CwAgAUGAPjsB5AEgAUEANgLgASABIAVCIhBvGiABIAVBMGpB+AMQPRogACAKQYAMbGohCUEDIQFBACEEQQAhAwNAIAVBMGogA2oiAy0AAiEGIAMtAAAgAy0AASIDQQh0QYAecXIiB0GAGk0EQCAJIARBAXRqIAc7AQAgBEEBaiEECwJAIARB/wFLDQAgBkEEdCADQQR2ciIDQYAaSw0AIAkgBEEBdGogAzsBACAEQQFqIQQLIARB/wFLIgZFBEAgASIDQQNqIQEgA0H2A0kNAQsLIAZFBEADQCAFQbAEaiAFQTBqQagBED0aQYACIARrIQcgCSAEQQF0aiEIQQAhA0EDIQZBACEBA0AgBUEwaiADaiIDLQACIQsgAy0AACADLQABIgNBCHRBgB5xciIMQYAaTQRAIAggAUEBdGogDDsBACABQQFqIQELAkAgASAHTw0AIAtBBHQgA0EEdnIiA0GAGksNACAIIAFBAXRqIAM7AQAgAUEBaiEBCyABIAdJBEAgBiIDQQNqIQYgA0GmAUkNAQsLIAEgBGoiBEGAAkkNAAsLIAVBASAKIAIbOgAhIAUgCkEBIAIbOgAgIAVBsARqIgFBAEHIAfwLACABQYA+OwHkASABQQA2AuABIAEgBUIiEG8aIAEgBUEwakH4AxA9GiAJQYAEaiEHQQAhAUEDIQNBACEEA0AgBUEwaiABaiIBLQACIQYgAS0AACABLQABIgFBCHRBgB5xciIIQYAaTQRAIAcgBEEBdGogCDsBACAEQQFqIQQLAkAgBEH/AUsNACAGQQR0IAFBBHZyIgFBgBpLDQAgByAEQQF0aiABOwEAIARBAWohBAsgBEH/AUsiBkUEQCADIgFBA2ohAyABQfYDSQ0BCwsgBkUEQANAIAVBsARqIAVBMGpBqAEQPRpBgAIgBGshCCAHIARBAXRqIQtBACEDQQMhBkEAIQEDQCAFQTBqIANqIgMtAAIhDCADLQAAIAMtAAEiA0EIdEGAHnFyIg1BgBpNBEAgCyABQQF0aiANOwEAIAFBAWohAQsCQCABIAhPDQAgDEEEdCADQQR2ciIDQYAaSw0AIAsgAUEBdGogAzsBACABQQFqIQELIAEgCEkEQCAGIgNBA2ohBiADQaYBSQ0BCwsgASAEaiIEQYACSQ0ACwsgBUECIAogAhs6ACEgBSAKQQIgAhs6ACAgBUGwBGoiAUEAQcgB/AsAIAFBgD47AeQBIAFBADYC4AEgASAFQiIQbxogASAFQTBqQfgDED0aIAlBgAhqIQlBACEBQQMhA0EAIQQDQCAFQTBqIAFqIgEtAAIhBiABLQAAIAEtAAEiAUEIdEGAHnFyIgdBgBpNBEAgCSAEQQF0aiAHOwEAIARBAWohBAsCQCAEQf8BSw0AIAZBBHQgAUEEdnIiAUGAGksNACAJIARBAXRqIAE7AQAgBEEBaiEECyAEQf8BSyIGRQRAIAMiAUEDaiEDIAFB9gNJDQELCyAGRQRAA0AgBUGwBGogBUEwakGoARA9GkGAAiAEayEHIAkgBEEBdGohCEEAIQNBAyEGQQAhAQNAIAVBMGogA2oiAy0AAiELIAMtAAAgAy0AASIDQQh0QYAecXIiDEGAGk0EQCAIIAFBAXRqIAw7AQAgAUEBaiEBCwJAIAEgB08NACALQQR0IANBBHZyIgNBgBpLDQAgCCABQQF0aiADOwEAIAFBAWohAQsgASAHSQRAIAYiA0EDaiEGIANBpgFJDQELCyABIARqIgRBgAJJDQALCyAKQQFqIgpBA0cNAAsgBUGwBmokAAsFAEGoAQsIACAAIAEQWwsFAEGIAQsFAEGAAwvBBwIDfwR+QX8hCAJAIAFBwQBrIglBQEkNACAFQcAASw0AAn8jACIIIQogCEGABGtBQHEiCCQAAkAgAkUgA0IAUnENACAARQ0AIAlB/wFxQb8BTQ0AIARFIglBACAFGw0AIAVBwQBPDQACQCAFBEAgCQ0CAn4gBkUEQEKf2PnZwpHagpt/IQtC0YWa7/rPlIfRAAwBCyAGKQAIQp/Y+dnCkdqCm3+FIQsgBikAAELRhZrv+s+Uh9EAhQshDQJ+IAdFBEBC+cL4m5Gjs/DbACEMQuv6htq/tfbBHwwBCyAHKQAIQvnC+JuRo7Pw2wCFIQwgBykAAELr+obav7X2wR+FCyEOIAhBQGtBAEGlAvwLACAIIAw3AzggCCAONwMwIAggCzcDKCAIIA03AyAgCELx7fT4paf9p6V/NwMYIAhCq/DT9K/uvLc8NwMQIAhCu86qptjQ67O7fzcDCCAIIAGtIAWtQgiGhEKIkveV/8z5hOoAhTcDAEGAASEGQYABIAVrIgcEQCAIQYADaiAFakEAIAf8CwALIAUEQCAIQYADaiAEIAX8CgAACyAIQeAAaiAIQYADaiIEQYAB/AoAACAIQYABNgLgAiAEQYABEAcMAQsCfiAGRQRAQp/Y+dnCkdqCm38hC0LRhZrv+s+Uh9EADAELIAYpAAhCn9j52cKR2oKbf4UhCyAGKQAAQtGFmu/6z5SH0QCFCyENAn4gB0UEQEL5wvibkaOz8NsAIQxC6/qG2r+19sEfDAELIAcpAAhC+cL4m5Gjs/DbAIUhDCAHKQAAQuv6htq/tfbBH4ULIQ5BACEGIAhBQGtBAEGlAvwLACAIIAw3AzggCCAONwMwIAggCzcDKCAIIA03AyAgCELx7fT4paf9p6V/NwMYIAhCq/DT9K/uvLc8NwMQIAhCu86qptjQ67O7fzcDCCAIIAGtQoiS95X/zPmE6gCFNwMACyADQgBSBEAgCEHgAGohBUGAAiAGayIErSILIANUBEAgCEHgAWohBwNAIAQEQCAFIAZqIAIgBPwKAAALIAggCCgC4AIgBGo2AuACIAggCCkDQCIMQoABfDcDQCAIIAgpA0ggDEL/flatfDcDSCAIIAUQXiAFIAdBgAH8CgAAIAggCCgC4AIiCUGAAWsiBjYC4AIgAiAEaiECIAMgC30iA0GAAyAJayIErSILVg0ACwsgA6ciBARAIAUgBmogAiAE/AoAAAsgCCAIKALgAiAEajYC4AILIAggACABEJ8BGiAKJABBAAwBCxAMAAshCAsgCAsKACAAIAEgAhAIC+YDAQJ/IwBBwAFrIgMkACADQgA3A4ABIANCADcDiAEgA0IANwOQASADQgA3A5gBIANCADcDYCADQgA3A2ggA0IANwNwIANCADcDeCADQZC3AikDADcDoAEgA0GYtwIpAwA3A6gBIANBoLcCKQMANwOwASADQai3AikDADcDuAEgAyACKQAANwNAIAMgAikACDcDSCADIAIpABA3A1AgAyACKQAYNwNYIANBgAFqIgIgA0FAayIEEKEBIAIQJiADIAMpA5gBNwMYIAMgAykDkAE3AxAgAyADKQOIATcDCCADIAMpA4ABNwMAIANCADcDeCADQgA3A3AgA0IANwNoIANCADcDYCADIAEpAAA3A0AgAyABKQAINwNIIAMgASkAEDcDUCADIAEpABg3A1ggA0IANwM4IANCADcDMCADQgA3AyggA0IANwMgIAQgAxCeAiADIAMpA3g3A7gBIAMgAykDcDcDsAEgAyADKQNoNwOoASADIAMpA2A3A6ABIAMgAykDWDcDmAEgAyADKQNQNwOQASADIAMpA0g3A4gBIAMgAykDQDcDgAEgAhAmIAAgAykDmAE3ABggACADKQOQATcAECAAIAMpA4gBNwAIIAAgAykDgAE3AAAgAkHAABAHIANBwAFqJAALlwEBAX8jAEFAaiICJAAgAiABKQA4NwM4IAIgASkAMDcDMCACIAEpACg3AyggAiABKQAgNwMgIAIgASkAGDcDGCACIAEpABA3AxAgAiABKQAINwMIIAIgASkAADcDACACECYgACACKQMYNwAYIAAgAikDEDcAECAAIAIpAwg3AAggACACKQMANwAAIAJBwAAQByACQUBrJAALvQIBAX8jAEHAAWsiAyQAIANCADcDYCADQgA3A2ggA0IANwNwIANCADcDeCADIAEpAAA3A0AgAyABKQAINwNIIAMgASkAEDcDUCADIAEpABg3A1ggA0IANwMgIANCADcDKCADQgA3AzAgA0IANwM4IAMgAikAADcDACADIAIpAAg3AwggAyACKQAQNwMQIAMgAikAGDcDGCADQUBrIAMQngIgAyADKQN4NwO4ASADIAMpA3A3A7ABIAMgAykDaDcDqAEgAyADKQNgNwOgASADIAMpA1g3A5gBIAMgAykDUDcDkAEgAyADKQNINwOIASADIAMpA0A3A4ABIANBgAFqIgEQJiAAIAMpA5gBNwAYIAAgAykDkAE3ABAgACADKQOIATcACCAAIAMpA4ABNwAAIAFBwAAQByADQcABaiQAC+UBAQF/IwBBgAFrIgIkACACQgA3A0AgAkIANwNIIAJCADcDUCACQgA3A1ggAkEBOgBAIAJCADcDICACQgA3AyggAkIANwMwIAJCADcDOCACQZC3AikDADcDYCACQZi3AikDADcDaCACQaC3AikDADcDcCACQai3AikDADcDeCACIAEpABg3AxggAiABKQAQNwMQIAIgASkACDcDCCACIAEpAAA3AwAgAkFAayIBIAIQoQEgARAmIAAgAikDWDcAGCAAIAIpA1A3ABAgACACKQNINwAIIAAgAikDQDcAACACQYABaiQAC94BAQF/IwBBgAFrIgIkACACQgA3A0AgAkIANwNIIAJCADcDUCACQgA3A1ggAkIANwMgIAJCADcDKCACQgA3AzAgAkIANwM4IAJBkLcCKQMANwNgIAJBmLcCKQMANwNoIAJBoLcCKQMANwNwIAJBqLcCKQMANwN4IAIgASkAADcDACACIAEpAAg3AwggAiABKQAQNwMQIAIgASkAGDcDGCACQUBrIgEgAhChASABECYgACACKQNYNwAYIAAgAikDUDcAECAAIAIpA0g3AAggACACKQNANwAAIAJBgAFqJAALzwsBC38jAEHgBWsiAiQAIAJBwAVqIgcgASABEAggAkHgAWoiBiABIAcQCCACQaAFaiIEIAEgBhAIIAJBgAVqIgUgBCAEEAggAkGgA2oiCSAHIAUQCCACQcACaiIHIAEgCRAIIAJB4ARqIgMgBSAFEAggAkGgAmoiBSAHIAcQCCACQcAEaiIIIAkgBRAIIAJBwANqIgwgAyAFEAggAkGgBGoiCiAIIAgQCCACQYADaiIIIAMgChAIIAJB4AJqIgsgBiAIEAggAkHAAWoiBiADIAsQCCACQaABaiIDIAQgBhAIIAJB4ABqIAQgAxAIIAJBgARqIgYgCiALEAggAkHgA2oiAyAEIAYQCCACQYACaiIGIAwgAxAIIAJBgAFqIAUgBhAIIAJBQGsiBSAIIAMQCCACQSBqIgMgBCAFEAggAiAJIAMQCCAAIAcgAhAIQQAhBANAIAAgACAAEAggBEEBaiIEQf4ARw0ACyAAIAAgAkHgAmoQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgAkHABWoQCCAAIAAgAhAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAJBoAFqEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAIQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAJBgAJqEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACACQUBrEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAJB4ABqEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAJBwAJqEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACACQYAEahAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAJBwAFqEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAJB4ANqEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgAhAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgAkGAAWoQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAAQCCAAIAAgABAIIAAgACAAEAggACAAIAJBIGoQCCACQeAFaiQAQQAgAUEgEBtrCygAA0AgAEEgEBYgACAALQAfQR9xOgAfIAAQqAFFDQAgAEEgEBsNAAsLCgAgACABIAIQOQsaAQF/EDpB3MgCKAIAKAIIIgAEQCAAERQACwsoACACQoCAgIAQWgRAEAwACyAAIAEgAiADQQEgBEHkvQIoAgAREQAaCwQAQQwLqwYBFH8jAEHgAWsiAyQAIAIoAhAhBCACQUBrIgUoAgAhBiACKAJQIQkgAigCICEKIAIoAjAhCyACKAIUIQcgAigCRCEMIAIoAlQhDSABKAAEIQ4gAigCJCEPIAIoAjQhECACKAIYIQggAigCSCERIAIoAlghEiABKAAIIRMgAigCKCEUIAIoAjghFSABKAAAIRYgACACKAIsIAIoAjxxIAIoAhwgAigCTCACKAJcIAEoAAxzc3NzIgE2AAwgACAUIBVxIAggESASIBNzc3NzIgg2AAggACAPIBBxIAcgDCANIA5zc3NzIgc2AAQgACAKIAtxIAQgBiAJIBZzc3NzIgA2AAAgAyACKQJYNwPYASADIAIpAlA3A9ABIAMgBSkCADcDsAEgAyACKQJINwO4ASADIAIpAlA3A6ABIAMgAikCWDcDqAEgA0HAAWoiBCADQbABaiADQaABahAGIAIgAykCyAE3AlggAiADKQLAATcCUCADIAIpAjA3A5ABIAMgAikCODcDmAEgAyAFKQIANwOAASADIAIpAkg3A4gBIAQgA0GQAWogA0GAAWoQBiACIAMpAsgBNwJIIAUgAykCwAE3AgAgAyACKQIgNwNwIAMgAikCKDcDeCADIAIpAjA3A2AgAyACKQI4NwNoIAQgA0HwAGogA0HgAGoQBiACIAMpAsgBNwI4IAIgAykCwAE3AjAgAyACKQIQNwNQIAMgAikCGDcDWCADIAIpAiA3A0AgAyACKQIoNwNIIAQgA0HQAGogA0FAaxAGIAIgAykCyAE3AiggAiADKQLAATcCICADIAIpAgA3AzAgAyACKQIINwM4IAMgAikCEDcDICADIAIpAhg3AyggBCADQTBqIANBIGoQBiACIAMpAsgBNwIYIAIgAykCwAE3AhAgAyADKQPQATcDECADIAMpA9gBNwMYIAMgAikCADcDACADIAIpAgg3AwggBCADQRBqIAMQBiADKALAASEFIAMoAsQBIQQgAygCyAEhBiACIAMoAswBIAFzNgIMIAIgBiAIczYCCCACIAQgB3M2AgQgAiAAIAVzNgIAIANB4AFqJAAL+QgBE38jAEHgAWsiBSQAIAQoAjwgA0IdiKdzIQkgBCgCOCADp0EDdHMhCiAEKAI0IAJCHYincyENIAQoAjAgAqdBA3RzIQ8gBEFAayEGA0AgBSAEKQJYNwPYASAFIAQpAlA3A9ABIAUgBikCADcDsAEgBSAGKQIINwO4ASAFIAQpAlA3A6ABIAUgBCkCWDcDqAEgBUHAAWoiByAFQbABaiAFQaABahAGIAQgBSkCyAE3AlggBCAFKQLAATcCUCAFIAQpAjA3A5ABIAUgBCkCODcDmAEgBSAGKQIANwOAASAFIAYpAgg3A4gBIAcgBUGQAWogBUGAAWoQBiAGIAUpAsgBNwIIIAYgBSkCwAE3AgAgBSAEKQIgNwNwIAUgBCkCKDcDeCAFIAQpAjA3A2AgBSAEKQI4NwNoIAcgBUHwAGogBUHgAGoQBiAEIAUpAsgBNwI4IAQgBSkCwAE3AjAgBSAEKQIQNwNQIAUgBCkCGDcDWCAFIAQpAiA3A0AgBSAEKQIoNwNIIAcgBUHQAGogBUFAaxAGIAQgBSkCyAE3AiggBCAFKQLAATcCICAFIAQpAgA3AzAgBSAEKQIINwM4IAUgBCkCEDcDICAFIAQpAhg3AyggByAFQTBqIAVBIGoQBiAEIAUpAsgBNwIYIAQgBSkCwAE3AhAgBSAFKQPQATcDECAFIAUpA9gBNwMYIAUgBCkCADcDACAFIAQpAgg3AwggByAFQRBqIAUQBiAFKALAASEHIAUoAsQBIQsgBSgCyAEhDCAEIAkgBSgCzAFzIg42AgwgBCAKIAxzIgw2AgggBCALIA1zIgs2AgQgBCAHIA9zIgc2AgAgCEEBaiIIQQdHDQALAkACQAJAAkAgAUEQaw4RAAICAgICAgICAgICAgICAgECCyAEKAIQIQEgBCgCMCEGIAQoAiAhCCAEKAJQIQkgBEFAaygCACEKIAQoAhQhDSAEKAI0IQ8gBCgCJCEQIAQoAlQhESAEKAJEIRIgBCgCGCETIAQoAjghFCAEKAIoIRUgBCgCWCEWIAQoAkghFyAAIAQoAhwgBCgCPCAEKAIsIAQoAlwgBCgCTHNzc3MgDnM2AAwgACATIBQgFSAWIBdzc3NzIAxzNgAIIAAgDSAPIBAgESASc3NzcyALczYABCAAIAEgBiAIIAkgCnNzc3MgB3M2AAAMAgsgBCgCICEBIAQoAhAhBiAEKAIkIQggBCgCFCEJIAQoAighCiAEKAIYIQ0gACAEKAIsIAQoAhxzIA5zNgAMIAAgCiANcyAMczYACCAAIAggCXMgC3M2AAQgACABIAZzIAdzNgAAIAQoAjAhASAEKAJQIQYgBEFAaygCACEIIAQoAjQhDiAEKAJUIQwgBCgCRCELIAQoAjghByAEKAJYIQkgBCgCSCEKIAAgBCgCPCAEKAJcIAQoAkxzczYAHCAAIAcgCSAKc3M2ABggACAOIAsgDHNzNgAUIAAgASAGIAhzczYAEAwBCyABRQ0AIABBACAB/AsACyAFQeABaiQAC6UGARR/IwBB4AFrIgMkACACKAIQIQUgAkFAayIEKAIAIQkgAigCUCEKIAIoAiAhCyACKAIwIQwgASgABCEGIAIoAhQhDSACKAJEIQ4gAigCVCEPIAIoAiQhECACKAI0IREgASgACCEHIAIoAhghEiACKAJIIRMgAigCWCEUIAIoAighFSACKAI4IRYgASgAACEIIAAgASgADCIBIAIoAiwgAigCPHEgAigCHCACKAJcIAIoAkxzc3NzNgAMIAAgByAVIBZxIBIgEyAUc3NzczYACCAAIAYgECARcSANIA4gD3Nzc3M2AAQgACAIIAsgDHEgBSAJIApzc3NzNgAAIAMgAikCWDcD2AEgAyACKQJQNwPQASADIAQpAgA3A7ABIAMgAikCSDcDuAEgAyACKQJQNwOgASADIAIpAlg3A6gBIANBwAFqIgAgA0GwAWogA0GgAWoQBiACIAMpAsgBNwJYIAIgAykCwAE3AlAgAyACKQIwNwOQASADIAIpAjg3A5gBIAMgBCkCADcDgAEgAyACKQJINwOIASAAIANBkAFqIANBgAFqEAYgAiADKQLIATcCSCAEIAMpAsABNwIAIAMgAikCIDcDcCADIAIpAig3A3ggAyACKQIwNwNgIAMgAikCODcDaCAAIANB8ABqIANB4ABqEAYgAiADKQLIATcCOCACIAMpAsABNwIwIAMgAikCEDcDUCADIAIpAhg3A1ggAyACKQIgNwNAIAMgAikCKDcDSCAAIANB0ABqIANBQGsQBiACIAMpAsgBNwIoIAIgAykCwAE3AiAgAyACKQIANwMwIAMgAikCCDcDOCADIAIpAhA3AyAgAyACKQIYNwMoIAAgA0EwaiADQSBqEAYgAiADKQLIATcCGCACIAMpAsABNwIQIAMgAykD0AE3AxAgAyADKQPYATcDGCADIAIpAgA3AwAgAyACKQIINwMIIAAgA0EQaiADEAYgAygCwAEhACADKALEASEEIAMoAsgBIQUgAiABIAMoAswBczYCDCACIAUgB3M2AgggAiAEIAZzNgIEIAIgACAIczYCACADQeABaiQAC6UJAQ1/IwBBoANrIgIkACAAKAAQIQYgACgAFCEHIAAoABghCCAAKAAcIQkgACgABCEEIAAoAAghBSAAKAAMIQogACgAACELIAIgASkCWDcDmAMgAiABKQJQNwOQAyACIAFBQGsiACkCADcD8AIgAiABKQJINwP4AiACIAEpAlA3A+ACIAIgASkCWDcD6AIgAkGAA2oiAyACQfACaiACQeACahAGIAEgAikCiAM3AlggASACKQKAAzcCUCACIAEpAjA3A9ACIAIgASkCODcD2AIgAiAAKQIANwPAAiACIAEpAkg3A8gCIAMgAkHQAmogAkHAAmoQBiABIAIpAogDNwJIIAAgAikCgAM3AgAgAiABKQIgNwOwAiACIAEpAig3A7gCIAIgASkCMDcDoAIgAiABKQI4NwOoAiADIAJBsAJqIAJBoAJqEAYgASACKQKIAzcCOCABIAIpAoADNwIwIAIgASkCEDcDkAIgAiABKQIYNwOYAiACIAEpAiA3A4ACIAIgASkCKDcDiAIgAyACQZACaiACQYACahAGIAEgAikCiAM3AiggASACKQKAAzcCICACIAEpAgA3A/ABIAIgASkCCDcD+AEgAiABKQIQNwPgASACIAEpAhg3A+gBIAMgAkHwAWogAkHgAWoQBiABIAIpAogDNwIYIAEgAikCgAM3AhAgAiACKQOQAzcD0AEgAiACKQOYAzcD2AEgAiABKQIANwPAASACIAEpAgg3A8gBIAMgAkHQAWogAkHAAWoQBiACKAKAAyEMIAIoAoQDIQ0gAigCiAMhDiABIAogAigCjANzNgIMIAEgBSAOczYCCCABIAQgDXM2AgQgASALIAxzNgIAIAIgASkCWDcDmAMgAiABKQJQNwOQAyACIAApAgA3A7ABIAIgASkCSDcDuAEgAiABKQJQNwOgASACIAEpAlg3A6gBIAMgAkGwAWogAkGgAWoQBiABIAIpAogDNwJYIAEgAikCgAM3AlAgAiABKQIwNwOQASACIAEpAjg3A5gBIAIgACkCADcDgAEgAiABKQJINwOIASADIAJBkAFqIAJBgAFqEAYgASACKQKIAzcCSCAAIAIpAoADNwIAIAIgASkCIDcDcCACIAEpAig3A3ggAiABKQIwNwNgIAIgASkCODcDaCADIAJB8ABqIAJB4ABqEAYgASACKQKIAzcCOCABIAIpAoADNwIwIAIgASkCEDcDUCACIAEpAhg3A1ggAiABKQIgNwNAIAIgASkCKDcDSCADIAJB0ABqIAJBQGsQBiABIAIpAogDNwIoIAEgAikCgAM3AiAgAiABKQIANwMwIAIgASkCCDcDOCACIAEpAhA3AyAgAiABKQIYNwMoIAMgAkEwaiACQSBqEAYgASACKQKIAzcCGCABIAIpAoADNwIQIAIgAikDkAM3AxAgAiACKQOYAzcDGCACIAEpAgA3AwAgAiABKQIINwMIIAMgAkEQaiACEAYgAigCgAMhACACKAKEAyEEIAIoAogDIQUgASAJIAIoAowDczYCDCABIAUgCHM2AgggASAEIAdzNgIEIAEgACAGczYCACACQaADaiQAC94UARV/IwBBoAZrIgMkACABKAAEIQggASgACCEJIAEoAAwhCiABKAAQIQsgASgAFCEMIAEoABghDSABKAAcIQ4gACgABCEPIAAoAAghECAAKAAMIREgACgAECESIAAoABQhEyAAKAAYIRQgACgAHCEVIAEoAAAhFiACQUBrIgEgACgAACIAQYCChBBzNgIAIAJClcTcyYWy+rziADcCOCACQoCChJCwoIGEDTcCMCACQqCixJG0rq2UXTcCKCACQtv74KjVzfCXcTcCICACIAAgFnMiFjYCACACIBVB8+qi6X1zNgJcIAIgFEGgosSRBHM2AlggAiATQe2Ev4l/czYCVCACIBJB2/vgqAVzNgJQIAIgEUGQ0+eTBnM2AkwgAiAQQZXE3MkFczYCSCACIA9Bg4qg6ABzNgJEIAIgDiAVcyIONgIcIAIgDSAUcyINNgIYIAIgDCATcyIMNgIUIAIgCyAScyILNgIQIAIgCiARcyIKNgIMIAIgCSAQcyIJNgIIIAIgCCAPcyIXNgIEQQAhCANAIAMgAikCWDcDmAYgAyACKQJQNwOQBiADIAEpAgA3A/AFIAMgASkCCDcD+AUgAyACKQJQNwPgBSADIAIpAlg3A+gFIANBgAZqIgQgA0HwBWogA0HgBWoQBiACIAMpAogGNwJYIAIgAykCgAY3AlAgAyACKQIwNwPQBSADIAIpAjg3A9gFIAMgASkCADcDwAUgAyABKQIINwPIBSAEIANB0AVqIANBwAVqEAYgASADKQKIBjcCCCABIAMpAoAGNwIAIAMgAikCIDcDsAUgAyACKQIoNwO4BSADIAIpAjA3A6AFIAMgAikCODcDqAUgBCADQbAFaiADQaAFahAGIAIgAykCiAY3AjggAiADKQKABjcCMCADIAIpAhA3A5AFIAMgAikCGDcDmAUgAyACKQIgNwOABSADIAIpAig3A4gFIAQgA0GQBWogA0GABWoQBiACIAMpAogGNwIoIAIgAykCgAY3AiAgAyACKQIANwPwBCADIAIpAgg3A/gEIAMgAikCEDcD4AQgAyACKQIYNwPoBCAEIANB8ARqIANB4ARqEAYgAiADKQKIBjcCGCACIAMpAoAGNwIQIAMgAykDkAY3A9AEIAMgAykDmAY3A9gEIAMgAikCADcDwAQgAyACKQIINwPIBCAEIANB0ARqIANBwARqEAYgAygCgAYhBSADKAKEBiEGIAMoAogGIQcgAiADKAKMBiARczYCDCACIAcgEHM2AgggAiAGIA9zNgIEIAIgACAFczYCACADIAIpAlg3A5gGIAMgAikCUDcDkAYgAyABKQIANwOwBCADIAEpAgg3A7gEIAMgAikCWDcDqAQgAyACKQJQNwOgBCAEIANBsARqIANBoARqEAYgAiADKQKIBjcCWCACIAMpAoAGNwJQIAMgAikCMDcDkAQgAyACKQI4NwOYBCADIAEpAgA3A4AEIAMgASkCCDcDiAQgBCADQZAEaiADQYAEahAGIAEgAykCiAY3AgggASADKQKABjcCACADIAIpAiA3A/ADIAMgAikCKDcD+AMgAyACKQIwNwPgAyADIAIpAjg3A+gDIAQgA0HwA2ogA0HgA2oQBiACIAMpAogGNwI4IAIgAykCgAY3AjAgAyACKQIQNwPQAyADIAIpAhg3A9gDIAMgAikCIDcDwAMgAyACKQIoNwPIAyAEIANB0ANqIANBwANqEAYgAiADKQKIBjcCKCACIAMpAoAGNwIgIAMgAikCADcDsAMgAyACKQIINwO4AyADIAIpAhA3A6ADIAMgAikCGDcDqAMgBCADQbADaiADQaADahAGIAIgAykCiAY3AhggAiADKQKABjcCECADIAMpA5AGNwOQAyADIAMpA5gGNwOYAyADIAIpAgA3A4ADIAMgAikCCDcDiAMgBCADQZADaiADQYADahAGIAMoAoAGIQUgAygChAYhBiADKAKIBiEHIAIgAygCjAYgFXM2AgwgAiAHIBRzNgIIIAIgBiATczYCBCACIAUgEnM2AgAgAyACKQJYNwOYBiADIAIpAlA3A5AGIAMgASkCADcD8AIgAyABKQIINwP4AiADIAIpAlg3A+gCIAMgAikCUDcD4AIgBCADQfACaiADQeACahAGIAIgAykCiAY3AlggAiADKQKABjcCUCADIAIpAjA3A9ACIAMgAikCODcD2AIgAyABKQIANwPAAiADIAEpAgg3A8gCIAQgA0HQAmogA0HAAmoQBiABIAMpAogGNwIIIAEgAykCgAY3AgAgAyACKQIgNwOwAiADIAIpAig3A7gCIAMgAikCMDcDoAIgAyACKQI4NwOoAiAEIANBsAJqIANBoAJqEAYgAiADKQKIBjcCOCACIAMpAoAGNwIwIAMgAikCEDcDkAIgAyACKQIYNwOYAiADIAIpAiA3A4ACIAMgAikCKDcDiAIgBCADQZACaiADQYACahAGIAIgAykCiAY3AiggAiADKQKABjcCICADIAIpAgA3A/ABIAMgAikCCDcD+AEgAyACKQIQNwPgASADIAIpAhg3A+gBIAQgA0HwAWogA0HgAWoQBiACIAMpAogGNwIYIAIgAykCgAY3AhAgAyADKQOQBjcD0AEgAyADKQOYBjcD2AEgAyACKQIANwPAASADIAIpAgg3A8gBIAQgA0HQAWogA0HAAWoQBiADKAKABiEFIAMoAoQGIQYgAygCiAYhByACIAMoAowGIApzNgIMIAIgByAJczYCCCACIAYgF3M2AgQgAiAFIBZzNgIAIAMgAikCWDcDmAYgAyACKQJQNwOQBiADIAEpAgA3A7ABIAMgASkCCDcDuAEgAyACKQJYNwOoASADIAIpAlA3A6ABIAQgA0GwAWogA0GgAWoQBiACIAMpAogGNwJYIAIgAykCgAY3AlAgAyACKQIwNwOQASADIAIpAjg3A5gBIAMgASkCADcDgAEgAyABKQIINwOIASAEIANBkAFqIANBgAFqEAYgASADKQKIBjcCCCABIAMpAoAGNwIAIAMgAikCIDcDcCADIAIpAig3A3ggAyACKQIwNwNgIAMgAikCODcDaCAEIANB8ABqIANB4ABqEAYgAiADKQKIBjcCOCACIAMpAoAGNwIwIAMgAikCEDcDUCADIAIpAhg3A1ggAyACKQIgNwNAIAMgAikCKDcDSCAEIANB0ABqIANBQGsQBiACIAMpAogGNwIoIAIgAykCgAY3AiAgAyACKQIANwMwIAMgAikCCDcDOCADIAIpAhA3AyAgAyACKQIYNwMoIAQgA0EwaiADQSBqEAYgAiADKQKIBjcCGCACIAMpAoAGNwIQIAMgAykDkAY3AxAgAyADKQOYBjcDGCADIAIpAgA3AwAgAyACKQIINwMIIAQgA0EQaiADEAYgAygCgAYhBSADKAKEBiEGIAMoAogGIQcgAiADKAKMBiAOczYCDCACIAcgDXM2AgggAiAGIAxzNgIEIAIgBSALczYCACAIQQFqIghBBEcNAAsgA0GgBmokAAsEAEFfC2MBBX8DQCAAIANqIgIgASADai0AACAEIAItAABqaiICOgAAIAAgA0EBciIEaiIGIAEgBGotAAAgBi0AACACQQh2amoiAjoAACACQQh2IQQgA0ECaiEDIAVBAmoiBUEgRw0ACwuRCQEefyMAQaACayIDJAAgAigCECEOIAIoAjAhDyACKAIUIRAgASgABCERIAIoAjQhEiACKAIYIRMgASgACCEUIAIoAjghFSACKAIcIQggASgADCEWIAIoAjwhFyACKAIgIQUgAigCUCEJIAEoABAhGCACKAJwIRkgAigCYCEEIAIoAiQhBiACKAJUIQogASgAFCEaIAIoAnQhGyACKAJkIQwgAigCKCEHIAIoAlghCyABKAAYIRwgAigCeCEdIAIoAmghDSABKAAAIR4gACACKAIsIh8gAigCbCIgIAIoAnxxIAIoAlwgASgAHHNzcyIBNgAcIAAgByANIB1xIAsgHHNzcyILNgAYIAAgBiAMIBtxIAogGnNzcyIKNgAUIAAgBSAEIBlxIAkgGHNzcyIJNgAQIAAgICAXIB9xIAggFnNzcyIINgAMIAAgDSAHIBVxIBMgFHNzcyIHNgAIIAAgDCAGIBJxIBAgEXNzcyIGNgAEIAAgBCAFIA9xIA4gHnNzcyIFNgAAIAMgAikCeDcDmAIgAyACKQJwNwOQAiADIAIpAmA3A/ABIAMgAikCaDcD+AEgAyACKQJwNwPgASADIAIpAng3A+gBIANBgAJqIgQgA0HwAWogA0HgAWoQBiACIAMpAogCNwJ4IAIgAykCgAI3AnAgAyACKQJQNwPQASADIAIpAlg3A9gBIAMgAikCYDcDwAEgAyACKQJoNwPIASAEIANB0AFqIANBwAFqEAYgAiADKQKIAjcCaCACIAMpAoACNwJgIAMgAkFAayIAKQIANwOwASADIAIpAkg3A7gBIAMgAikCUDcDoAEgAyACKQJYNwOoASAEIANBsAFqIANBoAFqEAYgAiADKQKIAjcCWCACIAMpAoACNwJQIAMgAikCMDcDkAEgAyACKQI4NwOYASADIAApAgA3A4ABIAMgAikCSDcDiAEgBCADQZABaiADQYABahAGIAIgAykCiAI3AkggACADKQKAAjcCACADIAIpAiA3A3AgAyACKQIoNwN4IAMgAikCMDcDYCADIAIpAjg3A2ggBCADQfAAaiADQeAAahAGIAIgAykCiAI3AjggAiADKQKAAjcCMCADIAIpAhA3A1AgAyACKQIYNwNYIAMgAikCIDcDQCADIAIpAig3A0ggBCADQdAAaiADQUBrEAYgAiADKQKIAjcCKCACIAMpAoACNwIgIAMgAikCADcDMCADIAIpAgg3AzggAyACKQIQNwMgIAMgAikCGDcDKCAEIANBMGogA0EgahAGIAIgAykCiAI3AhggAiADKQKAAjcCECADIAMpA5ACNwMQIAMgAykDmAI3AxggAyACKQIANwMAIAMgAikCCDcDCCAEIANBEGogAxAGIAIgAykCiAI3AgggAiADKQKAAjcCACACIAIoAgwgCHM2AgwgAiACKAIIIAdzNgIIIAIgAigCBCAGczYCBCACIAIoAgAgBXM2AgAgACAAKAIAIAlzNgIAIAIgAigCRCAKczYCRCACIAIoAkggC3M2AkggAiACKAJMIAFzNgJMIANBoAJqJAALsAsBF38jAEGgAmsiBSQAIAQoAiwgA0IdiKdzIQggBCgCKCADp0EDdHMhCSAEKAIkIAJCHYincyEKIAQoAiAgAqdBA3RzIQsgBEFAayEGA0AgBSAEKQJ4NwOYAiAFIAQpAnA3A5ACIAUgBCkCYDcD8AEgBSAEKQJoNwP4ASAFIAQpAnA3A+ABIAUgBCkCeDcD6AEgBUGAAmoiByAFQfABaiAFQeABahAGIAQgBSkCiAI3AnggBCAFKQKAAjcCcCAFIAQpAlA3A9ABIAUgBCkCWDcD2AEgBSAEKQJgNwPAASAFIAQpAmg3A8gBIAcgBUHQAWogBUHAAWoQBiAEIAUpAogCNwJoIAQgBSkCgAI3AmAgBSAGKQIANwOwASAFIAYpAgg3A7gBIAUgBCkCUDcDoAEgBSAEKQJYNwOoASAHIAVBsAFqIAVBoAFqEAYgBCAFKQKIAjcCWCAEIAUpAoACNwJQIAUgBCkCMDcDkAEgBSAEKQI4NwOYASAFIAYpAgA3A4ABIAUgBikCCDcDiAEgByAFQZABaiAFQYABahAGIAYgBSkCiAI3AgggBiAFKQKAAjcCACAFIAQpAiA3A3AgBSAEKQIoNwN4IAUgBCkCMDcDYCAFIAQpAjg3A2ggByAFQfAAaiAFQeAAahAGIAQgBSkCiAI3AjggBCAFKQKAAjcCMCAFIAQpAhA3A1AgBSAEKQIYNwNYIAUgBCkCIDcDQCAFIAQpAig3A0ggByAFQdAAaiAFQUBrEAYgBCAFKQKIAjcCKCAEIAUpAoACNwIgIAUgBCkCADcDMCAFIAQpAgg3AzggBSAEKQIQNwMgIAUgBCkCGDcDKCAHIAVBMGogBUEgahAGIAQgBSkCiAI3AhggBCAFKQKAAjcCECAFIAUpA5ACNwMQIAUgBSkDmAI3AxggBSAEKQIANwMAIAUgBCkCCDcDCCAHIAVBEGogBRAGIAQgBSkCiAI3AgggBCAFKQKAAjcCACAEIAQoAgwgCHMiDTYCDCAEIAQoAgggCXMiDjYCCCAEIAQoAgQgCnMiDzYCBCAEIAQoAgAgC3MiEDYCACAGIAYoAgAgC3MiBzYCACAEIAQoAkQgCnMiETYCRCAEIAQoAkggCXMiEjYCSCAEIAQoAkwgCHMiEzYCTCAMQQFqIgxBB0cNAAsCQAJAAkACQCABQRBrDhEAAgICAgICAgICAgICAgICAQILIAQoAhAhASAEKAIwIQYgBCgCICEIIAQoAmAhCSAEKAJQIQogBCgCFCELIAQoAjQhDCAEKAIkIRQgBCgCZCEVIAQoAlQhFiAEKAIYIRcgBCgCOCEYIAQoAighGSAEKAJoIRogBCgCWCEbIAAgBCgCHCAEKAI8IAQoAiwgBCgCXCAEKAJsc3NzcyATcyANczYADCAAIBcgGCAZIBogG3Nzc3MgEnMgDnM2AAggACALIAwgFCAVIBZzc3NzIBFzIA9zNgAEIAAgASAGIAggCSAKc3NzcyAHcyAQczYAAAwCCyAEKAIQIQEgBCgCMCEGIAQoAiAhCCAEKAIUIQkgBCgCNCEKIAQoAiQhCyAEKAIYIQwgBCgCOCEHIAQoAighESAAIAQoAhwgBCgCPCAEKAIsc3MgDXM2AAwgACAMIAcgEXNzIA5zNgAIIAAgCSAKIAtzcyAPczYABCAAIAEgBiAIc3MgEHM2AAAgBCgCUCEBIARBQGsoAgAhBiAEKAJwIQggBCgCYCEJIAQoAlQhCiAEKAJEIQsgBCgCdCEMIAQoAmQhDSAEKAJYIQ4gBCgCSCEPIAQoAnghECAEKAJoIQcgACAEKAJcIAQoAkwgBCgCfCAEKAJsc3NzNgAcIAAgDiAPIAcgEHNzczYAGCAAIAogCyAMIA1zc3M2ABQgACABIAYgCCAJc3NzNgAQDAELIAFFDQAgAEEAIAH8CwALIAVBoAJqJAALgwkBHn8jAEGgAmsiAyQAIAIoAhAhESACKAIwIRIgASgABCEFIAIoAhQhEyACKAI0IRQgASgACCEGIAIoAhghFSACKAI4IRYgASgADCEHIAIoAhwhFyACKAI8IRggAigCICEEIAEoABAhCCACKAJQIRkgAigCcCEaIAIoAmAhCSACKAIkIQogASgAFCELIAIoAlQhGyACKAJ0IRwgAigCZCEMIAIoAighDSABKAAYIQ4gAigCWCEdIAIoAnghHiACKAJoIQ8gASgAACEQIAAgAigCLCIfIAEoABwiASACKAJcIAIoAmwiICACKAJ8cXNzczYAHCAAIA0gDiAdIA8gHnFzc3M2ABggACAKIAsgGyAMIBxxc3NzNgAUIAAgBCAIIBkgCSAacXNzczYAECAAICAgByAXIBggH3Fzc3M2AAwgACAPIAYgFSANIBZxc3NzNgAIIAAgDCAFIBMgCiAUcXNzczYABCAAIAkgECARIAQgEnFzc3M2AAAgAyACKQJ4NwOYAiADIAIpAnA3A5ACIAMgAikCYDcD8AEgAyACKQJoNwP4ASADIAIpAnA3A+ABIAMgAikCeDcD6AEgA0GAAmoiBCADQfABaiADQeABahAGIAIgAykCiAI3AnggAiADKQKAAjcCcCADIAIpAlA3A9ABIAMgAikCWDcD2AEgAyACKQJgNwPAASADIAIpAmg3A8gBIAQgA0HQAWogA0HAAWoQBiACIAMpAogCNwJoIAIgAykCgAI3AmAgAyACQUBrIgApAgA3A7ABIAMgAikCSDcDuAEgAyACKQJQNwOgASADIAIpAlg3A6gBIAQgA0GwAWogA0GgAWoQBiACIAMpAogCNwJYIAIgAykCgAI3AlAgAyACKQIwNwOQASADIAIpAjg3A5gBIAMgACkCADcDgAEgAyACKQJINwOIASAEIANBkAFqIANBgAFqEAYgAiADKQKIAjcCSCAAIAMpAoACNwIAIAMgAikCIDcDcCADIAIpAig3A3ggAyACKQIwNwNgIAMgAikCODcDaCAEIANB8ABqIANB4ABqEAYgAiADKQKIAjcCOCACIAMpAoACNwIwIAMgAikCEDcDUCADIAIpAhg3A1ggAyACKQIgNwNAIAMgAikCKDcDSCAEIANB0ABqIANBQGsQBiACIAMpAogCNwIoIAIgAykCgAI3AiAgAyACKQIANwMwIAMgAikCCDcDOCADIAIpAhA3AyAgAyACKQIYNwMoIAQgA0EwaiADQSBqEAYgAiADKQKIAjcCGCACIAMpAoACNwIQIAMgAykDkAI3AxAgAyADKQOYAjcDGCADIAIpAgA3AwAgAyACKQIINwMIIAQgA0EQaiADEAYgAiADKQKIAjcCCCACIAMpAoACNwIAIAIgByACKAIMczYCDCACIAYgAigCCHM2AgggAiAFIAIoAgRzNgIEIAIgECACKAIAczYCACAAIAggACgCAHM2AgAgAiALIAIoAkRzNgJEIAIgDiACKAJIczYCSCACIAEgAigCTHM2AkwgA0GgAmokAAuZDQESfyMAQaAEayICJAAgACgAPCEEIAAoADghBSAAKAA0IQYgACgAMCEHIAAoACAhCCAAKAAkIQkgACgAKCEKIAAoACwhCyAAKAAcIQwgACgAGCENIAAoABQhDiAAKAAQIQ8gACgABCEQIAAoAAghESAAKAAMIRIgACgAACETIAIgASkCeDcDmAQgAiABKQJwNwOQBCACIAEpAmA3A/ADIAIgASkCaDcD+AMgAiABKQJwNwPgAyACIAEpAng3A+gDIAJBgARqIgMgAkHwA2ogAkHgA2oQBiABIAIpAogENwJ4IAEgAikCgAQ3AnAgAiABKQJQNwPQAyACIAEpAlg3A9gDIAIgASkCYDcDwAMgAiABKQJoNwPIAyADIAJB0ANqIAJBwANqEAYgASACKQKIBDcCaCABIAIpAoAENwJgIAIgAUFAayIAKQIANwOwAyACIAEpAkg3A7gDIAIgASkCUDcDoAMgAiABKQJYNwOoAyADIAJBsANqIAJBoANqEAYgASACKQKIBDcCWCABIAIpAoAENwJQIAIgASkCMDcDkAMgAiABKQI4NwOYAyACIAApAgA3A4ADIAIgASkCSDcDiAMgAyACQZADaiACQYADahAGIAEgAikCiAQ3AkggACACKQKABDcCACACIAEpAiA3A/ACIAIgASkCKDcD+AIgAiABKQIwNwPgAiACIAEpAjg3A+gCIAMgAkHwAmogAkHgAmoQBiABIAIpAogENwI4IAEgAikCgAQ3AjAgAiABKQIQNwPQAiACIAEpAhg3A9gCIAIgASkCIDcDwAIgAiABKQIoNwPIAiADIAJB0AJqIAJBwAJqEAYgASACKQKIBDcCKCABIAIpAoAENwIgIAIgASkCADcDsAIgAiABKQIINwO4AiACIAEpAhA3A6ACIAIgASkCGDcDqAIgAyACQbACaiACQaACahAGIAEgAikCiAQ3AhggASACKQKABDcCECACIAIpA5AENwOQAiACIAIpA5gENwOYAiACIAEpAgA3A4ACIAIgASkCCDcDiAIgAyACQZACaiACQYACahAGIAEgAikCiAQ3AgggASACKQKABDcCACABIBIgASgCDHM2AgwgASARIAEoAghzNgIIIAEgECABKAIEczYCBCABIBMgASgCAHM2AgAgACAPIAAoAgBzNgIAIAEgDiABKAJEczYCRCABIA0gASgCSHM2AkggASAMIAEoAkxzNgJMIAIgASkCeDcDmAQgAiABKQJwNwOQBCACIAEpAmA3A/ABIAIgASkCaDcD+AEgAiABKQJwNwPgASACIAEpAng3A+gBIAMgAkHwAWogAkHgAWoQBiABIAIpAogENwJ4IAEgAikCgAQ3AnAgAiABKQJQNwPQASACIAEpAlg3A9gBIAIgASkCYDcDwAEgAiABKQJoNwPIASADIAJB0AFqIAJBwAFqEAYgASACKQKIBDcCaCABIAIpAoAENwJgIAIgACkCADcDsAEgAiABKQJINwO4ASACIAEpAlA3A6ABIAIgASkCWDcDqAEgAyACQbABaiACQaABahAGIAEgAikCiAQ3AlggASACKQKABDcCUCACIAEpAjA3A5ABIAIgASkCODcDmAEgAiAAKQIANwOAASACIAEpAkg3A4gBIAMgAkGQAWogAkGAAWoQBiABIAIpAogENwJIIAAgAikCgAQ3AgAgAiABKQIgNwNwIAIgASkCKDcDeCACIAEpAjA3A2AgAiABKQI4NwNoIAMgAkHwAGogAkHgAGoQBiABIAIpAogENwI4IAEgAikCgAQ3AjAgAiABKQIQNwNQIAIgASkCGDcDWCACIAEpAiA3A0AgAiABKQIoNwNIIAMgAkHQAGogAkFAaxAGIAEgAikCiAQ3AiggASACKQKABDcCICACIAEpAgA3AzAgAiABKQIINwM4IAIgASkCEDcDICACIAEpAhg3AyggAyACQTBqIAJBIGoQBiABIAIpAogENwIYIAEgAikCgAQ3AhAgAiACKQOQBDcDECACIAIpA5gENwMYIAIgASkCADcDACACIAEpAgg3AwggAyACQRBqIAIQBiABIAIpAogENwIIIAEgAikCgAQ3AgAgASALIAEoAgxzNgIMIAEgCiABKAIIczYCCCABIAkgASgCBHM2AgQgASAIIAEoAgBzNgIAIAAgByAAKAIAczYCACABIAYgASgCRHM2AkQgASAFIAEoAkhzNgJIIAEgBCABKAJMczYCTCACQaAEaiQAC5wJAQt/IwBBoAJrIgMkACABKAAEIQogASgACCELIAEoAAwhDCAAKAAEIQYgACgACCEHIAAoAAwhCCABKAAAIQ0gAiAAKAAAIgFBgIKEEHMiADYCcCACIAFB2/vgqAVzNgJgIAIgADYCUCACQUBrIgAgASANcyIFNgIAIAJCoKLEkbSurZRdNwI4IAJC2/vgqNXN8JdxNwIwIAJClcTcyYWy+rziADcCKCACQoCChJCwoIGEDTcCICACQqCixJG0rq2UXTcCGCACQtv74KjVzfCXcTcCECACIAU2AgAgAiAIQZDT55MGcyIFNgJ8IAIgB0GVxNzJBXMiBDYCeCACIAZBg4qg6ABzIgk2AnQgAiAIQfPqoul9czYCbCACIAdBoKLEkQRzNgJoIAIgBkHthL+Jf3M2AmQgAiAFNgJcIAIgBDYCWCACIAk2AlQgAiAIIAxzIgU2AkwgAiAHIAtzIgQ2AkggAiAGIApzIgk2AkQgAiAFNgIMIAIgBDYCCCACIAk2AgRBACEFA0AgAyACKQJ4NwOYAiADIAIpAnA3A5ACIAMgAikCYDcD8AEgAyACKQJoNwP4ASADIAIpAnA3A+ABIAMgAikCeDcD6AEgA0GAAmoiBCADQfABaiADQeABahAGIAIgAykCiAI3AnggAiADKQKAAjcCcCADIAIpAlA3A9ABIAMgAikCWDcD2AEgAyACKQJgNwPAASADIAIpAmg3A8gBIAQgA0HQAWogA0HAAWoQBiACIAMpAogCNwJoIAIgAykCgAI3AmAgAyAAKQIANwOwASADIAApAgg3A7gBIAMgAikCUDcDoAEgAyACKQJYNwOoASAEIANBsAFqIANBoAFqEAYgAiADKQKIAjcCWCACIAMpAoACNwJQIAMgAikCMDcDkAEgAyACKQI4NwOYASADIAApAgA3A4ABIAMgACkCCDcDiAEgBCADQZABaiADQYABahAGIAAgAykCiAI3AgggACADKQKAAjcCACADIAIpAiA3A3AgAyACKQIoNwN4IAMgAikCMDcDYCADIAIpAjg3A2ggBCADQfAAaiADQeAAahAGIAIgAykCiAI3AjggAiADKQKAAjcCMCADIAIpAhA3A1AgAyACKQIYNwNYIAMgAikCIDcDQCADIAIpAig3A0ggBCADQdAAaiADQUBrEAYgAiADKQKIAjcCKCACIAMpAoACNwIgIAMgAikCADcDMCADIAIpAgg3AzggAyACKQIQNwMgIAMgAikCGDcDKCAEIANBMGogA0EgahAGIAIgAykCiAI3AhggAiADKQKAAjcCECADIAMpA5ACNwMQIAMgAykDmAI3AxggAyACKQIANwMAIAMgAikCCDcDCCAEIANBEGogAxAGIAIgAykCiAI3AgggAiADKQKAAjcCACACIAIoAgwgDHM2AgwgAiACKAIIIAtzNgIIIAIgAigCBCAKczYCBCACIAIoAgAgDXM2AgAgACAAKAIAIAFzNgIAIAIgAigCRCAGczYCRCACIAIoAkggB3M2AkggAiACKAJMIAhzNgJMIAVBAWoiBUEKRw0ACyADQaACaiQAC28BBH9BASECA0AgACADaiIBIAIgAS0AAGoiAjoAACABIAEtAAEgAkEIdmoiAjoAASABIAEtAAIgAkEIdmoiAjoAAiABIAEtAAMgAkEIdmoiAToAAyABQQh2IQIgA0EEaiEDIARBBGoiBEEERw0ACwvsBAEFfyMAQfAAayIGJAAgAkIAUgRAIAYgBSkAGDcDGCAGIAUpABA3AxAgBiAFKQAINwMIIAYgBSkAADcDACAGIAMpAAA3A2AgBiAEPABoIAYgBEI4iDwAbyAGIARCMIg8AG4gBiAEQiiIPABtIAYgBEIgiDwAbCAGIARCGIg8AGsgBiAEQhCIPABqIAYgBEIIiDwAaQJAIAJCwABaBEADQEEAIQUgBkEgaiAGQeAAaiAGQQAQVBoDQCAAIAVqIAZBIGoiByAFai0AACABIAVqLQAAczoAACAAIAVBAXIiA2ogAyAHai0AACABIANqLQAAczoAACAFQQJqIgVBwABHDQALIAYgBi0AaEEBaiIDOgBoIAYgBi0AaSADQQh2aiIDOgBpIAYgBi0AaiADQQh2aiIDOgBqIAYgBi0AayADQQh2aiIDOgBrIAYgBi0AbCADQQh2aiIDOgBsIAYgBi0AbSADQQh2aiIDOgBtIAYgBi0AbiADQQh2aiIDOgBuIAYgBi0AbyADQQh2ajoAbyABQUBrIQEgAEFAayEAIAJCQHwiAkI/Vg0ACyACUA0BC0EAIQUgBkEgaiAGQeAAaiAGQQAQVBogAkIBUgRAIAKnIgNBAXEgA0E+cSEJQQAhAwNAIAAgBWogBkEgaiIKIAVqLQAAIAEgBWotAABzOgAAIAAgBUEBciIHaiAHIApqLQAAIAEgB2otAABzOgAAIAVBAmohBSADQQJqIgMgCUcNAAtFDQELIAAgBWogBkEgaiAFai0AACABIAVqLQAAczoAAAsgBkEgakHAABAHIAZBIBAHCyAGQfAAaiQAQQALhAQCB38BfiMAQfAAayIEJAAgAUIAUgRAIAQgAykAGDcDGCAEIAMpABA3AxAgBCADKQAINwMIIAQgAykAADcDACACKQAAIQsgBEIANwNoIAQgCzcDYAJAIAFCwABaBEADQCAAIARB4ABqIARBABBUGiAEIAQtAGhBAWoiAjoAaCAEIAQtAGkgAkEIdmoiAjoAaSAEIAQtAGogAkEIdmoiAjoAaiAEIAQtAGsgAkEIdmoiAjoAayAEIAQtAGwgAkEIdmoiAjoAbCAEIAQtAG0gAkEIdmoiAjoAbSAEIAQtAG4gAkEIdmoiAjoAbiAEIAQtAG8gAkEIdmo6AG8gAEFAayEAIAFCQHwiAUI/Vg0ACyABUA0BC0EAIQIgBEEgaiAEQeAAaiAEQQAQVBogAaciBkEDcSEHQQAhAyABQgRaBEAgBkE8cSEIQQAhBgNAIAAgA2ogBEEgaiIJIgUgA2otAAA6AAAgACADQQFyIgpqIAUgCmotAAA6AAAgACADQQJyIgVqIAUgCWotAAA6AAAgACADQQNyIgVqIARBIGogBWotAAA6AAAgA0EEaiEDIAZBBGoiBiAIRw0ACyAHRQ0BCwNAIAAgA2ogBEEgaiADai0AADoAACADQQFqIQMgAkEBaiICIAdHDQALCyAEQSBqQcAAEAcgBEEgEAcLIARB8ABqJABBAAuGBgEUfyMAQbACayICJAAgACABLQAAOgAAIAAgAS0AAToAASAAIAEtAAI6AAIgACABLQADOgADIAAgAS0ABDoABCAAIAEtAAU6AAUgACABLQAGOgAGIAAgAS0ABzoAByAAIAEtAAg6AAggACABLQAJOgAJIAAgAS0ACjoACiAAIAEtAAs6AAsgACABLQAMOgAMIAAgAS0ADToADSAAIAEtAA46AA4gACABLQAPOgAPIAAgAS0AEDoAECAAIAEtABE6ABEgACABLQASOgASIAAgAS0AEzoAEyAAIAEtABQ6ABQgACABLQAVOgAVIAAgAS0AFjoAFiAAIAEtABc6ABcgACABLQAYOgAYIAAgAS0AGToAGSAAIAEtABo6ABogACABLQAbOgAbIAAgAS0AHDoAHCAAIAEtAB06AB0gACABLQAeOgAeIAEtAB8hASAAIAAtAABB+AFxOgAAIAAgAUE/cUHAAHI6AB8gAkEwaiAAEDAgAigCgAEhASACKAJYIQMgAigChAEhBCACKAJcIQUgAigCiAEhBiACKAJgIQcgAigCjAEhCCACKAJkIQkgAigCkAEhCiACKAJoIQsgAigClAEhDCACKAJsIQ0gAigCmAEhDiACKAJwIQ8gAigCnAEhECACKAJ0IREgAigCoAEhEiACKAJ4IRMgAiACKAJ8IhQgAigCpAEiFWo2AqQCIAIgEiATajYCoAIgAiAQIBFqNgKcAiACIA4gD2o2ApgCIAIgDCANajYClAIgAiAKIAtqNgKQAiACIAggCWo2AowCIAIgBiAHajYCiAIgAiAEIAVqNgKEAiACIAEgA2o2AoACIAIgFSAUazYC9AEgAiASIBNrNgLwASACIBAgEWs2AuwBIAIgDiAPazYC6AEgAiAMIA1rNgLkASACIAogC2s2AuABIAIgCCAJazYC3AEgAiAGIAdrNgLYASACIAQgBWs2AtQBIAIgASADazYC0AEgAkHQAWoiASABEEUgAiACQYACaiABEAUgACACEA8gAkGwAmokAEEAC/QbAj1/DX4jAEHwAmsiAyQAA0AgAiAWai0AACIEIBZB0IoCaiIFLQAAcyAMciEMIAQgBS0AwAFzIAZyIQYgBCAFLQCgAXMgCnIhCiAEIAUtAIABcyAHciEHIAQgBS0AYHMgCHIhCCAEIAVBQGstAABzIAlyIQkgBCAFLQAgcyALciELIBZBAWoiFkEfRw0AC0F/IQUgAi0AH0H/AHEiBCALckH/AXFBAWsgBCAMckH/AXFBAWtyIAQgCXJB/wFxQQFrciAEQdcAcyAIckH/AXFBAWtyIARB/wBzIgQgB3JB/wFxQQFrciAEIApyQf8BcUEBa3IgBCAGckH/AXFBAWtyQYACcUUEQCADIAEpAAAiQDcD0AIgAyABKQAYNwPoAiADIAEpABA3A+ACIAMgASkACDcD2AIgAyBAp0H4AXE6ANACIAMgAy0A7wJBP3FBwAByOgDvAiADQaACaiACEDUgA0IANwL0ASADQQE2AvABIANCADcC/AEgA0IANwKEAiADQgA3AowCIANBADYClAIgA0IANwPAASADQgA3A8gBIANCADcD0AEgA0IANwPYASADQgA3A+ABIAMgAykDoAI3A5ABIAMgAykDqAI3A5gBIAMgAykDsAI3A6ABIAMgAykDuAI3A6gBIAMgAykDwAI3A7ABIANCADcCZCADQQE2AmAgA0IANwJsIANCADcCdCADQgA3AnwgA0EANgKEAUH+ASECQQAhFgNAIAMoApABIQQgAygC8AEhBSADKAJgIQwgAygCwAEhBiADKAKUASEKIAMoAvQBIQcgAygCZCEIIAMoAsQBIQkgAygCmAEhCyADKAL4ASENIAMoAmghFyADKALIASEOIAMoApwBIQ8gAygC/AEhECADKAJsIRQgAygCzAEhESADKAKgASESIAMoAoACIRMgAygCcCEVIAMoAtABIRggAygCpAEhGiADKAKEAiEZIAMoAnQhGyADKALUASEcIAMoAqgBIR0gAygCiAIhHiADKAJ4ITIgAygC2AEhHyADKAKsASEgIAMoAowCISEgAygCfCEiIAMoAtwBISMgAygCsAEhJCADKAKQAiElIAMoAoABISYgAygC4AEhJyADQQAgFiADQdACaiIzIAIiAUEDdmotAAAgAkEHcXZBAXEiFnNrIgIgAygCtAEiKCADKAKUAiIpc3EiKiAocyIoIAMoAoQBIisgAygC5AEiLHMgAnEiLSArcyIrazYCVCADICQgJCAlcyACcSIucyIkICYgJiAncyACcSIvcyImazYCUCADICAgICAhcyACcSIwcyIgICIgIiAjcyACcSIxcyIiazYCTCADICkgKnMiKSAsIC1zIiprNgIkIAMgJSAucyIlICcgL3MiJ2s2AiAgAyAhIDBzIiEgIyAxcyIjazYCHCADIB4gHSAecyACcSIscyIeIB8gHyAycyACcSItcyIfazYCGCADIBkgGSAacyACcSIucyIZIBwgGyAccyACcSIvcyIcazYCFCADIBMgEiATcyACcSIwcyITIBggFSAYcyACcSIxcyIYazYCECADIBAgDyAQcyACcSI0cyIQIBEgESAUcyACcSI1cyIRazYCDCADIA0gCyANcyACcSI2cyINIA4gDiAXcyACcSI3cyIOazYCCCADIAcgByAKcyACcSI4cyI5IAkgCCAJcyACcSI6cyI7azYCBCADIAUgBCAFcyACcSI8cyI9IAYgBiAMcyACcSI+cyI/azYCACADIC0gMnMiAjYCeCADIB0gLHMiHSACazYCSCADIBsgL3MiBTYCdCADIBogLnMiGiAFazYCRCADIBUgMXMiBjYCcCADIBIgMHMiEiAGazYCQCADIBQgNXMiBzYCbCADIA8gNHMiDyAHazYCPCADIBcgN3MiCTYCaCADIAsgNnMiCyAJazYCOCADIAggOnMiCDYCZCADIAogOHMiCiAIazYCNCADIAwgPnMiDDYCYCADIAQgPHMiBCAMazYCMCADICkgKmo2ApQCIAMgJSAnajYCkAIgAyAhICNqNgKMAiADIB4gH2o2AogCIAMgGSAcajYChAIgAyATIBhqNgKAAiADIBAgEWo2AvwBIAMgDSAOajYC+AEgAyA5IDtqNgL0ASADID0gP2o2AvABIAMgKCArajYC5AEgAyAkICZqNgLgASADICAgImo2AtwBIAMgAiAdajYC2AEgAyAFIBpqNgLUASADIAYgEmo2AtABIAMgCSALajYCyAEgAyAIIApqNgLEASADIAQgDGo2AsABIAMgByAPajYCzAEgA0HgAGoiGiADQTBqIgwgA0HwAWoiBRAFIANBwAFqIgQgBCADEAUgDCADEAQgAyAFEAQgAygCwAEhAiADKAJgIQYgAygCxAEhCiADKAJkIQcgAygCyAEhCCADKAJoIQkgAygCzAEhCyADKAJsIQ0gAygC0AEhFyADKAJwIQ4gAygC1AEhDyADKAJ0IRAgAygC2AEhFCADKAJ4IREgAygC3AEhEiADKAJ8IRMgAygC4AEhFSADKAKAASEYIAMgAygC5AEiGSADKAKEASIbajYCtAEgAyAVIBhqNgKwASADIBIgE2o2AqwBIAMgESAUajYCqAEgAyAPIBBqNgKkASADIA4gF2o2AqABIAMgCyANajYCnAEgAyAIIAlqNgKYASADIAcgCmo2ApQBIAMgAiAGajYCkAEgAyAbIBlrNgLkASADIBggFWs2AuABIAMgEyASazYC3AEgAyARIBRrNgLYASADIBAgD2s2AtQBIAMgDiAXazYC0AEgAyANIAtrNgLMASADIAkgCGs2AsgBIAMgByAKazYCxAEgAyAGIAJrNgLAASAFIAMgDBAFIAMoAkghAiADKAIYIQ4gAygCRCEGIAMoAhQhDyADKAJAIQogAygCECEQIAMoAjwhByADKAIMIRQgAygCOCEIIAMoAgghESADKAI0IQkgAygCBCESIAMoAlQhCyADKAIkIRMgAygCMCENIAMoAgAhFSADKAJMIRcgAygCHCEYIAMgAygCICADKAJQIhlrIhs2AiAgAyAYIBdrIhg2AhwgAyAVIA1rIhU2AgAgAyATIAtrIhM2AiQgAyASIAlrIhI2AgQgAyARIAhrIhE2AgggAyAUIAdrIhQ2AgwgAyAQIAprIhA2AhAgAyAPIAZrIg82AhQgAyAOIAJrIg42AhggBCAEEAQgA0GQAWoiHCAcEAQgAyAZIBusQsK2B34gGKxCwrYHfiJAQoCAgAh8IkJCGYd8IkEgQUKAgIAQfCJBQoCAgOAPg32najYCUCADIAIgDqxCwrYHfiAPrELCtgd+IkZCgICACHwiR0IZh3wiQyBDQoCAgBB8IkNCgICA4A+DfadqNgJIIAMgCiAQrELCtgd+IBSsQsK2B34iSEKAgIAIfCJJQhmHfCJEIERCgICAEHwiREKAgIDgD4N9p2o2AkAgAyAIIBGsQsK2B34gEqxCwrYHfiJKQoCAgAh8IktCGYd8IkUgRUKAgIAQfCJFQoCAgOAPg32najYCOCADIAsgE6xCwrYHfiJMIEFCGoh8IExCgICACHwiQUKAgIDwD4N9p2o2AlQgAyAXIENCGoggQHwgQkKAgIDwD4N9p2o2AkwgAyAGIERCGoggRnwgR0KAgIDwD4N9p2o2AkQgAyAHIEVCGoggSHwgSUKAgIDwD4N9p2o2AjwgAyAJIEogS0KAgIDwD4N9IEFCGYdCE34gFaxCwrYHfnwiQEKAgIAQfCJCQhqIfKdqNgI0IAMgDSBAIEJCgICA4A+DfadqNgIwIAFBAWshAiAaIANBoAJqIAQQBSAEIAMgDBAFIAENAAsgAygCkAEhFyADKALwASECIAMoApQBIQ4gAygC9AEhDCADKAKYASEPIAMoAvgBIQYgAygCnAEhECADKAL8ASEKIAMoAqABIRQgAygCgAIhByADKAKkASERIAMoAoQCIQggAygCqAEhEiADKAKIAiEJIAMoAqwBIRMgAygCjAIhCyADKAKwASEVIAMoApACIQ0gA0EAIBZrIgEgAygClAIiFiADKAK0AXNxIBZzNgKUAiADIA0gDSAVcyABcXM2ApACIAMgCyALIBNzIAFxczYCjAIgAyAJIAkgEnMgAXFzNgKIAiADIAggCCARcyABcXM2AoQCIAMgByAHIBRzIAFxczYCgAIgAyAKIAogEHMgAXFzNgL8ASADIAYgBiAPcyABcXM2AvgBIAMgDCAMIA5zIAFxczYC9AEgAyACIAIgF3MgAXFzNgLwASADKALAASECIAMoAmAhDSADKALEASEWIAMoAmQhFyADKALIASEMIAMoAmghDiADKALMASEGIAMoAmwhDyADKALQASEKIAMoAnAhECADKALUASEHIAMoAnQhFCADKALYASEIIAMoAnghESADKALcASEJIAMoAnwhEiADKALgASELIAMoAoABIRMgAyADKALkASIVIAMoAoQBcyABcSAVczYC5AEgAyALIAsgE3MgAXFzNgLgASADIAkgCSAScyABcXM2AtwBIAMgCCAIIBFzIAFxczYC2AEgAyAHIAcgFHMgAXFzNgLUASADIAogCiAQcyABcXM2AtABIAMgBiAGIA9zIAFxczYCzAEgAyAMIAwgDnMgAXFzNgLIASADIBYgFiAXcyABcXM2AsQBIAMgAiACIA1zIAFxczYCwAEgBCAEEEUgBSAFIAQQBSAAIAUQDyAzQSAQB0EAIQULIANB8AJqJAAgBQs4AQF/IwBBIGsiBiQAIAYgBCAFQQAQHxogACABIAKtIAOtQiCGhCAEQRBqQgAgBhBJIAZBIGokAAtAAQF/IwBBIGsiCCQAIAggBCAHQQAQHxogACABIAKtIAOtQiCGhCAEQRBqIAWtIAatQiCGhCAIEEkgCEEgaiQACzQBAX8jAEEgayIFJAAgBSADIARBABAfGiAAIAGtIAKtQiCGhCADQRBqIAUQXyAFQSBqJAALtgQCA38CfiMAQfAAayIGJAAgAq0gA61CIIaEIglCAFIEQCAGIAUpABg3AxggBiAFKQAQNwMQIAYgBSkACDcDCCAGIAUpAAA3AwAgBCkAACEKIAZCADcDaCAGIAo3A2ACQCAJQsAAWgRAA0BBACECIAZBIGogBkHgAGogBkEAEFIaA0AgACACaiAGQSBqIgQgAmotAAAgASACai0AAHM6AAAgACACQQFyIgNqIAMgBGotAAAgASADai0AAHM6AAAgAkECaiICQcAARw0ACyAGIAYtAGhBAWoiAjoAaCAGIAYtAGkgAkEIdmoiAjoAaSAGIAYtAGogAkEIdmoiAjoAaiAGIAYtAGsgAkEIdmoiAjoAayAGIAYtAGwgAkEIdmoiAjoAbCAGIAYtAG0gAkEIdmoiAjoAbSAGIAYtAG4gAkEIdmoiAjoAbiAGIAYtAG8gAkEIdmo6AG8gAUFAayEBIABBQGshACAJQkB8IglCP1YNAAsgCVANAQtBACECIAZBIGogBkHgAGogBkEAEFIaIAlCAVIEQCAJpyIDQQFxIANBPnEhB0EAIQMDQCAAIAJqIAZBIGoiCCACai0AACABIAJqLQAAczoAACAAIAJBAXIiBGogBCAIai0AACABIARqLQAAczoAACACQQJqIQIgA0ECaiIDIAdHDQALRQ0BCyAAIAJqIAZBIGogAmotAAAgASACai0AAHM6AAALIAZBIGpBwAAQByAGQSAQBwsgBkHwAGokAEEAC4sEAgV/An4jAEHwAGsiBSQAIAGtIAKtQiCGhCIKQgBSBEAgBSAEKQAYNwMYIAUgBCkAEDcDECAFIAQpAAg3AwggBSAEKQAANwMAIAMpAAAhCyAFQgA3A2ggBSALNwNgAkAgCkLAAFoEQANAIAAgBUHgAGogBUEAEFIaIAUgBS0AaEEBaiIBOgBoIAUgBS0AaSABQQh2aiIBOgBpIAUgBS0AaiABQQh2aiIBOgBqIAUgBS0AayABQQh2aiIBOgBrIAUgBS0AbCABQQh2aiIBOgBsIAUgBS0AbSABQQh2aiIBOgBtIAUgBS0AbiABQQh2aiIBOgBuIAUgBS0AbyABQQh2ajoAbyAAQUBrIQAgCkJAfCIKQj9WDQALIApQDQELQQAhAiAFQSBqIAVB4ABqIAVBABBSGiAKpyIEQQNxIQNBACEBIApCBFoEQCAEQTxxIQhBACEEA0AgACABaiAFQSBqIgkiBiABai0AADoAACAAIAFBAXIiB2ogBiAHai0AADoAACAAIAFBAnIiB2ogBiAHai0AADoAACAAIAFBA3IiBmogBiAJai0AADoAACABQQRqIQEgBEEEaiIEIAhHDQALIANFDQELA0AgACABaiAFQSBqIAFqLQAAOgAAIAFBAWohASACQQFqIgIgA0cNAAsLIAVBIGpBwAAQByAFQSAQBwsgBUHwAGokAEEAC7YEAgN/An4jAEHwAGsiBiQAIAKtIAOtQiCGhCIJQgBSBEAgBiAFKQAYNwMYIAYgBSkAEDcDECAGIAUpAAg3AwggBiAFKQAANwMAIAQpAAAhCiAGQgA3A2ggBiAKNwNgAkAgCULAAFoEQANAQQAhAiAGQSBqIAZB4ABqIAZBABBTGgNAIAAgAmogBkEgaiIEIAJqLQAAIAEgAmotAABzOgAAIAAgAkEBciIDaiADIARqLQAAIAEgA2otAABzOgAAIAJBAmoiAkHAAEcNAAsgBiAGLQBoQQFqIgI6AGggBiAGLQBpIAJBCHZqIgI6AGkgBiAGLQBqIAJBCHZqIgI6AGogBiAGLQBrIAJBCHZqIgI6AGsgBiAGLQBsIAJBCHZqIgI6AGwgBiAGLQBtIAJBCHZqIgI6AG0gBiAGLQBuIAJBCHZqIgI6AG4gBiAGLQBvIAJBCHZqOgBvIAFBQGshASAAQUBrIQAgCUJAfCIJQj9WDQALIAlQDQELQQAhAiAGQSBqIAZB4ABqIAZBABBTGiAJQgFSBEAgCaciA0EBcSADQT5xIQdBACEDA0AgACACaiAGQSBqIgggAmotAAAgASACai0AAHM6AAAgACACQQFyIgRqIAQgCGotAAAgASAEai0AAHM6AAAgAkECaiECIANBAmoiAyAHRw0AC0UNAQsgACACaiAGQSBqIAJqLQAAIAEgAmotAABzOgAACyAGQSBqQcAAEAcgBkEgEAcLIAZB8ABqJABBAAuLBAIFfwJ+IwBB8ABrIgUkACABrSACrUIghoQiCkIAUgRAIAUgBCkAGDcDGCAFIAQpABA3AxAgBSAEKQAINwMIIAUgBCkAADcDACADKQAAIQsgBUIANwNoIAUgCzcDYAJAIApCwABaBEADQCAAIAVB4ABqIAVBABBTGiAFIAUtAGhBAWoiAToAaCAFIAUtAGkgAUEIdmoiAToAaSAFIAUtAGogAUEIdmoiAToAaiAFIAUtAGsgAUEIdmoiAToAayAFIAUtAGwgAUEIdmoiAToAbCAFIAUtAG0gAUEIdmoiAToAbSAFIAUtAG4gAUEIdmoiAToAbiAFIAUtAG8gAUEIdmo6AG8gAEFAayEAIApCQHwiCkI/Vg0ACyAKUA0BC0EAIQIgBUEgaiAFQeAAaiAFQQAQUxogCqciBEEDcSEDQQAhASAKQgRaBEAgBEE8cSEIQQAhBANAIAAgAWogBUEgaiIJIgYgAWotAAA6AAAgACABQQFyIgdqIAYgB2otAAA6AAAgACABQQJyIgdqIAYgB2otAAA6AAAgACABQQNyIgZqIAYgCWotAAA6AAAgAUEEaiEBIARBBGoiBCAIRw0ACyADRQ0BCwNAIAAgAWogBUEgaiABai0AADoAACABQQFqIQEgAkEBaiICIANHDQALCyAFQSBqQcAAEAcgBUEgEAcLIAVB8ABqJABBAAvQAgIDfwJ+IwBBoAhrIgYkACABQgA3AwBBfyEIAkAgA60gBK1CIIaEIglCwABUDQAgCUJAfCIKQr////8PVg0AIAIgCadqQQFrLQAAQR9LDQAgBRBDDQAgBkHIAmoiAyAFEGINACACEEMNACAGQagBaiIEIAIQYg0AIAZBgAZqIgUgAxAOIAZB4AdqIgMgAiAJQiB9EEAaIAMQJiAGQQhqIgcgAyAEEIYBIAZB4ARqIgMgByAFEBIgBkHoA2oiBSADIANB+ABqIgcQBSAFQShqIANBKGogA0HQAGoiAxAFIAVB0ABqIAMgBxAFIAZBwAdqIgMgBRAiIAYgBi0A3wdBgAFzOgDfByAEIAJBIGoiBSAKpyICahAwIAZBoAdqIgcgBBAiIAMgBxBGDQAgASAKNwMAIAIEQCAAIAUgAvwKAAALQQAhCAsgBkGgCGokACAIC7kCAgN/AX4jAEHQBWsiBiQAIAZBgARqIgcQMhogByAFQSBqQiAQExogByACIAOtIAStQiCGhCIJEBMaIAcgBkHAA2oiAxAeGiAGQaABaiIEIAUQMCAGQeACaiIIIAQQIiADECYgBiADEDAgBkHAAmoiBCAGECIgBxAyGiAHIARCIBATGiAHIAIgCRATGiAHIAZBgANqIgQQHhogBBAmIAggBCADIAUQqQEgBEHAABAHIABBIGohAyAJpyIEBEAgAyACIAT8CgAACyAAIAYpA9gCNwAYIAAgBikD0AI3ABAgACAGKQPIAjcACCAAIAYpA8ACNwAAIAMgBGoiACAGKQP4AjcAGCAAIAYpA/ACNwAQIAAgBikD6AI3AAggACAGKQPgAjcAACABIAlCQH03AwAgBkHQBWokAEEAC4AIAQd+IAQpAAAiBUL1ys2D16zbt/MAhSEHIAVC4eSV89bs2bzsAIUhCSAEKQAIIgVCg9+R85bM3LfkAIUhBiAFQvPK0cunjNmy9ACFIQggASABIAKtIAOtQiCGhCIFpyICaiACQQdxIgNrIAVQGyICIAFHBEADQCAJIAEpAAAiCiAIhSIIfCIJIAYgB3wiByAGQg2JhSIGfCILIAZCEYmFIgZCDYkgBiAIQhCJIAmFIgkgB0IgiXwiB3wiCIUiBkIRiSAGIAlCFYkgB4UiByALQiCJfCIJfCILhSEGIAdCEIkgCYUiB0IViSAHIAhCIIl8IgeFIQggC0IgiSEJIAcgCoUhByABQQhqIgEgAkcNAAsgAiEBCyAFQjiGIQUCQAJAAkACQAJAAkACQAJAIANBAWsOBwYFBAMCAQAHCyABMQAGQjCGIAWEIQULIAExAAVCKIYgBYQhBQsgATEABEIghiAFhCEFCyABMQADQhiGIAWEIQULIAExAAJCEIYgBYQhBQsgATEAAUIIhiAFhCEFCyAFIAExAACEIQULIAAgBSAFIAiFIghCEIkgCCAJfCIJhSIIQhWJIAggBiAHfCIHQiCJfCIIhSIKQhCJIAogCSAHIAZCDYmFIgZ8IgdCIIl8IgmFIgogCCAHIAZCEYmFIgZ8IgdCIIl8IgiFIAZCDYkgB4UiBUIRiSAFIAl8IgWFIgZ8IgcgBkINiYUiBkIRiSAGIApCFYkgCIUiCSAFQiCJQu4BhXwiBXwiBoUiCEINiSAIIAlCEIkgBYUiBSAHQiCJfCIHfCIJhSIIQhGJIAggBUIViSAHhSIFIAZCIIl8IgZ8IgeFIghCDYkgCCAFQhCJIAaFIgUgCUIgiXwiBnwiCYUiCEIRiSAIIAVCFYkgBoUiBSAHQiCJfCIGfCIHhSIIQg2JIAggBUIQiSAGhSIFIAlCIIl8IgZ8IgmFIghCEYkgCCAFQhWJIAaFIgUgB0IgiXwiBnwiB4UiCCAFQhCJIAaFIgYgCUIgiXwiBYUgB0IgiSIHhSAGQhWJIAWFIgaFNwAAIAAgBiAHfCIHIAZCEImFIgYgBSAIQt0BhSIJfCIFQiCJfCIIIAZCFYmFIgZCEIkgBiAJQg2JIAWFIgUgB3wiB0IgiXwiBoUiCUIViSAFQhGJIAeFIgUgCHwiB0IgiSAJfCIJhSIIQhCJIAVCDYkgB4UiBSAGfCIGQiCJIAh8IgeFIghCFYkgBUIRiSAGhSIFIAl8IgZCIIkgCHwiCYUiCEIQiSAFQg2JIAaFIgUgB3wiBkIgiSAIfCIHhUIViSAFQhGJIAaFIgVCDYkgBSAJfIUiBUIRiYUgBSAHfCIFQiCJhSAFhTcACEEACzEBAX4gAq0gA61CIIaEIgZC8P///w9aBEAQDAALIABBEGogACABIAYgBCAFEFgaQQALzAIBAn8gACEFIwBBIGsiBCQAIAGtIAKtQiCGhCADIARBHGogBEEUaiAEQQxqEIsBQQAhAAJAAkACQANAAkAgACAFai0AAEUEQCAAIQEMAQsgBSAAQQFqIgFqLQAARQ0AIAUgAEECaiIBai0AAEUNACAAQQNqIgBB5gBHDQEMAgsLIAFB5QBHDQAgBEEIaiECIARBEGohA0EAIQACQCAFLQAAQSRHDQAgBS0AAUE3Rw0AIAUtAAJBJEcNACAEQYAIIAUtAANBwQAQMSIBQYAIa0EAIAEbNgIYIAFFDQAgAiAFQQRqEGUiAUUNACADIAEQZSEACyAADQFBwMQCQRw2AgBBfyEADAILQcDEAkEcNgIAQX8hAAwBC0EBIQAgBCgCHCAEKAIYRw0AIAQoAgwgBCgCCEcNACAEKAIUIAQoAhBHIQALIARBIGokACAAC9IBAgN/AX4gACEEIAKtIAOtQiCGhCEHQQAhAiMAQYABayIFJAACQAJAA0AgAiAEai0AAEUEQCACIQAMAgsgBCACQQFqIgBqLQAARQ0BIAQgAkECaiIAai0AAEUNASACQQNqIgJB5gBHDQALQX8hAgwBC0F/IQIgAEHlAEcNACAFQQRqIgZCADcCACAGQQA2AgggBUEQaiIDQQBB5gD8CwAgBiABIAenIAQgAxDXASAGEGcaRQ0AIAMgBEHmABA7IQIgA0HmABAHCyAFQYABaiQAIAILsgYCB38CfiABIQsgBK0gBa1CIIaEIQ5BACEEIwBBgAFrIgckACAAIgxBAEHmAPwLAEEWIQoCfwJAIAKtIAOtQiCGhCIPQv////8PVg0AIA4gBiAHQRBqIAdBDGogB0EIahCLASAHQeAAaiIIQSAQFkEcIQogBygCCCEAIAcoAgwhAiAHQSBqIQECQCAHKAIQIgNBP0sNACACrSAArX5C/////wNWDQAgAUGk7gA7AAAgAUEkOgACIAEgAEE/cUGACGotAAA6AAQgASADQYAIai0AADoAAyABIABBGHZBP3FBgAhqLQAAOgAIIAEgAEESdkE/cUGACGotAAA6AAcgASAAQQx2QT9xQYAIai0AADoABiABIABBBnZBP3FBgAhqLQAAOgAFIAFBCWoiAEUNACABQTpqIgkgAEYNACAAIAJBP3FBgAhqLQAAOgAAIAkgAGsiAEEBRg0AIAEgAkEGdkE/cUGACGotAAA6AAogAEECRg0AIAEgAkEMdkE/cUGACGotAAA6AAsgAEEDRg0AIAEgAkESdkE/cUGACGotAAA6AAwgAEEERg0AIAEgAkEYdkE/cUGACGotAAA6AA0gAUEOaiICRQ0AIAkgAmshBkEAIQADQAJAIAIhAyAAQSBPDQAgACAIai0AACECAn8gAEEBaiIFQSBPIg0EQCAFIQBBAAwBCyAFIAhqLQAAQQh0IAJyIQIgAEECaiIFQSBPBEAgBSEAQQAMAQsgAEEDaiEAIAUgCGotAABBEHQgAnIhAkEBCyEFIAZFDQIgAyACQT9xQYAIai0AADoAACAGQQFGDQIgAyACQQZ2QT9xQYAIai0AADoAASADIAZqAn8gA0ECaiANDQAaIAZBAkYNAyADIAJBDHZBP3FBgAhqLQAAOgACIANBA2ogBUUNABogBkEDRg0DIAMgAkESdkGACGotAAA6AAMgA0EEagsiAmshBiACDQEMAgsLIAMgCU8NACADQQA6AAAgASEECyAERQ0AIAdBFGoiAEIANwIAIABBADYCCCAAIAsgD6cgASAMENcBIAAQZxpFDQBBAAwBC0HAxAIgCjYCAEF/CyAHQYABaiQAC8gBAQN+IAStIAWtQiCGhCEKIAetIAitQiCGhCEMIwBBEGsiBCQAIAGtIAKtQiCGhCILpyIBBEAgAEEAIAH8CwALAn8gCiALhEKAgICAEFoEQEHAxAJBFjYCAEF/DAELIAtCEFoEQCAMIAkgBEEMaiAEQQhqIARBBGoQiwEgACADRgRAQcDEAkEcNgIAQX8MAgsgAyAKpyAGQSBCASAENQIMhiAEKAIEIAQoAgggACABENYBDAELQcDEAkEcNgIAQX8LIARBEGokAAsfACAAIAEgAiADIAStIAWtQiCGhCAGIAcgCCAJENYBC3gCA38BfiMAIgYgBkHAA2tBQHEiBiQAQX8hByACrSADrUIghoQiCUIwWgRAIAZBQGsiAkEAQQBBGBAuGiACIAFCIBANGiACIARCIBANGiACIAZBIGoiAkEYECsaIAAgAUEgaiAJQiB9IAIgASAFEOgBIQcLJAAgBwvJAQIDfwF+An8jACIFIQYgBUGABGtBQHEiBSQAIAKtIAOtQiCGhCIIQvD///8PVARAQX8hAiAFQUBrIgcgBUEgaiIDEExFBEAgBUGAAWoiAkEAQQBBGBAuGiACIAdCIBANGiACIARCIBANGiACIAVB4ABqIgJBGBArGiAAQSBqIAEgCCACIAQgAxDpASECIAAgBSkDWDcAGCAAIAUpA1A3ABAgACAFKQNINwAIIAAgBSkDQDcAACADQSAQBwsgBiQAIAIMAQsQDAALCxkAIAAgASACrSADrUIghoQgBCAFIAYQ6AELZwEBfiADrSAErUIghoQhCCMAQUBqIgMkAAJAIANBIGogByAGECAEQEF/IQAMAQsgA0HgvAIgA0EgaiIEQQAQHxogBEEgEAcgACABIAIgCCAFIAMQbCEAIANBIBAHCyADQUBrJAAgAAsZACAAIAEgAq0gA61CIIaEIAQgBSAGEOkBCy4BAX4gAq0gA61CIIaEIgZC8P///w9aBEAQDAALIABBEGogACABIAYgBCAFEFgLZwEBfiADrSAErUIghoQhCCMAQUBqIgMkAAJAIANBIGogByAGECAEQEF/IQAMAQsgA0HgvAIgA0EgaiIEQQAQHxogBEEgEAcgACABIAIgCCAFIAMQWCEAIANBIBAHCyADQUBrJAAgAAtKAQF+AkAgAa0gAq1CIIaEIgNCgICAgBBUBEAQOiADQgBSBEAgACADp0HcyAIoAgAoAhARBgALDAELQcgKQa4JQdYBQcQIEAAACwubAQEDfyACrSADrUIghoSnIQMgAC0A5AEEfyAAECUgAEEANgLgASAAQQA6AOQBQX8FQQALIAMEQCAAKALgASECA0AgAkGIAUYEQCAAECUgAEEANgLgAUEAIQILIAAgASAEaiACQYgBIAJrIgIgAyAEayIFIAIgBUkbIgUQGCAAIAAoAuABIAVqIgI2AuABIAQgBWoiBCADSQ0ACwsLqAEBA38jAEHwAWsiBSQAIAVBAEHIAfwLACAFQYA+OwHkASAFQQA2AuABIAOtIAStQiCGhKciAwRAA0AgBkGIAUYEQCAFECUgBUEANgLgAUEAIQYLIAUgAiAHaiAGQYgBIAZrIgQgAyAHayIGIAQgBkkbIgQQGCAFIAUoAuABIARqIgY2AuABIAQgB2oiByADSQ0ACwsgBSAAIAEQ5wEaIAVB8AFqJABBAAubAQEDfyACrSADrUIghoSnIQMgAC0A5AEEfyAAECUgAEEANgLgASAAQQA6AOQBQX8FQQALIAMEQCAAKALgASECA0AgAkGoAUYEQCAAECUgAEEANgLgAUEAIQILIAAgASAEaiACQagBIAJrIgIgAyAEayIFIAIgBUkbIgUQGCAAIAAoAuABIAVqIgI2AuABIAQgBWoiBCADSQ0ACwsLqAEBA38jAEHwAWsiBSQAIAVBAEHIAfwLACAFQYA+OwHkASAFQQA2AuABIAOtIAStQiCGhKciAwRAA0AgBkGoAUYEQCAFECUgBUEANgLgAUEAIQYLIAUgAiAHaiAGQagBIAZrIgQgAyAHayIGIAQgBkkbIgQQGCAFIAUoAuABIARqIgY2AuABIAQgB2oiByADSQ0ACwsgBSAAIAEQzwEaIAVB8AFqJABBAAsSACAAIAEgAq0gA61CIIaEEHELFAAgACABIAIgA60gBK1CIIaEEHQLEgAgACABIAKtIAOtQiCGhBBvC6cBAQN/IwBB8AFrIgUkACAFQQBByAH8CwAgBUGAPjsB5AEgBUEANgLgASADrSAErUIghoSnIgMEQANAIAZBqAFGBEAgBRAaIAVBADYC4AFBACEGCyAFIAIgB2ogBkGoASAGayIEIAMgB2siBiAEIAZJGyIEEBggBSAFKALgASAEaiIGNgLgASAEIAdqIgcgA0kNAAsLIAUgACABED0aIAVB8AFqJABBAAtOAQF/IwBBIGsiCCQAIAggBCAHQQAQNhogACABIAKtIAOtQiCGhCAEQRBqIAWtIAatQiCGhCAIQcS9AigCABEOACAIQSAQByAIQSBqJAALIAAgACABIAKtIAOtQiCGhCAEQgAgBUHEvQIoAgARDgALKAAgACABIAKtIAOtQiCGhCAEIAWtIAatQiCGhCAHQcS9AigCABEOAAscACAAIAGtIAKtQiCGhCADIARBwL0CKAIAERAACxYAIAAgASACrSADrUIghoQgBCAFEHwLGAAgACABIAKtIAOtQiCGhCAEIAUgBhBICxQAIAAgAa0gAq1CIIaEIAMgBBBBCxYAIAAgASACrSADrUIghoQgBCAFEH0LIAAgACABIAKtIAOtQiCGhCAEIAWtIAatQiCGhCAHEEkLFAAgACABrSACrUIghoQgAyAEEF8LqgYCA34BfwJ/IAWtIAatQiCGhCEKIAitIAmtQiCGhCEMIwBBkANrIgUkACACBEAgAkIANwMACyADBEAgA0H/AToAAAtBfyENAkACQCAKQhFUDQAgCkIRfSILQu////8PWg0BIAVBIGoiCELAACAAQSBqIgkgABBBGiAFQeAAaiIGIAhBrL0CKAIAEQAAGiAIQcAAEAcgBiAHIAxBsL0CKAIAEQIAGiAGQbC3AkIAIAx9Qg+DQbC9AigCABECABogBUIANwNYIAVCADcDUCAFQgA3A0ggBUIANwNAIAVCADcDOCAFQgA3AzAgBUIANwMoIAVCADcDICAFIAQtAAA6ACAgCCAIQsAAIAlBASAAEEgaIAUtACAhByAFIAQtAAA6ACAgBiAIQsAAQbC9AigCABECABogBiAEQQFqIgQgC0GwvQIoAgARAgAaIAZBsLcCIApCAX1CD4NBsL0CKAIAEQIAGiAFIAw3AxggBiAFQRhqIghCCEGwvQIoAgARAgAaIAUgCkIvfDcDGCAGIAhCCEGwvQIoAgARAgAaIAYgBUG0vQIoAgARAAAaIAZBgAIQByAFIAQgC6dqQRAQOwRAIAVBEBAHDAELIAEgBCALIAlBAiAAEEgaIAAgAC0AJCAFLQAAczoAJCAAIAAtACUgBS0AAXM6ACUgACAALQAmIAUtAAJzOgAmIAAgAC0AJyAFLQADczoAJyAAIAAtACggBS0ABHM6ACggACAALQApIAUtAAVzOgApIAAgAC0AKiAFLQAGczoAKiAAIAAtACsgBS0AB3M6ACsgCRCkAgJAIAdBAnFFBEAgCUEEEBtFDQELIAUgACkAGDcD+AIgBSAAKQAQNwPwAiAFIAApAAg3A+gCIAUgACkAADcD4AIgBSAAKQAkNwOAAyAFQeACaiIBIAFCKCAJIAAQfBogACAFKQP4AjcAGCAAIAUpA/ACNwAQIAAgBSkD6AI3AAggACAFKQPgAjcAACAFKQOAAyEKIABBATYAICAAIAo3ACQLIAIEQCACIAs3AwALQQAhDSADRQ0AIAMgBzoAAAsgBUGQA2okACANDAELEAwACwvbBQECfgJ/IAStIAWtQiCGhCEKIAetIAitQiCGhCELIwBBgANrIgQkACACBEAgAkIANwMACyAKQu////8PVARAIARBEGoiCELAACAAQSBqIgcgABBBGiAEQdAAaiIFIAhBrL0CKAIAEQAAGiAIQcAAEAcgBSAGIAtBsL0CKAIAEQIAGiAFQbC3AkIAIAt9Qg+DQbC9AigCABECABogBEIANwMQIARCADcDSCAEQgA3A0AgBEIANwM4IARCADcDMCAEQgA3AyggBEIANwMgIARCADcDGCAEIAk6ABAgCCAIQsAAIAdBASAAEEgaIAUgCELAAEGwvQIoAgARAgAaIAEgBC0AEDoAACABQQFqIgEgAyAKIAdBAiAAEEgaIAUgASAKQbC9AigCABECABogBUGwtwIgCkIPg0GwvQIoAgARAgAaIAQgCzcDCCAFIARBCGoiA0IIQbC9AigCABECABogBCAKQkB9NwMIIAUgA0IIQbC9AigCABECABogBSABIAqnaiIBQbS9AigCABEAABogBUGAAhAHIAAgAC0AJCABLQAAczoAJCAAIAAtACUgAS0AAXM6ACUgACAALQAmIAEtAAJzOgAmIAAgAC0AJyABLQADczoAJyAAIAAtACggAS0ABHM6ACggACAALQApIAEtAAVzOgApIAAgAC0AKiABLQAGczoAKiAAIAAtACsgAS0AB3M6ACsgBxCkAgJAIAlBAnFFBEAgB0EEEBtFDQELIAQgACkAGDcD6AIgBCAAKQAQNwPgAiAEIAApAAg3A9gCIAQgACkAADcD0AIgBCAAKQAkNwPwAiAEQdACaiIBIAFCKCAHIAAQfBogACAEKQPoAjcAGCAAIAQpA+ACNwAQIAAgBCkD2AI3AAggACAEKQPQAjcAACAEKQPwAiELIAdBATYAACAAIAs3ACQLIAIEQCACIApCEXw3AwALIARBgANqJABBAAwBCxAMAAsLMQEBfiACrSADrUIghoQiBkLw////D1oEQBAMAAsgAEEQaiAAIAEgBiAEIAUQVxpBAAtQAQF+An8gAa0gAq1CIIaEIQQgAEGiDEEKEE5FBEAgACAEIANBAhBoDAELIABBmAxBCRBORQRAIAAgBCADQQEQaAwBC0HAxAJBHDYCAEF/CwtOAQF+An8gAq0gA61CIIaEIQQgAEGiDEEKEE5FBEAgACABIAQQ6gEMAQsgAEGYDEEJEE5FBEAgACABIAQQ8AEMAQtBwMQCQRw2AgBBfwsLUQECfgJ/IAKtIAOtQiCGhCEIIAStIAWtQiCGhCEJAkACQAJAIAdBAWsOAgIAAQsgACABIAggCSAGEOsBDAILEAwACyAAIAEgCCAJIAYQ8QELC3MBA34CfyABrSACrUIghoQhCyAErSAFrUIghoQhDCAHrSAIrUIghoQhDQJAAkACQCAKQQFrDgIAAQILIAAgCyADIAwgBiANIAlBARDyAQwCCyAAIAsgAyAMIAYgDSAJQQIQ7AEMAQtBwMQCQRw2AgBBfwsLEwAgACABIAKtIAOtQiCGhBDqAQstACAAIAGtIAKtQiCGhCADIAStIAWtQiCGhCAGIAetIAitQiCGhCAJIAoQ7AELFAAgACABrSACrUIghoQgA0ECEGgLFAAgACABrSACrUIghoQgA0EBEGgLEwAgACABIAKtIAOtQiCGhBDwAQsfACAAIAEgAq0gA61CIIaEIAStIAWtQiCGhCAGEPEBCy0AIAAgAa0gAq1CIIaEIAMgBK0gBa1CIIaEIAYgB60gCK1CIIaEIAkgChDyAQsSACAAIAEgAq0gA61CIIaEEHALEwAgACABIAKtIAOtQiCGhBCeAQtsAQJ/IwBB8ABrIgQkACAEQgA3AyggBEHAtwIpAwA3AwggBEHItwIpAwA3AxAgBEHQtwIpAwA3AxggBEHYtwIpAwA3AyAgBEEIaiIFIAEgAq0gA61CIIaEEC0aIAUgABA4GiAEQfAAaiQAQQALEgAgACABIAKtIAOtQiCGhBAtCx0AIAAgASACIAOtIAStQiCGhCAFIAYgByAIEIsCC3gCA38BfiMAIgYgBkHAA2tBQHEiBiQAQX8hByACrSADrUIghoQiCUIwWgRAIAZBQGsiAkEAQQBBGBAuGiACIAFCIBANGiACIARCIBANGiACIAZBIGoiAkEYECsaIAAgAUEgaiAJQiB9IAIgASAFENABIQcLJAAgBwvJAQIDfwF+An8jACIFIQYgBUGABGtBQHEiBSQAIAKtIAOtQiCGhCIIQvD///8PVARAQX8hAiAFQUBrIgcgBUEgaiIDEExFBEAgBUGAAWoiAkEAQQBBGBAuGiACIAdCIBANGiACIARCIBANGiACIAVB4ABqIgJBGBArGiAAQSBqIAEgCCACIAQgAxDRASECIAAgBSkDWDcAGCAAIAUpA1A3ABAgACAFKQNINwAIIAAgBSkDQDcAACADQSAQBwsgBiQAIAIMAQsQDAALCxkAIAAgASACrSADrUIghoQgBCAFIAYQ0AELSAEBfiADrSAErUIghoQhCCMAQSBrIgMkAEF/IQQgAyAGIAcQS0UEQCAAIAEgAiAIIAUgAxBrIQQgA0EgEAcLIANBIGokACAECxkAIAAgASACrSADrUIghoQgBCAFIAYQ0QELLgEBfiACrSADrUIghoQiBkLw////D1oEQBAMAAsgAEEQaiAAIAEgBiAEIAUQVwtIAQF+IAOtIAStQiCGhCEIIwBBIGsiAyQAQX8hBCADIAYgBxBLRQRAIAAgASACIAggBSADEFchBCADQSAQBwsgA0EgaiQAIAQLfQECfyMAQaAEayIFJAAgBUFAayIGIARBIBA5GiAGIAEgAq0gA61CIIaEEBMaIAYgBUHgA2oiARAeGiAFQZACaiICIAFCwAAQExogAiAFEB4aIAFBwAAQByAAIAUQ4wEhASAFIABBwAAQOyAFQaAEaiQAQX8gASAAIAVGG3ILXQEBfyMAQeADayIFJAAgBSAEQSAQORogBSABIAKtIAOtQiCGhBATGiAFIAVBoANqIgEQHhogBUHQAWoiAiABQsAAEBMaIAIgABAeGiABQcAAEAcgBUHgA2okAEEAC3kBAn8jAEGQAmsiBSQAIAVBIGoiBiAEQSAQPhogBiABIAKtIAOtQiCGhBAtGiAGIAVB8AFqIgEQOBogBUGIAWoiAiABQiAQLRogAiAFEDgaIAFBIBAHIAAgBRBGIQEgBSAAQSAQOyAFQZACaiQAQX8gASAAIAVGG3ILWwEBfyMAQfABayIFJAAgBSAEQSAQPhogBSABIAKtIAOtQiCGhBAtGiAFIAVB0AFqIgEQOBogBUHoAGoiAiABQiAQLRogAiAAEDgaIAFBIBAHIAVB8AFqJABBAAsSACAAIAEgAq0gA61CIIaEECwLWwECfiAHrSAIrUIghoQhDEF/IQIgBK0gBa1CIIaEIgtCEFoEQCAAIAMgC0IQfSADIAunakEQayAGIAwgCSAKEM0BIQILIAEEQCABQgAgC0IQfSACGzcDAAsgAgslACAAIAIgA60gBK1CIIaEIAUgBiAHrSAIrUIghoQgCSAKEM0BC1kBAn4CfyAGrSAHrUIghoQhDCADrSAErUIghoQiC0Lw////D1QEQCAAIAAgC6dqQQAgAiALIAUgDCAJIAoQzgEaIAEEQCABIAtCEHw3AwALQQAMAQsQDAALCycAIAAgASACIAMgBK0gBa1CIIaEIAYgB60gCK1CIIaEIAogCxDOAQtbAQJ+IAetIAitQiCGhCEMQX8hAiAErSAFrUIghoQiC0IQWgRAIAAgAyALQhB9IAMgC6dqQRBrIAYgDCAJIAoQ3wEhAgsgAQRAIAFCACALQhB9IAIbNwMACyACCyUAIAAgAiADrSAErUIghoQgBSAGIAetIAitQiCGhCAJIAoQ3wELWwECfiAHrSAIrUIghoQhDEF/IQIgBK0gBa1CIIaEIgtCEFoEQCAAIAMgC0IQfSADIAunakEQayAGIAwgCSAKEOABIQILIAEEQCABQgAgC0IQfSACGzcDAAsgAgslACAAIAIgA60gBK1CIIaEIAUgBiAHrSAIrUIghoQgCSAKEOABC1kBAn4CfyAGrSAHrUIghoQhDCADrSAErUIghoQiC0Lw////D1QEQCAAIAAgC6dqQQAgAiALIAUgDCAJIAoQ4QEaIAEEQCABIAtCEHw3AwALQQAMAQsQDAALCycAIAAgASACIAMgBK0gBa1CIIaEIAYgB60gCK1CIIaEIAogCxDhAQtZAQJ+An8gBq0gB61CIIaEIQwgA60gBK1CIIaEIgtC8P///w9UBEAgACAAIAunakEAIAIgCyAFIAwgCSAKEOIBGiABBEAgASALQhB8NwMAC0EADAELEAwACwsnACAAIAEgAiADIAStIAWtQiCGhCAGIAetIAitQiCGhCAKIAsQ4gELWQECfiAHrSAIrUIghoQhC0F/IQECQCADrSAErUIghoQiDELf////D1YNACALQt////8PVg0AIAAgAiAMpyAFQSAgBiALpyAJIApB1L0CKAIAEQ8AIQELIAELgAEBA34gB60gCK1CIIaEIQxBfyECAkAgBK0gBa1CIIaEIgtCIFQNACALQiB9Ig1C3////w9WDQAgDELf////D1YNACAAIAMgDacgAyALp2pBIGtBICAGIAynIAkgCkHUvQIoAgARDwAhAgsgAQRAIAFCACALQiB9IAIbNwMACyACC2ABAn4gBK0gBa1CIIaEIQwgB60gCK1CIIaEIQ0gAgRAIAJCIDcDAAsgDULg////D1QgDELf////D1hxRQRAEAwACyAAIAFBICADIAynIAYgDacgCiALQdC9AigCABEPAAt2AQJ+An8gBq0gB61CIIaEIQsCQCADrSAErUIghoQiDELg////D1oNACALQuD///8PWg0AIAAgACAMpyIDakEgIAIgAyAFIAunIAkgCkHQvQIoAgARDwAhACABBEAgAUIAIAxCIHwgABs3AwALIAAMAQsQDAALC1kBAn4gB60gCK1CIIaEIQtBfyEBAkAgA60gBK1CIIaEIgxC3////w9WDQAgC0Lf////D1YNACAAIAIgDKcgBUEgIAYgC6cgCSAKQcy9AigCABEPACEBCyABC4ABAQN+IAetIAitQiCGhCEMQX8hAgJAIAStIAWtQiCGhCILQiBUDQAgC0IgfSINQt////8PVg0AIAxC3////w9WDQAgACADIA2nIAMgC6dqQSBrQSAgBiAMpyAJIApBzL0CKAIAEQ8AIQILIAEEQCABQgAgC0IgfSACGzcDAAsgAgtgAQJ+IAStIAWtQiCGhCEMIAetIAitQiCGhCENIAIEQCACQiA3AwALIA1C4P///w9UIAxC3////w9YcUUEQBAMAAsgACABQSAgAyAMpyAGIA2nIAogC0HIvQIoAgARDwALdgECfgJ/IAatIAetQiCGhCELAkAgA60gBK1CIIaEIgxC4P///w9aDQAgC0Lg////D1oNACAAIAAgDKciA2pBICACIAMgBSALpyAJIApByL0CKAIAEQ8AIQAgAQRAIAFCACAMQiB8IAAbNwMACyAADAELEAwACwsFAEHoAAsEAEEaCwUAQYEMCwUAQboKC54GAQV/IwAiBSEJIAVBgARrQUBxIgUkACAAIAEgABsiBgRAQX8hByAFQeAAaiIIIAMgBBAgRQRAIAVBgAFqIgNBAEEAQcAAEC4aIAMgCEIgEA0aIAhBIBAHIAMgBEIgEA0aIAMgAkIgEA0aIAMgBUEgaiICQcAAECsaIANBgAMQByABIAAgARsiACAFLQAgOgAAIAYgBS0AQDoAACAAIAUtACE6AAEgBiAFLQBBOgABIAAgBS0AIjoAAiAGIAUtAEI6AAIgACAFLQAjOgADIAYgBS0AQzoAAyAAIAUtACQ6AAQgBiAFLQBEOgAEIAAgBS0AJToABSAGIAUtAEU6AAUgACAFLQAmOgAGIAYgBS0ARjoABiAAIAUtACc6AAcgBiAFLQBHOgAHIAAgBS0AKDoACCAGIAUtAEg6AAggACAFLQApOgAJIAYgBS0ASToACSAAIAUtACo6AAogBiAFLQBKOgAKIAAgBS0AKzoACyAGIAUtAEs6AAsgACAFLQAsOgAMIAYgBS0ATDoADCAAIAUtAC06AA0gBiAFLQBNOgANIAAgBS0ALjoADiAGIAUtAE46AA4gACAFLQAvOgAPIAYgBS0ATzoADyAAIAUtADA6ABAgBiAFLQBQOgAQIAAgBS0AMToAESAGIAUtAFE6ABEgACAFLQAyOgASIAYgBS0AUjoAEiAAIAUtADM6ABMgBiAFLQBTOgATIAAgBS0ANDoAFCAGIAUtAFQ6ABQgACAFLQA1OgAVIAYgBS0AVToAFSAAIAUtADY6ABYgBiAFLQBWOgAWIAAgBS0ANzoAFyAGIAUtAFc6ABcgACAFLQA4OgAYIAYgBS0AWDoAGCAAIAUtADk6ABkgBiAFLQBZOgAZIAAgBS0AOjoAGiAGIAUtAFo6ABogACAFLQA7OgAbIAYgBS0AWzoAGyAAIAUtADw6ABwgBiAFLQBcOgAcIAAgBS0APToAHSAGIAUtAF06AB0gACAFLQA+OgAeIAYgBS0AXjoAHiAAIAUtAD86AB8gBiAFLQBfOgAfIAJBwAAQB0EAIQcLIAkkACAHDwsQDAALngYBBX8jACIFIQkgBUGABGtBQHEiBSQAIAAgASAAGyIGBEBBfyEHIAVB4ABqIgggAyAEECBFBEAgBUGAAWoiA0EAQQBBwAAQLhogAyAIQiAQDRogCEEgEAcgAyACQiAQDRogAyAEQiAQDRogAyAFQSBqIgJBwAAQKxogA0GAAxAHIAYgBS0AIDoAACABIAAgARsiACAFLQBAOgAAIAYgBS0AIToAASAAIAUtAEE6AAEgBiAFLQAiOgACIAAgBS0AQjoAAiAGIAUtACM6AAMgACAFLQBDOgADIAYgBS0AJDoABCAAIAUtAEQ6AAQgBiAFLQAlOgAFIAAgBS0ARToABSAGIAUtACY6AAYgACAFLQBGOgAGIAYgBS0AJzoAByAAIAUtAEc6AAcgBiAFLQAoOgAIIAAgBS0ASDoACCAGIAUtACk6AAkgACAFLQBJOgAJIAYgBS0AKjoACiAAIAUtAEo6AAogBiAFLQArOgALIAAgBS0ASzoACyAGIAUtACw6AAwgACAFLQBMOgAMIAYgBS0ALToADSAAIAUtAE06AA0gBiAFLQAuOgAOIAAgBS0ATjoADiAGIAUtAC86AA8gACAFLQBPOgAPIAYgBS0AMDoAECAAIAUtAFA6ABAgBiAFLQAxOgARIAAgBS0AUToAESAGIAUtADI6ABIgACAFLQBSOgASIAYgBS0AMzoAEyAAIAUtAFM6ABMgBiAFLQA0OgAUIAAgBS0AVDoAFCAGIAUtADU6ABUgACAFLQBVOgAVIAYgBS0ANjoAFiAAIAUtAFY6ABYgBiAFLQA3OgAXIAAgBS0AVzoAFyAGIAUtADg6ABggACAFLQBYOgAYIAYgBS0AOToAGSAAIAUtAFk6ABkgBiAFLQA6OgAaIAAgBS0AWjoAGiAGIAUtADs6ABsgACAFLQBbOgAbIAYgBS0APDoAHCAAIAUtAFw6ABwgBiAFLQA9OgAdIAAgBS0AXToAHSAGIAUtAD46AB4gACAFLQBeOgAeIAYgBS0APzoAHyAAIAUtAF86AB8gAkHAABAHQQAhBwsgCSQAIAcPCxAMAAsfACABQSAgAkIgQQBBABB6GiAAIAFBvL0CKAIAEQAACwoAIAAgASACECALBQBBqQsLBQBBvAsLCwAgACABIAIQzwELBQBBiAwLBQBB1AsLiAEBAn8jAEGABGsiBCQAIARBIGoiBSADQSAQORogBSABIAIQLxogBSAEQcADaiIBED8aIAQgBCkD2AM3AxggBCAEKQPQAzcDECAEIAQpA8gDNwMIIAQgBCkDwAM3AwAgAUHAABAHIAAgBBBGIQEgBCAAQSAQOyAEQYAEaiQAQX8gASAAIARGG3ILCwAgACABEIwBQQALagEBfyMAQeADayIEJAAgBCADQSAQORogBCABIAIQLxogBCAEQaADaiIBED8aIAAgBCkDuAM3ABggACAEKQOwAzcAECAAIAQpA6gDNwAIIAAgBCkDoAM3AAAgAUHAABAHIARB4ANqJABBAAtMAQF/IwBBQGoiAiQAIAAgAhA/GiABIAIpAxg3ABggASACKQMQNwAQIAEgAikDCDcACCABIAIpAwA3AAAgAkHAABAHIAJBQGskAEEAC/UCAQF/IwBBoAFrIgIkACAAIAEtAAA6AAAgACABLQABOgABIAAgAS0AAjoAAiAAIAEtAAM6AAMgACABLQAEOgAEIAAgAS0ABToABSAAIAEtAAY6AAYgACABLQAHOgAHIAAgAS0ACDoACCAAIAEtAAk6AAkgACABLQAKOgAKIAAgAS0ACzoACyAAIAEtAAw6AAwgACABLQANOgANIAAgAS0ADjoADiAAIAEtAA86AA8gACABLQAQOgAQIAAgAS0AEToAESAAIAEtABI6ABIgACABLQATOgATIAAgAS0AFDoAFCAAIAEtABU6ABUgACABLQAWOgAWIAAgAS0AFzoAFyAAIAEtABg6ABggACABLQAZOgAZIAAgAS0AGjoAGiAAIAEtABs6ABsgACABLQAcOgAcIAAgAS0AHToAHSAAIAEtAB46AB4gACABLQAfQf8AcToAHyACIAAQMCAAIAIQVSAAQSAQGyEAIAJBoAFqJABBf0EAIAAbC4wDAQJ/IwBBwAJrIgMkAEF/IQQgAyACEEpFBEAgACABLQAAOgAAIAAgAS0AAToAASAAIAEtAAI6AAIgACABLQADOgADIAAgAS0ABDoABCAAIAEtAAU6AAUgACABLQAGOgAGIAAgAS0ABzoAByAAIAEtAAg6AAggACABLQAJOgAJIAAgAS0ACjoACiAAIAEtAAs6AAsgACABLQAMOgAMIAAgAS0ADToADSAAIAEtAA46AA4gACABLQAPOgAPIAAgAS0AEDoAECAAIAEtABE6ABEgACABLQASOgASIAAgAS0AEzoAEyAAIAEtABQ6ABQgACABLQAVOgAVIAAgAS0AFjoAFiAAIAEtABc6ABcgACABLQAYOgAYIAAgAS0AGToAGSAAIAEtABo6ABogACABLQAbOgAbIAAgAS0AHDoAHCAAIAEtAB06AB0gACABLQAeOgAeIAAgAS0AH0H/AHE6AB8gA0GgAWoiASAAIAMQhgEgACABEFVBf0EAIABBIBAbGyEECyADQcACaiQAIAQLBQBB3AsLCwAgACABIAIQ/QELCwAgACABIAIQ/gELCQAgACABEIACCwsAIAAgASACEIECCwUAQZ4JCw0AIAAgASACEI0BQQALBQBB9wsL+AUCBn4BfyADKQAAIgRC9crNg9es27fzAIUhBiAEQuHklfPW7Nm87ACFIQcgAykACCIFQu3ekfOWzNy35ACFIQQgBULzytHLp4zZsvQAhSEFIAEgASACpyIDaiADQQdxIgprIAJQGyIDIAFHBEADQCAHIAEpAAAiCCAFhSIHfCIFIAQgBnwiBiAEQg2JhSIEfCIJIARCEYmFIgRCDYkgBCAHQhCJIAWFIgQgBkIgiXwiBnwiB4UiBUIRiSAFIARCFYkgBoUiBiAJQiCJfCIFfCIJhSEEIAZCEIkgBYUiBkIViSAGIAdCIIl8IgaFIQUgCUIgiSEHIAYgCIUhBiABQQhqIgEgA0cNAAsgAyEBCyACQjiGIQICQAJAAkACQAJAAkACQAJAIApBAWsOBwYFBAMCAQAHCyABMQAGQjCGIAKEIQILIAExAAVCKIYgAoQhAgsgATEABEIghiAChCECCyABMQADQhiGIAKEIQILIAExAAJCEIYgAoQhAgsgATEAAUIIhiAChCECCyACIAExAACEIQILIAAgAiAFhSIFQhCJIAUgB3wiB4UiBUIViSAFIAQgBnwiBkIgiXwiBYUiCEIQiSAIIAcgBiAEQg2JhSIEfCIGQiCJfCIHhSIIQhWJIAggBSAGIARCEYmFIgR8IgZCIIl8IgWFIghCEIkgByAEQg2JIAaFIgR8IgZCIIlC/wGFIAh8IgeFIghCFYkgBEIRiSAGhSIEIAIgBYV8IgJCIIkgCHwiBoUiBUIQiSACIARCDYmFIgIgB3wiBEIgiSAFfCIHhSIFQhWJIAJCEYkgBIUiAiAGfCIEQiCJIAV8IgaFIgVCEIkgAkINiSAEhSICIAd8IgRCIIkgBXwiB4UiBUIViSACQhGJIASFIgIgBnwiBEIgiSAFfCIGhSIFQhCJIAJCDYkgBIUiAiAHfCIEQiCJIAV8IgeFQhWJIAJCEYkgBIUiAkINiSACIAZ8hSICQhGJhSACIAd8IgJCIImFIAKFNwAAQQALawIBfwF+IwBBIGsiBSQAIAMpAAAhBiAFQgA3AxggBSAGNwMQIAVCADcDCCAFIAI3AwACfyABQcEAa0FOTQRAQcDEAkEcNgIAQX8MAQsgACABQQBCACAEQSAgBSAFQRBqEIsCCyAFQSBqJAALEgAgACABIAJBhL4CKAIAEQQACxIAIAAgASACQYC+AigCABEEAAsSACAAIAEgAkH8vQIoAgARBAALFAAgACABIAIgA0H4vQIoAgARDQALEgAgACABIAJB9L0CKAIAEQQAC7QBAQF/IAAgASgAAEH///8fcTYCACAAIAEoAANBAnZBg/7/H3E2AgQgACABKAAGQQR2Qf+B/x9xNgIIIAAgASgACUEGdkH//8AfcTYCDCABKAAMIQIgAEIANwIUIABCADcCHCAAQQA2AiQgACACQQh2Qf//P3E2AhAgACABKAAQNgIoIAAgASgAFDYCLCAAIAEoABg2AjAgASgAHCEBIABBADoAUCAAQgA3AzggACABNgI0QQALFAAgACABIAIgA0HwvQIoAgARDQALEgAgACABIAJB7L0CKAIAEQQACxIAIAAgASACQei9AigCABEEAAv/FgIXfwJ+IwBBsAhrIgMkACADQYAHaiACEB0gA0HQBWoiBCACQRBqEB0gAyADKALQByADKAKgBnMiBTYCwAUgAyADKALUByADKAKkBnMiBjYCxAUgAyADKALYByADKAKoBnMiBzYCyAUgAyADKALcByADKAKsBnMiCDYCzAUgBUEIdiAFQRB2ciAFQRh2ciAGQQh2ciAGQRB2ciAGQRh2ciAHQQh2ciAHQRB2ciAHQRh2ciAIQQh2ciAIQRB2ciAIQRh2ciAFciAGciAHciAIckH/AXFFBEAgAyACLQAAQdoAczoAwAUgAyACLQABQdoAczoAwQUgAyACLQACQdoAczoAwgUgAyACLQADQdoAczoAwwUgAyACLQAEQdoAczoAxAUgAyACLQAFQdoAczoAxQUgAyACLQAGQdoAczoAxgUgAyACLQAHQdoAczoAxwUgAyACLQAIQdoAczoAyAUgAyACLQAJQdoAczoAyQUgAyACLQAKQdoAczoAygUgAyACLQALQdoAczoAywUgAyACLQAMQdoAczoAzAUgAyACLQANQdoAczoAzQUgAyACLQAOQdoAczoAzgUgAyACLQAPQdoAczoAzwUgBCADQcAFahAdCyABNQAIIRogASkAACEbIANCADcDuAUgA0IANwOwBQJ/IBsgGkKAgPz/D4WEQgBSBEBBACEFQQAhBkGAgIAIDAELIANB//8DOwG6BUEBIQZB4AAhBUGAgHwLIQIgA0GQCGohFCADQYAIaiEVIANBoAhqIRZBACEHQQAhCANAIAMgAygCjAcgAnM2AqwFIAMgDUH/AXEgE0EYdCIXIA9B/wFxQRB0ciAOQf8BcUEIdHJyIgQgAygCiAdzNgKoBSADIApB/wFxIBJBGHQiGCAMQf8BcUEQdHIgC0H/AXFBCHRyciIJIAMoAoQHczYCpAUgAyARQf8BcSAGQRh0IhkgCEH/AXFBEHRyIAdB/wFxQQh0cnIiECADKAKAB3M2AqAFIAMgAygC3AUgAnM2ApwFIAMgAygC2AUgBHM2ApgFIAMgAygC1AUgCXM2ApQFIAMgAygC0AUgEHM2ApAFIAMgAykDqAU3A/gEIAMgAykDoAU3A/AEIAMgAykCmAc3A+gEIAMgAykCkAc3A+AEIANBgAVqIgQgA0HwBGogA0HgBGoQBiADIAMpAogFNwOoBSADIAMpAoAFNwOgBSADIAMpA5AFNwPQBCADIAMpA5gFNwPYBCADIAMpAuAFNwPABCADIAMpAugFNwPIBCAEIANB0ARqIANBwARqEAYgAyADKQKIBTcDmAUgAyADKQKABTcDkAUgAyADKQOgBTcDsAQgAyADKQOoBTcDuAQgAyADKQKgBzcDoAQgAyADKQKoBzcDqAQgBCADQbAEaiADQaAEahAGIAMgAykCiAU3A6gFIAMgAykCgAU3A6AFIAMgAykDkAU3A5AEIAMgAykDmAU3A5gEIAMgAykC8AU3A4AEIAMgAykC+AU3A4gEIAQgA0GQBGogA0GABGoQBiADIAMpAogFNwOYBSADIAMpAoAFNwOQBSADIAMpA6AFNwPwAyADIAMpA6gFNwP4AyADIAMpArAHNwPgAyADIAMpArgHNwPoAyAEIANB8ANqIANB4ANqEAYgAyADKQKIBTcDqAUgAyADKQKABTcDoAUgAyADKQOQBTcD0AMgAyADKQOYBTcD2AMgAyADKQKABjcDwAMgAyADKQKIBjcDyAMgBCADQdADaiADQcADahAGIAMgAykCiAU3A5gFIAMgAykCgAU3A5AFIAMgAykDoAU3A7ADIAMgAykDqAU3A7gDIAMgAykCwAc3A6ADIAMgAykCyAc3A6gDIAQgA0GwA2ogA0GgA2oQBiADIAMpAogFNwOoBSADIAMpAoAFNwOgBSADIAMpA5AFNwOQAyADIAMpA5gFNwOYAyADIAMpApAGNwOAAyADIAMpApgGNwOIAyAEIANBkANqIANBgANqEAYgAyADKQKIBTcDmAUgAyADKQKABTcDkAUgAyADKQOgBTcD8AIgAyADKQOoBTcD+AIgAyADKQLQBzcD4AIgAyADKQLYBzcD6AIgBCADQfACaiADQeACahAGIAMgAykCiAU3A6gFIAMgAykCgAU3A6AFIAMgAykDkAU3A9ACIAMgAykDmAU3A9gCIAMgAykCoAY3A8ACIAMgAykCqAY3A8gCIAQgA0HQAmogA0HAAmoQBiADIAMpAogFNwOYBSADIAMpAoAFNwOQBSADIAMpA6AFNwOwAiADIAMpA6gFNwO4AiADIAMpAuAHNwOgAiADIAMpAugHNwOoAiAEIANBsAJqIANBoAJqEAYgAyADKQKIBTcDqAUgAyADKQKABTcDoAUgAyADKQOQBTcDkAIgAyADKQOYBTcDmAIgAyADKQKwBjcDgAIgAyADKQK4BjcDiAIgBCADQZACaiADQYACahAGIAMgAykCiAU3A5gFIAMgAykCgAU3A5AFIAMgAykDoAU3A/ABIAMgAykDqAU3A/gBIAMgAykC8Ac3A+ABIAMgAykC+Ac3A+gBIAQgA0HwAWogA0HgAWoQBiADIAMpAogFNwOoBSADIAMpAoAFNwOgBSADIAMpA5AFNwPQASADIAMpA5gFNwPYASADIAMpAsAGNwPAASADIAMpAsgGNwPIASAEIANB0AFqIANBwAFqEAYgAyADKQKIBTcDmAUgAyADKQKABTcDkAUgAyADKQOgBTcDsAEgAyADKQOoBTcDuAEgAyAVKQIANwOgASADIBUpAgg3A6gBIAQgA0GwAWogA0GgAWoQBiADIAMpAogFNwOoBSADIAMpAoAFNwOgBSADIAMpA5AFNwOQASADIAMpA5gFNwOYASADIAMpAtAGNwOAASADIAMpAtgGNwOIASAEIANBkAFqIANBgAFqEAYgAyADKQKIBTcDmAUgAyADKQKABTcDkAUgAyADKQOgBTcDcCADIAMpA6gFNwN4IAMgFCkCADcDYCADIBQpAgg3A2ggBCADQfAAaiADQeAAahAGIAMgAykCiAU3A6gFIAMgAykCgAU3A6AFIAMgAykDkAU3A1AgAyADKQOYBTcDWCADIAMpAuAGNwNAIAMgAykC6AY3A0ggBCADQdAAaiADQUBrEAYgAyADKQKIBTcDmAUgAyADKQKABTcDkAUgAyADKQOgBTcDMCADIAMpA6gFNwM4IAMgFikCADcDICADIBYpAgg3AyggBCADQTBqIANBIGoQQiADIAMpAogFNwOoBSADIAMpAoAFNwOgBSADIAMpA5AFNwMQIAMgAykDmAU3AxggAyADKQLwBjcDACADIAMpAvgGNwMIIAQgA0EQaiADEEIgAyADKQKIBTcDmAUgAyADKQKABTcDkAVBACABQf8AIAVrIgRBA3ZBD3MiCWotAAAgBEEHcSIEdiADKAKsBSADKAKcBXNBGHZzQQFxayEQIANBsAVqIAlyIgkgECAJLQAAIglzQQEgBHRxIAlzOgAAIAJBAXQiBEGAgIBwcSAQQQFxQRh0ciAEIAJBD3YiCUEBcXJB/wFxIAJBB3YiBEH+AXEgAkEXdkEBcXJBCHRyIAlB/gFxIAJBH3ZyQRB0cnIhAiAEQQFxIBNBAXRyIRMgDUEHdkEBcSASQQF0ciESIApBB3ZBAXEgBkEBdHIhBiAHQQd2QQFxIBFBAXRyIREgCEEHdkEBcSAHQQF0ciEHIAhBAXQgGUEfdnIhCCALQQd2QQFxIApBAXRyIQogDEEHdkEBcSALQQF0ciELIAxBAXQgGEEfdnIhDCAOQQd2QQFxIA1BAXRyIQ0gD0EHdkEBcSAOQQF0ciEOIA9BAXQgF0EfdnIhDyAFQQFqIgVBgAFHDQALIAAgAykDuAU3AAggACADKQOwBTcAACADQbAIaiQAC4cXAhh/An4jAEGwCGsiAyQAIANBgAdqIAIQHSADQdAFaiIEIAJBEGoQHSADIAMoAtAHIAMoAqAGcyIFNgLABSADIAMoAtQHIAMoAqQGcyIGNgLEBSADIAMoAtgHIAMoAqgGcyIHNgLIBSADIAMoAtwHIAMoAqwGcyIINgLMBSAFQQh2IAVBEHZyIAVBGHZyIAZBCHZyIAZBEHZyIAZBGHZyIAdBCHZyIAdBEHZyIAdBGHZyIAhBCHZyIAhBEHZyIAhBGHZyIAVyIAZyIAdyIAhyQf8BcUUEQCADIAItAABB2gBzOgDABSADIAItAAFB2gBzOgDBBSADIAItAAJB2gBzOgDCBSADIAItAANB2gBzOgDDBSADIAItAARB2gBzOgDEBSADIAItAAVB2gBzOgDFBSADIAItAAZB2gBzOgDGBSADIAItAAdB2gBzOgDHBSADIAItAAhB2gBzOgDIBSADIAItAAlB2gBzOgDJBSADIAItAApB2gBzOgDKBSADIAItAAtB2gBzOgDLBSADIAItAAxB2gBzOgDMBSADIAItAA1B2gBzOgDNBSADIAItAA5B2gBzOgDOBSADIAItAA9B2gBzOgDPBSAEIANBwAVqEB0LIAE1AAghGyABKQAAIRwgA0IANwO4BSADQgA3A7AFAn8gHCAbQoCA/P8PhYRCAFIEQEEAIQVBACEGQYCAgAgMAQsgA0H//wM7AboFQQEhBkHgACEFQYCAfAshAiADQZAIaiEUIANBgAhqIRUgA0GgCGohFkEAIQdBACEIA0AgAyADKAKMByACczYCrAUgAyANQf8BcSASQRh0IhcgD0H/AXFBEHRyIA5B/wFxQQh0cnIiBCADKAKIB3M2AqgFIAMgCkH/AXEgEUEYdCIYIAxB/wFxQRB0ciALQf8BcUEIdHJyIgkgAygChAdzNgKkBSADIBBB/wFxIAZBGHQiGSAIQf8BcUEQdHIgB0H/AXFBCHRyciITIAMoAoAHczYCoAUgAyADKALcBSACczYCnAUgAyADKALYBSAEczYCmAUgAyADKALUBSAJczYClAUgAyADKALQBSATczYCkAUgAyADKQOoBTcD+AQgAyADKQOgBTcD8AQgAyADKQKYBzcD6AQgAyADKQKQBzcD4AQgA0GABWoiBCADQfAEaiADQeAEahAGIAMgAykCiAU3A6gFIAMgAykCgAU3A6AFIAMgAykDkAU3A9AEIAMgAykDmAU3A9gEIAMgAykC4AU3A8AEIAMgAykC6AU3A8gEIAQgA0HQBGogA0HABGoQBiADIAMpAogFNwOYBSADIAMpAoAFNwOQBSADIAMpA6AFNwOwBCADIAMpA6gFNwO4BCADIAMpAqAHNwOgBCADIAMpAqgHNwOoBCAEIANBsARqIANBoARqEAYgAyADKQKIBTcDqAUgAyADKQKABTcDoAUgAyADKQOQBTcDkAQgAyADKQOYBTcDmAQgAyADKQLwBTcDgAQgAyADKQL4BTcDiAQgBCADQZAEaiADQYAEahAGIAMgAykCiAU3A5gFIAMgAykCgAU3A5AFIAMgAykDoAU3A/ADIAMgAykDqAU3A/gDIAMgAykCsAc3A+ADIAMgAykCuAc3A+gDIAQgA0HwA2ogA0HgA2oQBiADIAMpAogFNwOoBSADIAMpAoAFNwOgBSADIAMpA5AFNwPQAyADIAMpA5gFNwPYAyADIAMpAoAGNwPAAyADIAMpAogGNwPIAyAEIANB0ANqIANBwANqEAYgAyADKQKIBTcDmAUgAyADKQKABTcDkAUgAyADKQOgBTcDsAMgAyADKQOoBTcDuAMgAyADKQLABzcDoAMgAyADKQLIBzcDqAMgBCADQbADaiADQaADahAGIAMgAykCiAU3A6gFIAMgAykCgAU3A6AFIAMgAykDkAU3A5ADIAMgAykDmAU3A5gDIAMgAykCkAY3A4ADIAMgAykCmAY3A4gDIAQgA0GQA2ogA0GAA2oQBiADIAMpAogFNwOYBSADIAMpAoAFNwOQBSADIAMpA6AFNwPwAiADIAMpA6gFNwP4AiADIAMpAtAHNwPgAiADIAMpAtgHNwPoAiAEIANB8AJqIANB4AJqEAYgAyADKQKIBTcDqAUgAyADKQKABTcDoAUgAyADKQOQBTcD0AIgAyADKQOYBTcD2AIgAyADKQKgBjcDwAIgAyADKQKoBjcDyAIgBCADQdACaiADQcACahAGIAMgAykCiAU3A5gFIAMgAykCgAU3A5AFIAMgAykDoAU3A7ACIAMgAykDqAU3A7gCIAMgAykC4Ac3A6ACIAMgAykC6Ac3A6gCIAQgA0GwAmogA0GgAmoQBiADIAMpAogFNwOoBSADIAMpAoAFNwOgBSADIAMpA5AFNwOQAiADIAMpA5gFNwOYAiADIAMpArAGNwOAAiADIAMpArgGNwOIAiAEIANBkAJqIANBgAJqEAYgAyADKQKIBTcDmAUgAyADKQKABTcDkAUgAyADKQOgBTcD8AEgAyADKQOoBTcD+AEgAyADKQLwBzcD4AEgAyADKQL4BzcD6AEgBCADQfABaiADQeABahAGIAMgAykCiAU3A6gFIAMgAykCgAU3A6AFIAMgAykDkAU3A9ABIAMgAykDmAU3A9gBIAMgAykCwAY3A8ABIAMgAykCyAY3A8gBIAQgA0HQAWogA0HAAWoQBiADIAMpAogFNwOYBSADIAMpAoAFNwOQBSADIAMpA6AFNwOwASADIAMpA6gFNwO4ASADIBUpAgA3A6ABIAMgFSkCCDcDqAEgBCADQbABaiADQaABahAGIAMgAykCiAU3A6gFIAMgAykCgAU3A6AFIAMgAykDkAU3A5ABIAMgAykDmAU3A5gBIAMgAykC0AY3A4ABIAMgAykC2AY3A4gBIAQgA0GQAWogA0GAAWoQBiADIAMpAogFNwOYBSADIAMpAoAFNwOQBSADIAMpA6AFNwNwIAMgAykDqAU3A3ggAyAUKQIANwNgIAMgFCkCCDcDaCAEIANB8ABqIANB4ABqEAYgAyADKQKIBTcDqAUgAyADKQKABTcDoAUgAyADKQOQBTcDUCADIAMpA5gFNwNYIAMgAykC4AY3A0AgAyADKQLoBjcDSCAEIANB0ABqIANBQGsQBiADIAMpAogFNwOYBSADIAMpAoAFNwOQBSADIAMpA6AFNwMwIAMgAykDqAU3AzggAyAWKQIANwMgIAMgFikCCDcDKCAEIANBMGogA0EgahBCIAMgAykCiAU3A6gFIAMgAykCgAU3A6AFIAMgAykDkAU3AxAgAyADKQOYBTcDGCADIAMpAvAGNwMAIAMgAykC+AY3AwggBCADQRBqIAMQQiADIAMpAogFNwOYBSADIAMpAoAFNwOQBUEAIAFB/wAgBWsiBEEDdkEPcyIJai0AACAEQQdxIgR2IhMgAygCrAUgAygCnAVzQRh2c0EBcWshGiADQbAFaiAJciIJIBogCS0AACIJc0EBIAR0cSAJczoAACACQQF0IgRBgICAcHFBACATQQFxa0EBcUEYdHIgBCACQQ92IglBAXFyQf8BcSACQQd2IgRB/gFxIAJBF3ZBAXFyQQh0ciAJQf4BcSACQR92ckEQdHJyIQIgBEEBcSASQQF0ciESIA1BB3ZBAXEgEUEBdHIhESAKQQd2QQFxIAZBAXRyIQYgB0EHdkEBcSAQQQF0ciEQIAhBB3ZBAXEgB0EBdHIhByAIQQF0IBlBH3ZyIQggC0EHdkEBcSAKQQF0ciEKIAxBB3ZBAXEgC0EBdHIhCyAMQQF0IBhBH3ZyIQwgDkEHdkEBcSANQQF0ciENIA9BB3ZBAXEgDkEBdHIhDiAPQQF0IBdBH3ZyIQ8gBUEBaiIFQYABRw0ACyAAIAMpA7gFNwAIIAAgAykDsAU3AAAgA0GwCGokAAuGDAIGfwJ+IwBBoAdrIgMkACADQYAEaiACQRBqEB0gA0HQAmoiCCACEB0gAyADKALQBCADKAKgA3MiBDYCwAIgAyADKALUBCADKAKkA3MiBTYCxAIgAyADKALYBCADKAKoA3MiBjYCyAIgAyADKALcBCADKAKsA3MiBzYCzAIgBEEIdiAEQRB2ciAEQRh2ciAFQQh2ciAFQRB2ciAFQRh2ciAGQQh2ciAGQRB2ciAGQRh2ciAHQQh2ciAHQRB2ciAHQRh2ciAEciAFciAGciAHckH/AXFFBEAgAyACLQAAQdoAczoAwAIgAyACLQABQdoAczoAwQIgAyACLQACQdoAczoAwgIgAyACLQADQdoAczoAwwIgAyACLQAEQdoAczoAxAIgAyACLQAFQdoAczoAxQIgAyACLQAGQdoAczoAxgIgAyACLQAHQdoAczoAxwIgAyACLQAIQdoAczoAyAIgAyACLQAJQdoAczoAyQIgAyACLQAKQdoAczoAygIgAyACLQALQdoAczoAywIgAyACLQAMQdoAczoAzAIgAyACLQANQdoAczoAzQIgAyACLQAOQdoAczoAzgIgAyACLQAPQdoAczoAzwIgCCADQcACahAdCyADQeAFaiABIANBgARqENIBIANB8AVqIgIgA0HQAmpBsAH8CgAAIAIQgQEgASgAGCECIAEoABwhBCABKAAQIQUgAyADKALkBSIGIAEoABQgAygClAdzczYC1AUgAyADKALgBSIBIAUgAygCkAdzczYC0AUgAyADKALsBSIFIAQgAygCnAdzczYC3AUgAyADKALoBSIEIAIgAygCmAdzczYC2AUgAyADKQPQBTcDsAIgAyADKQPYBTcDuAIgAyADKQOABzcDoAIgAyADKQOIBzcDqAIgA0HABWoiAiADQbACaiADQaACahAQIAMgAykCyAUiCTcD2AUgAyADKQLABSIKNwPQBSADIAo3A5ACIAMgCTcDmAIgAyADKQPwBjcDgAIgAyADKQP4BjcDiAIgAiADQZACaiADQYACahAQIAMgAykCyAUiCTcD2AUgAyADKQLABSIKNwPQBSADIAo3A/ABIAMgCTcD+AEgAyADKQPgBjcD4AEgAyADKQPoBjcD6AEgAiADQfABaiADQeABahAQIAMgAykCyAUiCTcD2AUgAyADKQLABSIKNwPQBSADIAo3A9ABIAMgCTcD2AEgAyADKQPQBjcDwAEgAyADKQPYBjcDyAEgAiADQdABaiADQcABahAQIAMgAykCyAUiCTcD2AUgAyADKQLABSIKNwPQBSADIAo3A7ABIAMgCTcDuAEgAyADKQPABjcDoAEgAyADKQPIBjcDqAEgAiADQbABaiADQaABahAQIAMgAykCyAUiCTcD2AUgAyADKQLABSIKNwPQBSADIAo3A5ABIAMgCTcDmAEgAyADKQOwBjcDgAEgAyADKQO4BjcDiAEgAiADQZABaiADQYABahAQIAMgAykCyAUiCTcD2AUgAyADKQLABSIKNwPQBSADIAo3A3AgAyAJNwN4IAMgAykDoAY3A2AgAyADKQOoBjcDaCACIANB8ABqIANB4ABqEBAgAyADKQLIBSIJNwPYBSADIAMpAsAFIgo3A9AFIAMgCjcDUCADIAk3A1ggAyADKQOQBjcDQCADIAMpA5gGNwNIIAIgA0HQAGogA0FAaxAQIAMgAykCyAUiCTcD2AUgAyADKQLABSIKNwPQBSADIAo3AzAgAyAJNwM4IAMgAykDgAY3AyAgAyADKQOIBjcDKCACIANBMGogA0EgahAQIAMgBSADKAL8BXM2ArwFIAMgBCADKAL4BXM2ArgFIAMgBiADKAL0BXM2ArQFIAMgASADKALwBXM2ArAFIAMgAykCyAUiCTcD2AUgAyADKQLABSIKNwPQBSADIAo3AxAgAyAJNwMYIAMgAykCuAU3AwggAyADKQKwBTcDACACIANBEGogAxCiASADIAMpAsgFIgk3A9gFIAMgAykCwAUiCjcD0AUgACAJNwAIIAAgCjcAACADQaAHaiQAC/8LAgZ/An4jAEHwBWsiBCQAIARBgARqIANBEGoQHSAEQdACaiIJIAMQHSAEIAQoAtAEIAQoAqADcyIFNgLAAiAEIAQoAtQEIAQoAqQDcyIGNgLEAiAEIAQoAtgEIAQoAqgDcyIHNgLIAiAEIAQoAtwEIAQoAqwDcyIINgLMAiAFQQh2IAVBEHZyIAVBGHZyIAZBCHZyIAZBEHZyIAZBGHZyIAdBCHZyIAdBEHZyIAdBGHZyIAhBCHZyIAhBEHZyIAhBGHZyIAVyIAZyIAdyIAhyQf8BcUUEQCAEIAMtAABB2gBzOgDAAiAEIAMtAAFB2gBzOgDBAiAEIAMtAAJB2gBzOgDCAiAEIAMtAANB2gBzOgDDAiAEIAMtAARB2gBzOgDEAiAEIAMtAAVB2gBzOgDFAiAEIAMtAAZB2gBzOgDGAiAEIAMtAAdB2gBzOgDHAiAEIAMtAAhB2gBzOgDIAiAEIAMtAAlB2gBzOgDJAiAEIAMtAApB2gBzOgDKAiAEIAMtAAtB2gBzOgDLAiAEIAMtAAxB2gBzOgDMAiAEIAMtAA1B2gBzOgDNAiAEIAMtAA5B2gBzOgDOAiAEIAMtAA9B2gBzOgDPAiAJIARBwAJqEB0LIAAgAikACDcACCAAIAIpAAA3AAAgBEHgBWogAiAEQYAEahDSASABKAAIIQIgASgADCEDIAEoAAAhBSAEIAQoAuQFIgYgASgABCAEKALUAnNzNgLUBSAEIAQoAuAFIgEgBSAEKALQAnNzNgLQBSAEIAQoAuwFIgUgAyAEKALcAnNzNgLcBSAEIAQoAugFIgMgAiAEKALYAnNzNgLYBSAEIAQpA9AFNwOwAiAEIAQpA9gFNwO4AiAEIAQpA+gCNwOoAiAEIAQpA+ACNwOgAiAEQcAFaiICIARBsAJqIARBoAJqEAYgBCAEKQLIBSIKNwPYBSAEIAQpAsAFIgs3A9AFIAQgCzcDkAIgBCAKNwOYAiAEIAQpA/ACNwOAAiAEIAQpA/gCNwOIAiACIARBkAJqIARBgAJqEAYgBCAEKQLIBSIKNwPYBSAEIAQpAsAFIgs3A9AFIAQgCzcD8AEgBCAKNwP4ASAEIAQpA4ADNwPgASAEIAQpA4gDNwPoASACIARB8AFqIARB4AFqEAYgBCAEKQLIBSIKNwPYBSAEIAQpAsAFIgs3A9AFIAQgCzcD0AEgBCAKNwPYASAEIAQpA5ADNwPAASAEIAQpA5gDNwPIASACIARB0AFqIARBwAFqEAYgBCAEKQLIBSIKNwPYBSAEIAQpAsAFIgs3A9AFIAQgCzcDsAEgBCAKNwO4ASAEIAQpAqADNwOgASAEIAQpAqgDNwOoASACIARBsAFqIARBoAFqEAYgBCAEKQLIBSIKNwPYBSAEIAQpAsAFIgs3A9AFIAQgCzcDkAEgBCAKNwOYASAEIAQpA7ADNwOAASAEIAQpA7gDNwOIASACIARBkAFqIARBgAFqEAYgBCAEKQLIBSIKNwPYBSAEIAQpAsAFIgs3A9AFIAQgCzcDcCAEIAo3A3ggBCAEKQPAAzcDYCAEIAQpA8gDNwNoIAIgBEHwAGogBEHgAGoQBiAEIAQpAsgFIgo3A9gFIAQgBCkCwAUiCzcD0AUgBCALNwNQIAQgCjcDWCAEIAQpA9ADNwNAIAQgBCkD2AM3A0ggAiAEQdAAaiAEQUBrEAYgBCAEKQLIBSIKNwPYBSAEIAQpAsAFIgs3A9AFIAQgCzcDMCAEIAo3AzggBCAEKQPgAzcDICAEIAQpA+gDNwMoIAIgBEEwaiAEQSBqEAYgBCAFIAQoAvwDczYCvAUgBCADIAQoAvgDczYCuAUgBCAGIAQoAvQDczYCtAUgBCABIAQoAvADczYCsAUgBCAEKQLIBSIKNwPYBSAEIAQpAsAFIgs3A9AFIAQgCzcDECAEIAo3AxggBCAEKQK4BTcDCCAEIAQpArAFNwMAIAIgBEEQaiAEEEIgBCAEKQLIBSIKNwPYBSAEIAQpAsAFIgs3A9AFIAAgCjcAGCAAIAs3ABAgBEHwBWokAAvbDgIHfwJ+IwBBkAZrIgMkACADQdACaiIEIAIQHSADIAEvAAAiAjYC0AQgAyABLwACIgY2AtQEIAMgAS8ABCIHNgLYBCADIAEvAAYiCDYC3AQgAyADKQLQBDcDwAIgAyADKQLYBDcDyAIgAyADKALAAhALNgLABCADIAMoAsQCEAs2AsQEIAMgAygCyAIQCzYCyAQgAyADKALMAhALNgLMBCADQeAEaiIFIARBsAH8CgAAIAUQgQEgASgAECEEIAEoABQhBSABKAAIIQkgAyAGIAEoAAwgAygChAZzczYCtAQgAyACIAkgAygCgAZzczYCsAQgAyAIIAUgAygCjAZzczYCvAQgAyAHIAQgAygCiAZzczYCuAQgAyADKALEBCADKAL0BXM2ApQEIAMgAygCwAQgAygC8AVzNgKQBCADKAL4BSEBIAMoAsgEIQQgAyADKALMBCADKAL8BXM2ApwEIAMgASAEczYCmAQgAyADKQO4BDcDuAIgAyADKQOwBDcDsAIgAyADKQKYBDcDqAIgAyADKQKQBDcDoAIgA0GgBGoiASADQbACaiADQaACahAQIAMgAykCqAQiCjcDuAQgAyADKQKgBCILNwOwBCADIAMoAsQEIAMoAuQFczYClAQgAyADKALABCADKALgBXM2ApAEIAMgAygCzAQgAygC7AVzNgKcBCADIAMoAsgEIAMoAugFczYCmAQgAyAKNwOYAiADIAs3A5ACIAMgAykCmAQ3A4gCIAMgAykCkAQ3A4ACIAEgA0GQAmogA0GAAmoQECADIAMpAqgEIgo3A7gEIAMgAykCoAQiCzcDsAQgAyADKALEBCADKALUBXM2ApQEIAMgAygCwAQgAygC0AVzNgKQBCADIAMoAswEIAMoAtwFczYCnAQgAyADKALIBCADKALYBXM2ApgEIAMgCjcD+AEgAyALNwPwASADIAMpApgENwPoASADIAMpApAENwPgASABIANB8AFqIANB4AFqEBAgAyADKQKoBCIKNwO4BCADIAMpAqAEIgs3A7AEIAMgAygCxAQgAygCxAVzNgKUBCADIAMoAsAEIAMoAsAFczYCkAQgAyADKALMBCADKALMBXM2ApwEIAMgAygCyAQgAygCyAVzNgKYBCADIAo3A9gBIAMgCzcD0AEgAyADKQKYBDcDyAEgAyADKQKQBDcDwAEgASADQdABaiADQcABahAQIAMgAykCqAQiCjcDuAQgAyADKQKgBCILNwOwBCADIAMoAsQEIAMoArQFczYClAQgAyADKALABCADKAKwBXM2ApAEIAMgAygCzAQgAygCvAVzNgKcBCADIAMoAsgEIAMoArgFczYCmAQgAyAKNwO4ASADIAs3A7ABIAMgAykCmAQ3A6gBIAMgAykCkAQ3A6ABIAEgA0GwAWogA0GgAWoQECADIAMpAqgEIgo3A7gEIAMgAykCoAQiCzcDsAQgAyADKALEBCADKAKkBXM2ApQEIAMgAygCwAQgAygCoAVzNgKQBCADIAMoAswEIAMoAqwFczYCnAQgAyADKALIBCADKAKoBXM2ApgEIAMgCjcDmAEgAyALNwOQASADIAMpApgENwOIASADIAMpApAENwOAASABIANBkAFqIANBgAFqEBAgAyADKQKoBCIKNwO4BCADIAMpAqAEIgs3A7AEIAMgAygCxAQgAygClAVzNgKUBCADIAMoAsAEIAMoApAFczYCkAQgAyADKALMBCADKAKcBXM2ApwEIAMgAygCyAQgAygCmAVzNgKYBCADIAo3A3ggAyALNwNwIAMgAykCmAQ3A2ggAyADKQKQBDcDYCABIANB8ABqIANB4ABqEBAgAyADKQKoBCIKNwO4BCADIAMpAqAEIgs3A7AEIAMgAygCxAQgAygChAVzNgKUBCADIAMoAsAEIAMoAoAFczYCkAQgAyADKALMBCADKAKMBXM2ApwEIAMgAygCyAQgAygCiAVzNgKYBCADIAo3A1ggAyALNwNQIAMgAykCmAQ3A0ggAyADKQKQBDcDQCABIANB0ABqIANBQGsQECADIAMpAqgEIgo3A7gEIAMgAykCoAQiCzcDsAQgAyADKALEBCADKAL0BHM2ApQEIAMgAygCwAQgAygC8ARzNgKQBCADIAMoAswEIAMoAvwEczYCnAQgAyADKALIBCADKAL4BHM2ApgEIAMgCjcDOCADIAs3AzAgAyADKQKYBDcDKCADIAMpApAENwMgIAEgA0EwaiADQSBqEBAgAyAIIAMoAuwEczYCjAQgAyAHIAMoAugEczYCiAQgAyAGIAMoAuQEczYChAQgAyACIAMoAuAEczYCgAQgAyADKQKoBCIKNwO4BCADIAMpAqAEIgs3A7AEIAMgCzcDECADIAo3AxggAyADKQKIBDcDCCADIAMpAoAENwMAIAEgA0EQaiADEKIBIAMgAykCqAQiCjcDuAQgAyADKQKgBCILNwOwBCAAIAo3AAggACALNwAAIANBkAZqJAALygwCBn8CfiMAQbAEayIEJAAgBEHAAmogAxAdIAAgAikAADcAACACLwAEIQMgAi8ABiEFIAIvAAAhBiABKAAIIQcgASgADCEIIAEoAAAhCSAEIAIvAAIiAiABKAAEIAQoAsQCc3M2AqQEIAQgBiAJIAQoAsACc3M2AqAEIAQgBSAIIAQoAswCc3M2AqwEIAQgAyAHIAQoAsgCc3M2AqgEIAQgAiAEKALUAnM2AoQEIAQgBiAEKALQAnM2AoAEIAQgBSAEKALcAnM2AowEIAQgAyAEKALYAnM2AogEIAQgBCkDqAQ3A7gCIAQgBCkDoAQ3A7ACIAQgBCkCiAQ3A6gCIAQgBCkCgAQ3A6ACIARBkARqIgEgBEGwAmogBEGgAmoQBiAEIAUgBCgC7AJzNgKMBCAEIAMgBCgC6AJzNgKIBCAEIAIgBCgC5AJzNgKEBCAEIAYgBCgC4AJzNgKABCAEIAQpApgEIgo3A6gEIAQgBCkCkAQiCzcDoAQgBCALNwOQAiAEIAo3A5gCIAQgBCkCiAQ3A4gCIAQgBCkCgAQ3A4ACIAEgBEGQAmogBEGAAmoQBiAEIAUgBCgC/AJzNgKMBCAEIAMgBCgC+AJzNgKIBCAEIAIgBCgC9AJzNgKEBCAEIAYgBCgC8AJzNgKABCAEIAQpApgEIgo3A6gEIAQgBCkCkAQiCzcDoAQgBCALNwPwASAEIAo3A/gBIAQgBCkCiAQ3A+gBIAQgBCkCgAQ3A+ABIAEgBEHwAWogBEHgAWoQBiAEIAUgBCgCjANzNgKMBCAEIAMgBCgCiANzNgKIBCAEIAIgBCgChANzNgKEBCAEIAYgBCgCgANzNgKABCAEIAQpApgEIgo3A6gEIAQgBCkCkAQiCzcDoAQgBCALNwPQASAEIAo3A9gBIAQgBCkCiAQ3A8gBIAQgBCkCgAQ3A8ABIAEgBEHQAWogBEHAAWoQBiAEIAUgBCgCnANzNgKMBCAEIAMgBCgCmANzNgKIBCAEIAIgBCgClANzNgKEBCAEIAYgBCgCkANzNgKABCAEIAQpApgEIgo3A6gEIAQgBCkCkAQiCzcDoAQgBCALNwOwASAEIAo3A7gBIAQgBCkCiAQ3A6gBIAQgBCkCgAQ3A6ABIAEgBEGwAWogBEGgAWoQBiAEIAUgBCgCrANzNgKMBCAEIAMgBCgCqANzNgKIBCAEIAIgBCgCpANzNgKEBCAEIAYgBCgCoANzNgKABCAEIAQpApgEIgo3A6gEIAQgBCkCkAQiCzcDoAQgBCALNwOQASAEIAo3A5gBIAQgBCkCiAQ3A4gBIAQgBCkCgAQ3A4ABIAEgBEGQAWogBEGAAWoQBiAEIAUgBCgCvANzNgKMBCAEIAMgBCgCuANzNgKIBCAEIAIgBCgCtANzNgKEBCAEIAYgBCgCsANzNgKABCAEIAQpApgEIgo3A6gEIAQgBCkCkAQiCzcDoAQgBCALNwNwIAQgCjcDeCAEIAQpAogENwNoIAQgBCkCgAQ3A2AgASAEQfAAaiAEQeAAahAGIAQgBSAEKALMA3M2AowEIAQgAyAEKALIA3M2AogEIAQgAiAEKALEA3M2AoQEIAQgBiAEKALAA3M2AoAEIAQgBCkCmAQiCjcDqAQgBCAEKQKQBCILNwOgBCAEIAs3A1AgBCAKNwNYIAQgBCkCiAQ3A0ggBCAEKQKABDcDQCABIARB0ABqIARBQGsQBiAEIAUgBCgC3ANzNgKMBCAEIAMgBCgC2ANzNgKIBCAEIAIgBCgC1ANzNgKEBCAEIAYgBCgC0ANzNgKABCAEIAQpApgEIgo3A6gEIAQgBCkCkAQiCzcDoAQgBCALNwMwIAQgCjcDOCAEIAQpAogENwMoIAQgBCkCgAQ3AyAgASAEQTBqIARBIGoQBiAEIAUgBCgC7ANzNgL8AyAEIAMgBCgC6ANzNgL4AyAEIAIgBCgC5ANzNgL0AyAEIAYgBCgC4ANzNgLwAyAEIAQpApgEIgo3A6gEIAQgBCkCkAQiCzcDoAQgBCALNwMQIAQgCjcDGCAEIAQpAvgDNwMIIAQgBCkC8AM3AwAgASAEQRBqIAQQQiAEIAQpApgEIgo3A6gEIAQgBCkCkAQiCzcDoAQgACAKNwAQIAAgCzcACCAEQbAEaiQAC+YBAQN/IwAiBUHAAWtBQHEiBCQAIAQgAygAAEH///8fcTYCQCAEIAMoAANBAnZBg/7/H3E2AkQgBCADKAAGQQR2Qf+B/x9xNgJIIAQgAygACUEGdkH//8AfcTYCTCADKAAMIQYgBEIANwJUIARCADcCXCAEQQA2AmQgBCAGQQh2Qf//P3E2AlAgBCADKAAQNgJoIAQgAygAFDYCbCAEIAMoABg2AnAgAygAHCEDIARBADoAkAEgBEIANwN4IAQgAzYCdCAEQUBrIgMgASACEI0BIAMgBEEwaiIBEIwBIAAgARBHIAUkAAvbBwIDfwJ+IwBBwAVrIgMkACADQcACaiIEIAIQHSADQZAEaiICIARBsAH8CgAAIAIQgQEgASgACCECIAEoAAwhBCABKAAAIQUgAyADKAK0BSABKAAEczYChAQgAyAFIAMoArAFczYCgAQgAyAEIAMoArwFczYCjAQgAyACIAMoArgFczYCiAQgAyADKQOgBTcDoAIgAyADKQOoBTcDqAIgAyADKQOABDcDsAIgAyADKQOIBDcDuAIgA0HwA2oiASADQbACaiADQaACahAQIAMgAykC+AMiBjcDiAQgAyADKQLwAyIHNwOABCADIAc3A5ACIAMgBjcDmAIgAyADKQOQBTcDgAIgAyADKQOYBTcDiAIgASADQZACaiADQYACahAQIAMgAykC+AMiBjcDiAQgAyADKQLwAyIHNwOABCADIAc3A/ABIAMgBjcD+AEgAyADKQOABTcD4AEgAyADKQOIBTcD6AEgASADQfABaiADQeABahAQIAMgAykC+AMiBjcDiAQgAyADKQLwAyIHNwOABCADIAc3A9ABIAMgBjcD2AEgAyADKQPwBDcDwAEgAyADKQP4BDcDyAEgASADQdABaiADQcABahAQIAMgAykC+AMiBjcDiAQgAyADKQLwAyIHNwOABCADIAc3A7ABIAMgBjcDuAEgAyADKQPgBDcDoAEgAyADKQPoBDcDqAEgASADQbABaiADQaABahAQIAMgAykC+AMiBjcDiAQgAyADKQLwAyIHNwOABCADIAc3A5ABIAMgBjcDmAEgAyADKQPQBDcDgAEgAyADKQPYBDcDiAEgASADQZABaiADQYABahAQIAMgAykC+AMiBjcDiAQgAyADKQLwAyIHNwOABCADIAc3A3AgAyAGNwN4IAMgAykDwAQ3A2AgAyADKQPIBDcDaCABIANB8ABqIANB4ABqEBAgAyADKQL4AyIGNwOIBCADIAMpAvADIgc3A4AEIAMgBzcDUCADIAY3A1ggAyADKQOwBDcDQCADIAMpA7gENwNIIAEgA0HQAGogA0FAaxAQIAMgAykC+AMiBjcDiAQgAyADKQLwAyIHNwOABCADIAc3AzAgAyAGNwM4IAMgAykDoAQ3AyAgAyADKQOoBDcDKCABIANBMGogA0EgahAQIAMgAykC+AMiBjcDiAQgAyADKQLwAyIHNwOABCADIAc3AxAgAyAGNwMYIAMgAykDkAQ3AwAgAyADKQOYBDcDCCABIANBEGogAxCiASADIAMpAvgDIgY3A4gEIAMgAykC8AMiBzcDgAQgACAGNwAIIAAgBzcAACADQcAFaiQAC8IHAgN/An4jAEGQBGsiAyQAIANBwAJqIAIQHSABKAAIIQIgASgADCEEIAEoAAAhBSADIAMoAsQCIAEoAARzNgKEBCADIAUgAygCwAJzNgKABCADIAQgAygCzAJzNgKMBCADIAIgAygCyAJzNgKIBCADIAMpA4AENwOwAiADIAMpA4gENwO4AiADIAMpA9ACNwOgAiADIAMpA9gCNwOoAiADQfADaiIBIANBsAJqIANBoAJqEAYgAyADKQL4AyIGNwOIBCADIAMpAvADIgc3A4AEIAMgBzcDkAIgAyAGNwOYAiADIAMpA+ACNwOAAiADIAMpA+gCNwOIAiABIANBkAJqIANBgAJqEAYgAyADKQL4AyIGNwOIBCADIAMpAvADIgc3A4AEIAMgBzcD8AEgAyAGNwP4ASADIAMpA/ACNwPgASADIAMpA/gCNwPoASABIANB8AFqIANB4AFqEAYgAyADKQL4AyIGNwOIBCADIAMpAvADIgc3A4AEIAMgBzcD0AEgAyAGNwPYASADIAMpA4ADNwPAASADIAMpA4gDNwPIASABIANB0AFqIANBwAFqEAYgAyADKQL4AyIGNwOIBCADIAMpAvADIgc3A4AEIAMgBzcDsAEgAyAGNwO4ASADIAMpA5ADNwOgASADIAMpA5gDNwOoASABIANBsAFqIANBoAFqEAYgAyADKQL4AyIGNwOIBCADIAMpAvADIgc3A4AEIAMgBzcDkAEgAyAGNwOYASADIAMpA6ADNwOAASADIAMpA6gDNwOIASABIANBkAFqIANBgAFqEAYgAyADKQL4AyIGNwOIBCADIAMpAvADIgc3A4AEIAMgBzcDcCADIAY3A3ggAyADKQOwAzcDYCADIAMpA7gDNwNoIAEgA0HwAGogA0HgAGoQBiADIAMpAvgDIgY3A4gEIAMgAykC8AMiBzcDgAQgAyAHNwNQIAMgBjcDWCADIAMpA8ADNwNAIAMgAykDyAM3A0ggASADQdAAaiADQUBrEAYgAyADKQL4AyIGNwOIBCADIAMpAvADIgc3A4AEIAMgBzcDMCADIAY3AzggAyADKQPQAzcDICADIAMpA9gDNwMoIAEgA0EwaiADQSBqEAYgAyADKQL4AyIGNwOIBCADIAMpAvADIgc3A4AEIAMgBzcDECADIAY3AxggAyADKQPgAzcDACADIAMpA+gDNwMIIAEgA0EQaiADEEIgAyADKQL4AyIGNwOIBCADIAMpAvADIgc3A4AEIAAgBjcACCAAIAc3AAAgA0GQBGokAAsLACAAIAFBABDTAQsLACAAIAFBARDTAQsNACAAIAEgAkEAENQBCw0AIAAgASACQQEQ1AELBgBBgIAgCwYAQYCAAgsFAEGtDAsFAEHmAAsKACAAIAEgAhBLCwgAIAAgARBMCwsAIAAgASACEI8BCwUAQcoLC1oBAX8jAEFAaiIGJAACQCAGQSBqIAUgBBAgBEBBfyEEDAELIAZBgL0CIAZBIGoiBEEAEDYaIARBIBAHIAAgASACIAMgBhDbASEEIAZBIBAHCyAGQUBrJAAgBAtaAQF/IwBBQGoiBiQAAkAgBkEgaiAFIAQQIARAQX8hBAwBCyAGQYC9AiAGQSBqIgRBABA2GiAEQSAQByAAIAEgAiADIAYQ3AEhBCAGQSAQBwsgBkFAayQAIAQL1wEBA38jACIFQYABa0FAcSIEJAAgBCADKAAAQf///x9xNgIAIAQgAygAA0ECdkGD/v8fcTYCBCAEIAMoAAZBBHZB/4H/H3E2AgggBCADKAAJQQZ2Qf//wB9xNgIMIAMoAAwhBiAEQgA3AhQgBEIANwIcIARBADYCJCAEIAZBCHZB//8/cTYCECAEIAMoABA2AiggBCADKAAUNgIsIAQgAygAGDYCMCADKAAcIQMgBEEAOgBQIARCADcDOCAEIAM2AjQgBCABIAIQjQEgBCAAEIwBIAUkAEEACwoAIAAgASACECsLDAAgACABIAIgAxAuCwsAIAAgASACEPgBCw0AIAAgASACIAMQ+QELBwAgABD6AQsJACAAIAEQ5AELCwAgACABIAIQ5QELBQBBtAsLbQEBfyMAQUBqIgIkACACIAFCIBBAGiACIAItAABB+AFxOgAAIAIgAi0AH0E/cUHAAHI6AB8gACACKQMQNwAQIAAgAikDCDcACCAAIAIpAwA3AAAgACACKQMYNwAYIAJBwAAQByACQUBrJABBAAvnCgIPfyd+IwBBgAJrIgIkAEF/IQgCQCABEEMNACACQeAAaiIDIAEQYg0AIAMQhQFFDQBBACEIIAJBACACKAKsASIBazYCJCACQQAgAigCqAEiA2s2AiAgAkEAIAIoAqQBIglrNgIcIAJBACACKAKgASIEazYCGCACQQAgAigCnAEiCms2AhQgAkEAIAIoApgBIgVrNgIQIAJBACACKAKUASILazYCDCACQQAgAigCkAEiBms2AgggAkEAIAIoAowBIgxrNgIEIAJBASACKAKIASIHazYCACACIAIQRSACIAIoAgQiDawiGSAKQQF0rCIifiACNAIAIhEgBKwiFH58IAIoAggiBKwiGyAFrCIVfnwgAigCDCIFrCIeIAtBAXSsIiN+fCACKAIQIg6sIh8gBqwiFn58IAIoAhQiBqwiJCAMQQF0rCIlfnwgAigCGCIPrCIuIAdBAWqsIhd+fCACKAIcIgdBE2ysIhogAUEBdKwiJn58IAIoAiAiEEETbKwiEiADrCIYfnwgAigCJCIDQRNsrCITIAlBAXSsIid+fCAVIBl+IBEgCqwiKH58IBsgC6wiKX58IBYgHn58IB8gDKwiKn58IBcgJH58IA9BE2ysIhwgAawiK358IBggGn58IBIgCawiLH58IBMgFH58IBkgI34gESAVfnwgFiAbfnwgHiAlfnwgFyAffnwgBkETbKwiLSAmfnwgGCAcfnwgGiAnfnwgEiAUfnwgEyAifnwiMEKAgIAQfCIxQhqHfCIyQoCAgAh8IjNCGYd8IiAgIEKAgIAQfCIhQoCAgOAPg30+AkggAiAZICV+IBEgFn58IBcgG358IAVBE2ysIh0gJn58IA5BE2ysIiAgGH58ICcgLX58IBQgHH58IBogIn58IBIgFX58IBMgI358IBcgGX4gESAqfnwgBEETbKwiLyArfnwgGCAdfnwgICAsfnwgFCAtfnwgHCAofnwgFSAafnwgEiApfnwgEyAWfnwgDUETbKwgJn4gESAXfnwgGCAvfnwgHSAnfnwgFCAgfnwgIiAtfnwgFSAcfnwgGiAjfnwgEiAWfnwgEyAlfnwiL0KAgIAQfCI0QhqHfCI1QoCAgAh8IjZCGYd8Ih0gHUKAgIAQfCI3QoCAgOAPg30+AjggAiAUIBl+IBEgLH58IBsgKH58IBUgHn58IB8gKX58IBYgJH58ICogLn58IAesIh0gF358IBIgK358IBMgGH58ICFCGod8IiEgIUKAgIAIfCIhQoCAgPAPg30+AkwgAiAWIBl+IBEgKX58IBsgKn58IBcgHn58ICAgK358IBggLX58IBwgLH58IBQgGn58IBIgKH58IBMgFX58IDdCGod8IhIgEkKAgIAIfCISQoCAgPAPg30+AjwgAiAZICd+IBEgGH58IBQgG358IB4gIn58IBUgH358ICMgJH58IBYgLn58IB0gJX58IBCsIhogF358IBMgJn58ICFCGYd8IhMgE0KAgIAQfCITQoCAgOAPg30+AlAgAiAyIDNCgICA8A+DfSAwIDFCgICAYIN9IBJCGYd8IhJCgICAEHwiHEIaiHw+AkQgAiASIBxCgICA4A+DfT4CQCACIBggGX4gESArfnwgGyAsfnwgFCAefnwgHyAofnwgFSAkfnwgKSAufnwgFiAdfnwgGiAqfnwgA6wgF358IBNCGod8IhEgEUKAgIAIfCIRQoCAgPAPg30+AlQgAiA1IDZCgICA8A+DfSAvIDRCgICAYIN9IBFCGYdCE358IhFCgICAEHwiFEIaiHw+AjQgAiARIBRCgICA4A+DfT4CMCAAIAJBMGoQDwsgAkGAAmokACAICwUAQY8MCwsAIAAgASACEOcBCz0BAn8jAEEgayIDJABBfyEEIAMgAiABECBFBEAgAEHgvAIgA0EAEB8aIANBIBAHQQAhBAsgA0EgaiQAIAQLUgEBfyMAQaABayICJAAgAUEgEBYgASABQiAQQBogASABLQAAQfgBcToAACABIAEtAB9BP3FBwAByOgAfIAIgARAwIAAgAhAiIAJBoAFqJABBAAsFAEGECQsIAEGAgICAAgsIAEGAgIDAAAsEAEEGCwUAQZgMC7MSAQx/IAFBA0kEQEEADwsjAEFAaiEJAkACQAJAAkACfwJAIAIpAAAgAjUACEKAgPz/D4WEQgBSBEAgAi0AASACLQAAciEEIAItAAMgAi0AAnJFDQFBfyEHQX9BACAEGyEFIARFDAILIAItAAwhAyAJIQQDQCAFIgcgCUE8amogAyADQQpuIgtBCmxrQTByOgAAIAQiCEEBaiEEIAVBAWohBSADQQlLIAshAw0ACyAJIQQCQCAHQf7///8HSw0AIAhBAWpBA3EiCwRAQQAhAwNAIAQgBUEBayIFIAlBPGpqLQAAOgAAIARBAWohBCADQQFqIgMgC0cNAAsLIAdBA0kNAANAIAQgCUE8aiIHIAVqIgNBAWstAAA6AAAgBCADQQJrLQAAOgABIAQgA0EDay0AADoAAiAEQQNqIgMgByAFQQRrIgVqLQAAOgAAIARBBGohBCADIAhHDQALCyAEQS46AAAgAi0ADSEDQQAhBSAEQQFqIgYhBwNAIAUiCCAJQTxqaiADIANBCm4iCkEKbGtBMHI6AAAgByILQQFqIQcgBUEBaiEFIANBCUsgCiEDDQALAkAgCEH+////B0sNACALIARrQQNxIgQEQEEAIQMDQCAGIAVBAWsiBSAJQTxqai0AADoAACAGQQFqIQYgA0EBaiIDIARHDQALCyAIQQNJDQADQCAGIAlBPGoiByAFaiIDQQFrLQAAOgAAIAYgA0ECay0AADoAASAGIANBA2stAAA6AAIgBkEDaiIDIAcgBUEEayIFai0AADoAACAGQQRqIQYgAyALRw0ACwsgBkEuOgAAIAItAA4hA0EAIQUgBkEBaiIEIQcDQCAFIgggCUE8amogAyADQQpuIgpBCmxrQTByOgAAIAciC0EBaiEHIAVBAWohBSADQQlLIAohAw0ACwJAIAhB/v///wdLDQAgCyAGa0EDcSIHBEBBACEDA0AgBCAFQQFrIgUgCUE8amotAAA6AAAgBEEBaiEEIANBAWoiAyAHRw0ACwsgCEEDSQ0AA0AgBCAJQTxqIgcgBWoiA0EBay0AADoAACAEIANBAmstAAA6AAEgBCADQQNrLQAAOgACIARBA2oiAyAHIAVBBGsiBWotAAA6AAAgBEEEaiEEIAMgC0cNAAsLIARBLjoAACACLQAPIQNBACEFIARBAWoiBiEHA0AgBSICIAlBPGpqIAMgA0EKbiILQQpsa0EwcjoAACAHIghBAWohByAFQQFqIQUgA0EJSyALIQMNAAsCQCACQf7///8HSw0AIAggBGtBA3EiBARAQQAhAwNAIAYgBUEBayIFIAlBPGpqLQAAOgAAIAZBAWohBiADQQFqIgMgBEcNAAsLIAJBA0kNAANAIAYgCUE8aiIDIAVqIgJBAWstAAA6AAAgBiACQQJrLQAAOgABIAYgAkEDay0AADoAAiAGQQNqIgIgAyAFQQRrIgVqLQAAOgAAIAZBBGohBiACIAhHDQALCyAGIAlrIgUgAUkNAkEADwtBAUECIAQbIQYgBEEARyEHQX8hBUEACyEDAn8gAi0ABSACLQAEcgRAIAYgAyADIAZJIgQbIQMgByAFIAQbIQVBfyEHQQAMAQtBAiAHIAdBAEgbIQcgBkEBagshBAJ/IAItAAcgAi0ABnIEQCAEIAMgAyAESSIEGyEDIAcgBSAEGyEFQX8hBkEADAELQQMgByAHQQBIGyEGIARBAWoLIQQCfyACLQAJIAItAAhyBEAgBCADIAMgBEkiBBshAyAGIAUgBBshBUF/IQZBAAwBC0EEIAYgBkEASBshBiAEQQFqCyEEAn8gAi0ACyACLQAKcgRAIAQgAyADIARJIgQbIQMgBiAFIAQbIQVBfyEGQQAMAQtBBSAGIAZBAEgbIQYgBEEBagshBAJ/IAItAA0gAi0ADHIEQCAEIAMgAyAESSIEGyEDIAYgBSAEGyEFQX8hBkEADAELQQYgBiAGQQBIGyEGIARBAWoLIQQCfyACLQAPIAItAA5yBEAgBCADIAMgBEkiBBshAyAGIAUgBBshBUF/IQZBAAwBC0EHIAYgBkEASBshBiAEQQFqCyEEQX8gBiAFIAMgBEkiBRsgBCADIAUbIgNBAkkbIgwgA2oiDUEBayELIAkhAyAMQQBIDQEDQAJAIAggDEYEQCADQbr0ADsAACADQQJqIQMgCyEIDAELAkAgCEUNACAIIA1GDQAgA0E6OgAAIANBAWohAwsgAiAIQQF0aiIELQAAQQh0IAQtAAFyIQVBACEEIAMhBwNAIAQiCiAJQTxqaiAFQQ9xIgRBMHIgBEHXAGogBEEKSRs6AAAgByIGQQFqIQcgCkEBaiEEIAVBD0sgBUEEdiEFDQALIApB/////wdGDQBBACEFIAYgA2tBAWpBA3EiBwRAA0AgAyAEQQFrIgQgCUE8amotAAA6AAAgA0EBaiEDIAVBAWoiBSAHRw0ACwsgCkEDSQ0AA0AgAyAJQTxqIgcgBGoiBUEBay0AADoAACADIAVBAmstAAA6AAEgAyAFQQNrLQAAOgACIANBA2oiBSAHIARBBGsiBGotAAA6AAAgA0EEaiEDIAUgBkcNAAsLIAhBB0ggCEEBaiEIDQALDAILIAVBAWohAwwCCwNAAkAgCCAMRwRAIAgEQCADQTo6AAAgA0EBaiEDCyACIAhBAXRqIgQtAABBCHQgBC0AAXIhBUEAIQQgAyEHA0AgBCIKIAlBPGpqIAVBD3EiBEEwciAEQdcAaiAEQQpJGzoAACAHIgZBAWohByAKQQFqIQQgBUEPSyAFQQR2IQUNAAsgCkH/////B0YNAUEAIQUgBiADa0EBakEDcSIHBEADQCADIARBAWsiBCAJQTxqai0AADoAACADQQFqIQMgBUEBaiIFIAdHDQALCyAKQQNJDQEDQCADIAlBPGoiByAEaiIFQQFrLQAAOgAAIAMgBUECay0AADoAASADIAVBA2stAAA6AAIgA0EDaiIFIAcgBEEEayIEai0AADoAACADQQRqIQMgBSAGRw0ACwwBCyADQbr0ADsAACADQQJqIQMgCyEICyAIQQFqIghBCEgNAAsLIAMgCWsiAyEFIAEgA0sNAEEADwsgAwRAIAAgCSAD/AoAAAsgACAFakEAOgAAIAALlQgBCn8jAEEQayIGJAAgASEEAkAgASABIAJqIgJPDQADQCAELQAARQ0BIARBAWoiBCACRw0ACyACIQQLAkACQAJAAkAgAUElIAQgAWsiAhAxIgdFBEAgAUE6IAIQMUUNAiAEIQcMAQtBfyEFIAdBAWoiAiAETw0DA0ACQCACLQAAIgNBMGtB/wFxQQpJDQAgA0HfAXFBwQBrQf8BcUEaSQ0AIANBLWtBAkkNACADQd8ARw0FCyACQQFqIgIgBEcNAAsgAUE6IAcgAWsQMUUNAwsgBkIANwMIIAZCADcDAEF/IQUgASAHTw0CIAEtAABBOkcEf0EABSABQQFqIAdPDQMgAS0AAUE6Rw0DIAFBAmohASAGCyEEIAZBEGohCCAGIQIDQCAEIQsDQAJAAkAgASAHTwRAIAIhAwwBCwJAAkACQAJAAkACQCABLQAAIgRBLmsODQUAAAAAAAAAAAAAAAEACyAEwCIDQTBrIgRBCk8EQCADQSByIgRB5wBrQXpJDQQgBEHXAGshBAsgByABayIMQQFGDQIgASEDIAFBAWoiCS0AACIFQS5rDg0EAQEBAQEBAQEBAQEGAQsgAUEBaiEBIAIhBCALRQ0HDAoLIAXAIgVBMGsiA0EKTwRAQX8gBUEgciIDQdcAayADQeEAa0EGTxshAwtBfyEFIANBAEgNCSADIARBBHRyIQQgDEECRg0AIAkhAwJAIAFBAmoiCS0AACIKQS5rDg0DAAAAAAAAAAAAAAAFAAsgCsAiCkEwayIDQQpPBEBBfyAKQSByIgNB1wBrIANB4QBrQQZPGyEDCyADQQBIDQkgAyAEQQR0ciEEIAxBA0YNACAJIQMCQCABQQNqIgktAAAiCkEuaw4NAwAAAAAAAAAAAAAABQALIArAIgpBMGsiA0EKTwRAQX8gCkEgciIDQdcAayADQeEAa0EGTxshAwsgA0EASA0JIAMgBEEEdHIhBCAMQQRGDQAgCSEDIAEtAAQiCUE6Rg0EIAlBLkYNAgwJCyAIIAJBAmoiA0kEQAwJCyACIARBCHQgBEGA/gNxQQh2cjsAAAwCCwwHC0F/IQUgAkEEaiIDIAhLDQYgASAHIAIQ9wFFDQYLAkAgCwRAIAMgCEYEQAwICyADIAtrIgEEQCAIIAFrIAsgAfwKAAALIAggA2siAUUNASALQQAgAfwLAAwBCyADIAhGDQAMBgsgACAGKQMINwAIIAAgBikDADcAAAwEC0F/IQUgAkECaiIBIAhLDQQgAiAEQQh0IARBgP4DcUEIdnI7AAAgASECIANBAmoiASAHSQ0ACwsMAgsgASAEIAYQ9wFFBEBBfyEFDAILIABCADcAACAAQYCAfDYACCAAIAYoAgA2AAwLQQAhBQsgBkEQaiQAIAULSwEBfwJAIAFBeXFBAUcNACAAQf3///97Tw0AIAAgAEEDbiIAQX1saiICQQFqQQQgAUECcRtBACACQQNxGyAAQQJ0akEBag8LEAwAC6MFAQl/An8CQAJAAkACQAJAAkACQAJAIAMEQCAEDQFBASEIQQAhBANAIAIgB2otAAAiDEHfAXFBN2tB/wFxIgtB9v8DaiALQfD/A2pzQQh2Ig0gDEEwcyIMQfb/A2pBCHYiDnJB/wFxRQ0EIAEgCk0NAyALIA1xIAwgDnFyIQsCQCAJQf8BcUUEQCALQQR0IQQMAQsgACAKaiAEIAtyOgAAIApBAWohCgsgCUF/cyEJIAdBAWoiByADRw0ACyADIQcMAwtBACAGRQ0IGgwGCwNAAkACQAJAAn8CQCACIAdqLQAAIgtB3wFxQTdrQf8BcSIIQfb/A2ogCEHw/wNqc0EIdiIMIAtBMHMiDUH2/wNqQQh2Ig5yQf8BcUUEQCAJQf8BcQ0JQQAhCCAEIAsQTUUNCyAHQQFqIgkhByADIAlLDQEMCwsgASAKTQ0GIAggDHEgDSAOcXIiCCAJQf8BcUUNARogACAKaiAIIA9yOgAAIAlBf3MhCSAKQQFqIQoMBAsDQCACIAdqLQAAIgtB3wFxQTdrQf8BcSIMQfb/A2ogDEHw/wNqc0EIdiINIAtBMHMiDkH2/wNqQQh2Ig9yQf8BcUUEQCAEIAsQTUUNCyADIAdBAWoiB0sNAQwDCwsgASAKTQ0CIAwgDXEgDiAPcXILQQR0IQ9B/wEhCQwCCyADIAkgAyAJSxshBwwHC0EAIQkMAgtBASEIIAdBAWoiByADSQ0ACwwBC0HAxAJBxAA2AgBBACEICyAJQf8BcUUNAQtBwMQCQRw2AgBBfyEIIAdBAWshB0EAIQoMAQsgCkEAIAgbIQogCEEBayEICyAGDQAgAyAHRw0BIAgMAgsgBiACIAdqNgIAIAgMAQtBwMQCQRw2AgBBfwsgBQRAIAUgCjYCAAsLnQEBA38CQCADQf7///8HSw0AIAEgA0EBdE0NAEEAIQEgAwR/A0AgACABQQF0aiIEIAEgAmotAAAiBUEPcSIGQQh0IAZB9v8DakGAsgNxakGArgFqQQh2OgABIAQgBUEEdiIEIARB9v8DakEIdkHZAXFqQdcAajoAACABQQFqIgEgA0cNAAsgA0EBdAVBAAsgAGpBADoAACAADwsQDAALOgEDfiABKQAgIQIgASkAKCEDIAEpADAhBCAAIAEpADg3ABggACAENwAQIAAgAzcACCAAIAI3AABBAAs6AQN+IAEpAAAhAiABKQAIIQMgASkAECEEIAAgASkAGDcAGCAAIAQ3ABAgACADNwAIIAAgAjcAAEEAC4wBAQF/AkACQAJAIANCwABUDQAgA0JAfCIDQr////8PVg0AIAIgAkFAayIFIAMgBEEAEJgBRQ0BIABFDQAgA6ciAkUNACAAQQAgAvwLAAtBfyECIAFFDQEgAUIANwMAQX8PCyABBEAgASADNwMAC0EAIQIgAEUNACADpyIBRQ0AIAAgBSAB/AoAAAsgAguJAQEDfyMAQRBrIgUkACAAQUBrIQYgA6ciBwRAIAYgAiAH/AoAAAtBACECIAAgBUEIaiAGIAMgBEEAEJkBGgJAIAUpAwhCwABSBEAgAQRAIAFCADcDAAsgB0FAayIBBEAgAEEAIAH8CwALQX8hAgwBCyABRQ0AIAEgA0JAfTcDAAsgBUEQaiQAIAILFAAgACABIAIgAyAEQQAQmQEaQQALCwAgACABIAIQhAILDQAgACABIAIgAxCcAQsrAQF/IwBBIGsiAyQAIANBIBAWIAAgASACIAMQnAEgA0EgEAcgA0EgaiQACy0BAX8jAEFAaiICJAAgAkHAABAWIAAgASACEFoaIAJBwAAQByACQUBrJABBAAsKACAAIAEgAhBaCwUAQcAICwUAQeASCwUAQaAJCwoAIAAgASACED0LLAAgAEEAQcgB/AsAIABBADoA7AEgAEHAADYC6AEgAEKAgICAgAk3A+ABQQALKwAgAEEAQcgB/AsAIABBADoA7AEgAEEgNgLoASAAQoCAgICAETcD4AFBAAsKACAAIAEgAhB2CwYAIAAQGgsUACADBEAgASAAIAJqIAP8CgAACwsMACAAQQBByAH8CwALBQBB4AELBQBB4D8LrQICBH8BfiMAQYACayIFJAAgBUEBOgAPAn8gAUHgP00EQCABQSBPBEAgA60hCUEgIQYDQCAGIQcgBUEwaiIGIARBIBA+GiAIBEAgBiAAIAhqQSBrQiAQLBoLIAVBMGoiBiACIAkQLBogBiAFQQ9qQgEQLBogBiAAIAhqEE8aIAUgBS0AD0EBajoADyAHIQggB0EgaiIGIAFNDQALCyABQR9xIgEEQCAFQTBqIgggBEEgED4aIAcEQCAIIAAgB2pBIGtCIBAsGgsgBUEwaiIEIAIgA60QLBogBCAFQQ9qQgEQLBogBCAFQRBqIgIQTxogAQRAIAAgB2ogAiAB/AoAAAsgBUEQakEgEAcLIAVBMGpB0AEQB0EADAELQcDEAkEcNgIAQX8LIAVBgAJqJAALOQEBfyMAQdABayIFJAAgBSABIAIQPhogBSADIAStECwaIAUgABBPGiAFQdABEAcgBUHQAWokAEEAC88FAgJ/BH5BfyEHAkAgAkHAAEsNACADQcEAayIGQUBJDQACQCABQQAgAhtFBEACfyAGQf8BcUG/AUsEQAJ+IARFBEBCn9j52cKR2oKbfyEIQtGFmu/6z5SH0QAMAQsgBCkACEKf2PnZwpHagpt/hSEIIAQpAABC0YWa7/rPlIfRAIULIQoCfiAFRQRAQvnC+JuRo7Pw2wAhCULr+obav7X2wR8MAQsgBSkACEL5wvibkaOz8NsAhSEJIAUpAABC6/qG2r+19sEfhQshCyAAQUBrQQBBpQL8CwAgACAJNwA4IAAgCzcAMCAAIAg3ACggACAKNwAgIABC8e30+KWn/aelfzcAGCAAQqvw0/Sv7ry3PDcAECAAQrvOqqbY0Ouzu383AAggACADrUKIkveV/8z5hOoAhTcAAEEADAELEAwAC0UNAQwCCwJ/IwBBgAFrIgYkAAJAIANBwQBrQf8BcUG/AU0NACABRQ0AIAJBwQBrQf8BcUG/AU0NAAJ+IARFBEBCn9j52cKR2oKbfyEIQtGFmu/6z5SH0QAMAQsgBCkACEKf2PnZwpHagpt/hSEIIAQpAABC0YWa7/rPlIfRAIULIQoCfiAFRQRAQvnC+JuRo7Pw2wAhCULr+obav7X2wR8MAQsgBSkACEL5wvibkaOz8NsAhSEJIAUpAABC6/qG2r+19sEfhQshCyAAQUBrQQBBpQL8CwAgACAJNwA4IAAgCzcAMCAAIAg3ACggACAKNwAgIABC8e30+KWn/aelfzcAGCAAQqvw0/Sv7ry3PDcAECAAQrvOqqbY0Ouzu383AAggACADrSACrUIIhoRCiJL3lf/M+YTqAIU3AAAgBkEAQYAB/AsAIAIEQCAGIAEgAvwKAAALIABB4ABqIAZBgAH8CgAAIABBgAE2AOACIAZBgAEQByAGQYABaiQAQQAMAQsQDAALDQELQQAhBwsgBwsSACAAIAEQTxogAEHQARAHQQALCwAgACABIAKtECwLCgAgACABIAIQPgsEAEFuCwQAQRELBABBNAuVAQIBfwF+IwBBMGsiASQAIAEgACkAGDcDGCABIAApABA3AxAgASAAKQAINwMIIAEgACkAADcDACABIAApACQ3AyAgASABQiggAEEgaiAAEHwaIAAgASkDGDcAGCAAIAEpAxA3ABAgACABKQMINwAIIAAgASkDADcAACABKQMgIQIgAEEBNgAgIAAgAjcAJCABQTBqJAALLQEBfiAAIAEgAkEAEB8aIABBATYAICABKQAQIQMgAEIANwAsIAAgAzcAJEEACzMBAX4gAUEYEBYgACABIAJBABAfGiAAQQE2ACAgASkAECEDIABCADcALCAAIAM3ACRBAAsJACAAIAEQjgILCwAgACABIAIQjQILCwAgACABIAIQjwILCQAgACABEJACCwkAIAAgARCRAgsJACAAIAEQkgILBwAgABCTAgsiAQF/IwBBQGoiASQAIAFBwAAQFiAAIAEQpQEgAUFAayQACwsAIAAgARClAUEAC2UBA38jAEGgBmsiAyQAQX8hBAJAIANBgAVqIgUgARBKDQAgA0HgA2oiASACEEoNACADIAEQDiADQaABaiIBIAUgAxBgIANBwAJqIgIgARBhIAAgAhBVQQAhBAsgA0GgBmokACAEC2UBA38jAEGgBmsiAyQAQX8hBAJAIANBgAVqIgUgARBKDQAgA0HgA2oiASACEEoNACADIAEQDiADQaABaiIBIAUgAxASIANBwAJqIgIgARBhIAAgAhBVQQAhBAsgA0GgBmokACAECx0BAX8jAEGgAWsiASQAIAEgABBKIAFBoAFqJABFCyEBAX8jAEEgayIBJAAgAUEgEBYgACABEKcBIAFBIGokAAvvBAEMfyMAQaABayICJAAgAS0AACENA0AgAkGAAWoiBSADaiABIANrIgQtAD86AAAgAkHgAGoiBiADaiAELQAfOgAAIAUgA0EBciIHaiAELQA+OgAAIAYgB2ogBC0AHjoAACADQQJqIgNBIEcNAAsgAiACLQCfAUH/AHE6AJ8BIAIgAi0Af0H/AHE6AH8gAkEwaiIDIAUQNSACIAYQNSACIAIoAlAgAigCIEEmbGoiBCACKAJMIAIoAhxBJmxqIgUgAigCSCACKAIYQSZsaiIGIAIoAkQgAigCFEEmbGoiByACKAJAIAIoAhBBJmxqIgggAigCPCACKAIMQSZsaiIJIAIoAjggAigCCEEmbGoiCiACKAI0IAIoAgRBJmxqIgsgAigCMEHSyAItAABBAnYgAS0AIEEHdnNBE2xqIAIoAgBBJmxqIgwgAigCVCACKAIkQSZsaiIBQRNsQYCAgAhqQRl2akEadWpBGXVqQRp1akEZdWpBGnVqQRl1akEadWpBGXVqQRp1IAFqQRl1QRNsIAxqIgxB////H3E2AjAgAiAMQRp1IAtqIgtB////D3E2AjQgAiALQRl1IApqIgpB////H3E2AjggAiAKQRp1IAlqIglB////D3E2AjwgAiAJQRl1IAhqIghB////H3E2AkAgAiAIQRp1IAdqIgdB////D3E2AkQgAiAHQRl1IAZqIgZB////H3E2AkggAiAGQRp1IAVqIgVB////D3E2AkwgAiAFQRl1IARqIgRB////H3E2AlAgAiAEQRp1IAFqQf///w9xNgJUIAAgAyANQYABcRCmASACQaABaiQAQQALCwAgACABEKcBQQALcwEDfyMAQaAGayIDJABBfyEEAkAgA0GABWoiBSABEEQNACAFEFZFDQAgA0HgA2oiASACEEQNACABEFZFDQAgAyABEA4gA0GgAWoiASAFIAMQYCADQcACaiICIAEQYSAAIAIQIkEAIQQLIANBoAZqJAAgBAtzAQN/IwBBoAZrIgMkAEF/IQQCQCADQYAFaiIFIAEQRA0AIAUQVkUNACADQeADaiIBIAIQRA0AIAEQVkUNACADIAEQDiADQaABaiIBIAUgAxASIANBwAJqIgIgARBhIAAgAhAiQQAhBAsgA0GgBmokACAEC0IBAn8jAEGgAWsiASQAAkAgABCEAUUNACAAEEMNACABIAAQRA0AIAEQVkUNACABEIUBQQBHIQILIAFBoAFqJAAgAgsGAEHA/wALugICBH8BfiMAQfADayIFJAAgBUEBOgAPAn8gAUHA/wBNBEAgAUHAAE8EQCADrSEJQcAAIQYDQCAGIQcgBUHQAGoiBiAEQcAAEDkaIAgEQCAGIAAgCGpBQGpCwAAQLxoLIAVB0ABqIgYgAiAJEC8aIAYgBUEPakIBEC8aIAYgACAIahA/GiAFIAUtAA9BAWo6AA8gByEIIAdBQGsiBiABTQ0ACwsgAUE/cSIBBEAgBUHQAGoiCCAEQcAAEDkaIAcEQCAIIAAgB2pBQGpCwAAQLxoLIAVB0ABqIgQgAiADrRAvGiAEIAVBD2pCARAvGiAEIAVBEGoiAhA/GiABBEAgACAHaiACIAH8CgAACyAFQRBqQcAAEAcLIAVB0ABqQaADEAdBAAwBC0HAxAJBHDYCAEF/CyAFQfADaiQACwkAIABBwAAQFgs5AQF/IwBBoANrIgUkACAFIAEgAhA5GiAFIAMgBK0QLxogBSAAED8aIAVBoAMQByAFQaADaiQAQQALEgAgACABED8aIABBoAMQB0EACwsAIAAgASACrRAvCyYBAn8CQEHcyAIoAgAiAEUNACAAKAIUIgBFDQAgABEBACEBCyABCxAAIAAgAa1BwLACIAIQQRoLVAECfxA6QdzIAigCACgCDCIBBEAgACABEQkADwtBACEBIABBAk8Ef0EAIABrIABwIQEDQBA6QdzIAigCACgCBBEBACICIAFJDQALIAIgAHAFQQALCxEAEDpB3MgCKAIAKAIEEQEAC6UBAQZ/IwBBEGsiBUEANgIMQX8hBCACIANBAWtLBH8gASACQQFrIgdqIQhBACECQQAhAUEAIQQDQCAFIAUoAgwiBkEAIAggAmstAAAiCUGAAXNBAWsgBkEBayAEQQFrcXFBCHZBAXEiBmsgAnFyNgIMIAEgBnIhASAEIAlyIQQgAkEBaiICIANHDQALIAAgByAFKAIMazYCACABQf8BcUEBawVBfwsLBQBBwQgLKAECfyMAQRBrIgAkACAAQQA6AA9BiL4CIABBD2pBABABIABBEGokAAspAQF/IwBBEGsiACQAIABBADoAD0GsvgIgAEEPakEAEAEaIABBEGokAAsvAQF/IAEEQANAEDogACACakHcyAIoAgAoAgQRAQA6AAAgAkEBaiICIAFHDQALCwsRABA6QdzIAigCACgCABEBAAvaAQEDfyMAQRBrIgUkAAJAAkAgA0UEQEF/IQEMAQsCfyADIANBAWsiBnFFBEAgBiACQX9zIgdxDAELIAJBf3MhByAGIAIgA3BrCyIGIAdPDQEgBCACIAZqIgJNBEBBfyEBDAELIAAEQCAAIAJBAWo2AgALIAEgAmohAEEAIQEgBUEAOgAPQQAhAgNAIAAgAmsiBCAELQAAIAUtAA9xIAIgBnNBAWtBGHYiBEGAAXFyOgAAIAUgBS0ADyAEcjoADyACQQFqIgIgA0cNAAsLIAVBEGokACABDwsQDAALxwEBAX8jAEFAaiIGJAAgAkIAUgRAIAZCstqIy8eumZDrADcCCCAGQuXwwYvmjZmQMzcCACAGIAUoAAA2AhAgBiAFKAAENgIUIAYgBSgACDYCGCAGIAUoAAw2AhwgBiAFKAAQNgIgIAYgBSgAFDYCJCAGIAUoABg2AiggBSgAHCEFIAYgBDYCMCAGIAU2AiwgBiADKAAANgI0IAYgAygABDYCOCAGIAMoAAg2AjwgBiABIAAgAhB+IAZBwAAQBwsgBkFAayQAQQALvQEBAX8jAEFAaiIGJAAgAkIAUgRAIAZCstqIy8eumZDrADcCCCAGQuXwwYvmjZmQMzcCACAGIAUoAAA2AhAgBiAFKAAENgIUIAYgBSgACDYCGCAGIAUoAAw2AhwgBiAFKAAQNgIgIAYgBSgAFDYCJCAGIAUoABg2AiggBSgAHCEFIAYgBDcCMCAGIAU2AiwgBiADKAAANgI4IAYgAygABDYCPCAGIAEgACACEH4gBkHAABAHCyAGQUBrJABBAAvYAQEBfyMAQUBqIgQkACABQgBSBEAgBEKy2ojLx66ZkOsANwIIIARC5fDBi+aNmZAzNwIAIAQgAygAADYCECAEIAMoAAQ2AhQgBCADKAAINgIYIAQgAygADDYCHCAEIAMoABA2AiAgBCADKAAUNgIkIAQgAygAGDYCKCADKAAcIQMgBEEANgIwIAQgAzYCLCAEIAIoAAA2AjQgBCACKAAENgI4IAQgAigACDYCPCABpyICBEAgAEEAIAL8CwALIAQgACAAIAEQfiAEQcAAEAcLIARBQGskAEEAC84BAQF/IwBBQGoiBCQAIAFCAFIEQCAEQrLaiMvHrpmQ6wA3AgggBELl8MGL5o2ZkDM3AgAgBCADKAAANgIQIAQgAygABDYCFCAEIAMoAAg2AhggBCADKAAMNgIcIAQgAygAEDYCICAEIAMoABQ2AiQgBCADKAAYNgIoIAMoABwhAyAEQgA3AjAgBCADNgIsIAQgAigAADYCOCAEIAIoAAQ2AjwgAaciAgRAIABBACAC/AsACyAEIAAgACABEH4gBEHAABAHCyAEQUBrJABBAAslAEHUyAIoAgAEf0EBBRCVAkHAyAJBEBAWQdTIAkEBNgIAQQALC64UAhh/An4jAEGgBGsiCSQAIAggByAJQbADahCcAkEAIQggBkEfSwRAQSAhBwNAIAUgCGogCUGwA2oQmwIgByIIQSBqIgcgBk0NAAsLIAYgCEEQciIHTwRAA0AgBSAIaiIIKAAAIQ8gCCgABCENIAgoAAghDCAIKAAMIQggCSAJKQKIBDcDiAMgCSAJKQKABDcDgAMgCSAJKQLwAzcD8AIgCSAJKQL4AzcD+AIgCSAJKQKABDcD4AIgCSAJKQKIBDcD6AIgCUGQBGoiDiAJQfACaiAJQeACahAGIAkgCSkCmAQ3AogEIAkgCSkCkAQ3AoAEIAkgCSkC4AM3A9ACIAkgCSkC6AM3A9gCIAkgCSkC8AM3A8ACIAkgCSkC+AM3A8gCIA4gCUHQAmogCUHAAmoQBiAJIAkpApgENwL4AyAJIAkpApAENwLwAyAJIAkpAtADNwOwAiAJIAkpAtgDNwO4AiAJIAkpAuADNwOgAiAJIAkpAugDNwOoAiAOIAlBsAJqIAlBoAJqEAYgCSAJKQKYBDcC6AMgCSAJKQKQBDcC4AMgCSAJKQLAAzcDkAIgCSAJKQLIAzcDmAIgCSAJKQLQAzcDgAIgCSAJKQLYAzcDiAIgDiAJQZACaiAJQYACahAGIAkgCSkCmAQ3AtgDIAkgCSkCkAQ3AtADIAkgCSkDsAM3A/ABIAkgCSkDuAM3A/gBIAkgCSkCwAM3A+ABIAkgCSkCyAM3A+gBIA4gCUHwAWogCUHgAWoQBiAJIAkpApgENwLIAyAJIAkpApAENwLAAyAJIAkpA4ADNwPQASAJIAkpA4gDNwPYASAJIAkpA7ADNwPAASAJIAkpA7gDNwPIASAOIAlB0AFqIAlBwAFqEAYgCSAIIAkoApwEczYCvAMgCSAMIAkoApgEczYCuAMgCSANIAkoApQEczYCtAMgCSAPIAkoApAEczYCsAMgByIIQRBqIgcgBk0NAAsLIAZBD3EiDARAQRAgDGsiBwRAIAlBoANqIAxyQQAgB/wLAAsgDARAIAlBoANqIAUgCGogDPwKAAALIAkoAqADIQwgCSgCpAMhCCAJKAKoAyEHIAkoAqwDIQUgCSAJKQOIBCIhNwOIAyAJIAkpA4AEIiI3A4ADIAkgCSkD8AM3A7ABIAkgCSkD+AM3A7gBIAkgIjcDoAEgCSAhNwOoASAJQZAEaiINIAlBsAFqIAlBoAFqEAYgCSAJKQKYBDcDiAQgCSAJKQKQBDcDgAQgCSAJKQPgAzcDkAEgCSAJKQPoAzcDmAEgCSAJKQPwAzcDgAEgCSAJKQP4AzcDiAEgDSAJQZABaiAJQYABahAGIAkgCSkCmAQ3A/gDIAkgCSkCkAQ3A/ADIAkgCSkD0AM3A3AgCSAJKQPYAzcDeCAJIAkpA+ADNwNgIAkgCSkD6AM3A2ggDSAJQfAAaiAJQeAAahAGIAkgCSkCmAQ3A+gDIAkgCSkCkAQ3A+ADIAkgCSkDwAM3A1AgCSAJKQPIAzcDWCAJIAkpA9ADNwNAIAkgCSkD2AM3A0ggDSAJQdAAaiAJQUBrEAYgCSAJKQKYBDcD2AMgCSAJKQKQBDcD0AMgCSAJKQOwAzcDMCAJIAkpA7gDNwM4IAkgCSkDwAM3AyAgCSAJKQPIAzcDKCANIAlBMGogCUEgahAGIAkgCSkCmAQ3A8gDIAkgCSkCkAQ3A8ADIAkgCSkDgAM3AxAgCSAJKQOIAzcDGCAJIAkpA7ADNwMAIAkgCSkDuAM3AwggDSAJQRBqIAkQBiAJIAUgCSgCnARzNgK8AyAJIAcgCSgCmARzNgK4AyAJIAggCSgClARzNgK0AyAJIAwgCSgCkARzNgKwAwsCQCAABEBBECEIQQAhByACQRBJDQEDQCAAIAdqIAEgB2ogCUGwA2oQmAIgCCIHQRBqIgggAk0NAAsMAQtBECEIQQAhByACQRBJDQADQCAJQZAEaiABIAdqIAlBsANqEJgCIAgiB0EQaiIIIAJNDQALCyACQQ9xIgUEQCAAIAdqIAlBkARqIAAbIRMgASAHaiEBIAlBsANqIQsjAEHwAWsiCiQAIApBwAFqIAVqIRFBECAFayISRSIURQRAIBFBACAS/AsACyAFRSIVRQRAIApBwAFqIAEgBfwKAAALIAsoAhAhFiALQUBrIhAoAgAhFyALKAJQIRggCygCICEZIAsoAjAhGiALKAIUIRsgCygCRCEcIAsoAlQhHSALKAIkIR4gCygCNCEfIAsoAhghICALKAJIIQ4gCygCWCEPIAsoAighDSALKAI4IQwgCigCwAEhCCAKKALEASEHIAooAsgBIQEgCiALKAIsIAsoAjxxIAsoAhwgCygCTCALKAJcIAooAswBc3NzczYCzAEgCiAMIA1xICAgDiABIA9zc3NzNgLIASAKIB4gH3EgGyAcIAcgHXNzc3M2AsQBIAogGSAacSAWIBcgCCAYc3NzczYCwAEgFEUEQCARQQAgEvwLAAsgFUUEQCATIApBwAFqIAX8CgAACyAKKALAASEPIAooAsQBIQ0gCigCyAEhDCAKKALMASEIIAogCykCWDcD6AEgCiALKQJQNwPgASAKIBApAgA3A7ABIAogCykCSDcDuAEgCiALKQJQNwOgASAKIAspAlg3A6gBIApB0AFqIgEgCkGwAWogCkGgAWoQBiALIAopAtgBNwJYIAsgCikC0AE3AlAgCiALKQIwNwOQASAKIAspAjg3A5gBIAogECkCADcDgAEgCiALKQJINwOIASABIApBkAFqIApBgAFqEAYgCyAKKQLYATcCSCAQIAopAtABNwIAIAogCykCIDcDcCAKIAspAig3A3ggCiALKQIwNwNgIAogCykCODcDaCABIApB8ABqIApB4ABqEAYgCyAKKQLYATcCOCALIAopAtABNwIwIAogCykCEDcDUCAKIAspAhg3A1ggCiALKQIgNwNAIAogCykCKDcDSCABIApB0ABqIApBQGsQBiALIAopAtgBNwIoIAsgCikC0AE3AiAgCiALKQIANwMwIAogCykCCDcDOCAKIAspAhA3AyAgCiALKQIYNwMoIAEgCkEwaiAKQSBqEAYgCyAKKQLYATcCGCALIAopAtABNwIQIAogCikD4AE3AxAgCiAKKQPoATcDGCAKIAspAgA3AwAgCiALKQIINwMIIAEgCkEQaiAKEAYgCigC0AEhByAKKALUASEFIAooAtgBIQEgCyAIIAooAtwBczYCDCALIAEgDHM2AgggCyAFIA1zNgIEIAsgByAPczYCACAKQfABaiQACyAJQYADaiAEIAatIAKtIAlBsANqEJkCQX8hBwJAAkACQAJ/AkACQCAEQRBrDhEAAwMDAwMDAwMDAwMDAwMDAQMLIAlBgANqIAMQRwwBCyAJQYADaiADEEYLIgdFDQELIABFDQEgAkUNASAAQQAgAvwLAAwBC0EAIQcLIAlBoARqJAAgBwunDAIFfwJ+IwBBkARrIgkkACAIIAcgCUGQA2oQnAJBACEIIAZBH0sEQEEgIQcDQCAFIAhqIAlBkANqEJsCIAciCEEgaiIHIAZNDQALCyAGIAhBEHIiB08EQANAIAUgCGoiCCgAACELIAgoAAQhDCAIKAAIIQ0gCCgADCEIIAkgCSkC6AM3A4gEIAkgCSkC4AM3A4AEIAkgCSkC0AM3A/ACIAkgCSkC2AM3A/gCIAkgCSkC4AM3A+ACIAkgCSkC6AM3A+gCIAlB8ANqIgogCUHwAmogCUHgAmoQBiAJIAkpAvgDNwLoAyAJIAkpAvADNwLgAyAJIAkpAsADNwPQAiAJIAkpAsgDNwPYAiAJIAkpAtADNwPAAiAJIAkpAtgDNwPIAiAKIAlB0AJqIAlBwAJqEAYgCSAJKQL4AzcC2AMgCSAJKQLwAzcC0AMgCSAJKQKwAzcDsAIgCSAJKQK4AzcDuAIgCSAJKQLAAzcDoAIgCSAJKQLIAzcDqAIgCiAJQbACaiAJQaACahAGIAkgCSkC+AM3AsgDIAkgCSkC8AM3AsADIAkgCSkCoAM3A5ACIAkgCSkCqAM3A5gCIAkgCSkCsAM3A4ACIAkgCSkCuAM3A4gCIAogCUGQAmogCUGAAmoQBiAJIAkpAvgDNwK4AyAJIAkpAvADNwKwAyAJIAkpA5ADNwPwASAJIAkpA5gDNwP4ASAJIAkpAqADNwPgASAJIAkpAqgDNwPoASAKIAlB8AFqIAlB4AFqEAYgCSAJKQL4AzcCqAMgCSAJKQLwAzcCoAMgCSAJKQOABDcD0AEgCSAJKQOIBDcD2AEgCSAJKQOQAzcDwAEgCSAJKQOYAzcDyAEgCiAJQdABaiAJQcABahAGIAkgCCAJKAL8A3M2ApwDIAkgDSAJKAL4A3M2ApgDIAkgDCAJKAL0A3M2ApQDIAkgCyAJKALwA3M2ApADIAciCEEQaiIHIAZNDQALCyAGQQ9xIgcEQEEQIAdrIgsEQCAJQYADaiAHckEAIAv8CwALIAcEQCAJQYADaiAFIAhqIAf8CgAACyAJKAKAAyEFIAkoAoQDIQcgCSgCiAMhCCAJKAKMAyELIAkgCSkD6AMiDjcDiAQgCSAJKQPgAyIPNwOABCAJIAkpA9ADNwOwASAJIAkpA9gDNwO4ASAJIA83A6ABIAkgDjcDqAEgCUHwA2oiCiAJQbABaiAJQaABahAGIAkgCSkC+AM3A+gDIAkgCSkC8AM3A+ADIAkgCSkDwAM3A5ABIAkgCSkDyAM3A5gBIAkgCSkD0AM3A4ABIAkgCSkD2AM3A4gBIAogCUGQAWogCUGAAWoQBiAJIAkpAvgDNwPYAyAJIAkpAvADNwPQAyAJIAkpA7ADNwNwIAkgCSkDuAM3A3ggCSAJKQPAAzcDYCAJIAkpA8gDNwNoIAogCUHwAGogCUHgAGoQBiAJIAkpAvgDNwPIAyAJIAkpAvADNwPAAyAJIAkpA6ADNwNQIAkgCSkDqAM3A1ggCSAJKQOwAzcDQCAJIAkpA7gDNwNIIAogCUHQAGogCUFAaxAGIAkgCSkC+AM3A7gDIAkgCSkC8AM3A7ADIAkgCSkDkAM3AzAgCSAJKQOYAzcDOCAJIAkpA6ADNwMgIAkgCSkDqAM3AyggCiAJQTBqIAlBIGoQBiAJIAkpAvgDNwOoAyAJIAkpAvADNwOgAyAJIAkpA4AENwMQIAkgCSkDiAQ3AxggCSAJKQOQAzcDACAJIAkpA5gDNwMIIAogCUEQaiAJEAYgCSALIAkoAvwDczYCnAMgCSAIIAkoAvgDczYCmAMgCSAHIAkoAvQDczYClAMgCSAFIAkoAvADczYCkAMLQRAhCEEAIQcgBEEQTwRAA0AgACAHaiADIAdqIAlBkANqEJoCIAgiB0EQaiIIIARNDQALCwJAIARBD3EiBUUNAEEQIAVrIggEQCAJQYADaiAFckEAIAj8CwALIAVFIghFBEAgCUGAA2ogAyAHaiAF/AoAAAsgCUGABGoiAyAJQYADaiAJQZADahCaAiAIDQAgACAHaiADIAX8CgAACyABIAIgBq0gBK0gCUGQA2oQmQIgCUGQBGokAEEAC4AOASN/IwAiDCESIAxB4AFrQWBxIgskACAIIAcgC0HgAGoQowJBACEHIAZBP0sEQEHAACEIA0AgBSAHaiALQeAAahCiAiAIIgdBQGsiCCAGTQ0ACwsgBiAHQSByIghPBEADQCAFIAdqIAtB4ABqEIABIAgiB0EgaiIIIAZNDQALCyAGQR9xIgwEQEEgIAxrIggEQCALQUBrIAxyQQAgCPwLAAsgDARAIAtBQGsgBSAHaiAM/AoAAAsgC0FAayALQeAAahCAAQsCQCAABEBBICEFQQAhByACQSBJDQEDQCAAIAdqIAEgB2ogC0HgAGoQnwIgBSIHQSBqIgUgAk0NAAsMAQtBICEFQQAhByACQSBJDQADQCALQSBqIAEgB2ogC0HgAGoQnwIgBSIHQSBqIgUgAk0NAAsLIAJBH3EiBQRAIAAgB2ogC0EgaiAAGyEbIAEgB2ohASALQeAAaiEKIwBBwAJrIgkkACAJQYACaiAFaiETQSAgBWsiFEUiHEUEQCATQQAgFPwLAAsgBUUiHUUEQCAJQYACaiABIAX8CgAACyAKKAIQIR4gCigCMCEfIAooAhQhICAKKAI0ISEgCigCGCEiIAooAjghIyAKKAIcISQgCigCPCElIAooAiAhFSAKKAJQISYgCigCcCEnIAooAmAhFiAKKAIkIRcgCigCVCEoIAooAnQhKSAKKAJkIRggCigCKCEZIAooAlghKiAKKAJ4ISsgCigCaCEaIAkoAoACIQ0gCSgChAIhDiAJKAKIAiEPIAkoAowCIRAgCSgCkAIhESAJKAKUAiEMIAkoApgCIQggCSAKKAIsIgcgCigCbCIBIAooAnxxIAooAlwgCSgCnAJzc3M2ApwCIAkgGSAaICtxIAggKnNzczYCmAIgCSAXIBggKXEgDCAoc3NzNgKUAiAJIBUgFiAncSARICZzc3M2ApACIAkgASAHICVxIBAgJHNzczYCjAIgCSAaIBkgI3EgDyAic3NzNgKIAiAJIBggFyAhcSAOICBzc3M2AoQCIAkgFiAVIB9xIA0gHnNzczYCgAIgHEUEQCATQQAgFPwLAAsgHUUEQCAbIAlBgAJqIAX8CgAACyAJKAKcAiEPIAkoApgCIRAgCSgClAIhESAJKAKQAiEMIAkoAoACIQggCSgChAIhByAJKAKIAiEFIAkoAowCIQEgCSAKKQJ4NwO4AiAJIAopAnA3A7ACIAkgCikCYDcD8AEgCSAKKQJoNwP4ASAJIAopAnA3A+ABIAkgCikCeDcD6AEgCUGgAmoiDSAJQfABaiAJQeABahAGIAogCSkCqAI3AnggCiAJKQKgAjcCcCAJIAopAlA3A9ABIAkgCikCWDcD2AEgCSAKKQJgNwPAASAJIAopAmg3A8gBIA0gCUHQAWogCUHAAWoQBiAKIAkpAqgCNwJoIAogCSkCoAI3AmAgCSAKQUBrIg4pAgA3A7ABIAkgCikCSDcDuAEgCSAKKQJQNwOgASAJIAopAlg3A6gBIA0gCUGwAWogCUGgAWoQBiAKIAkpAqgCNwJYIAogCSkCoAI3AlAgCSAKKQIwNwOQASAJIAopAjg3A5gBIAkgDikCADcDgAEgCSAKKQJINwOIASANIAlBkAFqIAlBgAFqEAYgCiAJKQKoAjcCSCAOIAkpAqACNwIAIAkgCikCIDcDcCAJIAopAig3A3ggCSAKKQIwNwNgIAkgCikCODcDaCANIAlB8ABqIAlB4ABqEAYgCiAJKQKoAjcCOCAKIAkpAqACNwIwIAkgCikCEDcDUCAJIAopAhg3A1ggCSAKKQIgNwNAIAkgCikCKDcDSCANIAlB0ABqIAlBQGsQBiAKIAkpAqgCNwIoIAogCSkCoAI3AiAgCSAKKQIANwMwIAkgCikCCDcDOCAJIAopAhA3AyAgCSAKKQIYNwMoIA0gCUEwaiAJQSBqEAYgCiAJKQKoAjcCGCAKIAkpAqACNwIQIAkgCSkDsAI3AxAgCSAJKQO4AjcDGCAJIAopAgA3AwAgCSAKKQIINwMIIA0gCUEQaiAJEAYgCiAJKQKoAjcCCCAKIAkpAqACNwIAIAogASAKKAIMczYCDCAKIAUgCigCCHM2AgggCiAHIAooAgRzNgIEIAogCCAKKAIAczYCACAOIAwgDigCAHM2AgAgCiARIAooAkRzNgJEIAogECAKKAJIczYCSCAKIA8gCigCTHM2AkwgCUHAAmokAAsgCyAEIAatIAKtIAtB4ABqEKACQX8hBwJAAkACQAJ/AkACQCAEQRBrDhEAAwMDAwMDAwMDAwMDAwMDAQMLIAsgAxBHDAELIAsgAxBGCyIHRQ0BCyAARQ0BIAJFDQEgAEEAIAL8CwAgEiQAIAcPC0EAIQcLIBIkACAHC+gCAQN/IwAiCSAJQcABa0FgcSIJJAAgCCAHIAlBQGsQowJBACEHIAZBP0sEQEHAACEIA0AgBSAHaiAJQUBrEKICIAgiB0FAayIIIAZNDQALCyAGIAdBIHIiCE8EQANAIAUgB2ogCUFAaxCAASAIIgdBIGoiCCAGTQ0ACwsgBkEfcSIIBEBBICAIayILBEAgCUEgaiAIckEAIAv8CwALIAgEQCAJQSBqIAUgB2ogCPwKAAALIAlBIGogCUFAaxCAAQtBICEFQQAhByAEQSBPBEADQCAAIAdqIAMgB2ogCUFAaxChAiAFIgdBIGoiBSAETQ0ACwsCQCAEQR9xIgVFDQBBICAFayIIBEAgCUEgaiAFckEAIAj8CwALIAVFIghFBEAgCUEgaiADIAdqIAX8CgAACyAJIAlBIGogCUFAaxChAiAIDQAgACAHaiAJIAX8CgAACyABIAIgBq0gBK0gCUFAaxCgAiQAQQALC4ayAhEAQYAIC7AELi8wMTIzNDU2Nzg5QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5egBqcwByYW5kb21ieXRlcwBiNjRfcG9zIDw9IGI2NF9sZW4AY3J5cHRvX2dlbmVyaWNoYXNoX2JsYWtlMmJfZmluYWwAYXJnb24yaWQsYXJnb24yaQAkYXJnb24yaQB4d2luZwAkYXJnb24yaWQAcmFuZG9tYnl0ZXMvcmFuZG9tYnl0ZXMuYwBzb2RpdW0vY29kZWNzLmMAY3J5cHRvX2dlbmVyaWNoYXNoL2JsYWtlMmIvcmVmL2JsYWtlMmItcmVmLmMAY3J5cHRvX2dlbmVyaWNoYXNoL2JsYWtlMmIvcmVmL2dlbmVyaWNoYXNoX2JsYWtlMmIuYwB4MjU1MTlibGFrZTJiAGJ1Zl9sZW4gPD0gU0laRV9NQVgAb3V0bGVuIDw9IFVJTlQ4X01BWABTLT5idWZsZW4gPD0gQkxBS0UyQl9CTE9DS0JZVEVTACRhcmdvbjJpJHY9ACRhcmdvbjJpZCR2PQBjdXJ2ZTI1NTE5AGVkMjU1MTkAaG1hY3NoYTUxMjI1NgBjdXJ2ZTI1NTE5eHNhbHNhMjBwb2x5MTMwNQBzb2RpdW1fYmluMmJhc2U2NABzaXBoYXNoMjQAMS4wLjIyAHNoYTUxMgB4c2Fsc2EyMAAkYXJnb24yaSQAJGFyZ29uMmlkJAAkNyQAQcAMC1e2eFn/hXLTAL1uFf8PCmoAKcABAJjoef+8PKD/mXHO/wC34v60DUj/AAAAAAAAAACwoA7+08mG/54YjwB/aTUAYAy9AKfX+/+fTID+amXh/x78BACSDK4AQaANCydZ8bL+CuWm/3vdKv4eFNQAUoADADDR8wB3eUD/MuOc/wBuxQFnG5AAQdANC8AHhTuMAb3xJP/4JcMBYNw3ALdMPv/DQj0AMkykAeGkTP9MPaP/dT4fAFGRQP92QQ4AonPW/waKLgB85vT/CoqPADQawgC49EwAgY8pAb70E/97qnr/YoFEAHnVkwBWZR7/oWebAIxZQ//v5b4BQwu1AMbwif7uRbz/Q5fuABMqbP/lVXEBMkSH/xFqCQAyZwH/UAGoASOYHv8QqLkBOFno/2XS/AAp+kcAzKpP/w4u7/9QTe8AvdZL/xGN+QAmUEz/vlV1AFbkqgCc2NABw8+k/5ZCTP+v4RD/jVBiAUzb8gDGonIALtqYAJsr8f6boGj/M7ulAAIRrwBCVKAB9zoeACNBNf5F7L8ALYb1AaN73QAgbhT/NBelALrWRwDpsGAA8u82ATlZigBTAFT/iKBkAFyOeP5ofL4AtbE+//opVQCYgioBYPz2AJeXP/7vhT4AIDicAC2nvf+OhbMBg1bTALuzlv76qg7/0qNOACU0lwBjTRoA7pzV/9XA0QFJLlQAFEEpATbOTwDJg5L+qm8Y/7EhMv6rJsv/Tvd0ANHdmQCFgLIBOiwZAMknOwG9E/wAMeXSAXW7dQC1s7gBAHLbADBekwD1KTgAfQ3M/vStdwAs3SD+VOoUAPmgxgHsfur/L2Oo/qrimf9ms9gA4o16/3pCmf629YYA4+QZAdY56//YrTj/tefSAHeAnf+BX4j/bn4zAAKpt/8HgmL+RbBe/3QE4wHZ8pH/yq0fAWkBJ/8ur0UA5C86/9fgRf7POEX/EP6L/xfP1P/KFH7/X9Vg/wmwIQDIBc//8SqA/iMhwP/45cQBgRF4APtnl/8HNHD/jDhC/yji9f/ZRiX+rNYJ/0hDhgGSwNb/LCZwAES4S//OWvsAleuNALWqOgB09O8AXJ0CAGatYgDpiWABfzHLAAWblAAXlAn/03oMACKGGv/bzIgAhggp/+BTK/5VGfcAbX8A/qmIMADud9v/563VAM4S/v4Iugf/fgkHAW8qSABvNOz+YD+NAJO/f/7NTsD/DmrtAbvbTACv87v+aVmtAFUZWQGi85QAAnbR/iGeCQCLoy7/XUYoAGwqjv5v/I7/m9+QADPlp/9J/Jv/XnQM/5ig2v+c7iX/s+rP/8UAs/+apI0A4cRoAAojGf7R1PL/Yf3e/rhl5QDeEn8BpIiH/x7PjP6SYfMAgcAa/slUIf9vCk7/k1Gy/wQEGACh7tf/Bo0hADXXDv8ptdD/54udALPL3f//uXEAveKs/3FC1v/KPi3/ZkAI/06uEP6FdUT/AEGwFQsBAQBB0BULsAEm6JWPwrInsEXD9Iny75jw1d+sBdPGMzmxOAKIbVP8BccXanA9TdhPujwLdg0QZw8qIFP6LDnMxk7H/XeSrAN67P///////////////////////////////////////3/t////////////////////////////////////////f+7///////////////////////////////////////9/7dP1XBpjEljWnPei3vneFABBjxcLrPEBEP1AXQCgaj8AOdNX/gzSugBYvHT+QdgBAP/IPQHYQpT/APtcACSy4f8AAAAAAAAAAIU7jAG98ST/+CXDAWDcNwC3TD7/w0I9ADJMpAHhpEz/TD2j/3U+HwBRkUD/dkEOAKJz1v8Gii4AfOb0/wqKjwA0GsIAuPRMAIGPKQG+9BP/e6p6/2KBRAB51ZMAVmUe/6FnmwCMWUP/7+W+AUMLtQDG8In+7kW8/+pxPP8l/zn/RbK2/oDQswB2Gn3+AwfW//EyTf9Vy8X/04f6/xkwZP+71bT+EVhpAFPRngEFc2IABK48/qs3bv/ZtRH/FLyqAJKcZv5X1q7/cnqbAeksqgB/CO8B1uzqAK8F2wAxaj3/BkLQ/wJqbv9R6hP/12vA/0OX7gATKmz/5VVxATJEh/8RagkAMmcB/1ABqAEjmB7/EKi5AThZ6P9l0vwAKfpHAMyqT/8OLu//UE3vAL3WS/8RjfkAJlBM/75VdQBW5KoAnNjQAcPPpP+WQkz/r+EQ/41QYgFM2/IAxqJyAC7amACbK/H+m6Bo/7IJ/P5kbtQADgWnAOnvo/8cl50BZZIK//6eRv5H+eQAWB4yAEQ6oP+/GGgBgUKB/8AyVf8Is4r/JvrJAHNQoACD5nEAfViTAFpExwD9TJ4AHP92AHH6/gBCSy4A5torAOV4ugGURCsAiHzuAbtrxf9UNfb/M3T+/zO7pQACEa8AQlSgAfc6HgAjQTX+Rey/AC2G9QGje90AIG4U/zQXpQC61kcA6bBgAPLvNgE5WYoAUwBU/4igZABcjnj+aHy+ALWxPv/6KVUAmIIqAWD89gCXlz/+74U+ACA4nAAtp73/joWzAYNW0wC7s5b++qoO/0RxFf/eujv/QgfxAUUGSABWnGz+N6dZAG002/4NsBf/xCxq/++VR/+kjH3/n60BADMp5wCRPiEAim9dAblTRQCQcy4AYZcQ/xjkGgAx2eIAcUvq/sGZDP+2MGD/Dg0aAIDD+f5FwTsAhCVR/n1qPADW8KkBpONCANKjTgAlNJcAY00aAO6c1f/VwNEBSS5UABRBKQE2zk8AyYOS/qpvGP+xITL+qybL/073dADR3ZkAhYCyATosGQDJJzsBvRP8ADHl0gF1u3UAtbO4AQBy2wAwXpMA9Sk4AH0NzP70rXcALN0g/lTqFAD5oMYB7H7q/48+3QCBWdb/N4sF/kQUv/8OzLIBI8PZAC8zzgEm9qUAzhsG/p5XJADZNJL/fXvX/1U8H/+rDQcA2vVY/vwjPAA31qD/hWU4AOAgE/6TQOoAGpGiAXJ2fQD4/PoAZV7E/8aN4v4zKrYAhwwJ/m2s0v/F7MIB8UGaADCcL/+ZQzf/2qUi/kq0swDaQkcBWHpjANS12/9cKuf/7wCaAPVNt/9eUaoBEtXYAKtdRwA0XvgAEpeh/sXRQv+u9A/+ojC3ADE98P62XcMAx+QGAcgFEf+JLe3/bJQEAFpP7f8nP03/NVLPAY4Wdv9l6BIBXBpDAAXIWP8hqIr/leFIAALRG/8s9agB3O0R/x7Taf6N7t0AgFD1/m/+DgDeX74B3wnxAJJM1P9szWj/P3WZAJBFMAAj5G8AwCHB/3DWvv5zmJcAF2ZYADNK+ADix4/+zKJl/9BhvQH1aBIA5vYe/xeURQBuWDT+4rVZ/9AvWv5yoVD/IXT4ALOYV/9FkLEBWO4a/zogcQEBTUUAO3k0/5juUwA0CMEA5yfp/8ciigDeRK0AWzny/tzSf//AB/b+lyO7AMPspQBvXc4A1PeFAZqF0f+b5woAQE4mAHr5ZAEeE2H/Plv5AfiFTQDFP6j+dApSALjscf7Uy8L/PWT8/iQFyv93W5n/gU8dAGdnq/7t12//2DVFAO/wFwDCld3/JuHeAOj/tP52UoX/OdGxAYvohQCesC7+wnMuAFj35QEcZ78A3d6v/pXrLACX5Bn+2mlnAI5V0gCVgb7/1UFe/nWG4P9SxnUAnd3cAKNlJADFciUAaKym/gu2AABRSLz/YbwQ/0UGCgDHk5H/CAlzAUHWr//ZrdEAUH+mAPflBP6nt3z/WhzM/q878P8LKfgBbCgz/5Cxw/6W+n4AiltBAXg83v/1we8AHda9/4ACGQBQmqIATdxrAerNSv82pmf/dEgJAOReL/8eyBn/I9ZZ/z2wjP9T4qP/S4KsAIAmEQBfiZj/13yfAU9dAACUUp3+w4L7/yjKTP/7fuAAnWM+/s8H4f9gRMMAjLqd/4MT5/8qgP4ANNs9/mbLSACNBwv/uqTVAB96dwCF8pEA0Pzo/1vVtv+PBPr++ddKAKUebwGrCd8A5XsiAVyCGv9Nmy0Bw4sc/zvgTgCIEfcAbHkgAE/6vf9g4/z+JvE+AD6uff+bb13/CubOAWHFKP8AMTn+QfoNABL7lv/cbdL/Ba6m/iyBvQDrI5P/JfeN/0iNBP9na/8A91oEADUsKgACHvAABDs/AFhOJABxp7QAvkfB/8eepP86CKwATSEMAEE/AwCZTSH/rP5mAeTdBP9XHv4BkilW/4rM7/5sjRH/u/KHANLQfwBELQ7+SWA+AFE8GP+qBiT/A/kaACPVbQAWgTb/FSPh/+o9OP862QYAj3xYAOx+QgDRJrf/Iu4G/66RZgBfFtMAxA+Z/i5U6P91IpIB5/pK/xuGZAFcu8P/qsZwAHgcKgDRRkMAHVEfAB2oZAGpraAAayN1AD5gO/9RDEUBh+++/9z8EgCj3Dr/iYm8/1NmbQBgBkwA6t7S/7muzQE8ntX/DfHWAKyBjABdaPIAwJz7ACt1HgDhUZ4Af+jaAOIcywDpG5f/dSsF//IOL/8hFAYAifss/hsf9f+31n3+KHmVALqe1f9ZCOMARVgA/suH4QDJrssAk0e4ABJ5Kf5eBU4A4Nbw/iQFtAD7h+cBo4rUANL5dP5YgbsAEwgx/j4OkP+fTNMA1jNSAG115P5n38v/S/wPAZpH3P8XDVsBjahg/7W2hQD6MzcA6urU/q8/ngAn8DQBnr0k/9UoVQEgtPf/E2YaAVQYYf9FFd4AlIt6/9zV6wHoy/8AeTmTAOMHmgA1FpMBSAHhAFKGMP5TPJ3/kUipACJn7wDG6S8AdBME/7hqCf+3gVMAJLDmASJnSADbooYA9SqeACCVYP6lLJAAyu9I/teWBQAqQiQBhNevAFauVv8axZz/MeiH/me2UgD9gLABmbJ6APX6CgDsGLIAiWqEACgdKQAyHpj/fGkmAOa/SwCPK6oALIMU/ywNF//t/5sBn21k/3C1GP9o3GwAN9ODAGMM1f+Yl5H/7gWfAGGbCAAhbFEAAQNnAD5tIv/6m7QAIEfD/yZGkQGfX/UAReVlAYgc8ABP4BkATm55//iofAC7gPcAApPr/k8LhABGOgwBtQij/0+Jhf8lqgv/jfNV/7Dn1//MlqT/79cn/y5XnP4Io1j/rCLoAEIsZv8bNin+7GNX/yl7qQE0cisAdYYoAJuGGgDnz1v+I4Qm/xNmff4k44X/dgNx/x0NfACYYEoBWJLO/6e/3P6iElj/tmQXAB91NABRLmoBDAIHAEVQyQHR9qwADDCNAeDTWAB04p8AemKCAEHs6gHh4gn/z+J7AVnWOwBwh1gBWvTL/zELJgGBbLoAWXAPAWUuzP9/zC3+T//d/zNJEv9/KmX/8RXKAKDjBwBpMuwATzTF/2jK0AG0DxAAZcVO/2JNywApufEBI8F8ACObF//PNcAAC32jAfmeuf8EgzAAFV1v/z155wFFyCT/uTC5/2/uFf8nMhn/Y9ej/1fUHv+kkwX/gAYjAWzfbv/CTLIASmW0APMvMACuGSv/Uq39ATZywP8oN1sA12yw/ws4BwDg6UwA0WLK/vIZfQAswV3+ywixAIewEwBwR9X/zjuwAQRDGgAOj9X+KjfQ/zxDeADBFaMAY6RzAAoUdgCc1N7+oAfZ/3L1TAF1O3sAsMJW/tUPsABOzs/+1YE7AOn7FgFgN5j/7P8P/8VZVP9dlYUArqBxAOpjqf+YdFgAkKRT/18dxv8iLw//Y3iG/wXswQD5937/k7seADLmdf9s2dv/o1Gm/0gZqf6beU//HJtZ/gd+EQCTQSEBL+r9ABozEgBpU8f/o8TmAHH4pADi/toAvdHL/6T33v7/I6UABLzzAX+zRwAl7f7/ZLrwAAU5R/5nSEn/9BJR/uXShP/uBrT/C+Wu/+PdwAERMRwAo9fE/gl2BP8z8EcAcYFt/0zw5wC8sX8AfUcsARqv8wBeqRn+G+YdAA+LdwGoqrr/rMVM//xLvACJfMQASBZg/y2X+QHckWQAQMCf/3jv4gCBspIAAMB9AOuK6gC3nZIAU8fA/7isSP9J4YAATQb6/7pBQwBo9s8AvCCK/9oY8gBDilH+7YF5/xTPlgEpxxD/BhSAAJ92BQC1EI//3CYPABdAk/5JGg0AV+Q5Acx8gAArGN8A22PHABZLFP8TG34AnT7XAG4d5gCzp/8BNvy+AN3Mtv6znkH/UZ0DAMLanwCq3wAA4Asg/ybFYgCopCUAF1gHAaS6bgBgJIYA6vLlAPp5EwDy/nD/Ay9eAQnvBv9Rhpn+1v2o/0N84AD1X0oAHB4s/gFt3P+yWVkA/CRMABjGLv9MTW8AhuqI/ydeHQC5SOr/RkSH/+dmB/5N54wApy86AZRhdv8QG+EBps6P/26y1v+0g6IAj43hAQ3aTv9ymSEBYmjMAK9ydQGnzksAysRTATpAQwCKL28BxPeA/4ng4P6ecM8AmmT/AYYlawDGgE//f9Gb/6P+uf48DvMAH9tw/h3ZQQDIDXT+ezzE/+A7uP7yWcQAexBL/pUQzgBF/jAB53Tf/9GgQQHIUGIAJcK4/pQ/IgCL8EH/2ZCE/zgmLf7HeNIAbLGm/6DeBADcfnf+pWug/1Lc+AHxr4gAkI0X/6mKVACgiU7/4nZQ/zQbhP8/YIv/mPonALybDwDoM5b+KA/o//DlCf+Jrxv/S0lhAdrUCwCHBaIBa7nVAAL5a/8o8kYA28gZABmdDQBDUlD/xPkX/5EUlQAySJIAXkyUARj7QQAfwBcAuNTJ/3vpogH3rUgAolfb/n6GWQCfCwz+pmkdAEkb5AFxeLf/QqNtAdSPC/+f56gB/4BaADkOOv5ZNAr//QijAQCR0v8KgVUBLrUbAGeIoP5+vNH/IiNvANfbGP/UC9b+ZQV2AOjFhf/fp23/7VBW/0aLXgCewb8Bmw8z/w++cwBOh8//+QobAbV96QBfrA3+qtWh/yfsiv9fXVf/voBfAH0PzgCmlp8A4w+e/86eeP8qjYAAZbJ4AZxtgwDaDiz+96jO/9RwHABwEeT/WhAlAcXebAD+z1P/CVrz//P0rAAaWHP/zXR6AL/mwQC0ZAsB2SVg/5pOnADr6h//zrKy/5XA+wC2+ocA9hZpAHzBbf8C0pX/qRGqAABgbv91CQgBMnso/8G9YwAi46AAMFBG/tMz7AAtevX+LK4IAK0l6f+eQasAekXX/1pQAv+DamD+43KHAM0xd/6wPkD/UjMR//EU8/+CDQj+gNnz/6IbAf5advEA9sb2/zcQdv/In50AoxEBAIxreQBVoXb/JgCVAJwv7gAJpqYBS2K1/zJKGQBCDy8Ai+GfAEwDjv8O7rgAC881/7fAugGrIK7/v0zdAfeq2wAZrDL+2QnpAMt+RP+3XDAAf6e3AUEx/gAQP38B/hWq/zvgf/4WMD//G06C/ijDHQD6hHD+I8uQAGipqADP/R7/aCgm/l7kWADOEID/1Dd6/98W6gDfxX8A/bW1AZFmdgDsmST/1NlI/xQmGP6KPj4AmIwEAObcY/8BFdT/lMnnAPR7Cf4Aq9IAMzol/wH/Dv/0t5H+APKmABZKhAB52CkAX8Ny/oUYl/+c4uf/9wVN//aUc/7hXFH/3lD2/qp7Wf9Kx40AHRQI/4qIRv9dS1wA3ZMx/jR+4gDlfBcALgm1AM1ANAGD/hwAl57UAINATgDOGasAAOaLAL/9bv5n96cAQCgoASql8f87S+T+fPO9/8Rcsv+CjFb/jVk4AZPGBf/L+J7+kKKNAAus4gCCKhX/AaeP/5AkJP8wWKT+qKrcAGJH1gBb0E8An0zJAaYq1v9F/wD/BoB9/74BjACSU9r/1+5IAXp/NQC9dKX/VAhC/9YD0P/VboUAw6gsAZ7nRQCiQMj+WzpoALY6u/755IgAy4ZM/mPd6QBL/tb+UEWaAECY+P7siMr/nWmZ/pWvFAAWIxP/fHnpALr6xv6E5YsAiVCu/6V9RACQypT+6+/4AIe4dgBlXhH/ekhG/kWCkgB/3vgBRX92/x5S1/68ShP/5afC/nUZQv9B6jj+1RacAJc7Xf4tHBv/un6k/yAG7wB/cmMB2zQC/2Ngpv4+vn7/bN6oAUvirgDm4scAPHXa//z4FAHWvMwAH8KG/ntFwP+prST+N2JbAN8qZv6JAWYAnVoZAO96QP/8BukABzYU/1J0rgCHJTb/D7p9AONwr/9ktOH/Ku30//St4v74EiEAq2OW/0rrMv91UiD+aqjtAM9t0AHkCboAhzyp/rNcjwD0qmj/6y18/0ZjugB1ibcA4B/XACgJZAAaEF8BRNlXAAiXFP8aZDr/sKXLATR2RgAHIP7+9P71/6eQwv99cRf/sHm1AIhU0QCKBh7/WTAcACGbDv8Z8JoAjc1tAUZzPv8UKGv+iprH/17f4v+dqyYAo7EZ/i12A/8O3hcB0b5R/3Z76AEN1WX/ezd7/hv2pQAyY0z/jNYg/2FBQ/8YDBwArlZOAUD3YACgh0MAQjfz/5PMYP8aBiH/YjNTAZnV0P8CuDb/GdoLADFD9v4SlUj/DRlIACpP1gAqBCYBG4uQ/5W7FwASpIQA9VS4/njGaP9+2mAAOHXq/w0d1v5ELwr/p5qE/pgmxgBCsln/yC6r/w1jU//Su/3/qi0qAYrRfADWoo0ADOacAGYkcP4Dk0MANNd7/+mrNv9iiT4A99on/+fa7AD3v38Aw5JUAKWwXP8T1F7/EUrjAFgomQHGkwH/zkP1/vAD2v89jdX/YbdqAMPo6/5fVpoA0TDN/nbR8f/weN8B1R2fAKN/k/8N2l0AVRhE/kYUUP+9BYwBUmH+/2Njv/+EVIX/a9p0/3B6LgBpESAAwqA//0TeJwHY/VwAsWnN/5XJwwAq4Qv/KKJzAAkHUQCl2tsAtBYA/h2S/P+Sz+EBtIdgAB+jcACxC9v/hQzB/itOMgBBcXkBO9kG/25eGAFwrG8ABw9gACRVewBHlhX/0Em8AMALpwHV9SIACeZcAKKOJ//XWhsAYmFZAF5P0wBanfAAX9x+AWaw4gAkHuD+Ix9/AOfocwFVU4IA0kn1/y+Pcv9EQcUAO0g+/7eFrf5deXb/O7FR/+pFrf/NgLEA3PQzABr00QFJ3k3/owhg/paV0wCe/ssBNn+LAKHgOwAEbRb/3iot/9CSZv/sjrsAMs31/wpKWf4wT44A3kyC/x6mPwDsDA3/Mbj0ALtxZgDaZf0AmTm2/iCWKgAZxpIB7fE4AIxEBQBbpKz/TpG6/kM0zQDbz4EBbXMRADaPOgEV+Hj/s/8eAMHsQv8B/wf//cAw/xNF2QED1gD/QGWSAd99I//rSbP/+afiAOGvCgFhojoAanCrAVSsBf+FjLL/hvWOAGFaff+6y7n/300X/8BcagAPxnP/2Zj4AKuyeP/khjUAsDbBAfr7NQDVCmQBIsdqAJcf9P6s4Ff/Du0X//1VGv9/J3T/rGhkAPsORv/U0Ir//dP6ALAxpQAPTHv/Jdqg/1yHEAEKfnL/RgXg//f5jQBEFDwB8dK9/8PZuwGXA3EAl1yuAOc+sv/bt+EAFxch/821UAA5uPj/Q7QB/1p7Xf8nAKL/YPg0/1RCjAAif+T/wooHAaZuvAAVEZsBmr7G/9ZQO/8SB48ASB3iAcfZ+QDooUcBlb7JANmvX/5xk0P/io/H/3/MAQAdtlMBzuab/7rMPAAKfVX/6GAZ//9Z9//V/q8B6MFRABwrnP4MRQgAkxj4ABLGMQCGPCMAdvYS/zFY/v7kFbr/tkFwAdsWAf8WfjT/vTUx/3AZjwAmfzf/4mWj/tCFPf+JRa4BvnaR/zxi2//ZDfX/+ogKAFT+4gDJH30B8DP7/x+Dgv8CijL/19exAd8M7v/8lTj/fFtE/0h+qv53/2QAgofo/w5PsgD6g8UAisbQAHnYi/53EiT/HcF6ABAqLf/V8OsB5r6p/8Yj5P5urUgA1t3x/ziUhwDAdU7+jV3P/49BlQAVEmL/Xyz0AWq/TQD+VQj+1m6w/0mtE/6gxMf/7VqQAMGscf/Im4j+5FrdAIkxSgGk3df/0b0F/2nsN/8qH4EBwf/sAC7ZPACKWLv/4lLs/1FFl/+OvhABDYYIAH96MP9RQJwAq/OLAO0j9gB6j8H+1HqSAF8p/wFXhE0ABNQfABEfTgAnLa3+GI7Z/18JBv/jUwYAYjuC/j4eIQAIc9MBomGA/we4F/50HKj/+IqX/2L08AC6doIAcvjr/2mtyAGgfEf/XiSkAa9Bkv/u8ar+ysbFAORHiv4t9m3/wjSeAIW7sABT/Jr+Wb3d/6pJ/ACUOn0AJEQz/ipFsf+oTFb/JmTM/yY1IwCvE2EA4e79/1FRhwDSG//+60lrAAjPcwBSf4gAVGMV/s8TiABkpGUAUNBN/4TP7f8PAw//IaZuAJxfVf8luW8Blmoj/6aXTAByV4f/n8JAAAx6H//oB2X+rXdiAJpH3P6/OTX/qOig/+AgY//anKUAl5mjANkNlAHFcVkAlRyh/s8XHgBphOP/NuZe/4WtzP9ct53/WJD8/mYhWgCfYQMAtdqb//BydwBq1jX/pb5zAZhb4f9Yaiz/0D1xAJc0fAC/G5z/bjbsAQ4epv8nf88B5cccALzkvP5knesA9tq3AWsWwf/OoF8ATO+TAM+hdQAzpgL/NHUK/kk44/+YweEAhF6I/2W/0QAga+X/xiu0AWTSdgByQ5n/F1ga/1maXAHceIz/kHLP//xz+v8izkgAioV//wiyfAFXS2EAD+Vc/vBDg/92e+P+knho/5HV/wGBu0b/23c2AAETrQAtlpQB+FNIAMvpqQGOazgA9/kmAS3yUP8e6WcAYFJGABfJbwBRJx7/obdO/8LqIf9E44z+2M50AEYb6/9okE8ApOZd/taHnACau/L+vBSD/yRtrgCfcPEABW6VASSl2gCmHRMBsi5JAF0rIP74ve0AZpuNAMldw//xi/3/D29i/2xBo/6bT77/Sa7B/vYoMP9rWAv+ymFV//3MEv9x8kIAbqDC/tASugBRFTwAvGin/3ymYf7ShY4AOPKJ/ilvggBvlzoBb9WN/7es8f8mBsT/uQd7/y4L9gD1aXcBDwKh/wjOLf8Sykr/U3xzAdSNnQBTCNH+iw/o/6w2rf4y94QA1r3VAJC4aQDf/vgA/5Pw/xe8SAAHMzYAvBm0/ty0AP9ToBQAo73z/zrRwv9XSTwAahgxAPX53AAWracAdgvD/xN+7QBunyX/O1IvALS7VgC8lNABZCWF/wdwwQCBvJz/VGqB/4XhygAO7G//KBRlAKysMf4zNkr/+7m4/12b4P+0+eAB5rKSAEg5Nv6yPrgAd81IALnv/f89D9oAxEM4/+ogqwEu2+QA0Gzq/xQ/6P+lNccBheQF/zTNawBK7oz/lpzb/u+ssv/7vd/+II7T/9oPigHxxFAAHCRi/hbqxwA97dz/9jklAI4Rjv+dPhoAK+5f/gPZBv/VGfABJ9yu/5rNMP4TDcD/9CI2/owQmwDwtQX+m8E8AKaABP8kkTj/lvDbAHgzkQBSmSoBjOySAGtc+AG9CgMAP4jyANMnGAATyqEBrRu6/9LM7/4p0aL/tv6f/6x0NADDZ97+zUU7ADUWKQHaMMIAUNLyANK8zwC7oaH+2BEBAIjhcQD6uD8A3x5i/k2oogA7Na8AE8kK/4vgwgCTwZr/1L0M/gHIrv8yhXEBXrNaAK22hwBesXEAK1nX/4j8av97hlP+BfVC/1IxJwHcAuAAYYGxAE07WQA9HZsBy6vc/1xOiwCRIbX/qRiNATeWswCLPFD/2idhAAKTa/88+EgAreYvAQZTtv8QaaL+idRR/7S4hgEn3qT/3Wn7Ae9wfQA/B2EAP2jj/5Q6DABaPOD/VNT8AE/XqAD43ccBc3kBACSseAAgorv/OWsx/5MqFQBqxisBOUpXAH7LUf+Bh8MAjB+xAN2LwgAD3tcAg0TnALFWsv58l7QAuHwmAUajEQD5+7UBKjfjAOKhLAAX7G4AM5WOAV0F7ADat2r+QxhNACj10f/eeZkApTkeAFN9PABGJlIB5Qa8AG3enf83dj//zZe6AOMhlf/+sPYB47HjACJqo/6wK08Aal9OAbnxev+5Dj0AJAHKAA2yov/3C4QAoeZcAUEBuf/UMqUBjZJA/57y2gAVpH0A1Yt6AUNHVwDLnrIBl1wrAJhvBf8nA+//2f/6/7A/R/9K9U0B+q4S/yIx4//2Lvv/miMwAX2dPf9qJE7/YeyZAIi7eP9xhqv/E9XZ/the0f/8BT0AXgPKAAMat/9Avyv/HhcVAIGNTf9meAcBwkyMALyvNP8RUZQA6FY3AeEwrACGKir/7jIvAKkS/gAUk1f/DsPv/0X3FwDu5YD/sTFwAKhi+/95R/gA8wiR/vbjmf/bqbH++4ul/wyjuf+kKKv/mZ8b/vNtW//eGHABEtbnAGudtf7DkwD/wmNo/1mMvv+xQn7+arlCADHaHwD8rp4AvE/mAe4p4ADU6ggBiAu1AKZ1U/9Ew14ALoTJAPCYWACkOUX+oOAq/zvXQ/93w43/JLR5/s8vCP+u0t8AZcVE//9SjQH6iekAYVaFARBQRQCEg58AdF1kAC2NiwCYrJ3/WitbAEeZLgAnEHD/2Yhh/9zGGf6xNTEA3liG/4APPADPwKn/wHTR/2pO0wHI1bf/Bwx6/t7LPP8hbsf++2p1AOThBAF4Ogf/3cFU/nCFGwC9yMn/i4eWAOo3sP89MkEAmGyp/9xVAf9wh+MAohq6AM9guf70iGsAXZkyAcZhlwBuC1b/j3Wu/3PUyAAFyrcA7aQK/rnvPgDseBL+Yntj/6jJwv4u6tYAv4Ux/2OpdwC+uyMBcxUt//mDSABwBnv/1jG1/qbpIgBcxWb+/eTN/wM7yQEqYi4A2yUj/6nDJgBefMEBnCvfAF9Ihf54zr8AesXv/7G7T//+LgIB+qe+AFSBEwDLcab/+R+9/kidyv/QR0n/zxhIAAoQEgHSUUz/WNDA/37za//ujXj/x3nq/4kMO/8k3Hv/lLM8/vAMHQBCAGEBJB4m/3MBXf9gZ+f/xZ47AcCk8ADKyjn/GK4wAFlNmwEqTNcA9JfpABcwUQDvfzT+44Il//h0XQF8hHYArf7AAQbrU/9ur+cB+xy2AIH5Xf5UuIAATLU+AK+AugBkNYj+bR3iAN3pOgEUY0oAABagAIYNFQAJNDf/EVmMAK8iOwBUpXf/4OLq/wdIpv97c/8BEtb2APoHRwHZ3LkA1CNM/yZ9rwC9YdIAcu4s/ym8qf4tupoAUVwWAISgwQB50GL/DVEs/8ucUgBHOhX/0HK//jImkwCa2MMAZRkSADz61//phOv/Z6+OARAOXACNH27+7vEt/5nZ7wFhqC//+VUQARyvPv85/jYA3ud+AKYtdf4SvWD/5EwyAMj0XgDGmHgBRCJF/wxBoP5lE1oAp8V4/0Q2uf8p2rwAcagwAFhpvQEaUiD/uV2kAeTw7f9CtjUAq8Vc/2sJ6QHHeJD/TjEK/22qaf9aBB//HPRx/0o6CwA+3Pb/eZrI/pDSsv9+OYEBK/oO/2VvHAEvVvH/PUaW/zVJBf8eGp4A0RpWAIrtSgCkX7wAjjwd/qJ0+P+7r6AAlxIQANFvQf7Lhif/WGwx/4MaR//dG9f+aGld/x/sH/6HANP/j39uAdRJ5QDpQ6f+wwHQ/4QR3f8z2VoAQ+sy/9/SjwCzNYIB6WrGANmt3P9w5Rj/r5pd/kfL9v8wQoX/A4jm/xfdcf7rb9UAqnhf/vvdAgAtgp7+aV7Z//I0tP7VRC3/aCYcAPSeTAChyGD/zzUN/7tDlACqNvgAd6Ky/1MUCwAqKsABkp+j/7fobwBN5RX/RzWPABtMIgD2iC//2ye2/1zgyQETjg7/Rbbx/6N29QAJbWoBqrX3/04v7v9U0rD/1WuLACcmCwBIFZYASIJFAM1Nm/6OhRUAR2+s/uIqO/+zANcBIYDxAOr8DQG4TwgAbh5J//aNvQCqz9oBSppF/4r2Mf+bIGQAfUpp/1pVPf8j5bH/Pn3B/5lWvAFJeNQA0Xv2/ofRJv+XOiwBXEXW/w4MWP/8mab//c9w/zxOU//jfG4AtGD8/zV1If6k3FL/KQEb/yakpv+kY6n+PZBG/8CmEgBr+kIAxUEyAAGzEv//aAH/K5kj/1BvqABur6gAKWkt/9sOzf+k6Yz+KwF2AOlDwwCyUp//ild6/9TuWv+QI3z+GYykAPvXLP6FRmv/ZeNQ/lypNwDXKjEAcrRV/yHoGwGs1RkAPrB7/iCFGP/hvz4AXUaZALUqaAEWv+D/yMiM//nqJQCVOY0AwzjQ//6CRv8grfD/HdzHAG5kc/+E5fkA5Onf/yXY0f6ysdH/ty2l/uBhcgCJYaj/4d6sAKUNMQHS68z//AQc/kaglwDovjT+U/hd/z7XTQGvr7P/oDJCAHkw0AA/qdH/ANLIAOC7LAFJolIACbCP/xNMwf8dO6cBGCuaABy+vgCNvIEA6OvL/+oAbf82QZ8APFjo/3n9lv786YP/xm4pAVNNR//IFjv+av3y/xUMz//tQr0AWsbKAeGsfwA1FsoAOOaEAAFWtwBtvioA80SuAW3kmgDIsXoBI6C3/7EwVf9a2qn/+JhOAMr+bgAGNCsAjmJB/z+RFgBGal0A6IprAW6zPf/TgdoB8tFcACNa2QG2j2r/dGXZ/3L63f+tzAYAPJajAEmsLP/vblD/7UyZ/qGM+QCV6OUAhR8o/66kdwBxM9YAgeQC/kAi8wBr4/T/rmrI/1SZRgEyIxAA+krY/uy9Qv+Z+Q0A5rIE/90p7gB243n/XleM/v53XABJ7/b+dVeAABPTkf+xLvwA5Vv2AUWA9//KTTYBCAsJ/5lgpgDZ1q3/hsACAQDPAAC9rmsBjIZkAJ7B8wG2ZqsA65ozAI4Fe/88qFkB2Q5c/xPWBQHTp/4ALAbK/ngS7P8Pcbj/uN+LACixd/62e1r/sKWwAPdNwgAb6ngA5wDW/zsnHgB9Y5H/lkREAY3e+ACZe9L/bn+Y/+Uh1gGH3cUAiWECAAyPzP9RKbwAc0+C/14DhACYr7v/fI0K/37As/8LZ8YAlQYtANtVuwHmErL/SLaYAAPGuP+AcOABYaHmAP5jJv86n8UAl0LbADtFj/+5cPkAd4gv/3uChACoR1//cbAoAei5rQDPXXUBRJ1s/2YFk/4xYSEAWUFv/vceo/982d0BZvrYAMauS/45NxIA4wXsAeXVrQDJbdoBMenvAB43ngEZsmoAm2+8AV5+jADXH+4BTfAQANXyGQEmR6gAzbpd/jHTjP/bALT/hnalAKCThv9uuiP/xvMqAPOSdwCG66MBBPGH/8Euwf5ntE//4QS4/vJ2ggCSh7AB6m8eAEVC1f4pYHsAeV4q/7K/w/8ugioAdVQI/+kx1v7uem0ABkdZAezTewD0DTD+d5QOAHIcVv9L7Rn/keUQ/oFkNf+Glnj+qJ0yABdIaP/gMQ4A/3sW/5e5l/+qULgBhrYUAClkZQGZIRAATJpvAVbO6v/AoKT+pXtd/wHYpP5DEa//qQs7/54pPf9JvA7/wwaJ/xaTHf8UZwP/9oLj/3oogADiLxj+IyQgAJi6t/9FyhQAw4XDAN4z9wCpq14BtwCg/0DNEgGcUw//xTr5/vtZbv8yClj+MyvYAGLyxgH1l3EAq+zCAcUfx//lUSYBKTsUAP1o5gCYXQ7/9vKS/tap8P/wZmz+oKfsAJravACW6cr/GxP6AQJHhf+vDD8BkbfGAGh4c/+C+/cAEdSn/z57hP/3ZL0Am9+YAI/FIQCbOyz/ll3wAX8DV/9fR88Bp1UB/7yYdP8KFxcAicNdATZiYQDwAKj/lLx/AIZrlwBM/asAWoTAAJIWNgDgQjb+5rrl/ye2xACU+4L/QYNs/oABoACpMaf+x/6U//sGgwC7/oH/VVI+ALIXOv/+hAUApNUnAIb8kv4lNVH/m4ZSAM2n7v9eLbT/hCihAP5vcAE2S9kAs+bdAetev/8X8zABypHL/yd2Kv91jf0A/gDeACv7MgA2qeoBUETQAJTL8/6RB4cABv4AAPy5fwBiCIH/JiNI/9Mk3AEoGlkAqEDF/gPe7/8CU9f+tJ9pADpzwgC6dGr/5ffb/4F2wQDKrrcBpqFIAMlrk/7tiEoA6eZqAWlvqABA4B4BAeUDAGaXr//C7uT//vrUALvteQBD+2ABxR4LALdfzADNWYoAQN0lAf/fHv+yMNP/8cha/6fRYP85gt0ALnLI/z24QgA3thj+brYhAKu+6P9yXh8AEt0IAC/n/gD/cFMAdg/X/60ZKP7AwR//7hWS/6vBdv9l6jX+g9RwAFnAawEI0BsAtdkP/+eV6ACM7H4AkAnH/wxPtf6Ttsr/E222/zHU4QBKo8sAr+mUABpwMwDBwQn/D4f5AJbjggDMANsBGPLNAO7Qdf8W9HAAGuUiACVQvP8mLc7+8Frh/x0DL/8q4EwAuvOnACCED/8FM30Ai4cYAAbx2wCs5YX/9tYyAOcLz/+/flMBtKOq//U4GAGypNP/AxDKAWI5dv+Ng1n+ITMYAPOVW//9NA4AI6lD/jEeWP+zGyT/pYy3ADq9lwBYHwAAS6lCAEJlx/8Y2McBecQa/w5Py/7w4lH/XhwK/1PB8P/MwYP/Xg9WANoonQAzwdEAAPKxAGa59wCebXQAJodbAN+vlQDcQgH/VjzoABlgJf/heqIB17uo/56dLgA4q6IA6PBlAXoWCQAzCRX/NRnu/9ke6P59qZQADehmAJQJJQClYY0B5IMpAN4P8//+EhEABjztAWoDcQA7hL0AXHAeAGnQ1QAwVLP/u3nn/hvYbf+i3Wv+Se/D//ofOf+Vh1n/uRdzAQOjnf8ScPoAGTm7/6FgpAAvEPMADI37/kPquP8pEqEArwZg/6CsNP4YsLf/xsFVAXx5if+XMnL/3Ms8/8/vBQEAJmv/N+5e/kaYXgDV3E0BeBFF/1Wkvv/L6lEAJjEl/j2QfACJTjH+qPcwAF+k/ABpqYcA/eSGAECmSwBRSRT/z9IKAOpqlv9eIlr//p85/tyFYwCLk7T+GBe5ACk5Hv+9YUwAQbvf/+CsJf8iPl8B55DwAE1qfv5AmFsAHWKbAOL7Nf/q0wX/kMve/6Sw3f4F5xgAs3rNACQBhv99Rpf+YeT8AKyBF/4wWtH/luBSAVSGHgDxxC4AZ3Hq/y5lef4ofPr/hy3y/gn5qP+MbIP/j6OrADKtx/9Y3o7/yF+eAI7Ao/8HdYcAb3wWAOwMQf5EJkH/467+APT1JgDwMtD/oT/6ADzR7wB6IxMADiHm/gKfcQBqFH//5M1gAInSrv601JD/WWKaASJYiwCnonABQW7FAPElqQBCOIP/CslT/oX9u/+xcC3+xPsAAMT6l//u6Nb/ltHNABzwdgBHTFMB7GNbACr6gwFgEkD/dt4jAHHWy/96d7j/QhMkAMxA+QCSWYsAhj6HAWjpZQC8VBoAMfmBANDWS//Pgk3/c6/rAKsCif+vkboBN/WH/5pWtQFkOvb/bcc8/1LMhv/XMeYBjOXA/97B+/9RiA//s5Wi/xcnHf8HX0v+v1HeAPFRWv9rMcn/9NOdAN6Mlf9B2zj+vfZa/7I7nQEw2zQAYiLXABwRu/+vqRgAXE+h/+zIwgGTj+oA5eEHAcWoDgDrMzUB/XiuAMUGqP/KdasAoxXOAHJVWv8PKQr/whNjAEE32P6iknQAMs7U/0CSHf+enoMBZKWC/6wXgf99NQn/D8ESARoxC/+1rskBh8kO/2QTlQDbYk8AKmOP/mAAMP/F+VP+aJVP/+tuiP5SgCz/QSkk/ljTCgC7ebsAYobHAKu8s/7SC+7/QnuC/jTqPQAwcRf+BlZ4/3ey9QBXgckA8o3RAMpyVQCUFqEAZ8MwABkxq/+KQ4IAtkl6/pQYggDT5ZoAIJueAFRpPQCxwgn/pllWATZTuwD5KHX/bQPX/zWSLAE/L7MAwtgD/g5UiACIsQ3/SPO6/3URff/TOtP/XU/fAFpY9f+L0W//Rt4vAAr2T//G2bIA4+ELAU5+s/8+K34AZ5QjAIEIpf718JQAPTOOAFHQhgAPiXP/03fs/5/1+P8Choj/5os6AaCk/gByVY3/Maa2/5BGVAFVtgcALjVdAAmmof83orL/Lbi8AJIcLP6pWjEAeLLxAQ57f/8H8ccBvUIy/8aPZf6984f/jRgY/kthVwB2+5oB7TacAKuSz/+DxPb/iEBxAZfoOQDw2nMAMT0b/0CBSQH8qRv/KIQKAVrJwf/8efABus4pACvGYQCRZLcAzNhQ/qyWQQD55cT+aHtJ/01oYP6CtAgAaHs5ANzK5f9m+dMAVg7o/7ZO0QDv4aQAag0g/3hJEf+GQ+kAU/61ALfscAEwQIP/8djz/0HB4gDO8WT+ZIam/+3KxQA3DVEAIHxm/yjksQB2tR8B56CG/3e7ygAAjjz/gCa9/6bJlgDPeBoBNrisAAzyzP6FQuYAIiYfAbhwUAAgM6X+v/M3ADpJkv6bp83/ZGiY/8X+z/+tE/cA7grKAO+X8gBeOyf/8B1m/wpcmv/lVNv/oYFQANBazAHw267/nmaRATWyTP80bKgBU95rANMkbQB2OjgACB0WAO2gxwCq0Z0AiUcvAI9WIADG8gIA1DCIAVysugDml2kBYL/lAIpQv/7w2IL/YisG/qjEMQD9ElsBkEl5AD2SJwE/aBj/uKVw/n7rYgBQ1WL/ezxX/1KM9QHfeK3/D8aGAc487wDn6lz/Ie4T/6VxjgGwdyYAoCum/u9baQBrPcIBGQREAA+LMwCkhGr/InQu/qhfxQCJ1BcASJw6AIlwRf6WaZr/7MmdABfUmv+IUuP+4jvd/1+VwABRdjT/ISvXAQ6TS/9ZnHn+DhJPAJPQiwGX2j7/nFgIAdK4Yv8Ur3v/ZlPlANxBdAGW+gT/XI7c/yL3Qv/M4bP+l1GXAEco7P+KPz4ABk/w/7e5tQB2MhsAP+PAAHtjOgEy4Jv/EeHf/tzgTf8OLHsBjYCvAPjUyACWO7f/k2EdAJbMtQD9JUcAkVV3AJrIugACgPn/Uxh8AA5XjwCoM/UBfJfn/9DwxQF8vrkAMDr2ABTp6AB9EmL/Df4f//Wxgv9sjiMAq33y/owMIv+loaIAzs1lAPcZIgFkkTkAJ0Y5AHbMy//yAKIApfQeAMZ04gCAb5n/jDa2ATx6D/+bOjkBNjLGAKvTHf9riqf/rWvH/22hwQBZSPL/znNZ//r+jv6xyl7/UVkyAAdpQv8Z/v/+y0AX/0/ebP8n+UsA8XwyAO+YhQDd8WkAk5diANWhef7yMYkA6SX5/iq3GwC4d+b/2SCj/9D75AGJPoP/T0AJ/l4wcQARijL+wf8WAPcSxQFDN2gAEM1f/zAlQgA3nD8BQFJK/8g1R/7vQ30AGuDeAN+JXf8e4Mr/CdyEAMYm6wFmjVYAPCtRAYgcGgDpJAj+z/KUAKSiPwAzLuD/cjBP/wmv4gDeA8H/L6Do//9daf4OKuYAGopSAdAr9AAbJyb/YtB//0CVtv8F+tEAuzwc/jEZ2v+pdM3/dxJ4AJx0k/+ENW3/DQrKAG5TpwCd24n/BgOC/zKnHv88ny//gYCd/l4DvQADpkQAU9/XAJZawgEPqEEA41Mz/82rQv82uzwBmGYt/3ea4QDw94gAZMWy/4tH3//MUhABKc4q/5zA3f/Ye/T/2tq5/7u67//8rKD/wzQWAJCutf67ZHP/006w/xsHwQCT1Wj/WskK/1B7QgEWIboAAQdj/h7OCgDl6gUANR7SAIoI3P5HN6cASOFWAXa+vAD+wWUBq/ms/16et/5dAmz/sF1M/0ljT/9KQIH+9i5BAGPxf/72l2b/LDXQ/jtm6gCar6T/WPIgAG8mAQD/tr7/c7AP/qk8gQB67fEAWkw/AD5KeP96w24AdwSyAN7y0gCCIS7+nCgpAKeScAExo2//ebDrAEzPDv8DGcYBKevVAFUk1gExXG3/yBge/qjswwCRJ3wB7MOVAFokuP9DVar/JiMa/oN8RP/vmyP/NsmkAMQWdf8xD80AGOAdAX5xkAB1FbYAy5+NAN+HTQCw5rD/vuXX/2Mltf8zFYr/Gb1Z/zEwpf6YLfcAqmzeAFDKBQAbRWf+zBaB/7T8Pv7SAVv/km7+/9uiHADf/NUBOwghAM4Q9ACB0zAAa6DQAHA70QBtTdj+IhW5//ZjOP+zixP/uR0y/1RZEwBK+mL/4SrI/8DZzf/SEKcAY4RfASvmOQD+C8v/Y7w//3fB+/5QaTYA6LW9AbdFcP/Qq6X/L220/3tTpQCSojT/mgsE/5fjWv+SiWH+Pekp/14qN/9spOwAmET+AAqMg/8Kak/+856JAEOyQv6xe8b/Dz4iAMVYKv+VX7H/mADG/5X+cf/hWqP/fdn3ABIR4ACAQnj+wBkJ/zLdzQAx1EYA6f+kAALRCQDdNNv+rOD0/144zgHyswL/H1ukAeYuiv+95twAOS89/28LnQCxW5gAHOZiAGFXfgDGWZH/p09rAPlNoAEd6eb/lhVW/jwLwQCXJST+uZbz/+TUUwGsl7QAyambAPQ86gCO6wQBQ9o8AMBxSwF088//QaybAFEenP9QSCH+Eudt/45rFf59GoT/sBA7/5bJOgDOqckA0HniACisDv+WPV7/ODmc/408kf8tbJX/7pGb/9FVH/7ADNIAY2Jd/pgQlwDhudwAjess/6CsFf5HGh//DUBd/hw4xgCxPvgBtgjxAKZllP9OUYX/gd7XAbypgf/oB2EAMXA8/9nl+wB3bIoAJxN7/oMx6wCEVJEAguaU/xlKuwAF9Tb/udvxARLC5P/xymYAaXHKAJvrTwAVCbL/nAHvAMiUPQBz99L/Md2HADq9CAEjLgkAUUEF/zSeuf99dC7/SowN/9JcrP6TF0cA2eD9/nNstP+ROjD+27EY/5z/PAGak/IA/YZXADVL5QAww97/H68y/5zSeP/QI97/EvizAQIKZf+dwvj/nsxl/2j+xf9PPgQAsqxlAWCS+/9BCpwAAoml/3QE5wDy1wEAEyMd/yuhTwA7lfYB+0KwAMghA/9Qbo7/w6ERAeQ4Qv97L5H+hASkAEOurAAZ/XIAV2FXAfrcVABgW8j/JX07ABNBdgChNPH/7awG/7C///8BQYL+377mAGX95/+SI20A+h1NATEAEwB7WpsBFlYg/9rVQQBvXX8APF2p/wh/tgARug7+/Yn2/9UZMP5M7gD/+FxG/2PgiwC4Cf8BB6TQAM2DxgFX1scAgtZfAN2V3gAXJqv+xW7VACtzjP7XsXYAYDRCAXWe7QAOQLb/Lj+u/55fvv/hzbH/KwWO/6xj1P/0u5MAHTOZ/+R0GP4eZc8AE/aW/4bnBQB9huIBTUFiAOyCIf8Fbj4ARWx//wdxFgCRFFP+wqHn/4O1PADZ0bH/5ZTU/gODuAB1sbsBHA4f/7BmUAAyVJf/fR82/xWdhf8Ts4sB4OgaACJ1qv+n/Kv/SY3O/oH6IwBIT+wB3OUU/ynKrf9jTO7/xhbg/2zGw/8kjWAB7J47/2pkVwBu4gIA4+reAJpdd/9KcKT/Q1sC/xWRIf9m1on/r+Zn/qP2pgBd93T+p+Ac/9wCOQGrzlQAe+QR/xt4dwB3C5MBtC/h/2jIuf6lAnIATU7UAC2asf8YxHn+Up22AFoQvgEMk8UAX++Y/wvrRwBWknf/rIbWADyDxACh4YEAH4J4/l/IMwBp59L/OgmU/yuo3f987Y4AxtMy/i71ZwCk+FQAmEbQ/7R1sQBGT7kA80ogAJWczwDFxKEB9TXvAA9d9v6L8DH/xFgk/6ImewCAyJ0Brkxn/62pIv7YAav/cjMRAIjkwgBuljj+avafABO4T/+WTfD/m1CiAAA1qf8dl1YARF4QAFwHbv5idZX/+U3m//0KjADWfFz+I3brAFkwOQEWNaYAuJA9/7P/wgDW+D3+O272AHkVUf6mA+QAakAa/0Xohv/y3DX+LtxVAHGV9/9hs2f/vn8LAIfRtgBfNIEBqpDO/3rIzP+oZJIAPJCV/kY8KAB6NLH/9tNl/67tCAAHM3gAEx+tAH7vnP+PvcsAxIBY/+mF4v8efa3/yWwyAHtkO//+owMB3ZS1/9aIOf7etIn/z1g2/xwh+/9D1jQB0tBkAFGqXgCRKDUA4G/n/iMc9P/ix8P+7hHmANnZpP6pnd0A2i6iAcfPo/9sc6IBDmC7/3Y8TAC4n5gA0edH/iqkuv+6mTP+3au2/6KOrQDrL8EAB4sQAV+kQP8Q3aYA28UQAIQdLP9kRXX/POtY/ihRrQBHvj3/u1idAOcLFwDtdaQA4ajf/5pydP+jmPIBGCCqAH1icf6oE0wAEZ3c/ps0BQATb6H/R1r8/61u8AAKxnn//f/w/0J70gDdwtf+eaMR/+EHYwC+MbYAcwmFAegaiv/VRIQALHd6/7NiMwCVWmoARzLm/wqZdv+xRhkApVfNADeK6gDuHmEAcZvPAGKZfwAia9v+dXKs/0y0//7yObP/3SKs/jiiMf9TA///cd29/7wZ5P4QWFn/RxzG/hYRlf/zef7/a8pj/wnODgHcL5kAa4knAWExwv+VM8X+ujoL/2sr6AHIBg7/tYVB/t3kq/97PucB4+qz/yK91P70u/kAvg1QAYJZAQDfha0ACd7G/0J/SgCn2F3/m6jGAUKRAABEZi4BrFqaANiAS/+gKDMAnhEbAXzwMQDsyrD/l3zA/ybBvgBftj0Ao5N8//+lM/8cKBH+12BOAFaR2v4fJMr/VgkFAG8pyP/tbGEAOT4sAHW4DwEt8XQAmAHc/52lvAD6D4MBPCx9/0Hc+/9LMrgANVqA/+dQwv+IgX8BFRK7/y06of9HkyIArvkL/iONHQDvRLH/c246AO6+sQFX9ab/vjH3/5JTuP+tDif/ktdoAI7feACVyJv/1M+RARC12QCtIFf//yO1AHffoQHI317/Rga6/8BDVf8yqZgAkBp7/zjzs/4URIgAJ4y8/v3QBf/Ic4cBK6zl/5xouwCX+6cANIcXAJeZSACTxWv+lJ4F/+6PzgB+mYn/WJjF/gdEpwD8n6X/7042/xg/N/8m3l4A7bcM/87M0gATJ/b+HkrnAIdsHQGzcwAAdXZ0AYQG/P+RgaEBaUONAFIl4v/u4uT/zNaB/qJ7ZP+5eeoALWznAEIIOP+EiIAArOBC/q+dvADm3+L+8ttFALgOdwFSojgAcnsUAKJnVf8x72P+nIfXAG//p/4nxNYAkCZPAfmofQCbYZz/FzTb/5YWkAAslaX/KH+3AMRN6f92gdL/qofm/9Z3xgDp8CMA/TQH/3VmMP8VzJr/s4ix/xcCAwGVgln//BGfAUY8GgCQaxEAtL48/zi2O/9uRzb/xhKB/5XgV//fFZj/iha2//qczQDsLdD/T5TyAWVG0QBnTq4AZZCs/5iI7QG/wogAcVB9AZgEjQCbljX/xHT1AO9ySf4TUhH/fH3q/yg0vwAq0p7/m4SlALIFKgFAXCj/JFVN/7LkdgCJQmD+c+JCAG7wRf6Xb1AAp67s/+Nsa/+88kH/t1H/ADnOtf8vIrX/1fCeAUdLXwCcKBj/ZtJRAKvH5P+aIikA469LABXvwwCK5V8BTMAxAHV7VwHj4YIAfT4//wLGqwD+JA3+kbrOAJT/9P8jAKYAHpbbAVzk1ABcxjz+PoXI/8kpOwB97m3/tKPuAYx6UgAJFlj/xZ0v/5leOQBYHrYAVKFVALKSfACmpgf/FdDfAJy28gCbebkAU5yu/poQdv+6U+gB3zp5/x0XWAAjfX//qgWV/qQMgv+bxB0AoWCIAAcjHQGiJfsAAy7y/wDZvAA5ruIBzukCADm7iP57vQn/yXV//7okzADnGdgAUE5pABOGgf+Uy0QAjVF9/vilyP/WkIcAlzem/ybrWwAVLpoA3/6W/yOZtP99sB0BK2Ie/9h65v/poAwAObkM/vBxB/8FCRD+GltsAG3GywAIkygAgYbk/3y6KP9yYoT+poQXAGNFLAAJ8u7/uDU7AISBZv80IPP+k9/I/3tTs/6HkMn/jSU4AZc84/9aSZwBy6y7AFCXL/9eief/JL87/+HRtf9K19X+Bnaz/5k2wQEyAOcAaJ1IAYzjmv+24hD+YOFc/3MUqv4G+k4A+Eut/zVZBv8AtHYASK0BAEAIzgGuhd8AuT6F/9YLYgDFH9AAq6f0/xbntQGW2rkA96lhAaWL9/8veJUBZ/gzADxFHP4Zs8QAfAfa/jprUQC46Zz//EokAHa8QwCNXzX/3l6l/i49NQDOO3P/L+z6/0oFIAGBmu7/aiDiAHm7Pf8DpvH+Q6qs/x3Ysv8XyfwA/W7zAMh9OQBtwGD/NHPuACZ58//JOCEAwnaCAEtgGf+qHub+Jz/9ACQt+v/7Ae8AoNRcAS3R7QDzIVf+7VTJ/9QSnf7UY3//2WIQ/ous7wCoyYL/j8Gp/+6XwQHXaCkA7z2l/gID8gAWy7H+scwWAJWB1f4fCyn/AJ95/qAZcv+iUMgAnZcLAJqGTgHYNvwAMGeFAGncxQD9qE3+NbMXABh58AH/LmD/azyH/mLN+f8/+Xf/eDvT/3K0N/5bVe0AldRNAThJMQBWxpYAXdGgAEXNtv/0WisAFCSwAHp03QAzpycB5wE//w3FhgAD0SL/hzvKAKdkTgAv30wAuTw+ALKmewGEDKH/Pa4rAMNFkAB/L78BIixOADnqNAH/Fij/9l6SAFPkgAA8TuD/AGDS/5mv7ACfFUkAtHPE/oPhagD/p4YAnwhw/3hEwv+wxMb/djCo/12pAQBwyGYBShj+ABONBP6OPj8Ag7O7/02cm/93VqQAqtCS/9CFmv+Umzr/onjo/vzVmwDxDSoAXjKDALOqcACMU5f/N3dUAYwj7/+ZLUMB7K8nADaXZ/+eKkH/xO+H/lY1ywCVYS/+2CMR/0YDRgFnJFr/KBqtALgwDQCj29n/UQYB/92qbP7p0F0AZMn5/lYkI//Rmh4B48n7/wK9p/5kOQMADYApAMVkSwCWzOv/ka47AHj4lf9VN+EActI1/sfMdwAO90oBP/uBAENolwGHglAAT1k3/3Xmnf8ZYI8A1ZEFAEXxeAGV81//cioUAINIAgCaNRT/ST5tAMRmmAApDMz/eiYLAfoKkQDPfZQA9vTe/ykgVQFw1X4AovlWAUfGf/9RCRUBYicE/8xHLQFLb4kA6jvnACAwX//MH3IBHcS1/zPxp/5dbY4AaJAtAOsMtf80cKQATP7K/64OogA965P/K0C5/ul92QDzWKf+SjEIAJzMQgB81nsAJt12AZJw7AByYrEAl1nHAFfFcAC5laEALGClAPizFP+829j+KD4NAPOOjQDl487/rMoj/3Ww4f9SbiYBKvUO/xRTYQAxqwoA8nd4ABnoPQDU8JP/BHM4/5ER7/7KEfv/+RL1/2N17wC4BLP/9u0z/yXvif+mcKb/Ubwh/7n6jv82u60A0HDJAPYr5AFouFj/1DTE/zN1bP/+dZsALlsP/1cOkP9X48wAUxpTAZ9M4wCfG9UBGJdsAHWQs/6J0VIAJp8KAHOFyQDftpwBbsRd/zk86QAFp2n/msWkAGAiuv+ThSUB3GO+AAGnVP8UkasAwsX7/l9Ohf/8+PP/4V2D/7uGxP/YmaoAFHae/owBdgBWng8BLdMp/5MBZP5xdEz/039sAWcPMADBEGYBRTNf/2uAnQCJq+kAWnyQAWqhtgCvTOwByI2s/6M6aADptDT/8P0O/6Jx/v8m74r+NC6mAPFlIf6DupwAb9A+/3xeoP8frP4AcK44/7xjG/9DivsAfTqAAZyYrv+yDPf//FSeAFLFDv6syFP/JScuAWrPpwAYvSIAg7KQAM7VBACh4tIASDNp/2Etu/9OuN//sB37AE+gVv90JbIAUk3VAVJUjf/iZdQBr1jH//Ve9wGsdm3/prm+AIO1eABX/l3/hvBJ/yD1j/+Lomf/s2IS/tnMcACT33j/NQrzAKaMlgB9UMj/Dm3b/1vaAf/8/C/+bZx0/3MxfwHMV9P/lMrZ/xpV+f8O9YYBTFmp//It5gA7Yqz/ckmE/k6bMf+eflQAMa8r/xC2VP+dZyMAaMFt/0PdmgDJrAH+CKJYAKUBHf99m+X/HprcAWfvXADcAW3/ysYBAF4CjgEkNiwA6+Ke/6r71v+5TQkAYUryANujlf/wI3b/33JY/sDHAwBqJRj/yaF2/2FZYwHgOmf/ZceT/t48YwDqGTsBNIcbAGYDW/6o2OsA5eiIAGg8gQAuqO4AJ79DAEujLwCPYWL/ONioAajp/P8jbxb/XFQrABrIVwFb/ZgAyjhGAI4ITQBQCq8B/MdMABZuUv+BAcIAC4A9AVcOkf/93r4BD0iuAFWjVv46Yyz/LRi8/hrNDwAT5dL++EPDAGNHuACaxyX/l/N5/yYzS//JVYL+LEH6ADmT8/6SKzv/WRw1ACFUGP+zMxL+vUZTAAucswFihncAnm9vAHeaSf/IP4z+LQ0N/5rAAv5RSCoALqC5/ixwBgCS15UBGrBoAEQcVwHsMpn/s4D6/s7Bv/+mXIn+NSjvANIBzP6orSMAjfMtASQybf8P8sL/4596/7Cvyv5GOUgAKN84ANCiOv+3Yl0AD28MAB4ITP+Ef/b/LfJnAEW1D/8K0R4AA7N5APHo2gF7x1j/AtLKAbyCUf9eZdABZyQtAEzBGAFfGvH/paK7ACRyjADKQgX/JTiTAJgL8wF/Vej/+ofUAbmxcQBa3Ev/RfiSADJvMgBcFlAA9CRz/qNkUv8ZwQYBfz0kAP1DHv5B7Kr/oRHX/j+vjAA3fwQAT3DpAG2gKACPUwf/QRru/9mpjP9OXr3/AJO+/5NHuv5qTX//6Z3pAYdX7f/QDewBm20k/7Rk2gC0oxIAvm4JARE/e/+ziLT/pXt7/5C8Uf5H8Gz/GXAL/+PaM/+nMur/ck9s/x8Tc/+38GMA41eP/0jZ+P9mqV8BgZWVAO6FDAHjzCMA0HMaAWYI6gBwWI8BkPkOAPCerP5kcHcAwo2Z/ig4U/95sC4AKjVM/56/mgBb0VwArQ0QAQVI4v/M/pUAULjPAGQJev52Zav//MsA/qDPNgA4SPkBOIwN/wpAa/5bZTT/4bX4AYv/hADmkREA6TgXAHcB8f/VqZf/Y2MJ/rkPv/+tZ20Brg37/7JYB/4bO0T/CiEC//hhOwAaHpIBsJMKAF95zwG8WBgAuV7+/nM3yQAYMkYAeDUGAI5CkgDk4vn/aMDeAa1E2wCiuCT/j2aJ/50LFwB9LWIA613h/jhwoP9GdPMBmfk3/4EnEQHxUPQAV0UVAV7kSf9OQkH/wuPnAD2SV/+tmxf/cHTb/tgmC/+DuoUAXtS7AGQvWwDM/q//3hLX/q1EbP/j5E//Jt3VAKPjlv4fvhIAoLMLAQpaXv/crlgAo9Pl/8eINACCX93/jLzn/otxgP91q+z+MdwU/zsUq//kbbwAFOEg/sMQrgDj/ogBhydpAJZNzv/S7uIAN9SE/u85fACqwl3/+RD3/xiXPv8KlwoAT4uy/3jyygAa29UAPn0j/5ACbP/mIVP/US3YAeA+EQDW2X0AYpmZ/7Owav6DXYr/bT4k/7J5IP94/EYA3PglAMxYZwGA3Pv/7OMHAWoxxv88OGsAY3LuANzMXgFJuwEAWZoiAE7Zpf8Ow/n/Ceb9/82H9QAa/Af/VM0bAYYCcAAlniAA51vt/7+qzP+YB94AbcAxAMGmkv/oE7X/aY40/2cQGwH9yKUAw9kE/zS9kP97m6D+V4I2/054Pf8OOCkAGSl9/1eo9QDWpUYA1KkG/9vTwv5IXaT/xSFn/yuOjQCD4awA9GkcAERE4QCIVA3/gjko/otNOABUljUANl+dAJANsf5fc7oAdRd2//Sm8f8LuocAsmrL/2HaXQAr/S0ApJgEAIt27wBgARj+65nT/6huFP8y77AAcinoAMH6NQD+oG/+iHop/2FsQwDXmBf/jNHUACq9owDKKjL/amq9/75E2f/pOnUA5dzzAcUDBAAleDb+BJyG/yQ9q/6liGT/1OgOAFquCgDYxkH/DANAAHRxc//4ZwgA530S/6AcxQAeuCMB30n5/3sULv6HOCX/rQ3lAXehIv/1PUkAzX1wAIlohgDZ9h7/7Y6PAEGfZv9spL4A23Wt/yIleP7IRVAAH3za/koboP+6msf/R8f8AGhRnwERyCcA0z3AARruWwCU2QwAO1vV/wtRt/+B5nr/csuRAXe0Qv9IirQA4JVqAHdSaP/QjCsAYgm2/81lhv8SZSYAX8Wm/8vxkwA+0JH/hfb7AAKpDgAN97gAjgf+ACTIF/9Yzd8AW4E0/xW6HgCP5NIB9+r4/+ZFH/6wuof/7s00AYtPKwARsNn+IPNDAPJv6QAsIwn/43JRAQRHDP8mab8AB3Uy/1FPEAA/REH/nSRu/03xA//iLfsBjhnOAHh70QEc/u7/BYB+/1ve1/+iD78AVvBJAIe5Uf4s8aMA1NvS/3CimwDPZXYAqEg4/8QFNABIrPL/fhad/5JgO/+ieZj+jBBfAMP+yP5SlqIAdyuR/sysTv+m4J8AaBPt//V+0P/iO9UAddnFAJhI7QDcHxf+Dlrn/7zUQAE8Zfb/VRhWAAGxbQCSUyABS7bAAHfx4AC57Rv/uGVSAeslTf/9hhMA6PZ6ADxqswDDCwwAbULrAX1xOwA9KKQAr2jwAAIvu/8yDI0Awou1/4f6aABhXN7/2ZXJ/8vxdv9Pl0MAeo7a/5X17wCKKsj+UCVh/3xwp/8kilf/gh2T//FXTv/MYRMBsdEW//fjf/5jd1P/1BnGARCzswCRTaz+WZkO/9q9pwBr6Tv/IyHz/ixwcP+hf08BzK8KACgViv5odOQAx1+J/4W+qP+SpeoBt2MnALfcNv7/3oUAott5/j/vBgDhZjb/+xL2AAQigQGHJIMAzjI7AQ9htwCr2If/ZZgr/5b7WwAmkV8AIswm/rKMU/8ZgfP/TJAlAGokGv52kKz/RLrl/2uh1f8uo0T/lar9ALsRDwDaoKX/qyP2AWANEwCly3UA1mvA//R7sQFkA2gAsvJh//tMgv/TTSoB+k9G/z/0UAFpZfYAPYg6Ae5b1QAOO2L/p1RNABGELv45r8X/uT64AExAzwCsr9D+r0olAIob0/6UfcIACllRAKjLZf8r1dEB6/U2AB4j4v8JfkYA4n1e/px1FP85+HAB5jBA/6RcpgHg1ub/JHiPADcIK//7AfUBamKlAEprav41BDb/WrKWAQN4e//0BVkBcvo9//6ZUgFNDxEAOe5aAV/f5gDsNC/+Z5Sk/3nPJAESELn/SxRKALsLZQAuMIH/Fu/S/03sgf9vTcz/PUhh/8fZ+/8q18wAhZHJ/znmkgHrZMYAkkkj/mzGFP+2T9L/UmeIAPZssAAiETz/E0py/qiqTv+d7xT/lSmoADp5HABPs4b/53mH/67RYv/zer4Aq6bNANR0MAAdbEL/ot62AQ53FQDVJ/n//t/k/7elxgCFvjAAfNBt/3evVf8J0XkBMKu9/8NHhgGI2zP/tluN/jGfSAAjdvX/cLrj/zuJHwCJLKMAcmc8/gjVlgCiCnH/wmhIANyDdP+yT1wAy/rV/l3Bvf+C/yL+1LyXAIgRFP8UZVP/1M6mAOXuSf+XSgP/qFfXAJu8hf+mgUkA8E+F/7LTUf/LSKP+wailAA6kx/4e/8wAQUhbAaZKZv/IKgD/wnHj/0IX0ADl2GT/GO8aAArpPv97CrIBGiSu/3fbxwEto74AEKgqAKY5xv8cGhoAfqXnAPtsZP895Xn/OnaKAEzPEQANInD+WRCoACXQaf8jydf/KGpl/gbvcgAoZ+L+9n9u/z+nOgCE8I4ABZ5Y/4FJnv9eWZIA5jaSAAgtrQBPqQEAc7r3AFRAgwBD4P3/z71AAJocUQEtuDb/V9Tg/wBgSf+BIesBNEJQ//uum/8EsyUA6qRd/l2v/QDGRVf/4GouAGMd0gA+vHL/LOoIAKmv9/8XbYn/5bYnAMClXv71ZdkAv1hgAMReY/9q7gv+NX7zAF4BZf8ukwIAyXx8/40M2gANpp0BMPvt/5v6fP9qlJL/tg3KABw9pwDZmAj+3IIt/8jm/wE3QVf/Xb9h/nL7DgAgaVwBGs+NABjPDf4VMjD/upR0/9Mr4QAlIqL+pNIq/0QXYP+21gj/9XWJ/0LDMgBLDFP+UIykAAmlJAHkbuMA8RFaARk01AAG3wz/i/M5AAxxSwH2t7//1b9F/+YPjgABw8T/iqsv/0A/agEQqdb/z644AVhJhf+2hYwAsQ4Z/5O4Nf8K46H/eNj0/0lN6QCd7osBO0HpAEb72AEpuJn/IMtwAJKT/QBXZW0BLFKF//SWNf9emOj/O10n/1iT3P9OUQ0BIC/8/6ATcv9dayf/dhDTAbl30f/j23/+WGns/6JuF/8kpm7/W+zd/0LqdABvE/T+CukaACC3Bv4Cv/IA2pw1/ik8Rv+o7G8Aebl+/+6Oz/83fjQA3IHQ/lDMpP9DF5D+2ihs/3/KpADLIQP/Ap4AACVgvP/AMUoAbQQAAG+nCv5b2of/y0Kt/5bC4gDJ/Qb/rmZ5AM2/bgA1wgQAUSgt/iNmj/8MbMb/EBvo//xHugGwbnIAjgN1AXFNjgATnMUBXC/8ADXoFgE2EusALiO9/+zUgQACYND+yO7H/zuvpP+SK+cAwtk0/wPfDACKNrL+VevPAOjPIgAxNDL/pnFZ/wot2P8+rRwAb6X2AHZzW/+AVDwAp5DLAFcN8wAWHuQBsXGS/4Gq5v78mYH/keErAEbnBf96aX7+VvaU/24lmv7RA1sARJE+AOQQpf833fn+stJbAFOS4v5FkroAXdJo/hAZrQDnuiYAvXqM//sNcP9pbl0A+0iqAMAX3/8YA8oB4V3kAJmTx/5tqhYA+GX2/7J8DP+y/mb+NwRBAH3WtAC3YJMALXUX/oS/+QCPsMv+iLc2/5LqsQCSZVb/LHuPASHRmADAWin+Uw99/9WsUgDXqZAAEA0iACDRZP9UEvkBxRHs/9m65gAxoLD/b3Zh/+1o6wBPO1z+RfkL/yOsSgETdkQA3nyl/7RCI/9WrvYAK0pv/36QVv/k6lsA8tUY/kUs6//ctCMACPgH/2YvXP/wzWb/cearAR+5yf/C9kb/ehG7AIZGx/+VA5b/dT9nAEFoe//UNhMBBo1YAFOG8/+INWcAqRu0ALExGABvNqcAwz3X/x8BbAE8KkYAuQOi/8KVKP/2fyb+vncm/z13CAFgodv/KsvdAbHypP/1nwoAdMQAAAVdzf6Af7MAfe32/5Wi2f9XJRT+jO7AAAkJwQBhAeIAHSYKAACIP//lSNL+JoZc/07a0AFoJFT/DAXB//KvPf+/qS4Bs5OT/3G+i/59rB8AA0v8/tckDwDBGxgB/0WV/26BdgDLXfkAiolA/iZGBgCZdN4AoUp7AMFjT/92O17/PQwrAZKxnQAuk78AEP8mAAszHwE8OmL/b8JNAZpb9ACMKJABrQr7AMvRMv5sgk4A5LRaAK4H+gAfrjwAKaseAHRjUv92wYv/u63G/tpvOAC5e9gA+Z40ADS0Xf/JCVv/OC2m/oSby/866G4ANNNZ//0AogEJV7cAkYgsAV569QBVvKsBk1zGAAAIaAAeX64A3eY0Aff36/+JrjX/IxXM/0fj1gHoUsIACzDj/6pJuP/G+/z+LHAiAINlg/9IqLsAhId9/4poYf/uuKj/82hU/4fY4v+LkO0AvImWAVA4jP9Wqaf/wk4Z/9wRtP8RDcEAdYnU/43glwAx9K8AwWOv/xNjmgH/QT7/nNI3//L0A//6DpUAnljZ/53Phv776BwALpz7/6s4uP/vM+oAjoqD/xn+8wEKycIAP2FLANLvogDAyB8BddbzABhH3v42KOj/TLdv/pAOV//WT4j/2MTUAIQbjP6DBf0AfGwT/xzXSwBM3jf+6bY/AESrv/40b97/CmlN/1Cq6wCPGFj/Led5AJSB4AE99lQA/S7b/+9MIQAxlBL+5iVFAEOGFv6Om14AH53T/tUqHv8E5Pf+/LAN/ycAH/7x9P//qi0K/v3e+QDecoQA/y8G/7SjswFUXpf/WdFS/uU0qf/V7AAB1jjk/4d3l/9wycEAU6A1/gaXQgASohEA6WFbAIMFTgG1eDX/dV8//+11uQC/foj/kHfpALc5YQEvybv/p6V3AS1kfgAVYgb+kZZf/3g2mADRYmgAj28e/riU+QDr2C4A+MqU/zlfFgDy4aMA6ffo/0erE/9n9DH/VGdd/0R59AFS4A0AKU8r//nOp//XNBX+wCAW//dvPABlSib/FltU/h0cDf/G59f+9JrIAN+J7QDThA4AX0DO/xE+9//pg3kBXRdNAM3MNP5RvYgAtNuKAY8SXgDMK4z+vK/bAG9ij/+XP6L/0zJH/hOSNQCSLVP+slLu/xCFVP/ixl3/yWEU/3h2I/9yMuf/ouWc/9MaDAByJ3P/ztSGAMXZoP90gV7+x9fb/0vf+QH9dLX/6Ndo/+SC9v+5dVYADgUIAO8dPQHtV4X/fZKJ/syo3wAuqPUAmmkWANzUof9rRRj/idq1//FUxv+CetP/jQiZ/76xdgBgWbIA/xAw/npgaf91Nuj/In5p/8xDpgDoNIr/05MMABk2BwAsD9f+M+wtAL5EgQFqk+EAHF0t/uyND/8RPaEA3HPAAOyRGP5vqKkA4Do//3+kvABS6ksB4J6GANFEbgHZptkARuGmAbvBj/8QB1j/Cs2MAHXAnAEROCYAG3xsAavXN/9f/dQAm4eo//aymf6aREoA6D1g/mmEOwAhTMcBvbCC/wloGf5Lxmb/6QFwAGzcFP9y5kYAjMKF/zmepP6SBlD/qcRhAVW3ggBGnt4BO+3q/2AZGv/or2H/C3n4/lgjwgDbtPz+SgjjAMPjSQG4bqH/MemkAYA1LwBSDnn/wb46ADCudf+EFyAAKAqGARYzGf/wC7D/bjmSAHWP7wGdZXb/NlRMAM24Ev8vBEj/TnBV/8EyQgFdEDT/CGmGAAxtSP86nPsAkCPMACygdf4ya8IAAUSl/29uogCeUyj+TNbqADrYzf+rYJP/KONyAbDj8QBG+bcBiFSL/zx69/6PCXX/sa6J/kn3jwDsuX7/Phn3/y1AOP+h9AYAIjk4AWnKUwCAk9AABmcK/0qKQf9hUGT/1q4h/zKGSv9ul4L+b1SsAFTHS/74O3D/CNiyAQm3XwDuGwj+qs3cAMPlhwBiTO3/4lsaAVLbJ//hvscB2ch5/1GzCP+MQc4Ass9X/vr8Lv9oWW4B/b2e/5DWnv+g9Tb/NbdcARXIwv+SIXEB0QH/AOtqK/+nNOgAneXdADMeGQD63RsBQZNX/097xABBxN//TCwRAVXxRADKt/n/QdTU/wkhmgFHO1AAr8I7/41ICQBkoPQA5tA4ADsZS/5QwsIAEgPI/qCfcwCEj/cBb105/zrtCwGG3of/eqNsAXsrvv/7vc7+ULZI/9D24AERPAkAoc8mAI1tWwDYD9P/iE5uAGKjaP8VUHn/rbK3AX+PBABoPFL+1hAN/2DuIQGelOb/f4E+/zP/0v8+jez+nTfg/3In9ADAvPr/5Ew1AGJUUf+tyz3+kzI3/8zrvwA0xfQAWCvT/hu/dwC855oAQlGhAFzBoAH643gAezfiALgRSACFqAr+Foec/ykZZ/8wyjoAupVR/7yG7wDrtb3+2Yu8/0owUgAu2uUAvf37ADLlDP/Tjb8BgPQZ/6nnev5WL73/hLcX/yWylv8zif0AyE4fABZpMgCCPAAAhKNb/hfnuwDAT+8AnWak/8BSFAEYtWf/8AnqAAF7pP+F6QD/yvLyADy69QDxEMf/4HSe/r99W//gVs8AeSXn/+MJxv8Pme//eejZ/ktwUgBfDDn+M9Zp/5TcYQHHYiQAnNEM/grUNADZtDf+1Kro/9gUVP+d+ocAnWN//gHOKQCVJEYBNsTJ/1d0AP7rq5YAG6PqAMqHtADQXwD+e5xdALc+SwCJ67YAzOH//9aL0v8Ccwj/HQxvADScAQD9Ffv/JaUf/gyC0wBqEjX+KmOaAA7ZPf7YC1z/yMVw/pMmxwAk/Hj+a6lNAAF7n//PS2YAo6/EACwB8AB4urD+DWJM/+188f/okrz/yGDgAMwfKQDQyA0AFeFg/6+cxAD30H4APrj0/gKrUQBVc54ANkAt/xOKcgCHR80A4y+TAdrnQgD90RwA9A+t/wYPdv4QltD/uRYy/1Zwz/9LcdcBP5Ir/wThE/7jFz7/Dv/W/i0Izf9XxZf+0lLX//X49/+A+EYA4fdXAFp4RgDV9VwADYXiAC+1BQFco2n/Bh6F/uiyPf/mlRj/EjGeAORkPf508/v/TUtcAVHbk/9Mo/7+jdX2AOglmP5hLGQAySUyAdT0OQCuq7f/+UpwAKacHgDe3WH/811J/vtlZP/Y2V3//oq7/46+NP87y7H/yF40AHNynv+lmGgBfmPi/3ad9AFryBAAwVrlAHkGWACcIF3+ffHT/w7tnf+lmhX/uOAW//oYmP9xTR8A96sX/+2xzP80iZH/wrZyAODqlQAKb2cByYEEAO6OTgA0Bij/btWl/jzP/QA+10UAYGEA/zEtygB4eRb/64swAcYtIv+2MhsBg9Jb/y42gACve2n/xo1O/kP07//1Nmf+Tiby/wJc+f77rlf/iz+QABhsG/8iZhIBIhaYAELldv4yj2MAkKmVAXYemACyCHkBCJ8SAFpl5v+BHXcARCQLAei3NwAX/2D/oSnB/z+L3gAPs/MA/2QP/1I1hwCJOZUBY/Cq/xbm5P4xtFL/PVIrAG712QDHfT0ALv00AI3F2wDTn8EAN3lp/rcUgQCpd6r/y7KL/4cotv+sDcr/QbKUAAjPKwB6NX8BSqEwAOPWgP5WC/P/ZFYHAfVEhv89KxUBmFRe/748+v7vduj/1oglAXFMa/9daGQBkM4X/26WmgHkZ7kA2jEy/odNi/+5AU4AAKGU/2Ed6f/PlJX/oKgAAFuAq/8GHBP+C2/3ACe7lv+K6JUAdT5E/z/YvP/r6iD+HTmg/xkM8QGpPL8AIION/+2fe/9exV7+dP4D/1yzYf55YVz/qnAOABWV+AD44wMAUGBtAEvASgEMWuL/oWpEAdByf/9yKv/+ShpK//ezlv55jDwAk0bI/9Yoof+hvMn/jUGH//Jz/AA+L8oAtJX//oI37QClEbr/CqnCAJxt2v9wjHv/aIDf/rGObP95Jdv/gE0S/29sFwFbwEsArvUW/wTsPv8rQJkB463+AO16hAF/Wbr/jlKA/vxUrgBas7EB89ZX/2c8ov/Qgg7/C4KLAM6B2/9e2Z3/7+bm/3Rzn/6ka18AM9oCAdh9xv+MyoD+C19E/zcJXf6umQb/zKxgAEWgbgDVJjH+G1DVAHZ9cgBGRkP/D45J/4N6uf/zFDL+gu0oANKfjAHFl0H/VJlCAMN+WgAQ7uwBdrtm/wMYhf+7ReYAOMVcAdVFXv9QiuUBzgfmAN5v5gFb6Xf/CVkHAQJiAQCUSoX/M/a0/+SxcAE6vWz/wsvt/hXRwwCTCiMBVp3iAB+ji/44B0v/Plp0ALU8qQCKotT+UacfAM1acP8hcOMAU5d1AbHgSf+ukNn/5sxP/xZN6P9yTuoA4Dl+/gkxjQDyk6UBaLaM/6eEDAF7RH8A4VcnAftsCADGwY8BeYfP/6wWRgAyRHT/Za8o//hp6QCmywcAbsXaANf+Gv6o4v0AH49gAAtnKQC3gcv+ZPdK/9V+hADSkywAx+obAZQvtQCbW54BNmmv/wJOkf5mml8AgM9//jR87P+CVEcA3fPTAJiqzwDeascAt1Re/lzIOP+KtnMBjmCSAIWI5ABhEpYAN/tCAIxmBADKZ5cAHhP4/zO4zwDKxlkAN8Xh/qlf+f9CQUT/vOp+AKbfZAFw7/QAkBfCADontgD0LBj+r0Sz/5h2mgGwooIA2XLM/q1+Tv8h3h7/JAJb/wKP8wAJ69cAA6uXARjX9f+oL6T+8ZLPAEWBtABE83EAkDVI/vstDgAXbqgARERP/25GX/6uW5D/Ic5f/4kpB/8Tu5n+I/9w/wmRuf4ynSUAC3AxAWYIvv/q86kBPFUXAEonvQB0Me8ArdXSAC6hbP+fliUAxHi5/yJiBv+Zwz7/YeZH/2Y9TAAa1Oz/pGEQAMY7kgCjF8QAOBg9ALViwQD7k+X/Yr0Y/y42zv/qUvYAt2cmAW0+zAAK8OAAkhZ1/46aeABF1CMA0GN2AXn/A/9IBsIAdRHF/30PFwCaT5kA1l7F/7k3k/8+/k7+f1KZAG5mP/9sUqH/abvUAVCKJwA8/13/SAy6ANL7HwG+p5D/5CwT/oBD6ADW+Wv+iJFW/4QusAC9u+P/0BaMANnTdAAyUbr+i/ofAB5AxgGHm2QAoM4X/rui0/8QvD8A/tAxAFVUvwDxwPL/mX6RAeqiov/mYdgBQId+AL6U3wE0ACv/HCe9AUCI7gCvxLkAYuLV/3+f9AHirzwAoOmOAbTzz/9FmFkBH2UVAJAZpP6Lv9EAWxl5ACCTBQAnunv/P3Pm/12nxv+P1dz/s5wT/xlCegDWoNn/Ai0+/2pPkv4ziWP/V2Tn/6+R6P9luAH/rgl9AFIloQEkco3/MN6O//W6mgAFrt3+P3Kb/4c3oAFQH4cAfvqzAezaLQAUHJEBEJNJAPm9hAERvcD/347G/0gUD//6Ne3+DwsSABvTcf7Vazj/rpOS/2B+MAAXwW0BJaJeAMed+f4YgLv/zTGy/l2kKv8rd+sBWLft/9rSAf9r/ioA5gpj/6IA4gDb7VsAgbLLANAyX/7O0F//979Z/m7qT/+lPfMAFHpw//b2uf5nBHsA6WPmAdtb/P/H3hb/s/Xp/9Px6gBv+sD/VVSIAGU6Mv+DrZz+dy0z/3bpEP7yWtYAXp/bAQMD6v9iTFz+UDbmAAXk5/41GN//cTh2ARSEAf+r0uwAOPGe/7pzE/8I5a4AMCwAAXJypv8GSeL/zVn0AInjSwH4rTgASnj2/ncDC/9ReMb/iHpi/5Lx3QFtwk7/3/FGAdbIqf9hvi//L2eu/2NcSP526bT/wSPp/hrlIP/e/MYAzCtH/8dUrACGZr4Ab+5h/uYo5gDjzUD+yAzhAKYZ3gBxRTP/j58YAKe4SgAd4HT+ntDpAMF0fv/UC4X/FjqMAcwkM//oHisA60a1/0A4kv6pElT/4gEN/8gysP801fX+qNFhAL9HNwAiTpwA6JA6AblKvQC6jpX+QEV//6HLk/+wl78AiOfL/qO2iQChfvv+6SBCAETPQgAeHCUAXXJgAf5c9/8sq0UAyncL/7x2MgH/U4j/R1IaAEbjAgAg63kBtSmaAEeG5f7K/yQAKZgFAJo/Sf8itnwAed2W/xrM1QEprFcAWp2S/22CFABHa8j/82a9AAHDkf4uWHUACM7jAL9u/f9tgBT+hlUz/4mxcAHYIhb/gxDQ/3mVqgByExcBplAf/3HwegDos/oARG60/tKqdwDfbKT/z0/p/xvl4v7RYlH/T0QHAIO5ZACqHaL/EaJr/zkVCwFkyLX/f0GmAaWGzABop6gAAaRPAJKHOwFGMoD/ZncN/uMGhwCijrP/oGTeABvg2wGeXcP/6o2JABAYff/uzi//YRFi/3RuDP9gc00AW+Po//j+T/9c5Qb+WMaLAM5LgQD6Tc7/jfR7AYpF3AAglwYBg6cW/+1Ep/7HvZYAo6uK/zO8Bv9fHYn+lOKzALVr0P+GH1L/l2Ut/4HK4QDgSJMAMIqX/8NAzv7t2p4Aah2J/v296f9nDxH/wmH/ALItqf7G4ZsAJzB1/4dqcwBhJrUAli9B/1OC5f72JoEAXO+a/ltjfwChbyH/7tny/4O5w//Vv57/KZbaAISpgwBZVPwBq0aA/6P4y/4BMrT/fExVAftvUABjQu//mu22/91+hf5KzGP/QZN3/2M4p/9P+JX/dJvk/+0rDv5FiQv/FvrxAVt6j//N+fMA1Bo8/zC2sAEwF7//y3mY/i1K1f8+WhL+9aPm/7lqdP9TI58ADCEC/1AiPgAQV67/rWVVAMokUf6gRcz/QOG7ADrOXgBWkC8A5Vb1AD+RvgElBScAbfsaAImT6gCieZH/kHTO/8Xouf+3voz/SQz+/4sU8v+qWu//YUK7//W1h/7eiDQA9QUz/ssvTgCYZdgASRd9AP5gIQHr0kn/K9FYAQeBbQB6aOT+qvLLAPLMh//KHOn/QQZ/AJ+QRwBkjF8ATpYNAPtrdgG2On3/ASZs/4290f8Im30BcaNb/3lPvv+G72z/TC/4AKPk7wARbwoAWJVL/9fr7wCnnxj/L5ds/2vRvADp52P+HMqU/64jiv9uGET/AkW1AGtmUgBm7QcAXCTt/92iUwE3ygb/h+qH/xj63gBBXqj+9fjS/6dsyf7/oW8AzQj+AIgNdABksIT/K9d+/7GFgv+eT5QAQ+AlAQzOFf8+Im4B7Wiv/1CEb/+OrkgAVOW0/mmzjABA+A//6YoQAPVDe/7aedT/P1/aAdWFif+PtlL/MBwLAPRyjQHRr0z/nbWW/7rlA/+knW8B572LAHfKvv/aakD/ROs//mAarP+7LwsB1xL7/1FUWQBEOoAAXnEFAVyB0P9hD1P+CRy8AO8JpAA8zZgAwKNi/7gSPADZtosAbTt4/wTA+wCp0vD/Jaxc/pTT9f+zQTQA/Q1zALmuzgFyvJX/7VqtACvHwP9YbHEANCNMAEIZlP/dBAf/l/Fy/77R6ABiMscAl5bV/xJKJAE1KAcAE4dB/xqsRQCu7VUAY18pAAM4EAAnoLH/yGra/rlEVP9buj3+Q4+N/w30pv9jcsYAx26j/8ESugB87/YBbkQWAALrLgHUPGsAaSppAQ7mmAAHBYMAjWia/9UDBgCD5KL/s2QcAed7Vf/ODt8B/WDmACaYlQFiiXoA1s0D/+KYs/8GhYkAnkWM/3Gimv+086z/G71z/48u3P/VhuH/fh1FALwriQHyRgkAWsz//+eqkwAXOBP+OH2d/zCz2v9Ptv3/JtS/ASnrfABglxwAh5S+AM35J/40YIj/1CyI/0PRg//8ghf/24AU/8aBdgBsZQsAsgWSAT4HZP+17F7+HBqkAEwWcP94Zk8AysDlAciw1wApQPT/zrhOAKctPwGgIwD/OwyO/8wJkP/bXuUBehtwAL1pbf9A0Er/+383AQLixgAsTNEAl5hN/9IXLgHJq0X/LNPnAL4l4P/1xD7/qbXe/yLTEQB38cX/5SOYARVFKP+y4qEAlLPBANvC/gEozjP/51z6AUOZqgAVlPEAqkVS/3kS5/9ccgMAuD7mAOHJV/+SYKL/tfLcAK273QHiPqr/OH7ZAXUN4/+zLO8AnY2b/5DdUwDr0dAAKhGlAftRhQB89cn+YdMY/1PWpgCaJAn/+C9/AFrbjP+h2Sb+1JM//0JUlAHPAwEA5oZZAX9Oev/gmwH/UohKALKc0P+6GTH/3gPSAeWWvv9VojT/KVSN/0l7VP5dEZYAdxMcASAW1/8cF8z/jvE0/+Q0fQAdTM8A16f6/q+k5gA3z2kBbbv1/6Es3AEpZYD/pxBeAF3Wa/92SAD+UD3q/3mvfQCLqfsAYSeT/vrEMf+ls27+30a7/xaOfQGas4r/drAqAQqumQCcXGYAqA2h/48QIAD6xbT/y6MsAVcgJAChmRT/e/wPABnjUAA8WI4AERbJAZrNTf8nPy8ACHqNAIAXtv7MJxP/BHAd/xckjP/S6nT+NTI//3mraP+g214AV1IO/ucqBQCli3/+Vk4mAII8Qv7LHi3/LsR6Afk1ov+Ij2f+19JyAOcHoP6pmCr/by32AI6Dh/+DR8z/JOILAAAc8v/hitX/9y7Y/vUDtwBs/EoBzhow/8029v/TxiT/eSMyADTYyv8mi4H+8kmUAEPnjf8qL8wATnQZAQThv/8Gk+QAOlixAHql5f/8U8n/4KdgAbG4nv/yabMB+MbwAIVCywH+JC8ALRhz/3c+/gDE4br+e42sABpVKf/ib7cA1eeXAAQ7B//uipQAQpMh/x/2jf/RjXT/aHAfAFihrABT1+b+L2+XAC0mNAGELcwAioBt/ul1hv/zvq3+8ezwAFJ/7P4o36H/brbh/3uu7wCH8pEBM9GaAJYDc/7ZpPz/N5xFAVRe///oSS0BFBPU/2DFO/5g+yEAJsdJAUCs9/91dDj/5BESAD6KZwH25aT/9HbJ/lYgn/9tIokBVdO6AArBwf56wrEAeu5m/6LaqwBs2aEBnqoiALAvmwG15Av/CJwAABBLXQDOYv8BOpojAAzzuP5DdUL/5uV7AMkqbgCG5LL+umx2/zoTmv9SqT7/co9zAe/EMv+tMMH/kwJU/5aGk/5f6EkAbeM0/r+JCgAozB7+TDRh/6TrfgD+fLwASrYVAXkdI//xHgf+VdrW/wdUlv5RG3X/oJ+Y/kIY3f/jCjwBjYdmANC9lgF1s1wAhBaI/3jHHAAVgU/+tglBANqjqQD2k8b/ayaQAU6vzf/WBfr+L1gd/6QvzP8rNwb/g4bP/nRk1gBgjEsBatyQAMMgHAGsUQX/x7M0/yVUywCqcK4ACwRbAEX0GwF1g1wAIZiv/4yZa//7hyv+V4oE/8bqk/55mFT/zWWbAZ0JGQBIahH+bJkA/73lugDBCLD/rpXRAO6CHQDp1n4BPeJmADmjBAHGbzP/LU9OAXPSCv/aCRn/novG/9NSu/5QhVMAnYHmAfOFhv8oiBAATWtP/7dVXAGxzMoAo0eT/5hFvgCsM7wB+tKs/9PycQFZWRr/QEJv/nSYKgChJxv/NlD+AGrRcwFnfGEA3eZi/x/nBgCywHj+D9nL/3yeTwBwkfcAXPowAaO1wf8lL47+kL2l/y6S8AAGS4AAKZ3I/ld51QABcewABS36AJAMUgAfbOcA4e93/6cHvf+75IT/br0iAF4szAGiNMUATrzx/jkUjQD0ki8BzmQzAH1rlP4bw00AmP1aAQePkP8zJR8AIncm/wfFdgCZvNMAlxR0/vVBNP+0/W4BL7HRAKFjEf923soAfbP8AXs2fv+ROb8AN7p5AArzigDN0+X/fZzx/pScuf/jE7z/fCkg/x8izv4ROVMAzBYl/ypgYgB3ZrgBA74cAG5S2v/IzMD/yZF2AHXMkgCEIGIBwMJ5AGqh+AHtWHwAF9QaAM2rWv/4MNgBjSXm/3zLAP6eqB7/1vgVAHC7B/9Lhe//SuPz//qTRgDWeKIApwmz/xaeEgDaTdEBYW1R//Qhs/85NDn/QazS//lH0f+Oqe4Anr2Z/67+Z/5iIQ4AjUzm/3GLNP8POtQAqNfJ//jM1wHfRKD/OZq3/i/neQBqpokAUYiKAKUrMwDniz0AOV87/nZiGf+XP+wBXr76/6m5cgEF+jr/S2lhAdffhgBxY6MBgD5wAGNqkwCjwwoAIc22ANYOrv+BJuf/NbbfAGIqn//3DSgAvNKxAQYVAP//PZT+iS2B/1kadP5+JnIA+zLy/nmGgP/M+af+pevXAMqx8wCFjT4A8IK+AW6v/wAAFJIBJdJ5/wcnggCO+lT/jcjPAAlfaP8L9K4Ahuh+AKcBe/4QwZX/6OnvAdVGcP/8dKD+8t7c/81V4wAHuToAdvc/AXRNsf8+9cj+PxIl/2s16P4y3dMAotsH/gJeKwC2Prb+oE7I/4eMqgDruOQArzWK/lA6Tf+YyQIBP8QiAAUeuACrsJoAeTvOACZjJwCsUE3+AIaXALoh8f5e/d//LHL8AGx+Of/JKA3/J+Ub/yfvFwGXeTP/mZb4AArqrv929gT+yPUmAEWh8gEQspYAcTiCAKsfaQAaWGz/MSpqAPupQgBFXZUAFDn+AKQZbwBavFr/zATFACjVMgHUYIT/WIq0/uSSfP+49vcAQXVW//1m0v7+eSQAiXMD/zwY2ACGEh0AO+JhALCORwAH0aEAvVQz/pv6SADVVOv/Ld7gAO6Uj/+qKjX/Tqd1ALoAKP99sWf/ReFCAOMHWAFLrAYAqS3jARAkRv8yAgn/i8EWAI+35/7aRTIA7DihAdWDKgCKkSz+iOUo/zE/I/89kfX/ZcAC/uincQCYaCYBebnaAHmL0/538CMAQb3Z/ruzov+gu+YAPvgO/zxOYQD/96P/4Ttb/2tHOv/xLyEBMnXsANuxP/70WrMAI8LX/71DMv8Xh4EAaL0l/7k5wgAjPuf/3PhsAAznsgCPUFsBg11l/5AnAgH/+rIABRHs/osgLgDMvCb+9XM0/79xSf6/bEX/FkX1ARfLsgCqY6oAQfhvACVsmf9AJUUAAFg+/lmUkP+/ROAB8Sc1ACnL7f+RfsL/3Sr9/xljlwBh/d8BSnMx/wavSP87sMsAfLf5AeTkYwCBDM/+qMDD/8ywEP6Y6qsATSVV/yF4h/+OwuMBH9Y6ANW7ff/oLjz/vnQq/peyE/8zPu3+zOzBAMLoPACsIp3/vRC4/mcDX/+N6ST+KRkL/xXDpgB29S0AQ9WV/58MEv+7pOMBoBkFAAxOwwErxeEAMI4p/sSbPP/fxxIBkYicAPx1qf6R4u4A7xdrAG21vP/mcDH+Sart/+e34/9Q3BQAwmt/AX/NZQAuNMUB0qsk/1gDWv84l40AYLv//ypOyAD+RkYB9H2oAMxEigF810YAZkLI/hE05AB13I/+y/h7ADgSrv+6l6T/M+jQAaDkK//5HRkBRL4/AA0AAAAA/wAAAAD1AAAAAAAA+wAAAAAAAP0AAAAA8wAAAAAHAAAAAAADAAAAAPMAAAAABQAAAAAAAAAACwAAAAAACwAAAADzAAAAAAAA/QAAAAAA/wAAAAADAAAAAPUAAAAAAAAADwAAAAAA/wAAAAD/AAAAAAcAAAAABQBBvIkCCysBAAAAdsFfAGVwAv9Q/KH+8mrG/4UGsgDk33AA3+5V/jPzGgA+K4v+y0EKAEHwiQILVzNN7QCRqlb/NiYz//GAZf8peUr/7E6bAKmXaf6cKUgAwmav/86iZf8AAAAAAAAAABsuewESqP3/06+X/sPbYAA4dr7+/tH1/5lkfv7ogRX/Nbjy/8ek3QBB8IoCCwEBAEGQiwILgSvg63p8O0G4rhZW4/rxn8Rq2gmN65wysf2GYgUWX0m4AF+clbyjUIwksdCxVZyD71sERFzEWByOhtgiTt3QnxFX7P///////////////////////////////////////3/t////////////////////////////////////////f+7///////////////////////////////////////9/AAECBAgQIECAGzYAAAAAAMZjY6X4fHyE7nd3mfZ7e43/8vIN1mtrvd5vb7GRxcVUYDAwUAIBAQPOZ2epVisrfef+/hm119diTaur5ux2dpqPyspFH4KCnYnJyUD6fX2H7/r6FbJZWeuOR0fJ+/DwC0Gtreyz1NRnX6Ki/UWvr+ojnJy/U6Sk9+RycpabwMBbdbe3wuH9/Rw9k5OuTCYmamw2Nlp+Pz9B9ff3AoPMzE9oNDRcUaWl9NHl5TT58fEI4nFxk6vY2HNiMTFTKhUVPwgEBAyVx8dSRiMjZZ3Dw14wGBgoN5aWoQoFBQ8vmpq1DgcHCSQSEjYbgICb3+LiPc3r6yZOJydpf7Kyzep1dZ8SCQkbHYODnlgsLHQ0GhouNhsbLdxubrK0WlruW6Cg+6RSUvZ2OztNt9bWYX2zs85SKSl73ePjPl4vL3EThISXplNT9bnR0WgAAAAAwe3tLEAgIGDj/PwfebGxyLZbW+3Uamq+jcvLRme+vtlyOTlLlEpK3phMTNSwWFjohc/PSrvQ0GvF7+8qT6qq5e37+xaGQ0PFmk1N12YzM1URhYWUikVFz+n5+RAEAgIG/n9/gaBQUPB4PDxEJZ+fukuoqOOiUVHzXaOj/oBAQMAFj4+KP5KSrSGdnbxwODhI8fX1BGO8vN93trbBr9radUIhIWMgEBAw5f//Gv3z8w6/0tJtgc3NTBgMDBQmExM1w+zsL75fX+E1l5eiiEREzC4XFzmTxMRXVaen8vx+foJ6PT1HyGRkrLpdXecyGRkr5nNzlcBgYKAZgYGYnk9P0aPc3H9EIiJmVCoqfjuQkKsLiIiDjEZGysfu7ilruLjTKBQUPKfe3nm8Xl7iFgsLHa3b23bb4OA7ZDIyVnQ6Ok4UCgoekklJ2wwGBgpIJCRsuFxc5J/Cwl2909NuQ6ys78RiYqY5kZGoMZWVpNPk5DfyeXmL1efnMovIyENuNzdZ2m1ttwGNjYyx1dVknE5O0kmpqeDYbGy0rFZW+vP09AfP6uolymVlr/R6eo5Hrq7pEAgIGG+6utXweHiISiUlb1wuLnI4HBwkV6am8XO0tMeXxsZRy+joI6Hd3XzodHScPh8fIZZLS91hvb3cDYuLhg+KioXgcHCQfD4+QnG1tcTMZmaqkEhI2AYDAwX39vYBHA4OEsJhYaNqNTVfrldX+Wm5udAXhoaRmcHBWDodHScnnp652eHhOOv4+BMrmJizIhERM9Jpabup2dlwB46OiTOUlKctm5u2PB4eIhWHh5LJ6ekgh87OSapVVf9QKCh4pd/fegOMjI9ZoaH4CYmJgBoNDRdlv7/a1+bmMYRCQsbQaGi4gkFBwymZmbBaLS13Hg8PEXuwsMuoVFT8bbu71iwWFjqlxmNjhPh8fJnud3eN9nt7Df/y8r3Wa2ux3m9vVJHFxVBgMDADAgEBqc5nZ31WKysZ5/7+YrXX1+ZNq6ua7HZ2RY/Kyp0fgoJAicnJh/p9fRXv+vrrsllZyY5HRwv78PDsQa2tZ7PU1P1foqLqRa+vvyOcnPdTpKSW5HJyW5vAwMJ1t7cc4f39rj2Tk2pMJiZabDY2QX4/PwL19/dPg8zMXGg0NPRRpaU00eXlCPnx8ZPicXFzq9jYU2IxMT8qFRUMCAQEUpXHx2VGIyNencPDKDAYGKE3lpYPCgUFtS+amgkOBwc2JBISmxuAgD3f4uImzevraU4nJ81/srKf6nV1GxIJCZ4dg4N0WCwsLjQaGi02Gxuy3G5u7rRaWvtboKD2pFJSTXY7O2G31tbOfbOze1IpKT7d4+NxXi8vlxOEhPWmU1NoudHRAAAAACzB7e1gQCAgH+P8/Mh5sbHttltbvtRqakaNy8vZZ76+S3I5Od6USkrUmExM6LBYWEqFz89ru9DQKsXv7+VPqqoW7fv7xYZDQ9eaTU1VZjMzlBGFhc+KRUUQ6fn5BgQCAoH+f3/woFBQRHg8PLoln5/jS6io86JRUf5do6PAgEBAigWPj60/kpK8IZ2dSHA4OATx9fXfY7y8wXe2tnWv2tpjQiEhMCAQEBrl//8O/fPzbb/S0kyBzc0UGAwMNSYTEy/D7Ozhvl9fojWXl8yIREQ5LhcXV5PExPJVp6eC/H5+R3o9PazIZGTnul1dKzIZGZXmc3OgwGBgmBmBgdGeT09/o9zcZkQiIn5UKiqrO5CQgwuIiMqMRkYpx+7u02u4uDwoFBR5p97e4rxeXh0WCwt2rdvbO9vg4FZkMjJOdDo6HhQKCtuSSUkKDAYGbEgkJOS4XFxdn8LCbr3T0+9DrKymxGJiqDmRkaQxlZU30+Tki/J5eTLV5+dDi8jIWW43N7fabW2MAY2NZLHV1dKcTk7gSamptNhsbPqsVlYH8/T0Jc/q6q/KZWWO9Hp66UeurhgQCAjVb7q6iPB4eG9KJSVyXC4uJDgcHPFXpqbHc7S0UZfGxiPL6Oh8od3dnOh0dCE+Hx/dlktL3GG9vYYNi4uFD4qKkOBwcEJ8Pj7EcbW1qsxmZtiQSEgFBgMDAff29hIcDg6jwmFhX2o1NfmuV1fQabm5kReGhliZwcEnOh0duSeenjjZ4eET6/j4syuYmDMiERG70mlpcKnZ2YkHjo6nM5SUti2bmyI8Hh6SFYeHIMnp6UmHzs7/qlVVeFAoKHql39+PA4yM+FmhoYAJiYkXGg0N2mW/vzHX5ubGhEJCuNBoaMOCQUGwKZmZd1otLREeDw/Le7Cw/KhUVNZtu7s6LBYWY6XGY3yE+Hx3me53e432e/IN//JrvdZrb7Heb8VUkcUwUGAwAQMCAWepzmcrfVYr/hnn/tditder5k2rdprsdspFj8qCnR+CyUCJyX2H+n36Fe/6WeuyWUfJjkfwC/vwrexBrdRns9Si/V+ir+pFr5y/I5yk91OkcpbkcsBbm8C3wnW3/Rzh/ZOuPZMmakwmNlpsNj9Bfj/3AvX3zE+DzDRcaDSl9FGl5TTR5fEI+fFxk+Jx2HOr2DFTYjEVPyoVBAwIBMdSlccjZUYjw16dwxgoMBiWoTeWBQ8KBZq1L5oHCQ4HEjYkEoCbG4DiPd/i6ybN6ydpTieyzX+ydZ/qdQkbEgmDnh2DLHRYLBouNBobLTYbbrLcblrutFqg+1ugUvakUjtNdjvWYbfWs859syl7UinjPt3jL3FeL4SXE4RT9aZT0Wi50QAAAADtLMHtIGBAIPwf4/yxyHmxW+22W2q+1GrLRo3LvtlnvjlLcjlK3pRKTNSYTFjosFjPSoXP0Gu70O8qxe+q5U+q+xbt+0PFhkNN15pNM1VmM4WUEYVFz4pF+RDp+QIGBAJ/gf5/UPCgUDxEeDyfuiWfqONLqFHzolGj/l2jQMCAQI+KBY+SrT+SnbwhnThIcDj1BPH1vN9jvLbBd7bada/aIWNCIRAwIBD/GuX/8w7989Jtv9LNTIHNDBQYDBM1JhPsL8PsX+G+X5eiNZdEzIhEFzkuF8RXk8Sn8lWnfoL8fj1Hej1krMhkXee6XRkrMhlzleZzYKDAYIGYGYFP0Z5P3H+j3CJmRCIqflQqkKs7kIiDC4hGyoxG7inH7rjTa7gUPCgU3nmn3l7ivF4LHRYL23at2+A72+AyVmQyOk50OgoeFApJ25JJBgoMBiRsSCRc5Lhcwl2fwtNuvdOs70OsYqbEYpGoOZGVpDGV5DfT5HmL8nnnMtXnyEOLyDdZbjdtt9ptjYwBjdVksdVO0pxOqeBJqWy02GxW+qxW9Afz9Oolz+plr8pleo70eq7pR64IGBAIutVvuniI8Hglb0olLnJcLhwkOBym8VemtMdztMZRl8boI8vo3Xyh3XSc6HQfIT4fS92WS73cYb2Lhg2LioUPinCQ4HA+Qnw+tcRxtWaqzGZI2JBIAwUGA/YB9/YOEhwOYaPCYTVfajVX+a5XudBpuYaRF4bBWJnBHSc6HZ65J57hONnh+BPr+JizK5gRMyIRabvSadlwqdmOiQeOlKczlJu2LZseIjweh5IVh+kgyenOSYfOVf+qVSh4UCjfeqXfjI8DjKH4WaGJgAmJDRcaDb/aZb/mMdfmQsaEQmi40GhBw4JBmbApmS13Wi0PER4PsMt7sFT8qFS71m27FjosFmNjpcZ8fIT4d3eZ7nt7jfby8g3/a2u91m9vsd7FxVSRMDBQYAEBAwJnZ6nOKyt9Vv7+GefX12K1q6vmTXZ2muzKykWPgoKdH8nJQIl9fYf6+voV71lZ67JHR8mO8PAL+62t7EHU1GezoqL9X6+v6kWcnL8jpKT3U3JyluTAwFubt7fCdf39HOGTk649JiZqTDY2Wmw/P0F+9/cC9czMT4M0NFxopaX0UeXlNNHx8Qj5cXGT4tjYc6sxMVNiFRU/KgQEDAjHx1KVIyNlRsPDXp0YGCgwlpahNwUFDwqamrUvBwcJDhISNiSAgJsb4uI93+vrJs0nJ2lOsrLNf3V1n+oJCRsSg4OeHSwsdFgaGi40GxstNm5ustxaWu60oKD7W1JS9qQ7O0121tZht7Ozzn0pKXtS4+M+3S8vcV6EhJcTU1P1ptHRaLkAAAAA7e0swSAgYED8/B/jsbHIeVtb7bZqar7Uy8tGjb6+2Wc5OUtySkrelExM1JhYWOiwz89KhdDQa7vv7yrFqqrlT/v7Fu1DQ8WGTU3XmjMzVWaFhZQRRUXPivn5EOkCAgYEf3+B/lBQ8KA8PER4n5+6Jaio40tRUfOio6P+XUBAwICPj4oFkpKtP52dvCE4OEhw9fUE8by832O2tsF32tp1ryEhY0IQEDAg//8a5fPzDv3S0m2/zc1MgQwMFBgTEzUm7Owvw19f4b6Xl6I1RETMiBcXOS7ExFeTp6fyVX5+gvw9PUd6ZGSsyF1d57oZGSsyc3OV5mBgoMCBgZgZT0/Rntzcf6MiImZEKip+VJCQqzuIiIMLRkbKjO7uKce4uNNrFBQ8KN7eeadeXuK8CwsdFtvbdq3g4DvbMjJWZDo6TnQKCh4USUnbkgYGCgwkJGxIXFzkuMLCXZ/T0269rKzvQ2JipsSRkag5lZWkMeTkN9N5eYvy5+cy1cjIQ4s3N1lubW232o2NjAHV1WSxTk7SnKmp4ElsbLTYVlb6rPT0B/Pq6iXPZWWvynp6jvSurulHCAgYELq61W94eIjwJSVvSi4uclwcHCQ4pqbxV7S0x3PGxlGX6Ogjy93dfKF0dJzoHx8hPktL3Za9vdxhi4uGDYqKhQ9wcJDgPj5CfLW1xHFmZqrMSEjYkAMDBQb29gH3Dg4SHGFho8I1NV9qV1f5rrm50GmGhpEXwcFYmR0dJzqenrkn4eE42fj4E+uYmLMrEREzImlpu9LZ2XCpjo6JB5SUpzObm7YtHh4iPIeHkhXp6SDJzs5Jh1VV/6ooKHhQ3996pYyMjwOhofhZiYmACQ0NFxq/v9pl5uYx10JCxoRoaLjQQUHDgpmZsCktLXdaDw8RHrCwy3tUVPyou7vWbRYWOixSCWrVMDalOL9Ao56B89f7fOM5gpsv/4c0jkNExN7py1R7lDKmwiM97kyVC0L6w04ILqFmKNkksnZboklti9Elcvj2ZIZomBbUpFzMXWW2kmxwSFD97bnaXhVGV6eNnYSQ2KsAjLzTCvfkWAW4s0UG0Cwej8o/DwLBr70DAROKazqREUFPZ9zql/LPzvC05nOWrHQi5601heL5N+gcdd9uR/EacR0pxYlvt2IOqhi+G/xWPkvG0nkgmtvA/njNWvQf3agziAfHMbESEFkngOxfYFF/qRm1Sg0t5Xqfk8mc76DgO02uKvWwyOu7PINTmWEXKwR+unfWJuFpFGNVIQx9Y3x3e/Jrb8UwAWcr/terdsqCyX36WUfwrdSir5ykcsC3/ZMmNj/3zDSl5fFx2DEVBMcjwxiWBZoHEoDi6yeydQmDLBobblqgUjvWsynjL4RT0QDtIPyxW2rLvjlKTFjP0O+q+0NNM4VF+QJ/UDyfqFGjQI+SnTj1vLbaIRD/89LNDBPsX5dEF8Snfj1kXRlzYIFP3CIqkIhG7rgU3l4L2+AyOgpJBiRcwtOsYpGV5HnnyDdtjdVOqWxW9Opleq4IunglLhymtMbo3XQfS72LinA+tWZIA/YOYTVXuYbBHZ7h+JgRadmOlJseh+nOVSjfjKGJDb/mQmhBmS0PsFS7FkxpYnNvZGl1bURSRwAAAAAIybzzZ+YJajunyoSFrme7K/iU/nLzbjzxNh1fOvVPpdGC5q1/Ug5RH2w+K4xoBZtrvUH7q9mDH3khfhMZzeBbIq4o15gvikLNZe8jkUQ3cS87TezP+8C1vNuJgaXbtek4tUjzW8JWORnQBbbxEfFZm08Zr6SCP5IYgW3a1V4cq0ICA6OYqgfYvm9wRQFbgxKMsuROvoUxJOK0/9XDfQxVb4l78nRdvnKxlhY7/rHegDUSxyWnBtyblCZpz3Txm8HSSvGewWmb5OMlTziGR77vtdWMi8adwQ9lnKx3zKEMJHUCK1lvLOktg+SmbqqEdErU+0G93KmwXLVTEYPaiPl2q99m7lJRPpgQMrQtbcYxqD8h+5jIJwOw5A7vvsd/Wb/Cj6g98wvgxiWnCpNHkafVb4ID4FFjygZwbg4KZykpFPwv0kaFCrcnJskmXDghGy7tKsRa/G0sTd+zlZ0TDThT3mOvi1RzCmWosnc8uwpqduau7UcuycKBOzWCFIUscpJkA/FMoei/ogEwQrxLZhqokZf40HCLS8IwvlQGo1FsxxhS79YZ6JLREKllVSQGmdYqIHFXhTUO9LjRuzJwoGoQyNDSuBbBpBlTq0FRCGw3Hpnrjt9Md0gnqEib4bW8sDRjWsnFswwcOcuKQeNKqthOc+Njd0/KnFujuLLW828uaPyy713ugo90YC8XQ29jpXhyq/ChFHjIhOw5ZBoIAseMKB5jI/r/vpDpvYLe62xQpBV5xrL3o/m+K1Ny4/J4ccacYSbqzj4nygfCwCHHuIbRHuvgzdZ92up40W7uf0999bpvF3KqZ/AGppjIosV9YwquDfm+BJg/ERtHHBM1C3EbhH0EI/V32yiTJMdAe6vKMry+yRUKvp48TA0QnMRnHUO2Qj7LvtTFTCp+ZfycKX9Z7PrWOqtvy18XWEdKjBlEbIAAQZC3AgsQ7dP1XBpjEljWnPei3vneFABBr7cCCwEQAEHAtwILoQJn5glqha5nu3Lzbjw69U+lf1IOUYxoBZur2YMfGc3gW5gvikKRRDdxz/vAtaXbtelbwlY58RHxWaSCP5LVXhyrmKoH2AFbgxK+hTEkw30MVXRdvnL+sd6Apwbcm3Txm8HBaZvkhke+78adwQ/MoQwkbyzpLaqEdErcqbBc2oj5dlJRPphtxjGoyCcDsMd/Wb/zC+DGR5Gn1VFjygZnKSkUhQq3JzghGy78bSxNEw04U1RzCmW7Cmp2LsnCgYUscpKh6L+iS2YaqHCLS8KjUWzHGeiS0SQGmdaFNQ70cKBqEBbBpBkIbDceTHdIJ7W8sDSzDBw5SqrYTk/KnFvzby5o7oKPdG9jpXgUeMiECALHjPr/vpDrbFCk96P5vvJ4ccaAAEGgugILhgLtCAsKmgsUB9UFjgUfAcoAVgxuAikGtgDCA08IPwe8BT0C1AcIAX8BxAmyBb8GfwxYCvkD3AJgAvsGmwE0DN4GxwSMAtkK9wP0B9MF5wv5BgQC+QzBC2cKrwZ3CH4AvQWsCacM8gs+A2sAdAcKDEoJcwvBAx0HLArAAdgIpQIGCLIIrgErAksDHghnAw4GaQCmAUsCsQAWDN4LNQsmBnUGCwwKA4cEbgz4CcsFpwpfBMsGhAKZCV0BogFJAWUMtgwxA0kEWwJiAioF/AdIB4ABQgh5DMIEygeXCdwAXgiGBmAIBwcDCBoDGwerCZsJ3gGVDM0L5APfA74DTQfyBVwGXC4vL15cAEGwvAILIVNpZ0VkMjU1MTkgbm8gRWQyNTUxOSBjb2xsaXNpb25zAQBBoL0CC2WApAEAAQAAAAIAAAADAAAABAAAAAUAAAAGAAAABwAAAAgAAAAJAAAACgAAAAsAAAAMAAAADQAAAA4AAAAPAAAAEAAAABEAAAAWAAAAFwAAABgAAAAZAAAAGgAAABsAAAAcAAAAHQ=="), A4((await (async function(A5, g3, C4) {
      return (async function(A6, g4) {
        try {
          var C5 = await (async function(A7) {
            return (function(A8) {
              if (ArrayBuffer.isView(A8)) return A8;
              if (A8 == o2 && E2) return new Uint8Array(E2);
              if (I2) return I2(A8);
              throw "both async and sync fetching of the wasm failed";
            })(A7);
          })(A6);
          return await WebAssembly.instantiate(C5, g4);
        } catch (A7) {
          k2(`failed to asynchronously prepare wasm: ${A7}`), J2(A7);
        }
      })(g3, C4);
    })(0, o2, C3)).instance));
  })(), (function() {
    function A4() {
      g2.calledRun = true, M2 || (G2 = true, i2?.(g2), g2.onRuntimeInitialized?.(), (function() {
        if (g2.postRun) for ("function" == typeof g2.postRun && (g2.postRun = [g2.postRun]); g2.postRun.length; ) K2(g2.postRun.shift());
        U2(Y2);
      })());
    }
    !(function() {
      if (g2.preRun) for ("function" == typeof g2.preRun && (g2.preRun = [g2.preRun]); g2.preRun.length; ) s2(g2.preRun.shift());
      U2(H2);
    })(), g2.setStatus ? (g2.setStatus("Running..."), setTimeout(() => {
      setTimeout(() => g2.setStatus(""), 1), A4();
    }, 1)) : A4();
  })(), G2 ? g2 : new Promise((A4, I3) => {
    i2 = A4, D2 = I3;
  });
}
var libsodium_sumo_default = A;

// node_modules/libsodium-wrappers-sumo/dist/modules-sumo-esm/libsodium-wrappers.mjs
var r;
var t = {};
if (void 0 === globalThis.crypto || "function" != typeof globalThis.crypto.getRandomValues) throw new Error("globalThis.crypto.getRandomValues is not available. The ESM build of libsodium requires a secure random source (available in all browsers and Node.js 19+).");
var a = "function" == typeof (_ = libsodium_sumo_default) ? _ : null != _ && "function" == typeof _.default ? _.default : null;
var _;
var n = (function(e) {
  return null != e && void 0 !== e.ready ? e : null != e && null != e.default && void 0 !== e.default.ready ? e.default : null;
})(libsodium_sumo_default);
var s = (null != a ? a({ getRandomValue: function() {
  var e = new Uint32Array(1);
  return globalThis.crypto.getRandomValues(e), e[0] >>> 0;
} }) : null != n ? n.ready.then(function() {
  return n;
}) : Promise.reject(new Error("Unsupported libsodium ESM export shape"))).then(function(e) {
  r = e, t.libsodium = r, (function() {
    if (r._sodium_init() < 0) throw new Error("libsodium was not correctly initialized.");
    for (var e2 = ["crypto_aead_aegis128l_decrypt", "crypto_aead_aegis128l_decrypt_detached", "crypto_aead_aegis128l_encrypt", "crypto_aead_aegis128l_encrypt_detached", "crypto_aead_aegis128l_keygen", "crypto_aead_aegis256_decrypt", "crypto_aead_aegis256_decrypt_detached", "crypto_aead_aegis256_encrypt", "crypto_aead_aegis256_encrypt_detached", "crypto_aead_aegis256_keygen", "crypto_aead_chacha20poly1305_decrypt", "crypto_aead_chacha20poly1305_decrypt_detached", "crypto_aead_chacha20poly1305_encrypt", "crypto_aead_chacha20poly1305_encrypt_detached", "crypto_aead_chacha20poly1305_ietf_decrypt", "crypto_aead_chacha20poly1305_ietf_decrypt_detached", "crypto_aead_chacha20poly1305_ietf_encrypt", "crypto_aead_chacha20poly1305_ietf_encrypt_detached", "crypto_aead_chacha20poly1305_ietf_keygen", "crypto_aead_chacha20poly1305_keygen", "crypto_aead_xchacha20poly1305_ietf_decrypt", "crypto_aead_xchacha20poly1305_ietf_decrypt_detached", "crypto_aead_xchacha20poly1305_ietf_encrypt", "crypto_aead_xchacha20poly1305_ietf_encrypt_detached", "crypto_aead_xchacha20poly1305_ietf_keygen", "crypto_auth", "crypto_auth_hmacsha256", "crypto_auth_hmacsha256_final", "crypto_auth_hmacsha256_init", "crypto_auth_hmacsha256_keygen", "crypto_auth_hmacsha256_update", "crypto_auth_hmacsha256_verify", "crypto_auth_hmacsha512", "crypto_auth_hmacsha512256", "crypto_auth_hmacsha512256_final", "crypto_auth_hmacsha512256_init", "crypto_auth_hmacsha512256_keygen", "crypto_auth_hmacsha512256_update", "crypto_auth_hmacsha512256_verify", "crypto_auth_hmacsha512_final", "crypto_auth_hmacsha512_init", "crypto_auth_hmacsha512_keygen", "crypto_auth_hmacsha512_update", "crypto_auth_hmacsha512_verify", "crypto_auth_keygen", "crypto_auth_verify", "crypto_box_beforenm", "crypto_box_curve25519xchacha20poly1305_beforenm", "crypto_box_curve25519xchacha20poly1305_detached", "crypto_box_curve25519xchacha20poly1305_detached_afternm", "crypto_box_curve25519xchacha20poly1305_easy", "crypto_box_curve25519xchacha20poly1305_easy_afternm", "crypto_box_curve25519xchacha20poly1305_keypair", "crypto_box_curve25519xchacha20poly1305_open_detached", "crypto_box_curve25519xchacha20poly1305_open_detached_afternm", "crypto_box_curve25519xchacha20poly1305_open_easy", "crypto_box_curve25519xchacha20poly1305_open_easy_afternm", "crypto_box_curve25519xchacha20poly1305_seal", "crypto_box_curve25519xchacha20poly1305_seal_open", "crypto_box_curve25519xchacha20poly1305_seed_keypair", "crypto_box_detached", "crypto_box_easy", "crypto_box_easy_afternm", "crypto_box_keypair", "crypto_box_open_detached", "crypto_box_open_easy", "crypto_box_open_easy_afternm", "crypto_box_seal", "crypto_box_seal_open", "crypto_box_seed_keypair", "crypto_core_ed25519_add", "crypto_core_ed25519_from_hash", "crypto_core_ed25519_from_uniform", "crypto_core_ed25519_is_valid_point", "crypto_core_ed25519_random", "crypto_core_ed25519_scalar_add", "crypto_core_ed25519_scalar_complement", "crypto_core_ed25519_scalar_invert", "crypto_core_ed25519_scalar_mul", "crypto_core_ed25519_scalar_negate", "crypto_core_ed25519_scalar_random", "crypto_core_ed25519_scalar_reduce", "crypto_core_ed25519_scalar_sub", "crypto_core_ed25519_sub", "crypto_core_hchacha20", "crypto_core_hsalsa20", "crypto_core_ristretto255_add", "crypto_core_ristretto255_from_hash", "crypto_core_ristretto255_is_valid_point", "crypto_core_ristretto255_random", "crypto_core_ristretto255_scalar_add", "crypto_core_ristretto255_scalar_complement", "crypto_core_ristretto255_scalar_invert", "crypto_core_ristretto255_scalar_mul", "crypto_core_ristretto255_scalar_negate", "crypto_core_ristretto255_scalar_random", "crypto_core_ristretto255_scalar_reduce", "crypto_core_ristretto255_scalar_sub", "crypto_core_ristretto255_sub", "crypto_generichash", "crypto_generichash_blake2b_salt_personal", "crypto_generichash_final", "crypto_generichash_init", "crypto_generichash_keygen", "crypto_generichash_update", "crypto_hash", "crypto_hash_sha256", "crypto_hash_sha256_final", "crypto_hash_sha256_init", "crypto_hash_sha256_update", "crypto_hash_sha3256", "crypto_hash_sha3256_final", "crypto_hash_sha3256_init", "crypto_hash_sha3256_update", "crypto_hash_sha3512", "crypto_hash_sha3512_final", "crypto_hash_sha3512_init", "crypto_hash_sha3512_update", "crypto_hash_sha512", "crypto_hash_sha512_final", "crypto_hash_sha512_init", "crypto_hash_sha512_update", "crypto_ipcrypt_decrypt", "crypto_ipcrypt_encrypt", "crypto_ipcrypt_keygen", "crypto_ipcrypt_nd_decrypt", "crypto_ipcrypt_nd_encrypt", "crypto_ipcrypt_nd_keygen", "crypto_ipcrypt_ndx_decrypt", "crypto_ipcrypt_ndx_encrypt", "crypto_ipcrypt_ndx_keygen", "crypto_ipcrypt_pfx_decrypt", "crypto_ipcrypt_pfx_encrypt", "crypto_ipcrypt_pfx_keygen", "crypto_kdf_derive_from_key", "crypto_kdf_keygen", "crypto_kem_dec", "crypto_kem_enc", "crypto_kem_keypair", "crypto_kem_mlkem768_dec", "crypto_kem_mlkem768_enc", "crypto_kem_mlkem768_enc_deterministic", "crypto_kem_mlkem768_keypair", "crypto_kem_mlkem768_seed_keypair", "crypto_kem_primitive", "crypto_kem_seed_keypair", "crypto_kem_xwing_dec", "crypto_kem_xwing_enc", "crypto_kem_xwing_enc_deterministic", "crypto_kem_xwing_keypair", "crypto_kem_xwing_seed_keypair", "crypto_kx_client_session_keys", "crypto_kx_keypair", "crypto_kx_seed_keypair", "crypto_kx_server_session_keys", "crypto_onetimeauth", "crypto_onetimeauth_final", "crypto_onetimeauth_init", "crypto_onetimeauth_keygen", "crypto_onetimeauth_update", "crypto_onetimeauth_verify", "crypto_pwhash", "crypto_pwhash_scryptsalsa208sha256", "crypto_pwhash_scryptsalsa208sha256_ll", "crypto_pwhash_scryptsalsa208sha256_str", "crypto_pwhash_scryptsalsa208sha256_str_verify", "crypto_pwhash_str", "crypto_pwhash_str_needs_rehash", "crypto_pwhash_str_verify", "crypto_scalarmult", "crypto_scalarmult_base", "crypto_scalarmult_ed25519", "crypto_scalarmult_ed25519_base", "crypto_scalarmult_ed25519_base_noclamp", "crypto_scalarmult_ed25519_noclamp", "crypto_scalarmult_ristretto255", "crypto_scalarmult_ristretto255_base", "crypto_secretbox_detached", "crypto_secretbox_easy", "crypto_secretbox_keygen", "crypto_secretbox_open_detached", "crypto_secretbox_open_easy", "crypto_secretstream_xchacha20poly1305_init_pull", "crypto_secretstream_xchacha20poly1305_init_push", "crypto_secretstream_xchacha20poly1305_keygen", "crypto_secretstream_xchacha20poly1305_pull", "crypto_secretstream_xchacha20poly1305_push", "crypto_secretstream_xchacha20poly1305_rekey", "crypto_shorthash", "crypto_shorthash_keygen", "crypto_shorthash_siphashx24", "crypto_sign", "crypto_sign_detached", "crypto_sign_ed25519_pk_to_curve25519", "crypto_sign_ed25519_sk_to_curve25519", "crypto_sign_ed25519_sk_to_pk", "crypto_sign_ed25519_sk_to_seed", "crypto_sign_final_create", "crypto_sign_final_verify", "crypto_sign_init", "crypto_sign_keypair", "crypto_sign_open", "crypto_sign_seed_keypair", "crypto_sign_update", "crypto_sign_verify_detached", "crypto_stream_chacha20", "crypto_stream_chacha20_ietf_xor", "crypto_stream_chacha20_ietf_xor_ic", "crypto_stream_chacha20_keygen", "crypto_stream_chacha20_xor", "crypto_stream_chacha20_xor_ic", "crypto_stream_keygen", "crypto_stream_xchacha20_keygen", "crypto_stream_xchacha20_xor", "crypto_stream_xchacha20_xor_ic", "crypto_xof_shake128", "crypto_xof_shake128_init", "crypto_xof_shake128_init_with_domain", "crypto_xof_shake128_squeeze", "crypto_xof_shake128_update", "crypto_xof_shake256", "crypto_xof_shake256_init", "crypto_xof_shake256_init_with_domain", "crypto_xof_shake256_squeeze", "crypto_xof_shake256_update", "crypto_xof_turboshake128", "crypto_xof_turboshake128_init", "crypto_xof_turboshake128_init_with_domain", "crypto_xof_turboshake128_squeeze", "crypto_xof_turboshake128_update", "crypto_xof_turboshake256", "crypto_xof_turboshake256_init", "crypto_xof_turboshake256_init_with_domain", "crypto_xof_turboshake256_squeeze", "crypto_xof_turboshake256_update", "randombytes_buf", "randombytes_buf_deterministic", "randombytes_close", "randombytes_random", "randombytes_set_implementation", "randombytes_stir", "randombytes_uniform", "sodium_bin2ip", "sodium_ip2bin", "sodium_version_string"], a3 = [C, R, P, X, D, G, F, V, q, H, z, W, j, J, Q, Z, $, ee, re, te, ae, _e, ne, se, ce, pe, oe, he, ye, ie, le, ue, de, ve, ge, be, fe, me, ke, xe, Ee, Te, Se, we, Ye, Be, Ke, Ae, Ie, Me, Ne, Le, Ue, Oe, Ce, Re, Pe, Xe, De, Ge, Fe, Ve, qe, He, ze, We, je, Je, Qe, Ze, $e, er, rr, tr, ar, _r, nr, sr, cr, pr, or, hr, yr, ir, lr, ur, dr, vr, gr, br, fr, mr, kr, xr, Er, Tr, Sr, wr, Yr, Br, Kr, Ar, Ir, Mr, Nr, Lr, Ur, Or, Cr, Rr, Pr, Xr, Dr, Gr, Fr, Vr, qr, Hr, zr, Wr, jr, Jr, Qr, Zr, $r, et, rt, tt, at, _t, nt, st, ct, pt, ot, ht, yt, it, lt, ut, dt, vt, gt, bt, ft, mt, kt, xt, Et, Tt, St, wt, Yt, Bt, Kt, At, It, Mt, Nt, Lt, Ut, Ot, Ct, Rt, Pt, Xt, Dt, Gt, Ft, Vt, qt, Ht, zt, Wt, jt, Jt, Qt, Zt, $t, ea, ra, ta, aa, _a, na, sa, ca, pa, oa, ha, ya, ia, la, ua, da, va, ga, ba, fa, ma, ka, xa, Ea, Ta, Sa, wa, Ya, Ba, Ka, Aa, Ia, Ma, Na, La, Ua, Oa, Ca, Ra, Pa, Xa, Da, Ga, Fa, Va, qa, Ha, za, Wa, ja, Ja, Qa, Za, $a, e_, r_, t_, a_, __, n_, s_, c_, p_, o_, h_, y_], _3 = 0; _3 < a3.length; _3++) "function" == typeof r["_" + e2[_3]] && (t[e2[_3]] = a3[_3]);
    var n3 = ["SODIUM_LIBRARY_VERSION_MAJOR", "SODIUM_LIBRARY_VERSION_MINOR", "crypto_aead_aegis128l_ABYTES", "crypto_aead_aegis128l_KEYBYTES", "crypto_aead_aegis128l_MESSAGEBYTES_MAX", "crypto_aead_aegis128l_NPUBBYTES", "crypto_aead_aegis128l_NSECBYTES", "crypto_aead_aegis256_ABYTES", "crypto_aead_aegis256_KEYBYTES", "crypto_aead_aegis256_MESSAGEBYTES_MAX", "crypto_aead_aegis256_NPUBBYTES", "crypto_aead_aegis256_NSECBYTES", "crypto_aead_aes256gcm_ABYTES", "crypto_aead_aes256gcm_KEYBYTES", "crypto_aead_aes256gcm_MESSAGEBYTES_MAX", "crypto_aead_aes256gcm_NPUBBYTES", "crypto_aead_aes256gcm_NSECBYTES", "crypto_aead_chacha20poly1305_ABYTES", "crypto_aead_chacha20poly1305_IETF_ABYTES", "crypto_aead_chacha20poly1305_IETF_KEYBYTES", "crypto_aead_chacha20poly1305_IETF_MESSAGEBYTES_MAX", "crypto_aead_chacha20poly1305_IETF_NPUBBYTES", "crypto_aead_chacha20poly1305_IETF_NSECBYTES", "crypto_aead_chacha20poly1305_KEYBYTES", "crypto_aead_chacha20poly1305_MESSAGEBYTES_MAX", "crypto_aead_chacha20poly1305_NPUBBYTES", "crypto_aead_chacha20poly1305_NSECBYTES", "crypto_aead_chacha20poly1305_ietf_ABYTES", "crypto_aead_chacha20poly1305_ietf_KEYBYTES", "crypto_aead_chacha20poly1305_ietf_MESSAGEBYTES_MAX", "crypto_aead_chacha20poly1305_ietf_NPUBBYTES", "crypto_aead_chacha20poly1305_ietf_NSECBYTES", "crypto_aead_xchacha20poly1305_IETF_ABYTES", "crypto_aead_xchacha20poly1305_IETF_KEYBYTES", "crypto_aead_xchacha20poly1305_IETF_MESSAGEBYTES_MAX", "crypto_aead_xchacha20poly1305_IETF_NPUBBYTES", "crypto_aead_xchacha20poly1305_IETF_NSECBYTES", "crypto_aead_xchacha20poly1305_ietf_ABYTES", "crypto_aead_xchacha20poly1305_ietf_KEYBYTES", "crypto_aead_xchacha20poly1305_ietf_MESSAGEBYTES_MAX", "crypto_aead_xchacha20poly1305_ietf_NPUBBYTES", "crypto_aead_xchacha20poly1305_ietf_NSECBYTES", "crypto_auth_BYTES", "crypto_auth_KEYBYTES", "crypto_auth_hmacsha256_BYTES", "crypto_auth_hmacsha256_KEYBYTES", "crypto_auth_hmacsha512256_BYTES", "crypto_auth_hmacsha512256_KEYBYTES", "crypto_auth_hmacsha512_BYTES", "crypto_auth_hmacsha512_KEYBYTES", "crypto_box_BEFORENMBYTES", "crypto_box_MACBYTES", "crypto_box_MESSAGEBYTES_MAX", "crypto_box_NONCEBYTES", "crypto_box_PUBLICKEYBYTES", "crypto_box_SEALBYTES", "crypto_box_SECRETKEYBYTES", "crypto_box_SEEDBYTES", "crypto_box_curve25519xchacha20poly1305_BEFORENMBYTES", "crypto_box_curve25519xchacha20poly1305_MACBYTES", "crypto_box_curve25519xchacha20poly1305_MESSAGEBYTES_MAX", "crypto_box_curve25519xchacha20poly1305_NONCEBYTES", "crypto_box_curve25519xchacha20poly1305_PUBLICKEYBYTES", "crypto_box_curve25519xchacha20poly1305_SEALBYTES", "crypto_box_curve25519xchacha20poly1305_SECRETKEYBYTES", "crypto_box_curve25519xchacha20poly1305_SEEDBYTES", "crypto_box_curve25519xsalsa20poly1305_BEFORENMBYTES", "crypto_box_curve25519xsalsa20poly1305_MACBYTES", "crypto_box_curve25519xsalsa20poly1305_MESSAGEBYTES_MAX", "crypto_box_curve25519xsalsa20poly1305_NONCEBYTES", "crypto_box_curve25519xsalsa20poly1305_PUBLICKEYBYTES", "crypto_box_curve25519xsalsa20poly1305_SECRETKEYBYTES", "crypto_box_curve25519xsalsa20poly1305_SEEDBYTES", "crypto_core_ed25519_BYTES", "crypto_core_ed25519_HASHBYTES", "crypto_core_ed25519_NONREDUCEDSCALARBYTES", "crypto_core_ed25519_SCALARBYTES", "crypto_core_ed25519_UNIFORMBYTES", "crypto_core_hchacha20_CONSTBYTES", "crypto_core_hchacha20_INPUTBYTES", "crypto_core_hchacha20_KEYBYTES", "crypto_core_hchacha20_OUTPUTBYTES", "crypto_core_hsalsa20_CONSTBYTES", "crypto_core_hsalsa20_INPUTBYTES", "crypto_core_hsalsa20_KEYBYTES", "crypto_core_hsalsa20_OUTPUTBYTES", "crypto_core_ristretto255_BYTES", "crypto_core_ristretto255_HASHBYTES", "crypto_core_ristretto255_NONREDUCEDSCALARBYTES", "crypto_core_ristretto255_SCALARBYTES", "crypto_core_salsa2012_CONSTBYTES", "crypto_core_salsa2012_INPUTBYTES", "crypto_core_salsa2012_KEYBYTES", "crypto_core_salsa2012_OUTPUTBYTES", "crypto_core_salsa208_CONSTBYTES", "crypto_core_salsa208_INPUTBYTES", "crypto_core_salsa208_KEYBYTES", "crypto_core_salsa208_OUTPUTBYTES", "crypto_core_salsa20_CONSTBYTES", "crypto_core_salsa20_INPUTBYTES", "crypto_core_salsa20_KEYBYTES", "crypto_core_salsa20_OUTPUTBYTES", "crypto_generichash_BYTES", "crypto_generichash_BYTES_MAX", "crypto_generichash_BYTES_MIN", "crypto_generichash_KEYBYTES", "crypto_generichash_KEYBYTES_MAX", "crypto_generichash_KEYBYTES_MIN", "crypto_generichash_blake2b_BYTES", "crypto_generichash_blake2b_BYTES_MAX", "crypto_generichash_blake2b_BYTES_MIN", "crypto_generichash_blake2b_KEYBYTES", "crypto_generichash_blake2b_KEYBYTES_MAX", "crypto_generichash_blake2b_KEYBYTES_MIN", "crypto_generichash_blake2b_PERSONALBYTES", "crypto_generichash_blake2b_SALTBYTES", "crypto_hash_BYTES", "crypto_hash_sha256_BYTES", "crypto_hash_sha3256_BYTES", "crypto_hash_sha3512_BYTES", "crypto_hash_sha512_BYTES", "crypto_ipcrypt_BYTES", "crypto_ipcrypt_KEYBYTES", "crypto_ipcrypt_NDX_INPUTBYTES", "crypto_ipcrypt_NDX_KEYBYTES", "crypto_ipcrypt_NDX_OUTPUTBYTES", "crypto_ipcrypt_NDX_TWEAKBYTES", "crypto_ipcrypt_ND_INPUTBYTES", "crypto_ipcrypt_ND_KEYBYTES", "crypto_ipcrypt_ND_OUTPUTBYTES", "crypto_ipcrypt_ND_TWEAKBYTES", "crypto_ipcrypt_PFX_BYTES", "crypto_ipcrypt_PFX_KEYBYTES", "crypto_kdf_BYTES_MAX", "crypto_kdf_BYTES_MIN", "crypto_kdf_CONTEXTBYTES", "crypto_kdf_KEYBYTES", "crypto_kdf_blake2b_BYTES_MAX", "crypto_kdf_blake2b_BYTES_MIN", "crypto_kdf_blake2b_CONTEXTBYTES", "crypto_kdf_blake2b_KEYBYTES", "crypto_kdf_hkdf_sha256_BYTES_MAX", "crypto_kdf_hkdf_sha256_BYTES_MIN", "crypto_kdf_hkdf_sha256_KEYBYTES", "crypto_kdf_hkdf_sha512_BYTES_MAX", "crypto_kdf_hkdf_sha512_BYTES_MIN", "crypto_kdf_hkdf_sha512_KEYBYTES", "crypto_kem_CIPHERTEXTBYTES", "crypto_kem_PUBLICKEYBYTES", "crypto_kem_SECRETKEYBYTES", "crypto_kem_SEEDBYTES", "crypto_kem_SHAREDSECRETBYTES", "crypto_kem_mlkem768_CIPHERTEXTBYTES", "crypto_kem_mlkem768_PUBLICKEYBYTES", "crypto_kem_mlkem768_SECRETKEYBYTES", "crypto_kem_mlkem768_SEEDBYTES", "crypto_kem_mlkem768_SHAREDSECRETBYTES", "crypto_kem_xwing_CIPHERTEXTBYTES", "crypto_kem_xwing_PUBLICKEYBYTES", "crypto_kem_xwing_SECRETKEYBYTES", "crypto_kem_xwing_SEEDBYTES", "crypto_kem_xwing_SHAREDSECRETBYTES", "crypto_kx_PUBLICKEYBYTES", "crypto_kx_SECRETKEYBYTES", "crypto_kx_SEEDBYTES", "crypto_kx_SESSIONKEYBYTES", "crypto_onetimeauth_BYTES", "crypto_onetimeauth_KEYBYTES", "crypto_onetimeauth_poly1305_BYTES", "crypto_onetimeauth_poly1305_KEYBYTES", "crypto_pwhash_ALG_ARGON2I13", "crypto_pwhash_ALG_ARGON2ID13", "crypto_pwhash_ALG_DEFAULT", "crypto_pwhash_BYTES_MAX", "crypto_pwhash_BYTES_MIN", "crypto_pwhash_MEMLIMIT_INTERACTIVE", "crypto_pwhash_MEMLIMIT_MAX", "crypto_pwhash_MEMLIMIT_MIN", "crypto_pwhash_MEMLIMIT_MODERATE", "crypto_pwhash_MEMLIMIT_SENSITIVE", "crypto_pwhash_OPSLIMIT_INTERACTIVE", "crypto_pwhash_OPSLIMIT_MAX", "crypto_pwhash_OPSLIMIT_MIN", "crypto_pwhash_OPSLIMIT_MODERATE", "crypto_pwhash_OPSLIMIT_SENSITIVE", "crypto_pwhash_PASSWD_MAX", "crypto_pwhash_PASSWD_MIN", "crypto_pwhash_SALTBYTES", "crypto_pwhash_STRBYTES", "crypto_pwhash_argon2i_BYTES_MAX", "crypto_pwhash_argon2i_BYTES_MIN", "crypto_pwhash_argon2i_MEMLIMIT_INTERACTIVE", "crypto_pwhash_argon2i_MEMLIMIT_MAX", "crypto_pwhash_argon2i_MEMLIMIT_MIN", "crypto_pwhash_argon2i_MEMLIMIT_MODERATE", "crypto_pwhash_argon2i_MEMLIMIT_SENSITIVE", "crypto_pwhash_argon2i_OPSLIMIT_INTERACTIVE", "crypto_pwhash_argon2i_OPSLIMIT_MAX", "crypto_pwhash_argon2i_OPSLIMIT_MIN", "crypto_pwhash_argon2i_OPSLIMIT_MODERATE", "crypto_pwhash_argon2i_OPSLIMIT_SENSITIVE", "crypto_pwhash_argon2i_PASSWD_MAX", "crypto_pwhash_argon2i_PASSWD_MIN", "crypto_pwhash_argon2i_SALTBYTES", "crypto_pwhash_argon2i_STRBYTES", "crypto_pwhash_argon2id_BYTES_MAX", "crypto_pwhash_argon2id_BYTES_MIN", "crypto_pwhash_argon2id_MEMLIMIT_INTERACTIVE", "crypto_pwhash_argon2id_MEMLIMIT_MAX", "crypto_pwhash_argon2id_MEMLIMIT_MIN", "crypto_pwhash_argon2id_MEMLIMIT_MODERATE", "crypto_pwhash_argon2id_MEMLIMIT_SENSITIVE", "crypto_pwhash_argon2id_OPSLIMIT_INTERACTIVE", "crypto_pwhash_argon2id_OPSLIMIT_MAX", "crypto_pwhash_argon2id_OPSLIMIT_MIN", "crypto_pwhash_argon2id_OPSLIMIT_MODERATE", "crypto_pwhash_argon2id_OPSLIMIT_SENSITIVE", "crypto_pwhash_argon2id_PASSWD_MAX", "crypto_pwhash_argon2id_PASSWD_MIN", "crypto_pwhash_argon2id_SALTBYTES", "crypto_pwhash_argon2id_STRBYTES", "crypto_pwhash_scryptsalsa208sha256_BYTES_MAX", "crypto_pwhash_scryptsalsa208sha256_BYTES_MIN", "crypto_pwhash_scryptsalsa208sha256_MEMLIMIT_INTERACTIVE", "crypto_pwhash_scryptsalsa208sha256_MEMLIMIT_MAX", "crypto_pwhash_scryptsalsa208sha256_MEMLIMIT_MIN", "crypto_pwhash_scryptsalsa208sha256_MEMLIMIT_SENSITIVE", "crypto_pwhash_scryptsalsa208sha256_OPSLIMIT_INTERACTIVE", "crypto_pwhash_scryptsalsa208sha256_OPSLIMIT_MAX", "crypto_pwhash_scryptsalsa208sha256_OPSLIMIT_MIN", "crypto_pwhash_scryptsalsa208sha256_OPSLIMIT_SENSITIVE", "crypto_pwhash_scryptsalsa208sha256_PASSWD_MAX", "crypto_pwhash_scryptsalsa208sha256_PASSWD_MIN", "crypto_pwhash_scryptsalsa208sha256_SALTBYTES", "crypto_pwhash_scryptsalsa208sha256_STRBYTES", "crypto_scalarmult_BYTES", "crypto_scalarmult_SCALARBYTES", "crypto_scalarmult_curve25519_BYTES", "crypto_scalarmult_curve25519_SCALARBYTES", "crypto_scalarmult_ed25519_BYTES", "crypto_scalarmult_ed25519_SCALARBYTES", "crypto_scalarmult_ristretto255_BYTES", "crypto_scalarmult_ristretto255_SCALARBYTES", "crypto_secretbox_KEYBYTES", "crypto_secretbox_MACBYTES", "crypto_secretbox_MESSAGEBYTES_MAX", "crypto_secretbox_NONCEBYTES", "crypto_secretbox_xchacha20poly1305_KEYBYTES", "crypto_secretbox_xchacha20poly1305_MACBYTES", "crypto_secretbox_xchacha20poly1305_MESSAGEBYTES_MAX", "crypto_secretbox_xchacha20poly1305_NONCEBYTES", "crypto_secretbox_xsalsa20poly1305_KEYBYTES", "crypto_secretbox_xsalsa20poly1305_MACBYTES", "crypto_secretbox_xsalsa20poly1305_MESSAGEBYTES_MAX", "crypto_secretbox_xsalsa20poly1305_NONCEBYTES", "crypto_secretstream_xchacha20poly1305_ABYTES", "crypto_secretstream_xchacha20poly1305_HEADERBYTES", "crypto_secretstream_xchacha20poly1305_KEYBYTES", "crypto_secretstream_xchacha20poly1305_MESSAGEBYTES_MAX", "crypto_secretstream_xchacha20poly1305_TAG_FINAL", "crypto_secretstream_xchacha20poly1305_TAG_MESSAGE", "crypto_secretstream_xchacha20poly1305_TAG_PUSH", "crypto_secretstream_xchacha20poly1305_TAG_REKEY", "crypto_shorthash_BYTES", "crypto_shorthash_KEYBYTES", "crypto_shorthash_siphash24_BYTES", "crypto_shorthash_siphash24_KEYBYTES", "crypto_shorthash_siphashx24_BYTES", "crypto_shorthash_siphashx24_KEYBYTES", "crypto_sign_BYTES", "crypto_sign_MESSAGEBYTES_MAX", "crypto_sign_PUBLICKEYBYTES", "crypto_sign_SECRETKEYBYTES", "crypto_sign_SEEDBYTES", "crypto_sign_ed25519_BYTES", "crypto_sign_ed25519_MESSAGEBYTES_MAX", "crypto_sign_ed25519_PUBLICKEYBYTES", "crypto_sign_ed25519_SECRETKEYBYTES", "crypto_sign_ed25519_SEEDBYTES", "crypto_stream_KEYBYTES", "crypto_stream_MESSAGEBYTES_MAX", "crypto_stream_NONCEBYTES", "crypto_stream_chacha20_IETF_KEYBYTES", "crypto_stream_chacha20_IETF_MESSAGEBYTES_MAX", "crypto_stream_chacha20_IETF_NONCEBYTES", "crypto_stream_chacha20_KEYBYTES", "crypto_stream_chacha20_MESSAGEBYTES_MAX", "crypto_stream_chacha20_NONCEBYTES", "crypto_stream_chacha20_ietf_KEYBYTES", "crypto_stream_chacha20_ietf_MESSAGEBYTES_MAX", "crypto_stream_chacha20_ietf_NONCEBYTES", "crypto_stream_salsa2012_KEYBYTES", "crypto_stream_salsa2012_MESSAGEBYTES_MAX", "crypto_stream_salsa2012_NONCEBYTES", "crypto_stream_salsa208_KEYBYTES", "crypto_stream_salsa208_MESSAGEBYTES_MAX", "crypto_stream_salsa208_NONCEBYTES", "crypto_stream_salsa20_KEYBYTES", "crypto_stream_salsa20_MESSAGEBYTES_MAX", "crypto_stream_salsa20_NONCEBYTES", "crypto_stream_xchacha20_KEYBYTES", "crypto_stream_xchacha20_MESSAGEBYTES_MAX", "crypto_stream_xchacha20_NONCEBYTES", "crypto_stream_xsalsa20_KEYBYTES", "crypto_stream_xsalsa20_MESSAGEBYTES_MAX", "crypto_stream_xsalsa20_NONCEBYTES", "crypto_verify_16_BYTES", "crypto_verify_32_BYTES", "crypto_verify_64_BYTES", "crypto_xof_shake128_BLOCKBYTES", "crypto_xof_shake128_STATEBYTES", "crypto_xof_shake256_BLOCKBYTES", "crypto_xof_shake256_STATEBYTES", "crypto_xof_turboshake128_BLOCKBYTES", "crypto_xof_turboshake128_STATEBYTES", "crypto_xof_turboshake256_BLOCKBYTES", "crypto_xof_turboshake256_STATEBYTES"];
    for (_3 = 0; _3 < n3.length; _3++) "function" == typeof (c3 = r["_" + n3[_3].toLowerCase()]) && (t[n3[_3]] = c3());
    var s3 = ["SODIUM_VERSION_STRING", "crypto_kem_PRIMITIVE", "crypto_pwhash_STRPREFIX", "crypto_pwhash_argon2i_STRPREFIX", "crypto_pwhash_argon2id_STRPREFIX", "crypto_pwhash_scryptsalsa208sha256_STRPREFIX"];
    for (_3 = 0; _3 < s3.length; _3++) {
      var c3;
      "function" == typeof (c3 = r["_" + s3[_3].toLowerCase()]) && (t[s3[_3]] = r.UTF8ToString(c3()));
    }
  })();
  var a2 = new Uint8Array([98, 97, 108, 108, 115]), _2 = t.randombytes_buf(t.crypto_secretbox_NONCEBYTES), n2 = t.randombytes_buf(t.crypto_secretbox_KEYBYTES), s2 = t.crypto_secretbox_easy(a2, _2, n2), c2 = t.crypto_secretbox_open_easy(s2, _2, n2);
  if (!t.memcmp(a2, c2)) throw new Error("Initialization self-test failed");
});
function c() {
  return Object.keys(t).sort();
}
function p(e) {
  if (!(e instanceof Uint8Array)) throw new TypeError("Only Uint8Array instances can be incremented");
  for (var r2 = 256, t2 = 0, a2 = e.length; t2 < a2; t2++) r2 >>= 8, r2 += e[t2], e[t2] = 255 & r2;
}
function o(e, r2) {
  if (!(e instanceof Uint8Array && r2 instanceof Uint8Array)) throw new TypeError("Only Uint8Array instances can be added");
  var t2 = e.length, a2 = 0, _2 = 0;
  if (r2.length !== e.length) throw new TypeError("Arguments must have the same length");
  for (_2 = 0; _2 < t2; _2++) a2 >>= 8, a2 += e[_2] + r2[_2], e[_2] = 255 & a2;
}
function h(e) {
  if (!(e instanceof Uint8Array)) throw new TypeError("Only Uint8Array instances can be checked");
  for (var r2 = 0, t2 = 0, a2 = e.length; t2 < a2; t2++) r2 |= e[t2];
  return 0 === r2;
}
function y(e) {
  if (!(e instanceof Uint8Array)) throw new TypeError("Only Uint8Array instances can be wiped");
  for (var r2 = 0, t2 = e.length; r2 < t2; r2++) e[r2] = 0;
}
function i(e, r2) {
  if (!(e instanceof Uint8Array && r2 instanceof Uint8Array)) throw new TypeError("Only Uint8Array instances can be compared");
  if (e.length !== r2.length) throw new TypeError("Only instances of identical length can be compared");
  for (var t2 = 0, a2 = 0, _2 = e.length; a2 < _2; a2++) t2 |= e[a2] ^ r2[a2];
  return 0 === t2;
}
function l(e, r2) {
  if (!(e instanceof Uint8Array && r2 instanceof Uint8Array)) throw new TypeError("Only Uint8Array instances can be compared");
  if (e.length !== r2.length) throw new TypeError("Only instances of identical length can be compared");
  for (var t2 = 0, a2 = 1, _2 = e.length; _2-- > 0; ) t2 |= r2[_2] - e[_2] >> 8 & a2, a2 &= (r2[_2] ^ e[_2]) - 1 >> 8;
  return t2 + t2 + a2 - 1;
}
function u(e, t2) {
  if (!(e instanceof Uint8Array)) throw new TypeError("buffer must be a Uint8Array");
  if ((t2 |= 0) <= 0) throw new Error("block size must be > 0");
  var a2, _2 = [], n2 = A2(4), s2 = 1, c2 = 0, p2 = 0 | e.length, o2 = new B(p2 + t2);
  _2.push(n2), _2.push(o2.address);
  for (var h2 = o2.address, y2 = o2.address + p2 + t2; h2 < y2; h2++) r.HEAPU8[h2] = e[c2], c2 += s2 = 1 & ~((65535 & ((p2 -= s2) >>> 48 | p2 >>> 32 | p2 >>> 16 | p2)) - 1 >> 16);
  return 0 !== r._sodium_pad(n2, o2.address, e.length, t2, o2.length) && N(_2, "internal error"), o2.length = r.getValue(n2, "i32"), a2 = o2.to_Uint8Array(), M(_2), a2;
}
function d(e, t2) {
  if (!(e instanceof Uint8Array)) throw new TypeError("buffer must be a Uint8Array");
  if ((t2 |= 0) <= 0) throw new Error("block size must be > 0");
  var a2 = [], _2 = K(e), n2 = A2(4);
  return a2.push(_2), a2.push(n2), 0 !== r._sodium_unpad(n2, _2, e.length, t2) && N(a2, "unsupported/invalid padding"), e = (e = new Uint8Array(e)).subarray(0, r.getValue(n2, "i32")), M(a2), e;
}
function v(e) {
  if ("function" == typeof TextEncoder) return new TextEncoder().encode(e);
  e = unescape(encodeURIComponent(e));
  for (var r2 = new Uint8Array(e.length), t2 = 0, a2 = e.length; t2 < a2; t2++) r2[t2] = e.charCodeAt(t2);
  return r2;
}
function g(e) {
  if ("function" == typeof TextDecoder) return new TextDecoder("utf-8", { fatal: true }).decode(e);
  var r2 = 8192, t2 = Math.ceil(e.length / r2);
  if (t2 <= 1) try {
    return decodeURIComponent(escape(String.fromCharCode.apply(null, e)));
  } catch (e2) {
    throw new TypeError("The encoded data was not valid.");
  }
  for (var a2 = "", _2 = 0, n2 = 0; n2 < t2; n2++) {
    var s2 = Array.prototype.slice.call(e, n2 * r2 + _2, (n2 + 1) * r2 + _2);
    if (0 !== s2.length) {
      var c2, p2 = s2.length, o2 = 0;
      do {
        var h2 = s2[--p2];
        h2 >= 240 ? (o2 = 4, c2 = true) : h2 >= 224 ? (o2 = 3, c2 = true) : h2 >= 192 ? (o2 = 2, c2 = true) : h2 < 128 && (o2 = 1, c2 = true);
      } while (!c2);
      for (var y2 = o2 - (s2.length - p2), i2 = 0; i2 < y2; i2++) _2--, s2.pop();
      a2 += g(s2);
    }
  }
  return a2;
}
function b(e) {
  var t2, a2 = [], _2 = new B((e = O(a2, e, "input")).length / 2), n2 = K(e), s2 = A2(4);
  return a2.push(n2), a2.push(_2.address), a2.push(s2), 0 !== r._sodium_hex2bin(_2.address, _2.length, n2, e.length, 0, 0, s2) && N(a2, "invalid input"), r.getValue(s2, "i32") - n2 !== e.length && N(a2, "incomplete input"), t2 = _2.to_Uint8Array(), M(a2), t2;
}
function f(e) {
  e = O(null, e, "input");
  for (var r2, t2, a2, _2 = "", n2 = 0; n2 < e.length; n2++) a2 = 87 + (t2 = 15 & e[n2]) + (t2 - 10 >> 8 & -39) << 8 | 87 + (r2 = e[n2] >>> 4) + (r2 - 10 >> 8 & -39), _2 += String.fromCharCode(255 & a2) + String.fromCharCode(a2 >>> 8);
  return _2;
}
var m = { ORIGINAL: 1, ORIGINAL_NO_PADDING: 3, URLSAFE: 5, URLSAFE_NO_PADDING: 7 };
function k(e) {
  if (void 0 === e) return m.URLSAFE_NO_PADDING;
  if (e !== m.ORIGINAL && e !== m.ORIGINAL_NO_PADDING && e !== m.URLSAFE && e !== m.URLSAFE_NO_PADDING) throw new Error("unsupported base64 variant");
  return e;
}
function x(e, t2) {
  t2 = k(t2);
  var a2, _2 = [], n2 = new B(3 * (e = O(_2, e, "input")).length / 4), s2 = K(e), c2 = A2(4), p2 = A2(4);
  return _2.push(s2), _2.push(n2.address), _2.push(c2), _2.push(p2), 0 !== r._sodium_base642bin(n2.address, n2.length, s2, e.length, 0, c2, p2, t2) && N(_2, "invalid input"), r.getValue(p2, "i32") - s2 !== e.length && N(_2, "incomplete input"), n2.length = r.getValue(c2, "i32"), a2 = n2.to_Uint8Array(), M(_2), a2;
}
function E(e, t2) {
  t2 = k(t2);
  var a2 = [];
  e = O(a2, e, "input");
  var _2, n2 = 0 | Math.floor(e.length / 3), s2 = e.length - 3 * n2, c2 = 4 * n2 + (0 !== s2 ? 2 & t2 ? 2 + (s2 >>> 1) : 4 : 0), p2 = new B(c2 + 1), o2 = K(e);
  return a2.push(o2), a2.push(p2.address), 0 === r._sodium_bin2base64(p2.address, p2.length, o2, e.length, t2) && N(a2, "conversion failed"), p2.length = c2, _2 = g(p2.to_Uint8Array()), M(a2), _2;
}
function T() {
  return ["uint8array", "text", "hex", "base64"];
}
function S(e, r2) {
  var t2 = r2 || "uint8array";
  if (!w(t2)) throw new Error(t2 + " output format is not available");
  if (e instanceof B) {
    if ("uint8array" === t2) return e.to_Uint8Array();
    if ("text" === t2) return g(e.to_Uint8Array());
    if ("hex" === t2) return f(e.to_Uint8Array());
    if ("base64" === t2) return E(e.to_Uint8Array(), m.URLSAFE_NO_PADDING);
    throw new Error('What is output format "' + t2 + '"?');
  }
  if ("object" == typeof e) {
    for (var a2 = Object.keys(e), _2 = {}, n2 = 0; n2 < a2.length; n2++) _2[a2[n2]] = S(e[a2[n2]], t2);
    return _2;
  }
  if ("string" == typeof e) return e;
  throw new TypeError("Cannot format output");
}
function w(e) {
  for (var r2 = ["uint8array", "text", "hex", "base64"], t2 = 0; t2 < r2.length; t2++) if (r2[t2] === e) return true;
  return false;
}
function Y(e) {
  if (e) {
    if ("string" != typeof e) throw new TypeError("When defined, the output format must be a string");
    if (!w(e)) throw new Error(e + " is not a supported output format");
  }
}
function B(e) {
  this.length = e, this.address = A2(e);
}
function K(e) {
  var t2 = A2(e.length);
  return r.HEAPU8.set(e, t2), t2;
}
function A2(e) {
  var t2 = r._malloc(e);
  if (0 === t2) throw { message: "_malloc() failed", length: e };
  return t2;
}
function I(e) {
  r._free(e);
}
function M(e) {
  if (e) for (var r2 = 0; r2 < e.length; r2++) I(e[r2]);
}
function N(e, r2) {
  throw M(e), new Error(r2);
}
function L(e, r2) {
  throw M(e), new TypeError(r2);
}
function U(e, r2, t2) {
  null == r2 && L(e, t2 + " cannot be null or undefined");
}
function O(e, r2, t2) {
  return U(e, r2, t2), r2 instanceof Uint8Array ? r2 : "string" == typeof r2 ? v(r2) : void L(e, "unsupported input type for " + t2);
}
function C(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = null;
  null != e && (p2 = K(e = O(c2, e, "secret_nonce")), e.length, c2.push(p2)), t2 = O(c2, t2, "ciphertext");
  var o2, h2 = r._crypto_aead_aegis128l_abytes(), y2 = t2.length;
  y2 < h2 && L(c2, "ciphertext is too short"), o2 = K(t2), c2.push(o2);
  var i2 = null, l2 = 0;
  null != a2 && (i2 = K(a2 = O(c2, a2, "additional_data")), l2 = a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var u2, d2 = 0 | r._crypto_aead_aegis128l_npubbytes();
  _2.length !== d2 && L(c2, "invalid public_nonce length"), u2 = K(_2), c2.push(u2), n2 = O(c2, n2, "key");
  var v2, g2 = 0 | r._crypto_aead_aegis128l_keybytes();
  n2.length !== g2 && L(c2, "invalid key length"), v2 = K(n2), c2.push(v2);
  var b2 = new B(y2 - r._crypto_aead_aegis128l_abytes() | 0), f2 = b2.address;
  if (c2.push(f2), 0 === r._crypto_aead_aegis128l_decrypt(f2, null, p2, o2, y2, 0, i2, l2, 0, u2, v2)) {
    var m2 = S(b2, s2);
    return M(c2), m2;
  }
  N(c2, "ciphertext cannot be decrypted using that key");
}
function R(e, t2, a2, _2, n2, s2, c2) {
  var p2 = [];
  Y(c2);
  var o2 = null;
  null != e && (o2 = K(e = O(p2, e, "secret_nonce")), e.length, p2.push(o2));
  var h2 = K(t2 = O(p2, t2, "ciphertext")), y2 = t2.length;
  p2.push(h2), a2 = O(p2, a2, "mac");
  var i2, l2 = 0 | r._crypto_aead_aegis128l_abytes();
  a2.length !== l2 && L(p2, "invalid mac length"), i2 = K(a2), p2.push(i2);
  var u2 = null, d2 = 0;
  null != _2 && (u2 = K(_2 = O(p2, _2, "additional_data")), d2 = _2.length, p2.push(u2)), n2 = O(p2, n2, "public_nonce");
  var v2, g2 = 0 | r._crypto_aead_aegis128l_npubbytes();
  n2.length !== g2 && L(p2, "invalid public_nonce length"), v2 = K(n2), p2.push(v2), s2 = O(p2, s2, "key");
  var b2, f2 = 0 | r._crypto_aead_aegis128l_keybytes();
  s2.length !== f2 && L(p2, "invalid key length"), b2 = K(s2), p2.push(b2);
  var m2 = new B(0 | y2), k2 = m2.address;
  if (p2.push(k2), 0 === r._crypto_aead_aegis128l_decrypt_detached(k2, o2, h2, y2, 0, i2, u2, d2, 0, v2, b2)) {
    var x2 = S(m2, c2);
    return M(p2), x2;
  }
  N(p2, "ciphertext cannot be decrypted using that key");
}
function P(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "message")), o2 = e.length;
  c2.push(p2);
  var h2 = null, y2 = 0;
  null != t2 && (h2 = K(t2 = O(c2, t2, "additional_data")), y2 = t2.length, c2.push(h2));
  var i2 = null;
  null != a2 && (i2 = K(a2 = O(c2, a2, "secret_nonce")), a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var l2, u2 = 0 | r._crypto_aead_aegis128l_npubbytes();
  _2.length !== u2 && L(c2, "invalid public_nonce length"), l2 = K(_2), c2.push(l2), n2 = O(c2, n2, "key");
  var d2, v2 = 0 | r._crypto_aead_aegis128l_keybytes();
  n2.length !== v2 && L(c2, "invalid key length"), d2 = K(n2), c2.push(d2);
  var g2 = new B(o2 + r._crypto_aead_aegis128l_abytes() | 0), b2 = g2.address;
  if (c2.push(b2), 0 === r._crypto_aead_aegis128l_encrypt(b2, null, p2, o2, 0, h2, y2, 0, i2, l2, d2)) {
    var f2 = S(g2, s2);
    return M(c2), f2;
  }
  N(c2, "invalid usage");
}
function X(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "message")), o2 = e.length;
  c2.push(p2);
  var h2 = null, y2 = 0;
  null != t2 && (h2 = K(t2 = O(c2, t2, "additional_data")), y2 = t2.length, c2.push(h2));
  var i2 = null;
  null != a2 && (i2 = K(a2 = O(c2, a2, "secret_nonce")), a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var l2, u2 = 0 | r._crypto_aead_aegis128l_npubbytes();
  _2.length !== u2 && L(c2, "invalid public_nonce length"), l2 = K(_2), c2.push(l2), n2 = O(c2, n2, "key");
  var d2, v2 = 0 | r._crypto_aead_aegis128l_keybytes();
  n2.length !== v2 && L(c2, "invalid key length"), d2 = K(n2), c2.push(d2);
  var g2 = new B(0 | o2), b2 = g2.address;
  c2.push(b2);
  var f2 = new B(0 | r._crypto_aead_aegis128l_abytes()), m2 = f2.address;
  if (c2.push(m2), 0 === r._crypto_aead_aegis128l_encrypt_detached(b2, m2, null, p2, o2, 0, h2, y2, 0, i2, l2, d2)) {
    var k2 = S({ ciphertext: g2, mac: f2 }, s2);
    return M(c2), k2;
  }
  N(c2, "invalid usage");
}
function D(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_aead_aegis128l_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_aead_aegis128l_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function G(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = null;
  null != e && (p2 = K(e = O(c2, e, "secret_nonce")), e.length, c2.push(p2)), t2 = O(c2, t2, "ciphertext");
  var o2, h2 = r._crypto_aead_aegis256_abytes(), y2 = t2.length;
  y2 < h2 && L(c2, "ciphertext is too short"), o2 = K(t2), c2.push(o2);
  var i2 = null, l2 = 0;
  null != a2 && (i2 = K(a2 = O(c2, a2, "additional_data")), l2 = a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var u2, d2 = 0 | r._crypto_aead_aegis256_npubbytes();
  _2.length !== d2 && L(c2, "invalid public_nonce length"), u2 = K(_2), c2.push(u2), n2 = O(c2, n2, "key");
  var v2, g2 = 0 | r._crypto_aead_aegis256_keybytes();
  n2.length !== g2 && L(c2, "invalid key length"), v2 = K(n2), c2.push(v2);
  var b2 = new B(y2 - r._crypto_aead_aegis256_abytes() | 0), f2 = b2.address;
  if (c2.push(f2), 0 === r._crypto_aead_aegis256_decrypt(f2, null, p2, o2, y2, 0, i2, l2, 0, u2, v2)) {
    var m2 = S(b2, s2);
    return M(c2), m2;
  }
  N(c2, "ciphertext cannot be decrypted using that key");
}
function F(e, t2, a2, _2, n2, s2, c2) {
  var p2 = [];
  Y(c2);
  var o2 = null;
  null != e && (o2 = K(e = O(p2, e, "secret_nonce")), e.length, p2.push(o2));
  var h2 = K(t2 = O(p2, t2, "ciphertext")), y2 = t2.length;
  p2.push(h2), a2 = O(p2, a2, "mac");
  var i2, l2 = 0 | r._crypto_aead_aegis256_abytes();
  a2.length !== l2 && L(p2, "invalid mac length"), i2 = K(a2), p2.push(i2);
  var u2 = null, d2 = 0;
  null != _2 && (u2 = K(_2 = O(p2, _2, "additional_data")), d2 = _2.length, p2.push(u2)), n2 = O(p2, n2, "public_nonce");
  var v2, g2 = 0 | r._crypto_aead_aegis256_npubbytes();
  n2.length !== g2 && L(p2, "invalid public_nonce length"), v2 = K(n2), p2.push(v2), s2 = O(p2, s2, "key");
  var b2, f2 = 0 | r._crypto_aead_aegis256_keybytes();
  s2.length !== f2 && L(p2, "invalid key length"), b2 = K(s2), p2.push(b2);
  var m2 = new B(0 | y2), k2 = m2.address;
  if (p2.push(k2), 0 === r._crypto_aead_aegis256_decrypt_detached(k2, o2, h2, y2, 0, i2, u2, d2, 0, v2, b2)) {
    var x2 = S(m2, c2);
    return M(p2), x2;
  }
  N(p2, "ciphertext cannot be decrypted using that key");
}
function V(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "message")), o2 = e.length;
  c2.push(p2);
  var h2 = null, y2 = 0;
  null != t2 && (h2 = K(t2 = O(c2, t2, "additional_data")), y2 = t2.length, c2.push(h2));
  var i2 = null;
  null != a2 && (i2 = K(a2 = O(c2, a2, "secret_nonce")), a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var l2, u2 = 0 | r._crypto_aead_aegis256_npubbytes();
  _2.length !== u2 && L(c2, "invalid public_nonce length"), l2 = K(_2), c2.push(l2), n2 = O(c2, n2, "key");
  var d2, v2 = 0 | r._crypto_aead_aegis256_keybytes();
  n2.length !== v2 && L(c2, "invalid key length"), d2 = K(n2), c2.push(d2);
  var g2 = new B(o2 + r._crypto_aead_aegis256_abytes() | 0), b2 = g2.address;
  if (c2.push(b2), 0 === r._crypto_aead_aegis256_encrypt(b2, null, p2, o2, 0, h2, y2, 0, i2, l2, d2)) {
    var f2 = S(g2, s2);
    return M(c2), f2;
  }
  N(c2, "invalid usage");
}
function q(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "message")), o2 = e.length;
  c2.push(p2);
  var h2 = null, y2 = 0;
  null != t2 && (h2 = K(t2 = O(c2, t2, "additional_data")), y2 = t2.length, c2.push(h2));
  var i2 = null;
  null != a2 && (i2 = K(a2 = O(c2, a2, "secret_nonce")), a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var l2, u2 = 0 | r._crypto_aead_aegis256_npubbytes();
  _2.length !== u2 && L(c2, "invalid public_nonce length"), l2 = K(_2), c2.push(l2), n2 = O(c2, n2, "key");
  var d2, v2 = 0 | r._crypto_aead_aegis256_keybytes();
  n2.length !== v2 && L(c2, "invalid key length"), d2 = K(n2), c2.push(d2);
  var g2 = new B(0 | o2), b2 = g2.address;
  c2.push(b2);
  var f2 = new B(0 | r._crypto_aead_aegis256_abytes()), m2 = f2.address;
  if (c2.push(m2), 0 === r._crypto_aead_aegis256_encrypt_detached(b2, m2, null, p2, o2, 0, h2, y2, 0, i2, l2, d2)) {
    var k2 = S({ ciphertext: g2, mac: f2 }, s2);
    return M(c2), k2;
  }
  N(c2, "invalid usage");
}
function H(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_aead_aegis256_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_aead_aegis256_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function z(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = null;
  null != e && (p2 = K(e = O(c2, e, "secret_nonce")), e.length, c2.push(p2)), t2 = O(c2, t2, "ciphertext");
  var o2, h2 = r._crypto_aead_chacha20poly1305_abytes(), y2 = t2.length;
  y2 < h2 && L(c2, "ciphertext is too short"), o2 = K(t2), c2.push(o2);
  var i2 = null, l2 = 0;
  null != a2 && (i2 = K(a2 = O(c2, a2, "additional_data")), l2 = a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var u2, d2 = 0 | r._crypto_aead_chacha20poly1305_npubbytes();
  _2.length !== d2 && L(c2, "invalid public_nonce length"), u2 = K(_2), c2.push(u2), n2 = O(c2, n2, "key");
  var v2, g2 = 0 | r._crypto_aead_chacha20poly1305_keybytes();
  n2.length !== g2 && L(c2, "invalid key length"), v2 = K(n2), c2.push(v2);
  var b2 = new B(y2 - r._crypto_aead_chacha20poly1305_abytes() | 0), f2 = b2.address;
  if (c2.push(f2), 0 === r._crypto_aead_chacha20poly1305_decrypt(f2, null, p2, o2, y2, 0, i2, l2, 0, u2, v2)) {
    var m2 = S(b2, s2);
    return M(c2), m2;
  }
  N(c2, "ciphertext cannot be decrypted using that key");
}
function W(e, t2, a2, _2, n2, s2, c2) {
  var p2 = [];
  Y(c2);
  var o2 = null;
  null != e && (o2 = K(e = O(p2, e, "secret_nonce")), e.length, p2.push(o2));
  var h2 = K(t2 = O(p2, t2, "ciphertext")), y2 = t2.length;
  p2.push(h2), a2 = O(p2, a2, "mac");
  var i2, l2 = 0 | r._crypto_box_macbytes();
  a2.length !== l2 && L(p2, "invalid mac length"), i2 = K(a2), p2.push(i2);
  var u2 = null, d2 = 0;
  null != _2 && (u2 = K(_2 = O(p2, _2, "additional_data")), d2 = _2.length, p2.push(u2)), n2 = O(p2, n2, "public_nonce");
  var v2, g2 = 0 | r._crypto_aead_chacha20poly1305_npubbytes();
  n2.length !== g2 && L(p2, "invalid public_nonce length"), v2 = K(n2), p2.push(v2), s2 = O(p2, s2, "key");
  var b2, f2 = 0 | r._crypto_aead_chacha20poly1305_keybytes();
  s2.length !== f2 && L(p2, "invalid key length"), b2 = K(s2), p2.push(b2);
  var m2 = new B(0 | y2), k2 = m2.address;
  if (p2.push(k2), 0 === r._crypto_aead_chacha20poly1305_decrypt_detached(k2, o2, h2, y2, 0, i2, u2, d2, 0, v2, b2)) {
    var x2 = S(m2, c2);
    return M(p2), x2;
  }
  N(p2, "ciphertext cannot be decrypted using that key");
}
function j(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "message")), o2 = e.length;
  c2.push(p2);
  var h2 = null, y2 = 0;
  null != t2 && (h2 = K(t2 = O(c2, t2, "additional_data")), y2 = t2.length, c2.push(h2));
  var i2 = null;
  null != a2 && (i2 = K(a2 = O(c2, a2, "secret_nonce")), a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var l2, u2 = 0 | r._crypto_aead_chacha20poly1305_npubbytes();
  _2.length !== u2 && L(c2, "invalid public_nonce length"), l2 = K(_2), c2.push(l2), n2 = O(c2, n2, "key");
  var d2, v2 = 0 | r._crypto_aead_chacha20poly1305_keybytes();
  n2.length !== v2 && L(c2, "invalid key length"), d2 = K(n2), c2.push(d2);
  var g2 = new B(o2 + r._crypto_aead_chacha20poly1305_abytes() | 0), b2 = g2.address;
  if (c2.push(b2), 0 === r._crypto_aead_chacha20poly1305_encrypt(b2, null, p2, o2, 0, h2, y2, 0, i2, l2, d2)) {
    var f2 = S(g2, s2);
    return M(c2), f2;
  }
  N(c2, "invalid usage");
}
function J(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "message")), o2 = e.length;
  c2.push(p2);
  var h2 = null, y2 = 0;
  null != t2 && (h2 = K(t2 = O(c2, t2, "additional_data")), y2 = t2.length, c2.push(h2));
  var i2 = null;
  null != a2 && (i2 = K(a2 = O(c2, a2, "secret_nonce")), a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var l2, u2 = 0 | r._crypto_aead_chacha20poly1305_npubbytes();
  _2.length !== u2 && L(c2, "invalid public_nonce length"), l2 = K(_2), c2.push(l2), n2 = O(c2, n2, "key");
  var d2, v2 = 0 | r._crypto_aead_chacha20poly1305_keybytes();
  n2.length !== v2 && L(c2, "invalid key length"), d2 = K(n2), c2.push(d2);
  var g2 = new B(0 | o2), b2 = g2.address;
  c2.push(b2);
  var f2 = new B(0 | r._crypto_aead_chacha20poly1305_abytes()), m2 = f2.address;
  if (c2.push(m2), 0 === r._crypto_aead_chacha20poly1305_encrypt_detached(b2, m2, null, p2, o2, 0, h2, y2, 0, i2, l2, d2)) {
    var k2 = S({ ciphertext: g2, mac: f2 }, s2);
    return M(c2), k2;
  }
  N(c2, "invalid usage");
}
function Q(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = null;
  null != e && (p2 = K(e = O(c2, e, "secret_nonce")), e.length, c2.push(p2)), t2 = O(c2, t2, "ciphertext");
  var o2, h2 = r._crypto_aead_chacha20poly1305_ietf_abytes(), y2 = t2.length;
  y2 < h2 && L(c2, "ciphertext is too short"), o2 = K(t2), c2.push(o2);
  var i2 = null, l2 = 0;
  null != a2 && (i2 = K(a2 = O(c2, a2, "additional_data")), l2 = a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var u2, d2 = 0 | r._crypto_aead_chacha20poly1305_ietf_npubbytes();
  _2.length !== d2 && L(c2, "invalid public_nonce length"), u2 = K(_2), c2.push(u2), n2 = O(c2, n2, "key");
  var v2, g2 = 0 | r._crypto_aead_chacha20poly1305_ietf_keybytes();
  n2.length !== g2 && L(c2, "invalid key length"), v2 = K(n2), c2.push(v2);
  var b2 = new B(y2 - r._crypto_aead_chacha20poly1305_ietf_abytes() | 0), f2 = b2.address;
  if (c2.push(f2), 0 === r._crypto_aead_chacha20poly1305_ietf_decrypt(f2, null, p2, o2, y2, 0, i2, l2, 0, u2, v2)) {
    var m2 = S(b2, s2);
    return M(c2), m2;
  }
  N(c2, "ciphertext cannot be decrypted using that key");
}
function Z(e, t2, a2, _2, n2, s2, c2) {
  var p2 = [];
  Y(c2);
  var o2 = null;
  null != e && (o2 = K(e = O(p2, e, "secret_nonce")), e.length, p2.push(o2));
  var h2 = K(t2 = O(p2, t2, "ciphertext")), y2 = t2.length;
  p2.push(h2), a2 = O(p2, a2, "mac");
  var i2, l2 = 0 | r._crypto_box_macbytes();
  a2.length !== l2 && L(p2, "invalid mac length"), i2 = K(a2), p2.push(i2);
  var u2 = null, d2 = 0;
  null != _2 && (u2 = K(_2 = O(p2, _2, "additional_data")), d2 = _2.length, p2.push(u2)), n2 = O(p2, n2, "public_nonce");
  var v2, g2 = 0 | r._crypto_aead_chacha20poly1305_ietf_npubbytes();
  n2.length !== g2 && L(p2, "invalid public_nonce length"), v2 = K(n2), p2.push(v2), s2 = O(p2, s2, "key");
  var b2, f2 = 0 | r._crypto_aead_chacha20poly1305_ietf_keybytes();
  s2.length !== f2 && L(p2, "invalid key length"), b2 = K(s2), p2.push(b2);
  var m2 = new B(0 | y2), k2 = m2.address;
  if (p2.push(k2), 0 === r._crypto_aead_chacha20poly1305_ietf_decrypt_detached(k2, o2, h2, y2, 0, i2, u2, d2, 0, v2, b2)) {
    var x2 = S(m2, c2);
    return M(p2), x2;
  }
  N(p2, "ciphertext cannot be decrypted using that key");
}
function $(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "message")), o2 = e.length;
  c2.push(p2);
  var h2 = null, y2 = 0;
  null != t2 && (h2 = K(t2 = O(c2, t2, "additional_data")), y2 = t2.length, c2.push(h2));
  var i2 = null;
  null != a2 && (i2 = K(a2 = O(c2, a2, "secret_nonce")), a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var l2, u2 = 0 | r._crypto_aead_chacha20poly1305_ietf_npubbytes();
  _2.length !== u2 && L(c2, "invalid public_nonce length"), l2 = K(_2), c2.push(l2), n2 = O(c2, n2, "key");
  var d2, v2 = 0 | r._crypto_aead_chacha20poly1305_ietf_keybytes();
  n2.length !== v2 && L(c2, "invalid key length"), d2 = K(n2), c2.push(d2);
  var g2 = new B(o2 + r._crypto_aead_chacha20poly1305_ietf_abytes() | 0), b2 = g2.address;
  if (c2.push(b2), 0 === r._crypto_aead_chacha20poly1305_ietf_encrypt(b2, null, p2, o2, 0, h2, y2, 0, i2, l2, d2)) {
    var f2 = S(g2, s2);
    return M(c2), f2;
  }
  N(c2, "invalid usage");
}
function ee(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "message")), o2 = e.length;
  c2.push(p2);
  var h2 = null, y2 = 0;
  null != t2 && (h2 = K(t2 = O(c2, t2, "additional_data")), y2 = t2.length, c2.push(h2));
  var i2 = null;
  null != a2 && (i2 = K(a2 = O(c2, a2, "secret_nonce")), a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var l2, u2 = 0 | r._crypto_aead_chacha20poly1305_ietf_npubbytes();
  _2.length !== u2 && L(c2, "invalid public_nonce length"), l2 = K(_2), c2.push(l2), n2 = O(c2, n2, "key");
  var d2, v2 = 0 | r._crypto_aead_chacha20poly1305_ietf_keybytes();
  n2.length !== v2 && L(c2, "invalid key length"), d2 = K(n2), c2.push(d2);
  var g2 = new B(0 | o2), b2 = g2.address;
  c2.push(b2);
  var f2 = new B(0 | r._crypto_aead_chacha20poly1305_ietf_abytes()), m2 = f2.address;
  if (c2.push(m2), 0 === r._crypto_aead_chacha20poly1305_ietf_encrypt_detached(b2, m2, null, p2, o2, 0, h2, y2, 0, i2, l2, d2)) {
    var k2 = S({ ciphertext: g2, mac: f2 }, s2);
    return M(c2), k2;
  }
  N(c2, "invalid usage");
}
function re(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_aead_chacha20poly1305_ietf_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_aead_chacha20poly1305_ietf_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function te(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_aead_chacha20poly1305_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_aead_chacha20poly1305_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function ae(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = null;
  null != e && (p2 = K(e = O(c2, e, "secret_nonce")), e.length, c2.push(p2)), t2 = O(c2, t2, "ciphertext");
  var o2, h2 = r._crypto_aead_xchacha20poly1305_ietf_abytes(), y2 = t2.length;
  y2 < h2 && L(c2, "ciphertext is too short"), o2 = K(t2), c2.push(o2);
  var i2 = null, l2 = 0;
  null != a2 && (i2 = K(a2 = O(c2, a2, "additional_data")), l2 = a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var u2, d2 = 0 | r._crypto_aead_xchacha20poly1305_ietf_npubbytes();
  _2.length !== d2 && L(c2, "invalid public_nonce length"), u2 = K(_2), c2.push(u2), n2 = O(c2, n2, "key");
  var v2, g2 = 0 | r._crypto_aead_xchacha20poly1305_ietf_keybytes();
  n2.length !== g2 && L(c2, "invalid key length"), v2 = K(n2), c2.push(v2);
  var b2 = new B(y2 - r._crypto_aead_xchacha20poly1305_ietf_abytes() | 0), f2 = b2.address;
  if (c2.push(f2), 0 === r._crypto_aead_xchacha20poly1305_ietf_decrypt(f2, null, p2, o2, y2, 0, i2, l2, 0, u2, v2)) {
    var m2 = S(b2, s2);
    return M(c2), m2;
  }
  N(c2, "ciphertext cannot be decrypted using that key");
}
function _e(e, t2, a2, _2, n2, s2, c2) {
  var p2 = [];
  Y(c2);
  var o2 = null;
  null != e && (o2 = K(e = O(p2, e, "secret_nonce")), e.length, p2.push(o2));
  var h2 = K(t2 = O(p2, t2, "ciphertext")), y2 = t2.length;
  p2.push(h2), a2 = O(p2, a2, "mac");
  var i2, l2 = 0 | r._crypto_box_macbytes();
  a2.length !== l2 && L(p2, "invalid mac length"), i2 = K(a2), p2.push(i2);
  var u2 = null, d2 = 0;
  null != _2 && (u2 = K(_2 = O(p2, _2, "additional_data")), d2 = _2.length, p2.push(u2)), n2 = O(p2, n2, "public_nonce");
  var v2, g2 = 0 | r._crypto_aead_xchacha20poly1305_ietf_npubbytes();
  n2.length !== g2 && L(p2, "invalid public_nonce length"), v2 = K(n2), p2.push(v2), s2 = O(p2, s2, "key");
  var b2, f2 = 0 | r._crypto_aead_xchacha20poly1305_ietf_keybytes();
  s2.length !== f2 && L(p2, "invalid key length"), b2 = K(s2), p2.push(b2);
  var m2 = new B(0 | y2), k2 = m2.address;
  if (p2.push(k2), 0 === r._crypto_aead_xchacha20poly1305_ietf_decrypt_detached(k2, o2, h2, y2, 0, i2, u2, d2, 0, v2, b2)) {
    var x2 = S(m2, c2);
    return M(p2), x2;
  }
  N(p2, "ciphertext cannot be decrypted using that key");
}
function ne(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "message")), o2 = e.length;
  c2.push(p2);
  var h2 = null, y2 = 0;
  null != t2 && (h2 = K(t2 = O(c2, t2, "additional_data")), y2 = t2.length, c2.push(h2));
  var i2 = null;
  null != a2 && (i2 = K(a2 = O(c2, a2, "secret_nonce")), a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var l2, u2 = 0 | r._crypto_aead_xchacha20poly1305_ietf_npubbytes();
  _2.length !== u2 && L(c2, "invalid public_nonce length"), l2 = K(_2), c2.push(l2), n2 = O(c2, n2, "key");
  var d2, v2 = 0 | r._crypto_aead_xchacha20poly1305_ietf_keybytes();
  n2.length !== v2 && L(c2, "invalid key length"), d2 = K(n2), c2.push(d2);
  var g2 = new B(o2 + r._crypto_aead_xchacha20poly1305_ietf_abytes() | 0), b2 = g2.address;
  if (c2.push(b2), 0 === r._crypto_aead_xchacha20poly1305_ietf_encrypt(b2, null, p2, o2, 0, h2, y2, 0, i2, l2, d2)) {
    var f2 = S(g2, s2);
    return M(c2), f2;
  }
  N(c2, "invalid usage");
}
function se(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "message")), o2 = e.length;
  c2.push(p2);
  var h2 = null, y2 = 0;
  null != t2 && (h2 = K(t2 = O(c2, t2, "additional_data")), y2 = t2.length, c2.push(h2));
  var i2 = null;
  null != a2 && (i2 = K(a2 = O(c2, a2, "secret_nonce")), a2.length, c2.push(i2)), _2 = O(c2, _2, "public_nonce");
  var l2, u2 = 0 | r._crypto_aead_xchacha20poly1305_ietf_npubbytes();
  _2.length !== u2 && L(c2, "invalid public_nonce length"), l2 = K(_2), c2.push(l2), n2 = O(c2, n2, "key");
  var d2, v2 = 0 | r._crypto_aead_xchacha20poly1305_ietf_keybytes();
  n2.length !== v2 && L(c2, "invalid key length"), d2 = K(n2), c2.push(d2);
  var g2 = new B(0 | o2), b2 = g2.address;
  c2.push(b2);
  var f2 = new B(0 | r._crypto_aead_xchacha20poly1305_ietf_abytes()), m2 = f2.address;
  if (c2.push(m2), 0 === r._crypto_aead_xchacha20poly1305_ietf_encrypt_detached(b2, m2, null, p2, o2, 0, h2, y2, 0, i2, l2, d2)) {
    var k2 = S({ ciphertext: g2, mac: f2 }, s2);
    return M(c2), k2;
  }
  N(c2, "invalid usage");
}
function ce(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_aead_xchacha20poly1305_ietf_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_aead_xchacha20poly1305_ietf_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function pe(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_auth_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_auth_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_auth(h2, n2, s2, 0, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function oe(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_auth_hmacsha256_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_auth_hmacsha256_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_auth_hmacsha256(h2, n2, s2, 0, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function he(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "state_address");
  var _2 = new B(0 | r._crypto_auth_hmacsha256_bytes()), n2 = _2.address;
  if (a2.push(n2), !(0 | r._crypto_auth_hmacsha256_final(e, n2))) {
    var s2 = (r._free(e), S(_2, t2));
    return M(a2), s2;
  }
  N(a2, "invalid usage");
}
function ye(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = null, n2 = 0;
  null != e && (_2 = K(e = O(a2, e, "key")), n2 = e.length, a2.push(_2));
  var s2 = new B(208).address;
  if (!(0 | r._crypto_auth_hmacsha256_init(s2, _2, n2))) {
    var c2 = s2;
    return M(a2), c2;
  }
  N(a2, "invalid usage");
}
function ie(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_auth_hmacsha256_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_auth_hmacsha256_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function le(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_auth_hmacsha256_update(e, n2, s2) && N(_2, "invalid usage"), M(_2);
}
function ue(e, t2, a2) {
  var _2 = [];
  e = O(_2, e, "tag");
  var n2, s2 = 0 | r._crypto_auth_hmacsha256_bytes();
  e.length !== s2 && L(_2, "invalid tag length"), n2 = K(e), _2.push(n2);
  var c2 = K(t2 = O(_2, t2, "message")), p2 = t2.length;
  _2.push(c2), a2 = O(_2, a2, "key");
  var o2, h2 = 0 | r._crypto_auth_hmacsha256_keybytes();
  a2.length !== h2 && L(_2, "invalid key length"), o2 = K(a2), _2.push(o2);
  var y2 = !(0 | r._crypto_auth_hmacsha256_verify(n2, c2, p2, 0, o2));
  return M(_2), y2;
}
function de(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_auth_hmacsha512_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_auth_hmacsha512_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_auth_hmacsha512(h2, n2, s2, 0, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function ve(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_auth_hmacsha512256_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_auth_hmacsha512256_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_auth_hmacsha512256(h2, n2, s2, 0, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function ge(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "state_address");
  var _2 = new B(0 | r._crypto_auth_hmacsha512256_bytes()), n2 = _2.address;
  if (a2.push(n2), !(0 | r._crypto_auth_hmacsha512256_final(e, n2))) {
    var s2 = (r._free(e), S(_2, t2));
    return M(a2), s2;
  }
  N(a2, "invalid usage");
}
function be(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = null, n2 = 0;
  null != e && (_2 = K(e = O(a2, e, "key")), n2 = e.length, a2.push(_2));
  var s2 = new B(416).address;
  if (!(0 | r._crypto_auth_hmacsha512256_init(s2, _2, n2))) {
    var c2 = s2;
    return M(a2), c2;
  }
  N(a2, "invalid usage");
}
function fe(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_auth_hmacsha512256_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_auth_hmacsha512256_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function me(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_auth_hmacsha512256_update(e, n2, s2) && N(_2, "invalid usage"), M(_2);
}
function ke(e, t2, a2) {
  var _2 = [];
  e = O(_2, e, "tag");
  var n2, s2 = 0 | r._crypto_auth_hmacsha512256_bytes();
  e.length !== s2 && L(_2, "invalid tag length"), n2 = K(e), _2.push(n2);
  var c2 = K(t2 = O(_2, t2, "message")), p2 = t2.length;
  _2.push(c2), a2 = O(_2, a2, "key");
  var o2, h2 = 0 | r._crypto_auth_hmacsha512256_keybytes();
  a2.length !== h2 && L(_2, "invalid key length"), o2 = K(a2), _2.push(o2);
  var y2 = !(0 | r._crypto_auth_hmacsha512256_verify(n2, c2, p2, 0, o2));
  return M(_2), y2;
}
function xe(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "state_address");
  var _2 = new B(0 | r._crypto_auth_hmacsha512_bytes()), n2 = _2.address;
  if (a2.push(n2), !(0 | r._crypto_auth_hmacsha512_final(e, n2))) {
    var s2 = (r._free(e), S(_2, t2));
    return M(a2), s2;
  }
  N(a2, "invalid usage");
}
function Ee(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = null, n2 = 0;
  null != e && (_2 = K(e = O(a2, e, "key")), n2 = e.length, a2.push(_2));
  var s2 = new B(416).address;
  if (!(0 | r._crypto_auth_hmacsha512_init(s2, _2, n2))) {
    var c2 = s2;
    return M(a2), c2;
  }
  N(a2, "invalid usage");
}
function Te(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_auth_hmacsha512_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_auth_hmacsha512_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function Se(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_auth_hmacsha512_update(e, n2, s2) && N(_2, "invalid usage"), M(_2);
}
function we(e, t2, a2) {
  var _2 = [];
  e = O(_2, e, "tag");
  var n2, s2 = 0 | r._crypto_auth_hmacsha512_bytes();
  e.length !== s2 && L(_2, "invalid tag length"), n2 = K(e), _2.push(n2);
  var c2 = K(t2 = O(_2, t2, "message")), p2 = t2.length;
  _2.push(c2), a2 = O(_2, a2, "key");
  var o2, h2 = 0 | r._crypto_auth_hmacsha512_keybytes();
  a2.length !== h2 && L(_2, "invalid key length"), o2 = K(a2), _2.push(o2);
  var y2 = !(0 | r._crypto_auth_hmacsha512_verify(n2, c2, p2, 0, o2));
  return M(_2), y2;
}
function Ye(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_auth_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_auth_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function Be(e, t2, a2) {
  var _2 = [];
  e = O(_2, e, "tag");
  var n2, s2 = 0 | r._crypto_auth_bytes();
  e.length !== s2 && L(_2, "invalid tag length"), n2 = K(e), _2.push(n2);
  var c2 = K(t2 = O(_2, t2, "message")), p2 = t2.length;
  _2.push(c2), a2 = O(_2, a2, "key");
  var o2, h2 = 0 | r._crypto_auth_keybytes();
  a2.length !== h2 && L(_2, "invalid key length"), o2 = K(a2), _2.push(o2);
  var y2 = !(0 | r._crypto_auth_verify(n2, c2, p2, 0, o2));
  return M(_2), y2;
}
function Ke(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "publicKey");
  var n2, s2 = 0 | r._crypto_box_publickeybytes();
  e.length !== s2 && L(_2, "invalid publicKey length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "privateKey");
  var c2, p2 = 0 | r._crypto_box_secretkeybytes();
  t2.length !== p2 && L(_2, "invalid privateKey length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_box_beforenmbytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_box_beforenm(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function Ae(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "publicKey");
  var n2, s2 = 0 | r._crypto_box_curve25519xchacha20poly1305_publickeybytes();
  e.length !== s2 && L(_2, "invalid publicKey length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "privateKey");
  var c2, p2 = 0 | r._crypto_box_curve25519xchacha20poly1305_secretkeybytes();
  t2.length !== p2 && L(_2, "invalid privateKey length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_box_curve25519xchacha20poly1305_beforenmbytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_box_curve25519xchacha20poly1305_beforenm(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function Ie(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2);
  var c2 = K(e = O(s2, e, "message")), p2 = e.length;
  s2.push(c2), t2 = O(s2, t2, "nonce");
  var o2, h2 = 0 | r._crypto_box_curve25519xchacha20poly1305_noncebytes();
  t2.length !== h2 && L(s2, "invalid nonce length"), o2 = K(t2), s2.push(o2), a2 = O(s2, a2, "publicKey");
  var y2, i2 = 0 | r._crypto_box_curve25519xchacha20poly1305_publickeybytes();
  a2.length !== i2 && L(s2, "invalid publicKey length"), y2 = K(a2), s2.push(y2), _2 = O(s2, _2, "privateKey");
  var l2, u2 = 0 | r._crypto_box_curve25519xchacha20poly1305_secretkeybytes();
  _2.length !== u2 && L(s2, "invalid privateKey length"), l2 = K(_2), s2.push(l2);
  var d2 = new B(0 | p2), v2 = d2.address;
  s2.push(v2);
  var g2 = new B(0 | r._crypto_box_curve25519xchacha20poly1305_macbytes()), b2 = g2.address;
  if (s2.push(b2), !(0 | r._crypto_box_curve25519xchacha20poly1305_detached(v2, b2, c2, p2, 0, o2, y2, l2))) {
    var f2 = S({ ciphertext: d2, mac: g2 }, n2);
    return M(s2), f2;
  }
  N(s2, "invalid usage");
}
function Me(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "message")), c2 = e.length;
  n2.push(s2), t2 = O(n2, t2, "nonce");
  var p2, o2 = 0 | r._crypto_box_curve25519xchacha20poly1305_noncebytes();
  t2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "sharedKey");
  var h2, y2 = 0 | r._crypto_box_curve25519xchacha20poly1305_beforenmbytes();
  a2.length !== y2 && L(n2, "invalid sharedKey length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(0 | c2), l2 = i2.address;
  n2.push(l2);
  var u2 = new B(0 | r._crypto_box_curve25519xchacha20poly1305_macbytes()), d2 = u2.address;
  if (n2.push(d2), !(0 | r._crypto_box_curve25519xchacha20poly1305_detached_afternm(l2, d2, s2, c2, 0, p2, h2))) {
    var v2 = S({ ciphertext: i2, mac: u2 }, _2);
    return M(n2), v2;
  }
  N(n2, "invalid usage");
}
function Ne(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2);
  var c2 = K(e = O(s2, e, "message")), p2 = e.length;
  s2.push(c2), t2 = O(s2, t2, "nonce");
  var o2, h2 = 0 | r._crypto_box_curve25519xchacha20poly1305_noncebytes();
  t2.length !== h2 && L(s2, "invalid nonce length"), o2 = K(t2), s2.push(o2), a2 = O(s2, a2, "publicKey");
  var y2, i2 = 0 | r._crypto_box_curve25519xchacha20poly1305_publickeybytes();
  a2.length !== i2 && L(s2, "invalid publicKey length"), y2 = K(a2), s2.push(y2), _2 = O(s2, _2, "privateKey");
  var l2, u2 = 0 | r._crypto_box_curve25519xchacha20poly1305_secretkeybytes();
  _2.length !== u2 && L(s2, "invalid privateKey length"), l2 = K(_2), s2.push(l2);
  var d2 = new B(p2 + r._crypto_box_curve25519xchacha20poly1305_macbytes() | 0), v2 = d2.address;
  if (s2.push(v2), !(0 | r._crypto_box_curve25519xchacha20poly1305_easy(v2, c2, p2, 0, o2, y2, l2))) {
    var g2 = S(d2, n2);
    return M(s2), g2;
  }
  N(s2, "invalid usage");
}
function Le(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "message")), c2 = e.length;
  n2.push(s2), t2 = O(n2, t2, "nonce");
  var p2, o2 = 0 | r._crypto_box_curve25519xchacha20poly1305_noncebytes();
  t2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "sharedKey");
  var h2, y2 = 0 | r._crypto_box_curve25519xchacha20poly1305_beforenmbytes();
  a2.length !== y2 && L(n2, "invalid sharedKey length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(c2 + r._crypto_box_curve25519xchacha20poly1305_macbytes() | 0), l2 = i2.address;
  if (n2.push(l2), !(0 | r._crypto_box_curve25519xchacha20poly1305_easy_afternm(l2, s2, c2, 0, p2, h2))) {
    var u2 = S(i2, _2);
    return M(n2), u2;
  }
  N(n2, "invalid usage");
}
function Ue(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_box_curve25519xchacha20poly1305_publickeybytes()), _2 = a2.address;
  t2.push(_2);
  var n2 = new B(0 | r._crypto_box_curve25519xchacha20poly1305_secretkeybytes()), s2 = n2.address;
  t2.push(s2), r._crypto_box_curve25519xchacha20poly1305_keypair(_2, s2);
  var c2 = S({ publicKey: a2, privateKey: n2, keyType: "curve25519" }, e);
  return M(t2), c2;
}
function Oe(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "ciphertext")), o2 = e.length;
  c2.push(p2), t2 = O(c2, t2, "mac");
  var h2, y2 = 0 | r._crypto_box_curve25519xchacha20poly1305_macbytes();
  t2.length !== y2 && L(c2, "invalid mac length"), h2 = K(t2), c2.push(h2), a2 = O(c2, a2, "nonce");
  var i2, l2 = 0 | r._crypto_box_curve25519xchacha20poly1305_noncebytes();
  a2.length !== l2 && L(c2, "invalid nonce length"), i2 = K(a2), c2.push(i2), _2 = O(c2, _2, "publicKey");
  var u2, d2 = 0 | r._crypto_box_curve25519xchacha20poly1305_publickeybytes();
  _2.length !== d2 && L(c2, "invalid publicKey length"), u2 = K(_2), c2.push(u2), n2 = O(c2, n2, "privateKey");
  var v2, g2 = 0 | r._crypto_box_curve25519xchacha20poly1305_secretkeybytes();
  n2.length !== g2 && L(c2, "invalid privateKey length"), v2 = K(n2), c2.push(v2);
  var b2 = new B(0 | o2), f2 = b2.address;
  if (c2.push(f2), !(0 | r._crypto_box_curve25519xchacha20poly1305_open_detached(f2, p2, h2, o2, 0, i2, u2, v2))) {
    var m2 = S(b2, s2);
    return M(c2), m2;
  }
  N(c2, "incorrect key pair for the given ciphertext");
}
function Ce(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2);
  var c2 = K(e = O(s2, e, "ciphertext")), p2 = e.length;
  s2.push(c2), t2 = O(s2, t2, "mac");
  var o2, h2 = 0 | r._crypto_box_curve25519xchacha20poly1305_macbytes();
  t2.length !== h2 && L(s2, "invalid mac length"), o2 = K(t2), s2.push(o2), a2 = O(s2, a2, "nonce");
  var y2, i2 = 0 | r._crypto_box_curve25519xchacha20poly1305_noncebytes();
  a2.length !== i2 && L(s2, "invalid nonce length"), y2 = K(a2), s2.push(y2), _2 = O(s2, _2, "sharedKey");
  var l2, u2 = 0 | r._crypto_box_curve25519xchacha20poly1305_beforenmbytes();
  _2.length !== u2 && L(s2, "invalid sharedKey length"), l2 = K(_2), s2.push(l2);
  var d2 = new B(0 | p2), v2 = d2.address;
  if (s2.push(v2), !(0 | r._crypto_box_curve25519xchacha20poly1305_open_detached_afternm(v2, c2, o2, p2, 0, y2, l2))) {
    var g2 = S(d2, n2);
    return M(s2), g2;
  }
  N(s2, "incorrect secret key for the given ciphertext");
}
function Re(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2), e = O(s2, e, "ciphertext");
  var c2, p2 = r._crypto_box_curve25519xchacha20poly1305_macbytes(), o2 = e.length;
  o2 < p2 && L(s2, "ciphertext is too short"), c2 = K(e), s2.push(c2), t2 = O(s2, t2, "nonce");
  var h2, y2 = 0 | r._crypto_box_curve25519xchacha20poly1305_noncebytes();
  t2.length !== y2 && L(s2, "invalid nonce length"), h2 = K(t2), s2.push(h2), a2 = O(s2, a2, "publicKey");
  var i2, l2 = 0 | r._crypto_box_curve25519xchacha20poly1305_publickeybytes();
  a2.length !== l2 && L(s2, "invalid publicKey length"), i2 = K(a2), s2.push(i2), _2 = O(s2, _2, "privateKey");
  var u2, d2 = 0 | r._crypto_box_curve25519xchacha20poly1305_secretkeybytes();
  _2.length !== d2 && L(s2, "invalid privateKey length"), u2 = K(_2), s2.push(u2);
  var v2 = new B(o2 - r._crypto_box_curve25519xchacha20poly1305_macbytes() | 0), g2 = v2.address;
  if (s2.push(g2), !(0 | r._crypto_box_curve25519xchacha20poly1305_open_easy(g2, c2, o2, 0, h2, i2, u2))) {
    var b2 = S(v2, n2);
    return M(s2), b2;
  }
  N(s2, "incorrect key pair for the given ciphertext");
}
function Pe(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "ciphertext")), c2 = e.length;
  n2.push(s2), t2 = O(n2, t2, "nonce");
  var p2, o2 = 0 | r._crypto_box_curve25519xchacha20poly1305_noncebytes();
  t2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "sharedKey");
  var h2, y2 = 0 | r._crypto_box_curve25519xchacha20poly1305_beforenmbytes();
  a2.length !== y2 && L(n2, "invalid sharedKey length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(c2 - r._crypto_box_curve25519xchacha20poly1305_macbytes() | 0), l2 = i2.address;
  if (n2.push(l2), !(0 | r._crypto_box_curve25519xchacha20poly1305_open_easy_afternm(l2, s2, c2, 0, p2, h2))) {
    var u2 = S(i2, _2);
    return M(n2), u2;
  }
  N(n2, "incorrect secret key for the given ciphertext");
}
function Xe(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "publicKey");
  var c2, p2 = 0 | r._crypto_box_curve25519xchacha20poly1305_publickeybytes();
  t2.length !== p2 && L(_2, "invalid publicKey length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(s2 + r._crypto_box_curve25519xchacha20poly1305_sealbytes() | 0), h2 = o2.address;
  _2.push(h2), r._crypto_box_curve25519xchacha20poly1305_seal(h2, n2, s2, 0, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function De(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), e = O(n2, e, "ciphertext");
  var s2, c2 = r._crypto_box_curve25519xchacha20poly1305_sealbytes(), p2 = e.length;
  p2 < c2 && L(n2, "ciphertext is too short"), s2 = K(e), n2.push(s2), t2 = O(n2, t2, "publicKey");
  var o2, h2 = 0 | r._crypto_box_curve25519xchacha20poly1305_publickeybytes();
  t2.length !== h2 && L(n2, "invalid publicKey length"), o2 = K(t2), n2.push(o2), a2 = O(n2, a2, "secretKey");
  var y2, i2 = 0 | r._crypto_box_curve25519xchacha20poly1305_secretkeybytes();
  a2.length !== i2 && L(n2, "invalid secretKey length"), y2 = K(a2), n2.push(y2);
  var l2 = new B(p2 - r._crypto_box_curve25519xchacha20poly1305_sealbytes() | 0), u2 = l2.address;
  n2.push(u2), r._crypto_box_curve25519xchacha20poly1305_seal_open(u2, s2, p2, 0, o2, y2);
  var d2 = S(l2, _2);
  return M(n2), d2;
}
function Ge(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "seed");
  var _2, n2 = 0 | r._crypto_box_curve25519xchacha20poly1305_seedbytes();
  e.length !== n2 && L(a2, "invalid seed length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_box_curve25519xchacha20poly1305_publickeybytes()), c2 = s2.address;
  a2.push(c2);
  var p2 = new B(0 | r._crypto_box_curve25519xchacha20poly1305_secretkeybytes()), o2 = p2.address;
  if (a2.push(o2), !(0 | r._crypto_box_curve25519xchacha20poly1305_seed_keypair(c2, o2, _2))) {
    var h2 = { publicKey: S(s2, t2), privateKey: S(p2, t2), keyType: "x25519" };
    return M(a2), h2;
  }
  N(a2, "invalid usage");
}
function Fe(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2);
  var c2 = K(e = O(s2, e, "message")), p2 = e.length;
  s2.push(c2), t2 = O(s2, t2, "nonce");
  var o2, h2 = 0 | r._crypto_box_noncebytes();
  t2.length !== h2 && L(s2, "invalid nonce length"), o2 = K(t2), s2.push(o2), a2 = O(s2, a2, "publicKey");
  var y2, i2 = 0 | r._crypto_box_publickeybytes();
  a2.length !== i2 && L(s2, "invalid publicKey length"), y2 = K(a2), s2.push(y2), _2 = O(s2, _2, "privateKey");
  var l2, u2 = 0 | r._crypto_box_secretkeybytes();
  _2.length !== u2 && L(s2, "invalid privateKey length"), l2 = K(_2), s2.push(l2);
  var d2 = new B(0 | p2), v2 = d2.address;
  s2.push(v2);
  var g2 = new B(0 | r._crypto_box_macbytes()), b2 = g2.address;
  if (s2.push(b2), !(0 | r._crypto_box_detached(v2, b2, c2, p2, 0, o2, y2, l2))) {
    var f2 = S({ ciphertext: d2, mac: g2 }, n2);
    return M(s2), f2;
  }
  N(s2, "invalid usage");
}
function Ve(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2);
  var c2 = K(e = O(s2, e, "message")), p2 = e.length;
  s2.push(c2), t2 = O(s2, t2, "nonce");
  var o2, h2 = 0 | r._crypto_box_noncebytes();
  t2.length !== h2 && L(s2, "invalid nonce length"), o2 = K(t2), s2.push(o2), a2 = O(s2, a2, "publicKey");
  var y2, i2 = 0 | r._crypto_box_publickeybytes();
  a2.length !== i2 && L(s2, "invalid publicKey length"), y2 = K(a2), s2.push(y2), _2 = O(s2, _2, "privateKey");
  var l2, u2 = 0 | r._crypto_box_secretkeybytes();
  _2.length !== u2 && L(s2, "invalid privateKey length"), l2 = K(_2), s2.push(l2);
  var d2 = new B(p2 + r._crypto_box_macbytes() | 0), v2 = d2.address;
  if (s2.push(v2), !(0 | r._crypto_box_easy(v2, c2, p2, 0, o2, y2, l2))) {
    var g2 = S(d2, n2);
    return M(s2), g2;
  }
  N(s2, "invalid usage");
}
function qe(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "message")), c2 = e.length;
  n2.push(s2), t2 = O(n2, t2, "nonce");
  var p2, o2 = 0 | r._crypto_box_noncebytes();
  t2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "sharedKey");
  var h2, y2 = 0 | r._crypto_box_beforenmbytes();
  a2.length !== y2 && L(n2, "invalid sharedKey length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(c2 + r._crypto_box_macbytes() | 0), l2 = i2.address;
  if (n2.push(l2), !(0 | r._crypto_box_easy_afternm(l2, s2, c2, 0, p2, h2))) {
    var u2 = S(i2, _2);
    return M(n2), u2;
  }
  N(n2, "invalid usage");
}
function He(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_box_publickeybytes()), _2 = a2.address;
  t2.push(_2);
  var n2 = new B(0 | r._crypto_box_secretkeybytes()), s2 = n2.address;
  if (t2.push(s2), !(0 | r._crypto_box_keypair(_2, s2))) {
    var c2 = { publicKey: S(a2, e), privateKey: S(n2, e), keyType: "x25519" };
    return M(t2), c2;
  }
  N(t2, "internal error");
}
function ze(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2);
  var p2 = K(e = O(c2, e, "ciphertext")), o2 = e.length;
  c2.push(p2), t2 = O(c2, t2, "mac");
  var h2, y2 = 0 | r._crypto_box_macbytes();
  t2.length !== y2 && L(c2, "invalid mac length"), h2 = K(t2), c2.push(h2), a2 = O(c2, a2, "nonce");
  var i2, l2 = 0 | r._crypto_box_noncebytes();
  a2.length !== l2 && L(c2, "invalid nonce length"), i2 = K(a2), c2.push(i2), _2 = O(c2, _2, "publicKey");
  var u2, d2 = 0 | r._crypto_box_publickeybytes();
  _2.length !== d2 && L(c2, "invalid publicKey length"), u2 = K(_2), c2.push(u2), n2 = O(c2, n2, "privateKey");
  var v2, g2 = 0 | r._crypto_box_secretkeybytes();
  n2.length !== g2 && L(c2, "invalid privateKey length"), v2 = K(n2), c2.push(v2);
  var b2 = new B(0 | o2), f2 = b2.address;
  if (c2.push(f2), !(0 | r._crypto_box_open_detached(f2, p2, h2, o2, 0, i2, u2, v2))) {
    var m2 = S(b2, s2);
    return M(c2), m2;
  }
  N(c2, "incorrect key pair for the given ciphertext");
}
function We(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2), e = O(s2, e, "ciphertext");
  var c2, p2 = r._crypto_box_macbytes(), o2 = e.length;
  o2 < p2 && L(s2, "ciphertext is too short"), c2 = K(e), s2.push(c2), t2 = O(s2, t2, "nonce");
  var h2, y2 = 0 | r._crypto_box_noncebytes();
  t2.length !== y2 && L(s2, "invalid nonce length"), h2 = K(t2), s2.push(h2), a2 = O(s2, a2, "publicKey");
  var i2, l2 = 0 | r._crypto_box_publickeybytes();
  a2.length !== l2 && L(s2, "invalid publicKey length"), i2 = K(a2), s2.push(i2), _2 = O(s2, _2, "privateKey");
  var u2, d2 = 0 | r._crypto_box_secretkeybytes();
  _2.length !== d2 && L(s2, "invalid privateKey length"), u2 = K(_2), s2.push(u2);
  var v2 = new B(o2 - r._crypto_box_macbytes() | 0), g2 = v2.address;
  if (s2.push(g2), !(0 | r._crypto_box_open_easy(g2, c2, o2, 0, h2, i2, u2))) {
    var b2 = S(v2, n2);
    return M(s2), b2;
  }
  N(s2, "incorrect key pair for the given ciphertext");
}
function je(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "ciphertext")), c2 = e.length;
  n2.push(s2), t2 = O(n2, t2, "nonce");
  var p2, o2 = 0 | r._crypto_box_noncebytes();
  t2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "sharedKey");
  var h2, y2 = 0 | r._crypto_box_beforenmbytes();
  a2.length !== y2 && L(n2, "invalid sharedKey length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(c2 - r._crypto_box_macbytes() | 0), l2 = i2.address;
  if (n2.push(l2), !(0 | r._crypto_box_open_easy_afternm(l2, s2, c2, 0, p2, h2))) {
    var u2 = S(i2, _2);
    return M(n2), u2;
  }
  N(n2, "incorrect secret key for the given ciphertext");
}
function Je(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "publicKey");
  var c2, p2 = 0 | r._crypto_box_publickeybytes();
  t2.length !== p2 && L(_2, "invalid publicKey length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(s2 + r._crypto_box_sealbytes() | 0), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_box_seal(h2, n2, s2, 0, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function Qe(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), e = O(n2, e, "ciphertext");
  var s2, c2 = r._crypto_box_sealbytes(), p2 = e.length;
  p2 < c2 && L(n2, "ciphertext is too short"), s2 = K(e), n2.push(s2), t2 = O(n2, t2, "publicKey");
  var o2, h2 = 0 | r._crypto_box_publickeybytes();
  t2.length !== h2 && L(n2, "invalid publicKey length"), o2 = K(t2), n2.push(o2), a2 = O(n2, a2, "privateKey");
  var y2, i2 = 0 | r._crypto_box_secretkeybytes();
  a2.length !== i2 && L(n2, "invalid privateKey length"), y2 = K(a2), n2.push(y2);
  var l2 = new B(p2 - r._crypto_box_sealbytes() | 0), u2 = l2.address;
  if (n2.push(u2), !(0 | r._crypto_box_seal_open(u2, s2, p2, 0, o2, y2))) {
    var d2 = S(l2, _2);
    return M(n2), d2;
  }
  N(n2, "incorrect key pair for the given ciphertext");
}
function Ze(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "seed");
  var _2, n2 = 0 | r._crypto_box_seedbytes();
  e.length !== n2 && L(a2, "invalid seed length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_box_publickeybytes()), c2 = s2.address;
  a2.push(c2);
  var p2 = new B(0 | r._crypto_box_secretkeybytes()), o2 = p2.address;
  if (a2.push(o2), !(0 | r._crypto_box_seed_keypair(c2, o2, _2))) {
    var h2 = { publicKey: S(s2, t2), privateKey: S(p2, t2), keyType: "x25519" };
    return M(a2), h2;
  }
  N(a2, "invalid usage");
}
function $e(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "p");
  var n2, s2 = 0 | r._crypto_core_ed25519_bytes();
  e.length !== s2 && L(_2, "invalid p length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "q");
  var c2, p2 = 0 | r._crypto_core_ed25519_bytes();
  t2.length !== p2 && L(_2, "invalid q length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_core_ed25519_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_core_ed25519_add(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "input is an invalid element");
}
function er(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = K(e = O(a2, e, "r"));
  e.length, a2.push(_2);
  var n2 = new B(0 | r._crypto_core_ed25519_bytes()), s2 = n2.address;
  if (a2.push(s2), !(0 | r._crypto_core_ed25519_from_hash(s2, _2))) {
    var c2 = S(n2, t2);
    return M(a2), c2;
  }
  N(a2, "invalid usage");
}
function rr(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = K(e = O(a2, e, "r"));
  e.length, a2.push(_2);
  var n2 = new B(0 | r._crypto_core_ed25519_bytes()), s2 = n2.address;
  if (a2.push(s2), !(0 | r._crypto_core_ed25519_from_uniform(s2, _2))) {
    var c2 = S(n2, t2);
    return M(a2), c2;
  }
  N(a2, "invalid usage");
}
function tr(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "repr");
  var _2, n2 = 0 | r._crypto_core_ed25519_bytes();
  e.length !== n2 && L(a2, "invalid repr length"), _2 = K(e), a2.push(_2);
  var s2 = 1 == (0 | r._crypto_core_ed25519_is_valid_point(_2));
  return M(a2), s2;
}
function ar(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_core_ed25519_bytes()), _2 = a2.address;
  t2.push(_2), r._crypto_core_ed25519_random(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function _r(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "x");
  var n2, s2 = 0 | r._crypto_core_ed25519_scalarbytes();
  e.length !== s2 && L(_2, "invalid x length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "y");
  var c2, p2 = 0 | r._crypto_core_ed25519_scalarbytes();
  t2.length !== p2 && L(_2, "invalid y length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_core_ed25519_scalarbytes()), h2 = o2.address;
  _2.push(h2), r._crypto_core_ed25519_scalar_add(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function nr(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "s");
  var _2, n2 = 0 | r._crypto_core_ed25519_scalarbytes();
  e.length !== n2 && L(a2, "invalid s length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_core_ed25519_scalarbytes()), c2 = s2.address;
  a2.push(c2), r._crypto_core_ed25519_scalar_complement(c2, _2);
  var p2 = S(s2, t2);
  return M(a2), p2;
}
function sr(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "s");
  var _2, n2 = 0 | r._crypto_core_ed25519_scalarbytes();
  e.length !== n2 && L(a2, "invalid s length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_core_ed25519_scalarbytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_core_ed25519_scalar_invert(c2, _2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid reciprocate");
}
function cr(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "x");
  var n2, s2 = 0 | r._crypto_core_ed25519_scalarbytes();
  e.length !== s2 && L(_2, "invalid x length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "y");
  var c2, p2 = 0 | r._crypto_core_ed25519_scalarbytes();
  t2.length !== p2 && L(_2, "invalid y length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_core_ed25519_scalarbytes()), h2 = o2.address;
  _2.push(h2), r._crypto_core_ed25519_scalar_mul(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function pr(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "s");
  var _2, n2 = 0 | r._crypto_core_ed25519_scalarbytes();
  e.length !== n2 && L(a2, "invalid s length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_core_ed25519_scalarbytes()), c2 = s2.address;
  a2.push(c2), r._crypto_core_ed25519_scalar_negate(c2, _2);
  var p2 = S(s2, t2);
  return M(a2), p2;
}
function or(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_core_ed25519_scalarbytes()), _2 = a2.address;
  t2.push(_2), r._crypto_core_ed25519_scalar_random(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function hr(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "sample");
  var _2, n2 = 0 | r._crypto_core_ed25519_nonreducedscalarbytes();
  e.length !== n2 && L(a2, "invalid sample length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_core_ed25519_scalarbytes()), c2 = s2.address;
  a2.push(c2), r._crypto_core_ed25519_scalar_reduce(c2, _2);
  var p2 = S(s2, t2);
  return M(a2), p2;
}
function yr(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "x");
  var n2, s2 = 0 | r._crypto_core_ed25519_scalarbytes();
  e.length !== s2 && L(_2, "invalid x length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "y");
  var c2, p2 = 0 | r._crypto_core_ed25519_scalarbytes();
  t2.length !== p2 && L(_2, "invalid y length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_core_ed25519_scalarbytes()), h2 = o2.address;
  _2.push(h2), r._crypto_core_ed25519_scalar_sub(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function ir(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "p");
  var n2, s2 = 0 | r._crypto_core_ed25519_bytes();
  e.length !== s2 && L(_2, "invalid p length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "q");
  var c2, p2 = 0 | r._crypto_core_ed25519_bytes();
  t2.length !== p2 && L(_2, "invalid q length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_core_ed25519_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_core_ed25519_sub(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "input is an invalid element");
}
function lr(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), e = O(n2, e, "input");
  var s2, c2 = 0 | r._crypto_core_hchacha20_inputbytes();
  e.length !== c2 && L(n2, "invalid input length"), s2 = K(e), n2.push(s2), t2 = O(n2, t2, "privateKey");
  var p2, o2 = 0 | r._crypto_core_hchacha20_keybytes();
  t2.length !== o2 && L(n2, "invalid privateKey length"), p2 = K(t2), n2.push(p2);
  var h2 = null;
  null != a2 && (h2 = K(a2 = O(n2, a2, "constant")), a2.length, n2.push(h2));
  var y2 = new B(0 | r._crypto_core_hchacha20_outputbytes()), i2 = y2.address;
  if (n2.push(i2), !(0 | r._crypto_core_hchacha20(i2, s2, p2, h2))) {
    var l2 = S(y2, _2);
    return M(n2), l2;
  }
  N(n2, "invalid usage");
}
function ur(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), e = O(n2, e, "input");
  var s2, c2 = 0 | r._crypto_core_hsalsa20_inputbytes();
  e.length !== c2 && L(n2, "invalid input length"), s2 = K(e), n2.push(s2), t2 = O(n2, t2, "privateKey");
  var p2, o2 = 0 | r._crypto_core_hsalsa20_keybytes();
  t2.length !== o2 && L(n2, "invalid privateKey length"), p2 = K(t2), n2.push(p2);
  var h2 = null;
  null != a2 && (h2 = K(a2 = O(n2, a2, "constant")), a2.length, n2.push(h2));
  var y2 = new B(0 | r._crypto_core_hsalsa20_outputbytes()), i2 = y2.address;
  if (n2.push(i2), !(0 | r._crypto_core_hsalsa20(i2, s2, p2, h2))) {
    var l2 = S(y2, _2);
    return M(n2), l2;
  }
  N(n2, "invalid usage");
}
function dr(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "p");
  var n2, s2 = 0 | r._crypto_core_ristretto255_bytes();
  e.length !== s2 && L(_2, "invalid p length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "q");
  var c2, p2 = 0 | r._crypto_core_ristretto255_bytes();
  t2.length !== p2 && L(_2, "invalid q length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_core_ristretto255_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_core_ristretto255_add(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "input is an invalid element");
}
function vr(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = K(e = O(a2, e, "r"));
  e.length, a2.push(_2);
  var n2 = new B(0 | r._crypto_core_ristretto255_bytes()), s2 = n2.address;
  if (a2.push(s2), !(0 | r._crypto_core_ristretto255_from_hash(s2, _2))) {
    var c2 = S(n2, t2);
    return M(a2), c2;
  }
  N(a2, "invalid usage");
}
function gr(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "repr");
  var _2, n2 = 0 | r._crypto_core_ristretto255_bytes();
  e.length !== n2 && L(a2, "invalid repr length"), _2 = K(e), a2.push(_2);
  var s2 = 1 == (0 | r._crypto_core_ristretto255_is_valid_point(_2));
  return M(a2), s2;
}
function br(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_core_ristretto255_bytes()), _2 = a2.address;
  t2.push(_2), r._crypto_core_ristretto255_random(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function fr(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "x");
  var n2, s2 = 0 | r._crypto_core_ristretto255_scalarbytes();
  e.length !== s2 && L(_2, "invalid x length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "y");
  var c2, p2 = 0 | r._crypto_core_ristretto255_scalarbytes();
  t2.length !== p2 && L(_2, "invalid y length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_core_ristretto255_scalarbytes()), h2 = o2.address;
  _2.push(h2), r._crypto_core_ristretto255_scalar_add(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function mr(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "s");
  var _2, n2 = 0 | r._crypto_core_ristretto255_scalarbytes();
  e.length !== n2 && L(a2, "invalid s length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_core_ristretto255_scalarbytes()), c2 = s2.address;
  a2.push(c2), r._crypto_core_ristretto255_scalar_complement(c2, _2);
  var p2 = S(s2, t2);
  return M(a2), p2;
}
function kr(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "s");
  var _2, n2 = 0 | r._crypto_core_ristretto255_scalarbytes();
  e.length !== n2 && L(a2, "invalid s length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_core_ristretto255_scalarbytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_core_ristretto255_scalar_invert(c2, _2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid reciprocate");
}
function xr(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "x");
  var n2, s2 = 0 | r._crypto_core_ristretto255_scalarbytes();
  e.length !== s2 && L(_2, "invalid x length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "y");
  var c2, p2 = 0 | r._crypto_core_ristretto255_scalarbytes();
  t2.length !== p2 && L(_2, "invalid y length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_core_ristretto255_scalarbytes()), h2 = o2.address;
  _2.push(h2), r._crypto_core_ristretto255_scalar_mul(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function Er(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "s");
  var _2, n2 = 0 | r._crypto_core_ristretto255_scalarbytes();
  e.length !== n2 && L(a2, "invalid s length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_core_ristretto255_scalarbytes()), c2 = s2.address;
  a2.push(c2), r._crypto_core_ristretto255_scalar_negate(c2, _2);
  var p2 = S(s2, t2);
  return M(a2), p2;
}
function Tr(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_core_ristretto255_scalarbytes()), _2 = a2.address;
  t2.push(_2), r._crypto_core_ristretto255_scalar_random(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function Sr(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "sample");
  var _2, n2 = 0 | r._crypto_core_ristretto255_nonreducedscalarbytes();
  e.length !== n2 && L(a2, "invalid sample length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_core_ristretto255_scalarbytes()), c2 = s2.address;
  a2.push(c2), r._crypto_core_ristretto255_scalar_reduce(c2, _2);
  var p2 = S(s2, t2);
  return M(a2), p2;
}
function wr(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "x");
  var n2, s2 = 0 | r._crypto_core_ristretto255_scalarbytes();
  e.length !== s2 && L(_2, "invalid x length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "y");
  var c2, p2 = 0 | r._crypto_core_ristretto255_scalarbytes();
  t2.length !== p2 && L(_2, "invalid y length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_core_ristretto255_scalarbytes()), h2 = o2.address;
  _2.push(h2), r._crypto_core_ristretto255_scalar_sub(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function Yr(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "p");
  var n2, s2 = 0 | r._crypto_core_ristretto255_bytes();
  e.length !== s2 && L(_2, "invalid p length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "q");
  var c2, p2 = 0 | r._crypto_core_ristretto255_bytes();
  t2.length !== p2 && L(_2, "invalid q length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_core_ristretto255_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_core_ristretto255_sub(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "input is an invalid element");
}
function Br(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), U(n2, e, "hash_length"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(n2, "hash_length must be an unsigned integer");
  var s2 = K(t2 = O(n2, t2, "message")), c2 = t2.length;
  n2.push(s2);
  var p2 = null, o2 = 0;
  null != a2 && (p2 = K(a2 = O(n2, a2, "key")), o2 = a2.length, n2.push(p2));
  var h2 = new B(e |= 0), y2 = h2.address;
  if (n2.push(y2), !(0 | r._crypto_generichash(y2, e, s2, c2, 0, p2, o2))) {
    var i2 = S(h2, _2);
    return M(n2), i2;
  }
  N(n2, "invalid usage");
}
function Kr(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2), U(s2, e, "subkey_len"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(s2, "subkey_len must be an unsigned integer");
  var c2 = null, p2 = 0;
  null != t2 && (c2 = K(t2 = O(s2, t2, "key")), p2 = t2.length, s2.push(c2));
  var o2 = null, h2 = 0;
  null != a2 && (a2 = O(s2, a2, "id"), h2 = 0 | r._crypto_generichash_blake2b_saltbytes(), a2.length !== h2 && L(s2, "invalid id length"), o2 = K(a2), s2.push(o2));
  var y2 = null, i2 = 0;
  null != _2 && (_2 = O(s2, _2, "ctx"), i2 = 0 | r._crypto_generichash_blake2b_personalbytes(), _2.length !== i2 && L(s2, "invalid ctx length"), y2 = K(_2), s2.push(y2));
  var l2 = new B(0 | e), u2 = l2.address;
  if (s2.push(u2), !(0 | r._crypto_generichash_blake2b_salt_personal(u2, e, null, 0, 0, c2, p2, o2, y2))) {
    var d2 = S(l2, n2);
    return M(s2), d2;
  }
  N(s2, "invalid usage");
}
function Ar(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address"), U(_2, t2, "hash_length"), ("number" != typeof t2 || (0 | t2) !== t2 || t2 < 0) && L(_2, "hash_length must be an unsigned integer");
  var n2 = new B(t2 |= 0), s2 = n2.address;
  if (_2.push(s2), !(0 | r._crypto_generichash_final(e, s2, t2))) {
    var c2 = (r._free(e), S(n2, a2));
    return M(_2), c2;
  }
  N(_2, "invalid usage");
}
function Ir(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = null, s2 = 0;
  null != e && (n2 = K(e = O(_2, e, "key")), s2 = e.length, _2.push(n2)), U(_2, t2, "hash_length"), ("number" != typeof t2 || (0 | t2) !== t2 || t2 < 0) && L(_2, "hash_length must be an unsigned integer");
  var c2 = new B(357).address;
  if (!(0 | r._crypto_generichash_init(c2, n2, s2, t2))) {
    var p2 = c2;
    return M(_2), p2;
  }
  N(_2, "invalid usage");
}
function Mr(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_generichash_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_generichash_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function Nr(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_generichash_update(e, n2, s2) && N(_2, "invalid usage"), M(_2);
}
function Lr(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = K(e = O(a2, e, "message")), n2 = e.length;
  a2.push(_2);
  var s2 = new B(0 | r._crypto_hash_bytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_hash(c2, _2, n2, 0))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid usage");
}
function Ur(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = K(e = O(a2, e, "message")), n2 = e.length;
  a2.push(_2);
  var s2 = new B(0 | r._crypto_hash_sha256_bytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_hash_sha256(c2, _2, n2, 0))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid usage");
}
function Or(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "state_address");
  var _2 = new B(0 | r._crypto_hash_sha256_bytes()), n2 = _2.address;
  if (a2.push(n2), !(0 | r._crypto_hash_sha256_final(e, n2))) {
    var s2 = (r._free(e), S(_2, t2));
    return M(a2), s2;
  }
  N(a2, "invalid usage");
}
function Cr(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(104).address;
  if (!(0 | r._crypto_hash_sha256_init(a2))) {
    var _2 = a2;
    return M(t2), _2;
  }
  N(t2, "invalid usage");
}
function Rr(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_hash_sha256_update(e, n2, s2) && N(_2, "invalid usage"), M(_2);
}
function Pr(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = K(e = O(a2, e, "message")), n2 = e.length;
  a2.push(_2);
  var s2 = new B(0 | r._crypto_hash_sha3256_bytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_hash_sha3256(c2, _2, n2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid usage");
}
function Xr(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "state_address");
  var _2 = new B(0 | r._crypto_hash_sha3256_bytes()), n2 = _2.address;
  if (a2.push(n2), !(0 | r._crypto_hash_sha3256_final(e, n2))) {
    var s2 = (r._free(e), S(_2, t2));
    return M(a2), s2;
  }
  N(a2, "invalid usage");
}
function Dr(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(256).address;
  if (!(0 | r._crypto_hash_sha3256_init(a2))) {
    var _2 = a2;
    return M(t2), _2;
  }
  N(t2, "invalid usage");
}
function Gr(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_hash_sha3256_update(e, n2, s2) && N(_2, "invalid usage"), M(_2);
}
function Fr(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = K(e = O(a2, e, "message")), n2 = e.length;
  a2.push(_2);
  var s2 = new B(0 | r._crypto_hash_sha3512_bytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_hash_sha3512(c2, _2, n2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid usage");
}
function Vr(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "state_address");
  var _2 = new B(0 | r._crypto_hash_sha3512_bytes()), n2 = _2.address;
  if (a2.push(n2), !(0 | r._crypto_hash_sha3512_final(e, n2))) {
    var s2 = (r._free(e), S(_2, t2));
    return M(a2), s2;
  }
  N(a2, "invalid usage");
}
function qr(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(256).address;
  if (!(0 | r._crypto_hash_sha3512_init(a2))) {
    var _2 = a2;
    return M(t2), _2;
  }
  N(t2, "invalid usage");
}
function Hr(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_hash_sha3512_update(e, n2, s2) && N(_2, "invalid usage"), M(_2);
}
function zr(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = K(e = O(a2, e, "message")), n2 = e.length;
  a2.push(_2);
  var s2 = new B(0 | r._crypto_hash_sha512_bytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_hash_sha512(c2, _2, n2, 0))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid usage");
}
function Wr(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "state_address");
  var _2 = new B(0 | r._crypto_hash_sha512_bytes()), n2 = _2.address;
  if (a2.push(n2), !(0 | r._crypto_hash_sha512_final(e, n2))) {
    var s2 = (r._free(e), S(_2, t2));
    return M(a2), s2;
  }
  N(a2, "invalid usage");
}
function jr(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(208).address;
  if (!(0 | r._crypto_hash_sha512_init(a2))) {
    var _2 = a2;
    return M(t2), _2;
  }
  N(t2, "invalid usage");
}
function Jr(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_hash_sha512_update(e, n2, s2) && N(_2, "invalid usage"), M(_2);
}
function Qr(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "input");
  var n2, s2 = 0 | r._crypto_ipcrypt_bytes();
  e.length !== s2 && L(_2, "invalid input length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_ipcrypt_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_ipcrypt_bytes()), h2 = o2.address;
  _2.push(h2), r._crypto_ipcrypt_decrypt(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function Zr(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "input");
  var n2, s2 = 0 | r._crypto_ipcrypt_bytes();
  e.length !== s2 && L(_2, "invalid input length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_ipcrypt_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_ipcrypt_bytes()), h2 = o2.address;
  _2.push(h2), r._crypto_ipcrypt_encrypt(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function $r(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_ipcrypt_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_ipcrypt_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function et(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "input");
  var n2, s2 = 0 | r._crypto_ipcrypt_nd_outputbytes();
  e.length !== s2 && L(_2, "invalid input length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_ipcrypt_nd_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_ipcrypt_nd_inputbytes()), h2 = o2.address;
  _2.push(h2), r._crypto_ipcrypt_nd_decrypt(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function rt(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), e = O(n2, e, "input");
  var s2, c2 = 0 | r._crypto_ipcrypt_nd_inputbytes();
  e.length !== c2 && L(n2, "invalid input length"), s2 = K(e), n2.push(s2), t2 = O(n2, t2, "tweak");
  var p2, o2 = 0 | r._crypto_ipcrypt_nd_tweakbytes();
  t2.length !== o2 && L(n2, "invalid tweak length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "key");
  var h2, y2 = 0 | r._crypto_ipcrypt_nd_keybytes();
  a2.length !== y2 && L(n2, "invalid key length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(0 | r._crypto_ipcrypt_nd_outputbytes()), l2 = i2.address;
  n2.push(l2), r._crypto_ipcrypt_nd_encrypt(l2, s2, p2, h2);
  var u2 = S(i2, _2);
  return M(n2), u2;
}
function tt(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_ipcrypt_nd_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_ipcrypt_nd_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function at(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "input");
  var n2, s2 = 0 | r._crypto_ipcrypt_ndx_outputbytes();
  e.length !== s2 && L(_2, "invalid input length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_ipcrypt_ndx_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_ipcrypt_ndx_inputbytes()), h2 = o2.address;
  _2.push(h2), r._crypto_ipcrypt_ndx_decrypt(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function _t(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), e = O(n2, e, "input");
  var s2, c2 = 0 | r._crypto_ipcrypt_ndx_inputbytes();
  e.length !== c2 && L(n2, "invalid input length"), s2 = K(e), n2.push(s2), t2 = O(n2, t2, "tweak");
  var p2, o2 = 0 | r._crypto_ipcrypt_ndx_tweakbytes();
  t2.length !== o2 && L(n2, "invalid tweak length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "key");
  var h2, y2 = 0 | r._crypto_ipcrypt_ndx_keybytes();
  a2.length !== y2 && L(n2, "invalid key length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(0 | r._crypto_ipcrypt_ndx_outputbytes()), l2 = i2.address;
  n2.push(l2), r._crypto_ipcrypt_ndx_encrypt(l2, s2, p2, h2);
  var u2 = S(i2, _2);
  return M(n2), u2;
}
function nt(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_ipcrypt_ndx_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_ipcrypt_ndx_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function st(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "input");
  var n2, s2 = 0 | r._crypto_ipcrypt_pfx_bytes();
  e.length !== s2 && L(_2, "invalid input length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_ipcrypt_pfx_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_ipcrypt_pfx_bytes()), h2 = o2.address;
  _2.push(h2), r._crypto_ipcrypt_pfx_decrypt(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function ct(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "input");
  var n2, s2 = 0 | r._crypto_ipcrypt_pfx_bytes();
  e.length !== s2 && L(_2, "invalid input length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_ipcrypt_pfx_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_ipcrypt_pfx_bytes()), h2 = o2.address;
  _2.push(h2), r._crypto_ipcrypt_pfx_encrypt(h2, n2, c2);
  var y2 = S(o2, a2);
  return M(_2), y2;
}
function pt(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_ipcrypt_pfx_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_ipcrypt_pfx_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function ot(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2), U(s2, e, "subkey_len"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(s2, "subkey_len must be an unsigned integer"), U(s2, t2, "subkey_id");
  var c2, p2 = 0;
  if ("bigint" == typeof t2 && t2 >= BigInt(0)) {
    const e2 = t2 >> BigInt(32);
    e2 > BigInt(4294967295) && L(s2, "subkey_id cannot be more than 64 bits"), p2 = Number(e2), c2 = Number(t2 & BigInt(4294967295));
  } else "number" == typeof t2 && (0 | t2) === t2 && t2 >= 0 ? c2 = t2 : L(s2, "subkey_id must be an unsigned integer or bigint");
  "string" != typeof a2 && L(s2, "ctx must be a string"), (a2 = v(a2 + "\0")).length - 1 !== r._crypto_kdf_contextbytes() && L(s2, "invalid ctx length");
  var o2 = K(a2);
  a2.length, s2.push(o2), _2 = O(s2, _2, "key");
  var h2, y2 = 0 | r._crypto_kdf_keybytes();
  _2.length !== y2 && L(s2, "invalid key length"), h2 = K(_2), s2.push(h2);
  var i2 = new B(0 | e), l2 = i2.address;
  s2.push(l2), r._crypto_kdf_derive_from_key(l2, e, c2, p2, o2, h2);
  var u2 = S(i2, n2);
  return M(s2), u2;
}
function ht(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_kdf_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_kdf_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function yt(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "ciphertext");
  var n2, s2 = 0 | r._crypto_kem_ciphertextbytes();
  e.length !== s2 && L(_2, "invalid ciphertext length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "privateKey");
  var c2, p2 = 0 | r._crypto_kem_secretkeybytes();
  t2.length !== p2 && L(_2, "invalid privateKey length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_kem_sharedsecretbytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_kem_dec(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function it(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "publicKey");
  var _2, n2 = 0 | r._crypto_kem_publickeybytes();
  e.length !== n2 && L(a2, "invalid publicKey length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_kem_ciphertextbytes()), c2 = s2.address;
  a2.push(c2);
  var p2 = new B(0 | r._crypto_kem_sharedsecretbytes()), o2 = p2.address;
  if (a2.push(o2), !(0 | r._crypto_kem_enc(c2, o2, _2))) {
    var h2 = S({ ciphertext: s2, sharedSecret: p2 }, t2);
    return M(a2), h2;
  }
  N(a2, "invalid usage");
}
function lt(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_kem_publickeybytes()), _2 = a2.address;
  t2.push(_2);
  var n2 = new B(0 | r._crypto_kem_secretkeybytes()), s2 = n2.address;
  if (t2.push(s2), !(0 | r._crypto_kem_keypair(_2, s2))) {
    var c2 = { publicKey: S(a2, e), privateKey: S(n2, e), keyType: "xwing" };
    return M(t2), c2;
  }
  N(t2, "internal error");
}
function ut(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "ciphertext");
  var n2, s2 = 0 | r._crypto_kem_mlkem768_ciphertextbytes();
  e.length !== s2 && L(_2, "invalid ciphertext length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "privateKey");
  var c2, p2 = 0 | r._crypto_kem_mlkem768_secretkeybytes();
  t2.length !== p2 && L(_2, "invalid privateKey length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_kem_mlkem768_sharedsecretbytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_kem_mlkem768_dec(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function dt(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "publicKey");
  var _2, n2 = 0 | r._crypto_kem_mlkem768_publickeybytes();
  e.length !== n2 && L(a2, "invalid publicKey length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_kem_mlkem768_ciphertextbytes()), c2 = s2.address;
  a2.push(c2);
  var p2 = new B(0 | r._crypto_kem_mlkem768_sharedsecretbytes()), o2 = p2.address;
  if (a2.push(o2), !(0 | r._crypto_kem_mlkem768_enc(c2, o2, _2))) {
    var h2 = S({ ciphertext: s2, sharedSecret: p2 }, t2);
    return M(a2), h2;
  }
  N(a2, "invalid usage");
}
function vt(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "publicKey");
  var n2, s2, c2 = 0 | r._crypto_kem_mlkem768_publickeybytes();
  e.length !== c2 && L(_2, "invalid publicKey length"), n2 = K(e), _2.push(n2), 32 !== (t2 = O(_2, t2, "seed")).length && L(_2, "invalid seed length"), s2 = K(t2), _2.push(s2);
  var p2 = new B(0 | r._crypto_kem_mlkem768_ciphertextbytes()), o2 = p2.address;
  _2.push(o2);
  var h2 = new B(0 | r._crypto_kem_mlkem768_sharedsecretbytes()), y2 = h2.address;
  if (_2.push(y2), !(0 | r._crypto_kem_mlkem768_enc_deterministic(o2, y2, n2, s2))) {
    var i2 = S({ ciphertext: p2, sharedSecret: h2 }, a2);
    return M(_2), i2;
  }
  N(_2, "invalid usage");
}
function gt(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_kem_mlkem768_publickeybytes()), _2 = a2.address;
  t2.push(_2);
  var n2 = new B(0 | r._crypto_kem_mlkem768_secretkeybytes()), s2 = n2.address;
  if (t2.push(s2), !(0 | r._crypto_kem_mlkem768_keypair(_2, s2))) {
    var c2 = { publicKey: S(a2, e), privateKey: S(n2, e), keyType: "ml-kem-768" };
    return M(t2), c2;
  }
  N(t2, "internal error");
}
function bt(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "seed");
  var _2, n2 = 0 | r._crypto_kem_mlkem768_seedbytes();
  e.length !== n2 && L(a2, "invalid seed length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_kem_mlkem768_publickeybytes()), c2 = s2.address;
  a2.push(c2);
  var p2 = new B(0 | r._crypto_kem_mlkem768_secretkeybytes()), o2 = p2.address;
  if (a2.push(o2), !(0 | r._crypto_kem_mlkem768_seed_keypair(c2, o2, _2))) {
    var h2 = { publicKey: S(s2, t2), privateKey: S(p2, t2), keyType: "ml-kem-768" };
    return M(a2), h2;
  }
  N(a2, "invalid usage");
}
function ft() {
  var e = r._crypto_kem_primitive(), t2 = r.UTF8ToString(e);
  return M([]), t2;
}
function mt(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "seed");
  var _2, n2 = 0 | r._crypto_kem_seedbytes();
  e.length !== n2 && L(a2, "invalid seed length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_kem_publickeybytes()), c2 = s2.address;
  a2.push(c2);
  var p2 = new B(0 | r._crypto_kem_secretkeybytes()), o2 = p2.address;
  if (a2.push(o2), !(0 | r._crypto_kem_seed_keypair(c2, o2, _2))) {
    var h2 = { publicKey: S(s2, t2), privateKey: S(p2, t2), keyType: "xwing" };
    return M(a2), h2;
  }
  N(a2, "invalid usage");
}
function kt(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "ciphertext");
  var n2, s2 = 0 | r._crypto_kem_xwing_ciphertextbytes();
  e.length !== s2 && L(_2, "invalid ciphertext length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "privateKey");
  var c2, p2 = 0 | r._crypto_kem_xwing_secretkeybytes();
  t2.length !== p2 && L(_2, "invalid privateKey length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_kem_xwing_sharedsecretbytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_kem_xwing_dec(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function xt(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "publicKey");
  var _2, n2 = 0 | r._crypto_kem_xwing_publickeybytes();
  e.length !== n2 && L(a2, "invalid publicKey length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_kem_xwing_ciphertextbytes()), c2 = s2.address;
  a2.push(c2);
  var p2 = new B(0 | r._crypto_kem_xwing_sharedsecretbytes()), o2 = p2.address;
  if (a2.push(o2), !(0 | r._crypto_kem_xwing_enc(c2, o2, _2))) {
    var h2 = S({ ciphertext: s2, sharedSecret: p2 }, t2);
    return M(a2), h2;
  }
  N(a2, "invalid usage");
}
function Et(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "publicKey");
  var n2, s2, c2 = 0 | r._crypto_kem_xwing_publickeybytes();
  e.length !== c2 && L(_2, "invalid publicKey length"), n2 = K(e), _2.push(n2), 64 !== (t2 = O(_2, t2, "seed")).length && L(_2, "invalid seed length"), s2 = K(t2), _2.push(s2);
  var p2 = new B(0 | r._crypto_kem_xwing_ciphertextbytes()), o2 = p2.address;
  _2.push(o2);
  var h2 = new B(0 | r._crypto_kem_xwing_sharedsecretbytes()), y2 = h2.address;
  if (_2.push(y2), !(0 | r._crypto_kem_xwing_enc_deterministic(o2, y2, n2, s2))) {
    var i2 = S({ ciphertext: p2, sharedSecret: h2 }, a2);
    return M(_2), i2;
  }
  N(_2, "invalid usage");
}
function Tt(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_kem_xwing_publickeybytes()), _2 = a2.address;
  t2.push(_2);
  var n2 = new B(0 | r._crypto_kem_xwing_secretkeybytes()), s2 = n2.address;
  if (t2.push(s2), !(0 | r._crypto_kem_xwing_keypair(_2, s2))) {
    var c2 = { publicKey: S(a2, e), privateKey: S(n2, e), keyType: "xwing" };
    return M(t2), c2;
  }
  N(t2, "internal error");
}
function St(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "seed");
  var _2, n2 = 0 | r._crypto_kem_xwing_seedbytes();
  e.length !== n2 && L(a2, "invalid seed length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_kem_xwing_publickeybytes()), c2 = s2.address;
  a2.push(c2);
  var p2 = new B(0 | r._crypto_kem_xwing_secretkeybytes()), o2 = p2.address;
  if (a2.push(o2), !(0 | r._crypto_kem_xwing_seed_keypair(c2, o2, _2))) {
    var h2 = { publicKey: S(s2, t2), privateKey: S(p2, t2), keyType: "xwing" };
    return M(a2), h2;
  }
  N(a2, "invalid usage");
}
function wt(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), e = O(n2, e, "clientPublicKey");
  var s2, c2 = 0 | r._crypto_kx_publickeybytes();
  e.length !== c2 && L(n2, "invalid clientPublicKey length"), s2 = K(e), n2.push(s2), t2 = O(n2, t2, "clientSecretKey");
  var p2, o2 = 0 | r._crypto_kx_secretkeybytes();
  t2.length !== o2 && L(n2, "invalid clientSecretKey length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "serverPublicKey");
  var h2, y2 = 0 | r._crypto_kx_publickeybytes();
  a2.length !== y2 && L(n2, "invalid serverPublicKey length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(0 | r._crypto_kx_sessionkeybytes()), l2 = i2.address;
  n2.push(l2);
  var u2 = new B(0 | r._crypto_kx_sessionkeybytes()), d2 = u2.address;
  if (n2.push(d2), !(0 | r._crypto_kx_client_session_keys(l2, d2, s2, p2, h2))) {
    var v2 = S({ sharedRx: i2, sharedTx: u2 }, _2);
    return M(n2), v2;
  }
  N(n2, "invalid usage");
}
function Yt(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_kx_publickeybytes()), _2 = a2.address;
  t2.push(_2);
  var n2 = new B(0 | r._crypto_kx_secretkeybytes()), s2 = n2.address;
  if (t2.push(s2), !(0 | r._crypto_kx_keypair(_2, s2))) {
    var c2 = { publicKey: S(a2, e), privateKey: S(n2, e), keyType: "x25519" };
    return M(t2), c2;
  }
  N(t2, "internal error");
}
function Bt(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "seed");
  var _2, n2 = 0 | r._crypto_kx_seedbytes();
  e.length !== n2 && L(a2, "invalid seed length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_kx_publickeybytes()), c2 = s2.address;
  a2.push(c2);
  var p2 = new B(0 | r._crypto_kx_secretkeybytes()), o2 = p2.address;
  if (a2.push(o2), !(0 | r._crypto_kx_seed_keypair(c2, o2, _2))) {
    var h2 = { publicKey: S(s2, t2), privateKey: S(p2, t2), keyType: "x25519" };
    return M(a2), h2;
  }
  N(a2, "internal error");
}
function Kt(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), e = O(n2, e, "serverPublicKey");
  var s2, c2 = 0 | r._crypto_kx_publickeybytes();
  e.length !== c2 && L(n2, "invalid serverPublicKey length"), s2 = K(e), n2.push(s2), t2 = O(n2, t2, "serverSecretKey");
  var p2, o2 = 0 | r._crypto_kx_secretkeybytes();
  t2.length !== o2 && L(n2, "invalid serverSecretKey length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "clientPublicKey");
  var h2, y2 = 0 | r._crypto_kx_publickeybytes();
  a2.length !== y2 && L(n2, "invalid clientPublicKey length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(0 | r._crypto_kx_sessionkeybytes()), l2 = i2.address;
  n2.push(l2);
  var u2 = new B(0 | r._crypto_kx_sessionkeybytes()), d2 = u2.address;
  if (n2.push(d2), !(0 | r._crypto_kx_server_session_keys(l2, d2, s2, p2, h2))) {
    var v2 = S({ sharedRx: i2, sharedTx: u2 }, _2);
    return M(n2), v2;
  }
  N(n2, "invalid usage");
}
function At(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_onetimeauth_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_onetimeauth_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_onetimeauth(h2, n2, s2, 0, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function It(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "state_address");
  var _2 = new B(0 | r._crypto_onetimeauth_bytes()), n2 = _2.address;
  if (a2.push(n2), !(0 | r._crypto_onetimeauth_final(e, n2))) {
    var s2 = (r._free(e), S(_2, t2));
    return M(a2), s2;
  }
  N(a2, "invalid usage");
}
function Mt(e, t2) {
  var a2 = [];
  Y(t2);
  var _2 = null;
  null != e && (_2 = K(e = O(a2, e, "key")), e.length, a2.push(_2));
  var n2 = new B(144).address;
  if (!(0 | r._crypto_onetimeauth_init(n2, _2))) {
    var s2 = n2;
    return M(a2), s2;
  }
  N(a2, "invalid usage");
}
function Nt(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_onetimeauth_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_onetimeauth_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function Lt(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_onetimeauth_update(e, n2, s2) && N(_2, "invalid usage"), M(_2);
}
function Ut(e, t2, a2) {
  var _2 = [];
  e = O(_2, e, "hash");
  var n2, s2 = 0 | r._crypto_onetimeauth_bytes();
  e.length !== s2 && L(_2, "invalid hash length"), n2 = K(e), _2.push(n2);
  var c2 = K(t2 = O(_2, t2, "message")), p2 = t2.length;
  _2.push(c2), a2 = O(_2, a2, "key");
  var o2, h2 = 0 | r._crypto_onetimeauth_keybytes();
  a2.length !== h2 && L(_2, "invalid key length"), o2 = K(a2), _2.push(o2);
  var y2 = !(0 | r._crypto_onetimeauth_verify(n2, c2, p2, 0, o2));
  return M(_2), y2;
}
function Ot(e, t2, a2, _2, n2, s2, c2) {
  var p2 = [];
  Y(c2), U(p2, e, "keyLength"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(p2, "keyLength must be an unsigned integer");
  var o2 = K(t2 = O(p2, t2, "password")), h2 = t2.length;
  p2.push(o2), a2 = O(p2, a2, "salt");
  var y2, i2 = 0 | r._crypto_pwhash_saltbytes();
  a2.length !== i2 && L(p2, "invalid salt length"), y2 = K(a2), p2.push(y2), U(p2, _2, "opsLimit"), ("number" != typeof _2 || (0 | _2) !== _2 || _2 < 0) && L(p2, "opsLimit must be an unsigned integer"), U(p2, n2, "memLimit"), ("number" != typeof n2 || (0 | n2) !== n2 || n2 < 0) && L(p2, "memLimit must be an unsigned integer"), U(p2, s2, "algorithm"), ("number" != typeof s2 || (0 | s2) !== s2 || s2 < 0) && L(p2, "algorithm must be an unsigned integer");
  var l2 = new B(0 | e), u2 = l2.address;
  if (p2.push(u2), !(0 | r._crypto_pwhash(u2, e, 0, o2, h2, 0, y2, _2, 0, n2, s2))) {
    var d2 = S(l2, c2);
    return M(p2), d2;
  }
  N(p2, "invalid usage");
}
function Ct(e, t2, a2, _2, n2, s2) {
  var c2 = [];
  Y(s2), U(c2, e, "keyLength"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(c2, "keyLength must be an unsigned integer");
  var p2 = K(t2 = O(c2, t2, "password")), o2 = t2.length;
  c2.push(p2), a2 = O(c2, a2, "salt");
  var h2, y2 = 0 | r._crypto_pwhash_scryptsalsa208sha256_saltbytes();
  a2.length !== y2 && L(c2, "invalid salt length"), h2 = K(a2), c2.push(h2), U(c2, _2, "opsLimit"), ("number" != typeof _2 || (0 | _2) !== _2 || _2 < 0) && L(c2, "opsLimit must be an unsigned integer"), U(c2, n2, "memLimit"), ("number" != typeof n2 || (0 | n2) !== n2 || n2 < 0) && L(c2, "memLimit must be an unsigned integer");
  var i2 = new B(0 | e), l2 = i2.address;
  if (c2.push(l2), !(0 | r._crypto_pwhash_scryptsalsa208sha256(l2, e, 0, p2, o2, 0, h2, _2, 0, n2))) {
    var u2 = S(i2, s2);
    return M(c2), u2;
  }
  N(c2, "invalid usage");
}
function Rt(e, t2, a2, _2, n2, s2, c2) {
  var p2 = [];
  Y(c2);
  var o2 = K(e = O(p2, e, "password")), h2 = e.length;
  p2.push(o2);
  var y2 = K(t2 = O(p2, t2, "salt")), i2 = t2.length;
  p2.push(y2), U(p2, a2, "opsLimit"), ("number" != typeof a2 || (0 | a2) !== a2 || a2 < 0) && L(p2, "opsLimit must be an unsigned integer"), U(p2, _2, "r"), ("number" != typeof _2 || (0 | _2) !== _2 || _2 < 0) && L(p2, "r must be an unsigned integer"), U(p2, n2, "p"), ("number" != typeof n2 || (0 | n2) !== n2 || n2 < 0) && L(p2, "p must be an unsigned integer"), U(p2, s2, "keyLength"), ("number" != typeof s2 || (0 | s2) !== s2 || s2 < 0) && L(p2, "keyLength must be an unsigned integer");
  var l2 = new B(0 | s2), u2 = l2.address;
  if (p2.push(u2), !(0 | r._crypto_pwhash_scryptsalsa208sha256_ll(o2, h2, y2, i2, a2, 0, _2, n2, u2, s2))) {
    var d2 = S(l2, c2);
    return M(p2), d2;
  }
  N(p2, "invalid usage");
}
function Pt(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "password")), c2 = e.length;
  n2.push(s2), U(n2, t2, "opsLimit"), ("number" != typeof t2 || (0 | t2) !== t2 || t2 < 0) && L(n2, "opsLimit must be an unsigned integer"), U(n2, a2, "memLimit"), ("number" != typeof a2 || (0 | a2) !== a2 || a2 < 0) && L(n2, "memLimit must be an unsigned integer");
  var p2 = new B(0 | r._crypto_pwhash_scryptsalsa208sha256_strbytes()).address;
  if (n2.push(p2), !(0 | r._crypto_pwhash_scryptsalsa208sha256_str(p2, s2, c2, 0, t2, 0, a2))) {
    var o2 = r.UTF8ToString(p2);
    return M(n2), o2;
  }
  N(n2, "invalid usage");
}
function Xt(e, t2, a2) {
  var _2 = [];
  Y(a2), "string" != typeof e && L(_2, "hashed_password must be a string");
  var n2 = K(e = v(e + "\0"));
  e.length, _2.push(n2);
  var s2 = K(t2 = O(_2, t2, "password")), c2 = t2.length;
  _2.push(s2);
  var p2 = !(0 | r._crypto_pwhash_scryptsalsa208sha256_str_verify(n2, s2, c2, 0));
  return M(_2), p2;
}
function Dt(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "password")), c2 = e.length;
  n2.push(s2), U(n2, t2, "opsLimit"), ("number" != typeof t2 || (0 | t2) !== t2 || t2 < 0) && L(n2, "opsLimit must be an unsigned integer"), U(n2, a2, "memLimit"), ("number" != typeof a2 || (0 | a2) !== a2 || a2 < 0) && L(n2, "memLimit must be an unsigned integer");
  var p2 = new B(0 | r._crypto_pwhash_strbytes()).address;
  if (n2.push(p2), !(0 | r._crypto_pwhash_str(p2, s2, c2, 0, t2, 0, a2))) {
    var o2 = r.UTF8ToString(p2);
    return M(n2), o2;
  }
  N(n2, "invalid usage");
}
function Gt(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), "string" != typeof e && L(n2, "hashed_password must be a string");
  var s2 = K(e = v(e + "\0"));
  e.length, n2.push(s2), U(n2, t2, "opsLimit"), ("number" != typeof t2 || (0 | t2) !== t2 || t2 < 0) && L(n2, "opsLimit must be an unsigned integer"), U(n2, a2, "memLimit"), ("number" != typeof a2 || (0 | a2) !== a2 || a2 < 0) && L(n2, "memLimit must be an unsigned integer");
  var c2 = !!(0 | r._crypto_pwhash_str_needs_rehash(s2, t2, 0, a2));
  return M(n2), c2;
}
function Ft(e, t2, a2) {
  var _2 = [];
  Y(a2), "string" != typeof e && L(_2, "hashed_password must be a string");
  var n2 = K(e = v(e + "\0"));
  e.length, _2.push(n2);
  var s2 = K(t2 = O(_2, t2, "password")), c2 = t2.length;
  _2.push(s2);
  var p2 = !(0 | r._crypto_pwhash_str_verify(n2, s2, c2, 0));
  return M(_2), p2;
}
function Vt(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "privateKey");
  var n2, s2 = 0 | r._crypto_scalarmult_scalarbytes();
  e.length !== s2 && L(_2, "invalid privateKey length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "publicKey");
  var c2, p2 = 0 | r._crypto_scalarmult_bytes();
  t2.length !== p2 && L(_2, "invalid publicKey length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_scalarmult_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_scalarmult(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "weak public key");
}
function qt(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "privateKey");
  var _2, n2 = 0 | r._crypto_scalarmult_scalarbytes();
  e.length !== n2 && L(a2, "invalid privateKey length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_scalarmult_bytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_scalarmult_base(c2, _2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "unknown error");
}
function Ht(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "n");
  var n2, s2 = 0 | r._crypto_scalarmult_ed25519_scalarbytes();
  e.length !== s2 && L(_2, "invalid n length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "p");
  var c2, p2 = 0 | r._crypto_scalarmult_ed25519_bytes();
  t2.length !== p2 && L(_2, "invalid p length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_scalarmult_ed25519_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_scalarmult_ed25519(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid point or scalar is 0");
}
function zt(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "scalar");
  var _2, n2 = 0 | r._crypto_scalarmult_ed25519_scalarbytes();
  e.length !== n2 && L(a2, "invalid scalar length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_scalarmult_ed25519_bytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_scalarmult_ed25519_base(c2, _2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "scalar is 0");
}
function Wt(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "scalar");
  var _2, n2 = 0 | r._crypto_scalarmult_ed25519_scalarbytes();
  e.length !== n2 && L(a2, "invalid scalar length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_scalarmult_ed25519_bytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_scalarmult_ed25519_base_noclamp(c2, _2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "scalar is 0");
}
function jt(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "n");
  var n2, s2 = 0 | r._crypto_scalarmult_ed25519_scalarbytes();
  e.length !== s2 && L(_2, "invalid n length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "p");
  var c2, p2 = 0 | r._crypto_scalarmult_ed25519_bytes();
  t2.length !== p2 && L(_2, "invalid p length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_scalarmult_ed25519_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_scalarmult_ed25519_noclamp(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid point or scalar is 0");
}
function Jt(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "scalar");
  var n2, s2 = 0 | r._crypto_scalarmult_ristretto255_scalarbytes();
  e.length !== s2 && L(_2, "invalid scalar length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "element");
  var c2, p2 = 0 | r._crypto_scalarmult_ristretto255_bytes();
  t2.length !== p2 && L(_2, "invalid element length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_scalarmult_ristretto255_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_scalarmult_ristretto255(h2, n2, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "result is identity element");
}
function Qt(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "scalar");
  var _2, n2 = 0 | r._crypto_core_ristretto255_scalarbytes();
  e.length !== n2 && L(a2, "invalid scalar length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_core_ristretto255_bytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_scalarmult_ristretto255_base(c2, _2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "scalar is 0");
}
function Zt(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "message")), c2 = e.length;
  n2.push(s2), t2 = O(n2, t2, "nonce");
  var p2, o2 = 0 | r._crypto_secretbox_noncebytes();
  t2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "key");
  var h2, y2 = 0 | r._crypto_secretbox_keybytes();
  a2.length !== y2 && L(n2, "invalid key length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(0 | c2), l2 = i2.address;
  n2.push(l2);
  var u2 = new B(0 | r._crypto_secretbox_macbytes()), d2 = u2.address;
  if (n2.push(d2), !(0 | r._crypto_secretbox_detached(l2, d2, s2, c2, 0, p2, h2))) {
    var v2 = S({ mac: u2, cipher: i2 }, _2);
    return M(n2), v2;
  }
  N(n2, "invalid usage");
}
function $t(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "message")), c2 = e.length;
  n2.push(s2), t2 = O(n2, t2, "nonce");
  var p2, o2 = 0 | r._crypto_secretbox_noncebytes();
  t2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "key");
  var h2, y2 = 0 | r._crypto_secretbox_keybytes();
  a2.length !== y2 && L(n2, "invalid key length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(c2 + r._crypto_secretbox_macbytes() | 0), l2 = i2.address;
  if (n2.push(l2), !(0 | r._crypto_secretbox_easy(l2, s2, c2, 0, p2, h2))) {
    var u2 = S(i2, _2);
    return M(n2), u2;
  }
  N(n2, "invalid usage");
}
function ea(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_secretbox_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_secretbox_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function ra(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2);
  var c2 = K(e = O(s2, e, "ciphertext")), p2 = e.length;
  s2.push(c2), t2 = O(s2, t2, "mac");
  var o2, h2 = 0 | r._crypto_secretbox_macbytes();
  t2.length !== h2 && L(s2, "invalid mac length"), o2 = K(t2), s2.push(o2), a2 = O(s2, a2, "nonce");
  var y2, i2 = 0 | r._crypto_secretbox_noncebytes();
  a2.length !== i2 && L(s2, "invalid nonce length"), y2 = K(a2), s2.push(y2), _2 = O(s2, _2, "key");
  var l2, u2 = 0 | r._crypto_secretbox_keybytes();
  _2.length !== u2 && L(s2, "invalid key length"), l2 = K(_2), s2.push(l2);
  var d2 = new B(0 | p2), v2 = d2.address;
  if (s2.push(v2), !(0 | r._crypto_secretbox_open_detached(v2, c2, o2, p2, 0, y2, l2))) {
    var g2 = S(d2, n2);
    return M(s2), g2;
  }
  N(s2, "wrong secret key for the given ciphertext");
}
function ta(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), e = O(n2, e, "ciphertext");
  var s2, c2 = r._crypto_secretbox_macbytes(), p2 = e.length;
  p2 < c2 && L(n2, "ciphertext is too short"), s2 = K(e), n2.push(s2), t2 = O(n2, t2, "nonce");
  var o2, h2 = 0 | r._crypto_secretbox_noncebytes();
  t2.length !== h2 && L(n2, "invalid nonce length"), o2 = K(t2), n2.push(o2), a2 = O(n2, a2, "key");
  var y2, i2 = 0 | r._crypto_secretbox_keybytes();
  a2.length !== i2 && L(n2, "invalid key length"), y2 = K(a2), n2.push(y2);
  var l2 = new B(p2 - r._crypto_secretbox_macbytes() | 0), u2 = l2.address;
  if (n2.push(u2), !(0 | r._crypto_secretbox_open_easy(u2, s2, p2, 0, o2, y2))) {
    var d2 = S(l2, _2);
    return M(n2), d2;
  }
  N(n2, "wrong secret key for the given ciphertext");
}
function aa(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "header");
  var n2, s2 = 0 | r._crypto_secretstream_xchacha20poly1305_headerbytes();
  e.length !== s2 && L(_2, "invalid header length"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_secretstream_xchacha20poly1305_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(52).address;
  if (!(0 | r._crypto_secretstream_xchacha20poly1305_init_pull(o2, n2, c2))) {
    var h2 = o2;
    return M(_2), h2;
  }
  N(_2, "invalid usage");
}
function _a(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "key");
  var _2, n2 = 0 | r._crypto_secretstream_xchacha20poly1305_keybytes();
  e.length !== n2 && L(a2, "invalid key length"), _2 = K(e), a2.push(_2);
  var s2 = new B(52).address, c2 = new B(0 | r._crypto_secretstream_xchacha20poly1305_headerbytes()), p2 = c2.address;
  if (a2.push(p2), !(0 | r._crypto_secretstream_xchacha20poly1305_init_push(s2, p2, _2))) {
    var o2 = { state: s2, header: S(c2, t2) };
    return M(a2), o2;
  }
  N(a2, "invalid usage");
}
function na(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_secretstream_xchacha20poly1305_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_secretstream_xchacha20poly1305_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function sa(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), U(n2, e, "state_address"), t2 = O(n2, t2, "cipher");
  var s2, c2 = r._crypto_secretstream_xchacha20poly1305_abytes(), p2 = t2.length;
  p2 < c2 && L(n2, "cipher is too short"), s2 = K(t2), n2.push(s2);
  var o2 = null, h2 = 0;
  null != a2 && (o2 = K(a2 = O(n2, a2, "ad")), h2 = a2.length, n2.push(o2));
  var y2 = new B(p2 - r._crypto_secretstream_xchacha20poly1305_abytes() | 0), i2 = y2.address;
  n2.push(i2);
  var l2, u2 = (l2 = A2(1), n2.push(l2), (u2 = 0 === r._crypto_secretstream_xchacha20poly1305_pull(e, i2, 0, l2, s2, p2, 0, o2, h2) && { tag: r.HEAPU8[l2], message: y2 }) && { message: S(u2.message, _2), tag: u2.tag });
  return M(n2), u2;
}
function ca(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2), U(s2, e, "state_address");
  var c2 = K(t2 = O(s2, t2, "message_chunk")), p2 = t2.length;
  s2.push(c2);
  var o2 = null, h2 = 0;
  null != a2 && (o2 = K(a2 = O(s2, a2, "ad")), h2 = a2.length, s2.push(o2)), U(s2, _2, "tag"), ("number" != typeof _2 || (0 | _2) !== _2 || _2 < 0) && L(s2, "tag must be an unsigned integer");
  var y2 = new B(p2 + r._crypto_secretstream_xchacha20poly1305_abytes() | 0), i2 = y2.address;
  if (s2.push(i2), !(0 | r._crypto_secretstream_xchacha20poly1305_push(e, i2, 0, c2, p2, 0, o2, h2, 0, _2))) {
    var l2 = S(y2, n2);
    return M(s2), l2;
  }
  N(s2, "invalid usage");
}
function pa(e, t2) {
  var a2 = [];
  return Y(t2), U(a2, e, "state_address"), r._crypto_secretstream_xchacha20poly1305_rekey(e), M(a2), true;
}
function oa(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_shorthash_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_shorthash_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_shorthash(h2, n2, s2, 0, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function ha(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_shorthash_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_shorthash_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function ya(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "key");
  var c2, p2 = 0 | r._crypto_shorthash_siphashx24_keybytes();
  t2.length !== p2 && L(_2, "invalid key length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_shorthash_siphashx24_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_shorthash_siphashx24(h2, n2, s2, 0, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function ia(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "privateKey");
  var c2, p2 = 0 | r._crypto_sign_secretkeybytes();
  t2.length !== p2 && L(_2, "invalid privateKey length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(e.length + r._crypto_sign_bytes() | 0), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_sign(h2, null, n2, s2, 0, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function la(e, t2, a2) {
  var _2 = [];
  Y(a2);
  var n2 = K(e = O(_2, e, "message")), s2 = e.length;
  _2.push(n2), t2 = O(_2, t2, "privateKey");
  var c2, p2 = 0 | r._crypto_sign_secretkeybytes();
  t2.length !== p2 && L(_2, "invalid privateKey length"), c2 = K(t2), _2.push(c2);
  var o2 = new B(0 | r._crypto_sign_bytes()), h2 = o2.address;
  if (_2.push(h2), !(0 | r._crypto_sign_detached(h2, null, n2, s2, 0, c2))) {
    var y2 = S(o2, a2);
    return M(_2), y2;
  }
  N(_2, "invalid usage");
}
function ua(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "edPk");
  var _2, n2 = 0 | r._crypto_sign_publickeybytes();
  e.length !== n2 && L(a2, "invalid edPk length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_scalarmult_scalarbytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_sign_ed25519_pk_to_curve25519(c2, _2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid key");
}
function da(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "edSk");
  var _2, n2 = 0 | r._crypto_sign_secretkeybytes();
  e.length !== n2 && L(a2, "invalid edSk length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_scalarmult_scalarbytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_sign_ed25519_sk_to_curve25519(c2, _2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid key");
}
function va(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "privateKey");
  var _2, n2 = 0 | r._crypto_sign_secretkeybytes();
  e.length !== n2 && L(a2, "invalid privateKey length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_sign_publickeybytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_sign_ed25519_sk_to_pk(c2, _2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid key");
}
function ga(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "privateKey");
  var _2, n2 = 0 | r._crypto_sign_secretkeybytes();
  e.length !== n2 && L(a2, "invalid privateKey length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_sign_seedbytes()), c2 = s2.address;
  if (a2.push(c2), !(0 | r._crypto_sign_ed25519_sk_to_seed(c2, _2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid key");
}
function ba(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address"), t2 = O(_2, t2, "privateKey");
  var n2, s2 = 0 | r._crypto_sign_secretkeybytes();
  t2.length !== s2 && L(_2, "invalid privateKey length"), n2 = K(t2), _2.push(n2);
  var c2 = new B(0 | r._crypto_sign_bytes()), p2 = c2.address;
  if (_2.push(p2), !(0 | r._crypto_sign_final_create(e, p2, null, n2))) {
    var o2 = (r._free(e), S(c2, a2));
    return M(_2), o2;
  }
  N(_2, "invalid usage");
}
function fa(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), U(n2, e, "state_address"), t2 = O(n2, t2, "signature");
  var s2, c2 = 0 | r._crypto_sign_bytes();
  t2.length !== c2 && L(n2, "invalid signature length"), s2 = K(t2), n2.push(s2), a2 = O(n2, a2, "publicKey");
  var p2, o2 = 0 | r._crypto_sign_publickeybytes();
  a2.length !== o2 && L(n2, "invalid publicKey length"), p2 = K(a2), n2.push(p2);
  var h2 = !(0 | r._crypto_sign_final_verify(e, s2, p2));
  return M(n2), h2;
}
function ma(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(208).address;
  if (!(0 | r._crypto_sign_init(a2))) {
    var _2 = a2;
    return M(t2), _2;
  }
  N(t2, "internal error");
}
function ka(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_sign_publickeybytes()), _2 = a2.address;
  t2.push(_2);
  var n2 = new B(0 | r._crypto_sign_secretkeybytes()), s2 = n2.address;
  if (t2.push(s2), !(0 | r._crypto_sign_keypair(_2, s2))) {
    var c2 = { publicKey: S(a2, e), privateKey: S(n2, e), keyType: "ed25519" };
    return M(t2), c2;
  }
  N(t2, "internal error");
}
function xa(e, t2, a2) {
  var _2 = [];
  Y(a2), e = O(_2, e, "signedMessage");
  var n2, s2 = r._crypto_sign_bytes(), c2 = e.length;
  c2 < s2 && L(_2, "signedMessage is too short"), n2 = K(e), _2.push(n2), t2 = O(_2, t2, "publicKey");
  var p2, o2 = 0 | r._crypto_sign_publickeybytes();
  t2.length !== o2 && L(_2, "invalid publicKey length"), p2 = K(t2), _2.push(p2);
  var h2 = new B(c2 - r._crypto_sign_bytes() | 0), y2 = h2.address;
  if (_2.push(y2), !(0 | r._crypto_sign_open(y2, null, n2, c2, 0, p2))) {
    var i2 = S(h2, a2);
    return M(_2), i2;
  }
  N(_2, "incorrect signature for the given public key");
}
function Ea(e, t2) {
  var a2 = [];
  Y(t2), e = O(a2, e, "seed");
  var _2, n2 = 0 | r._crypto_sign_seedbytes();
  e.length !== n2 && L(a2, "invalid seed length"), _2 = K(e), a2.push(_2);
  var s2 = new B(0 | r._crypto_sign_publickeybytes()), c2 = s2.address;
  a2.push(c2);
  var p2 = new B(0 | r._crypto_sign_secretkeybytes()), o2 = p2.address;
  if (a2.push(o2), !(0 | r._crypto_sign_seed_keypair(c2, o2, _2))) {
    var h2 = { publicKey: S(s2, t2), privateKey: S(p2, t2), keyType: "ed25519" };
    return M(a2), h2;
  }
  N(a2, "invalid usage");
}
function Ta(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_sign_update(e, n2, s2, 0) && N(_2, "invalid usage"), M(_2);
}
function Sa(e, t2, a2) {
  var _2 = [];
  e = O(_2, e, "signature");
  var n2, s2 = 0 | r._crypto_sign_bytes();
  e.length !== s2 && L(_2, "invalid signature length"), n2 = K(e), _2.push(n2);
  var c2 = K(t2 = O(_2, t2, "message")), p2 = t2.length;
  _2.push(c2), a2 = O(_2, a2, "publicKey");
  var o2, h2 = 0 | r._crypto_sign_publickeybytes();
  a2.length !== h2 && L(_2, "invalid publicKey length"), o2 = K(a2), _2.push(o2);
  var y2 = !(0 | r._crypto_sign_verify_detached(n2, c2, p2, 0, o2));
  return M(_2), y2;
}
function wa(e, t2, a2, _2) {
  var n2 = [];
  Y(_2), U(n2, e, "outLength"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(n2, "outLength must be an unsigned integer"), t2 = O(n2, t2, "key");
  var s2, c2 = 0 | r._crypto_stream_chacha20_keybytes();
  t2.length !== c2 && L(n2, "invalid key length"), s2 = K(t2), n2.push(s2), a2 = O(n2, a2, "nonce");
  var p2, o2 = 0 | r._crypto_stream_chacha20_noncebytes();
  a2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(a2), n2.push(p2);
  var h2 = new B(0 | e), y2 = h2.address;
  n2.push(y2), r._crypto_stream_chacha20(y2, e, 0, p2, s2);
  var i2 = S(h2, _2);
  return M(n2), i2;
}
function Ya(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "input_message")), c2 = e.length;
  n2.push(s2), t2 = O(n2, t2, "nonce");
  var p2, o2 = 0 | r._crypto_stream_chacha20_ietf_noncebytes();
  t2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "key");
  var h2, y2 = 0 | r._crypto_stream_chacha20_ietf_keybytes();
  a2.length !== y2 && L(n2, "invalid key length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(0 | c2), l2 = i2.address;
  if (n2.push(l2), 0 === r._crypto_stream_chacha20_ietf_xor(l2, s2, c2, 0, p2, h2)) {
    var u2 = S(i2, _2);
    return M(n2), u2;
  }
  N(n2, "invalid usage");
}
function Ba(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2);
  var c2 = K(e = O(s2, e, "input_message")), p2 = e.length;
  s2.push(c2), t2 = O(s2, t2, "nonce");
  var o2, h2 = 0 | r._crypto_stream_chacha20_ietf_noncebytes();
  t2.length !== h2 && L(s2, "invalid nonce length"), o2 = K(t2), s2.push(o2), U(s2, a2, "nonce_increment"), ("number" != typeof a2 || (0 | a2) !== a2 || a2 < 0) && L(s2, "nonce_increment must be an unsigned integer"), _2 = O(s2, _2, "key");
  var y2, i2 = 0 | r._crypto_stream_chacha20_ietf_keybytes();
  _2.length !== i2 && L(s2, "invalid key length"), y2 = K(_2), s2.push(y2);
  var l2 = new B(0 | p2), u2 = l2.address;
  if (s2.push(u2), 0 === r._crypto_stream_chacha20_ietf_xor_ic(u2, c2, p2, 0, o2, a2, y2)) {
    var d2 = S(l2, n2);
    return M(s2), d2;
  }
  N(s2, "invalid usage");
}
function Ka(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_stream_chacha20_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_stream_chacha20_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function Aa(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "input_message")), c2 = e.length;
  n2.push(s2), t2 = O(n2, t2, "nonce");
  var p2, o2 = 0 | r._crypto_stream_chacha20_noncebytes();
  t2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "key");
  var h2, y2 = 0 | r._crypto_stream_chacha20_keybytes();
  a2.length !== y2 && L(n2, "invalid key length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(0 | c2), l2 = i2.address;
  if (n2.push(l2), 0 === r._crypto_stream_chacha20_xor(l2, s2, c2, 0, p2, h2)) {
    var u2 = S(i2, _2);
    return M(n2), u2;
  }
  N(n2, "invalid usage");
}
function Ia(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2);
  var c2 = K(e = O(s2, e, "input_message")), p2 = e.length;
  s2.push(c2), t2 = O(s2, t2, "nonce");
  var o2, h2 = 0 | r._crypto_stream_chacha20_noncebytes();
  t2.length !== h2 && L(s2, "invalid nonce length"), o2 = K(t2), s2.push(o2), U(s2, a2, "nonce_increment"), ("number" != typeof a2 || (0 | a2) !== a2 || a2 < 0) && L(s2, "nonce_increment must be an unsigned integer"), _2 = O(s2, _2, "key");
  var y2, i2 = 0 | r._crypto_stream_chacha20_keybytes();
  _2.length !== i2 && L(s2, "invalid key length"), y2 = K(_2), s2.push(y2);
  var l2 = new B(0 | p2), u2 = l2.address;
  if (s2.push(u2), 0 === r._crypto_stream_chacha20_xor_ic(u2, c2, p2, 0, o2, a2, 0, y2)) {
    var d2 = S(l2, n2);
    return M(s2), d2;
  }
  N(s2, "invalid usage");
}
function Ma(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_stream_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_stream_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function Na(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(0 | r._crypto_stream_xchacha20_keybytes()), _2 = a2.address;
  t2.push(_2), r._crypto_stream_xchacha20_keygen(_2);
  var n2 = S(a2, e);
  return M(t2), n2;
}
function La(e, t2, a2, _2) {
  var n2 = [];
  Y(_2);
  var s2 = K(e = O(n2, e, "input_message")), c2 = e.length;
  n2.push(s2), t2 = O(n2, t2, "nonce");
  var p2, o2 = 0 | r._crypto_stream_xchacha20_noncebytes();
  t2.length !== o2 && L(n2, "invalid nonce length"), p2 = K(t2), n2.push(p2), a2 = O(n2, a2, "key");
  var h2, y2 = 0 | r._crypto_stream_xchacha20_keybytes();
  a2.length !== y2 && L(n2, "invalid key length"), h2 = K(a2), n2.push(h2);
  var i2 = new B(0 | c2), l2 = i2.address;
  if (n2.push(l2), 0 === r._crypto_stream_xchacha20_xor(l2, s2, c2, 0, p2, h2)) {
    var u2 = S(i2, _2);
    return M(n2), u2;
  }
  N(n2, "invalid usage");
}
function Ua(e, t2, a2, _2, n2) {
  var s2 = [];
  Y(n2);
  var c2 = K(e = O(s2, e, "input_message")), p2 = e.length;
  s2.push(c2), t2 = O(s2, t2, "nonce");
  var o2, h2 = 0 | r._crypto_stream_xchacha20_noncebytes();
  t2.length !== h2 && L(s2, "invalid nonce length"), o2 = K(t2), s2.push(o2), U(s2, a2, "nonce_increment"), ("number" != typeof a2 || (0 | a2) !== a2 || a2 < 0) && L(s2, "nonce_increment must be an unsigned integer"), _2 = O(s2, _2, "key");
  var y2, i2 = 0 | r._crypto_stream_xchacha20_keybytes();
  _2.length !== i2 && L(s2, "invalid key length"), y2 = K(_2), s2.push(y2);
  var l2 = new B(0 | p2), u2 = l2.address;
  if (s2.push(u2), 0 === r._crypto_stream_xchacha20_xor_ic(u2, c2, p2, 0, o2, a2, 0, y2)) {
    var d2 = S(l2, n2);
    return M(s2), d2;
  }
  N(s2, "invalid usage");
}
function Oa(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "out_length"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(_2, "out_length must be an unsigned integer");
  var n2 = K(t2 = O(_2, t2, "message")), s2 = t2.length;
  _2.push(n2);
  var c2 = new B(e |= 0), p2 = c2.address;
  if (_2.push(p2), !(0 | r._crypto_xof_shake128(p2, e, n2, s2, 0))) {
    var o2 = S(c2, a2);
    return M(_2), o2;
  }
  N(_2, "invalid usage");
}
function Ca(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(256).address;
  if (!(0 | r._crypto_xof_shake128_init(a2))) {
    var _2 = a2;
    return M(t2), _2;
  }
  N(t2, "invalid usage");
}
function Ra(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "domain"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(a2, "domain must be an unsigned integer");
  var _2 = new B(256).address;
  if (!(0 | r._crypto_xof_shake128_init_with_domain(_2, e))) {
    var n2 = _2;
    return M(a2), n2;
  }
  N(a2, "invalid usage");
}
function Pa(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address"), U(_2, t2, "out_length"), ("number" != typeof t2 || (0 | t2) !== t2 || t2 < 0) && L(_2, "out_length must be an unsigned integer");
  var n2 = new B(t2 |= 0), s2 = n2.address;
  if (_2.push(s2), !(0 | r._crypto_xof_shake128_squeeze(e, s2, t2))) {
    var c2 = S(n2, a2);
    return M(_2), c2;
  }
  N(_2, "invalid usage");
}
function Xa(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_xof_shake128_update(e, n2, s2, 0) && N(_2, "invalid usage"), M(_2);
}
function Da(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "out_length"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(_2, "out_length must be an unsigned integer");
  var n2 = K(t2 = O(_2, t2, "message")), s2 = t2.length;
  _2.push(n2);
  var c2 = new B(e |= 0), p2 = c2.address;
  if (_2.push(p2), !(0 | r._crypto_xof_shake256(p2, e, n2, s2, 0))) {
    var o2 = S(c2, a2);
    return M(_2), o2;
  }
  N(_2, "invalid usage");
}
function Ga(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(256).address;
  if (!(0 | r._crypto_xof_shake256_init(a2))) {
    var _2 = a2;
    return M(t2), _2;
  }
  N(t2, "invalid usage");
}
function Fa(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "domain"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(a2, "domain must be an unsigned integer");
  var _2 = new B(256).address;
  if (!(0 | r._crypto_xof_shake256_init_with_domain(_2, e))) {
    var n2 = _2;
    return M(a2), n2;
  }
  N(a2, "invalid usage");
}
function Va(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address"), U(_2, t2, "out_length"), ("number" != typeof t2 || (0 | t2) !== t2 || t2 < 0) && L(_2, "out_length must be an unsigned integer");
  var n2 = new B(t2 |= 0), s2 = n2.address;
  if (_2.push(s2), !(0 | r._crypto_xof_shake256_squeeze(e, s2, t2))) {
    var c2 = S(n2, a2);
    return M(_2), c2;
  }
  N(_2, "invalid usage");
}
function qa(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_xof_shake256_update(e, n2, s2, 0) && N(_2, "invalid usage"), M(_2);
}
function Ha(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "out_length"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(_2, "out_length must be an unsigned integer");
  var n2 = K(t2 = O(_2, t2, "message")), s2 = t2.length;
  _2.push(n2);
  var c2 = new B(e |= 0), p2 = c2.address;
  if (_2.push(p2), !(0 | r._crypto_xof_turboshake128(p2, e, n2, s2, 0))) {
    var o2 = S(c2, a2);
    return M(_2), o2;
  }
  N(_2, "invalid usage");
}
function za(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(256).address;
  if (!(0 | r._crypto_xof_turboshake128_init(a2))) {
    var _2 = a2;
    return M(t2), _2;
  }
  N(t2, "invalid usage");
}
function Wa(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "domain"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(a2, "domain must be an unsigned integer");
  var _2 = new B(256).address;
  if (!(0 | r._crypto_xof_turboshake128_init_with_domain(_2, e))) {
    var n2 = _2;
    return M(a2), n2;
  }
  N(a2, "invalid usage");
}
function ja(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address"), U(_2, t2, "out_length"), ("number" != typeof t2 || (0 | t2) !== t2 || t2 < 0) && L(_2, "out_length must be an unsigned integer");
  var n2 = new B(t2 |= 0), s2 = n2.address;
  if (_2.push(s2), !(0 | r._crypto_xof_turboshake128_squeeze(e, s2, t2))) {
    var c2 = S(n2, a2);
    return M(_2), c2;
  }
  N(_2, "invalid usage");
}
function Ja(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_xof_turboshake128_update(e, n2, s2, 0) && N(_2, "invalid usage"), M(_2);
}
function Qa(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "out_length"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(_2, "out_length must be an unsigned integer");
  var n2 = K(t2 = O(_2, t2, "message")), s2 = t2.length;
  _2.push(n2);
  var c2 = new B(e |= 0), p2 = c2.address;
  if (_2.push(p2), !(0 | r._crypto_xof_turboshake256(p2, e, n2, s2, 0))) {
    var o2 = S(c2, a2);
    return M(_2), o2;
  }
  N(_2, "invalid usage");
}
function Za(e) {
  var t2 = [];
  Y(e);
  var a2 = new B(256).address;
  if (!(0 | r._crypto_xof_turboshake256_init(a2))) {
    var _2 = a2;
    return M(t2), _2;
  }
  N(t2, "invalid usage");
}
function $a(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "domain"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(a2, "domain must be an unsigned integer");
  var _2 = new B(256).address;
  if (!(0 | r._crypto_xof_turboshake256_init_with_domain(_2, e))) {
    var n2 = _2;
    return M(a2), n2;
  }
  N(a2, "invalid usage");
}
function e_(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address"), U(_2, t2, "out_length"), ("number" != typeof t2 || (0 | t2) !== t2 || t2 < 0) && L(_2, "out_length must be an unsigned integer");
  var n2 = new B(t2 |= 0), s2 = n2.address;
  if (_2.push(s2), !(0 | r._crypto_xof_turboshake256_squeeze(e, s2, t2))) {
    var c2 = S(n2, a2);
    return M(_2), c2;
  }
  N(_2, "invalid usage");
}
function r_(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "state_address");
  var n2 = K(t2 = O(_2, t2, "message_chunk")), s2 = t2.length;
  _2.push(n2), 0 | r._crypto_xof_turboshake256_update(e, n2, s2, 0) && N(_2, "invalid usage"), M(_2);
}
function t_(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "length"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(a2, "length must be an unsigned integer");
  var _2 = new B(0 | e), n2 = _2.address;
  a2.push(n2), r._randombytes_buf(n2, e);
  var s2 = S(_2, t2);
  return M(a2), s2;
}
function a_(e, t2, a2) {
  var _2 = [];
  Y(a2), U(_2, e, "length"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(_2, "length must be an unsigned integer"), t2 = O(_2, t2, "seed");
  var n2, s2 = 0 | r._randombytes_seedbytes();
  t2.length !== s2 && L(_2, "invalid seed length"), n2 = K(t2), _2.push(n2);
  var c2 = new B(0 | e), p2 = c2.address;
  _2.push(p2), r._randombytes_buf_deterministic(p2, e, n2);
  var o2 = S(c2, a2);
  return M(_2), o2;
}
function __(e) {
  Y(e), r._randombytes_close();
}
function n_(e) {
  Y(e);
  var t2 = r._randombytes_random() >>> 0;
  return M([]), t2;
}
function s_(e, t2) {
  var a2 = [];
  Y(t2);
  for (var _2 = r._malloc(24), n2 = 0; n2 < 6; n2++) r.setValue(_2 + 4 * n2, r.Runtime.addFunction(e[["implementation_name", "random", "stir", "uniform", "buf", "close"][n2]]), "i32");
  0 | r._randombytes_set_implementation(_2) && N(a2, "unsupported implementation"), M(a2);
}
function c_(e) {
  Y(e), r._randombytes_stir();
}
function p_(e, t2) {
  var a2 = [];
  Y(t2), U(a2, e, "upper_bound"), ("number" != typeof e || (0 | e) !== e || e < 0) && L(a2, "upper_bound must be an unsigned integer");
  var _2 = r._randombytes_uniform(e) >>> 0;
  return M(a2), _2;
}
function o_(e) {
  var t2, a2 = [];
  16 !== (e = O(a2, e, "bin")).length && L(a2, "invalid bin length"), t2 = K(e), a2.push(t2);
  var _2 = new B(46).address;
  if (a2.push(_2), 0 !== r._sodium_bin2ip(_2, 46, t2)) {
    var n2 = r.UTF8ToString(_2);
    return M(a2), n2;
  }
  N(a2, "conversion failed");
}
function h_(e, t2) {
  var a2 = [];
  Y(t2), "string" != typeof e && L(a2, "ip must be a string");
  var _2 = K(e = v(e + "\0")), n2 = e.length - 1;
  a2.push(_2);
  var s2 = new B(16), c2 = s2.address;
  if (a2.push(c2), !(0 | r._sodium_ip2bin(c2, _2, n2))) {
    var p2 = S(s2, t2);
    return M(a2), p2;
  }
  N(a2, "invalid IP address");
}
function y_() {
  var e = r._sodium_version_string(), t2 = r.UTF8ToString(e);
  return M([]), t2;
}
B.prototype.to_Uint8Array = function() {
  var e = new Uint8Array(this.length);
  return e.set(r.HEAPU8.subarray(this.address, this.address + this.length)), e;
}, t.add = o, t.base64_variants = m, t.compare = l, t.from_base64 = x, t.from_hex = b, t.from_string = v, t.increment = p, t.is_zero = h, t.memcmp = i, t.memzero = y, t.output_formats = T, t.pad = u, t.unpad = d, t.ready = s, t.symbols = c, t.to_base64 = E, t.to_hex = f, t.to_string = g;
var libsodium_wrappers_default = t;

// src/features/auth/account-password.ts
var ACCOUNT_AUTH_KDF = Object.freeze({
  algorithm: "argon2id13",
  operations: 3,
  memoryBytes: 64 * 1024 * 1024,
  outputBytes: 32
});
function normalizeAccountUsername(username) {
  return username.trim().toLocaleLowerCase("en-US");
}

// src/features/vault/batch-scoped-value-cache.ts
var BatchScopedValueCache = class {
  entries = /* @__PURE__ */ new Map();
  getOrLoad(key, fingerprint, load) {
    const cached = this.entries.get(key);
    if (cached?.fingerprint === fingerprint) return cached.value;
    const value = load();
    const entry = { fingerprint, value };
    this.entries.set(key, entry);
    void value.catch(() => {
      if (this.entries.get(key) === entry) this.entries.delete(key);
    });
    return value;
  }
  delete(key) {
    this.entries.delete(key);
  }
  clear() {
    this.entries.clear();
  }
};

// src/features/vault/bounded-async.ts
var NO_FAILURE = /* @__PURE__ */ Symbol("no failure");
function concurrencyForHardware(hardwareConcurrency, maximum, divisor = 1, fallback = 4) {
  if (!Number.isSafeInteger(maximum) || maximum < 1 || !Number.isSafeInteger(divisor) || divisor < 1 || !Number.isSafeInteger(fallback) || fallback < 1) {
    throw new Error("Invalid bounded-concurrency configuration.");
  }
  const available = typeof hardwareConcurrency === "number" && Number.isFinite(hardwareConcurrency) && hardwareConcurrency >= 1 ? Math.floor(hardwareConcurrency) : fallback;
  return Math.max(1, Math.min(maximum, Math.ceil(available / divisor)));
}
function detectedCryptoConcurrency(maximum, divisor = 1) {
  const hardwareConcurrency = typeof navigator === "undefined" ? void 0 : navigator.hardwareConcurrency;
  return concurrencyForHardware(hardwareConcurrency, maximum, divisor);
}
async function mapWithConcurrency(values, concurrency, transform) {
  if (!Number.isSafeInteger(concurrency) || concurrency < 1) {
    throw new Error("Concurrency must be a positive integer.");
  }
  if (values.length === 0) return [];
  const results = new Array(values.length);
  let nextIndex = 0;
  let stopped = false;
  let failure = NO_FAILURE;
  const workers = Array.from(
    { length: Math.min(concurrency, values.length) },
    async () => {
      while (!stopped) {
        const index = nextIndex;
        if (index >= values.length) return;
        nextIndex += 1;
        try {
          results[index] = await transform(values[index], index);
        } catch (error) {
          if (failure === NO_FAILURE) failure = error;
          stopped = true;
        }
      }
    }
  );
  await Promise.all(workers);
  if (failure !== NO_FAILURE) throw failure;
  return results;
}

// src/features/vault/bounded-lru-cache.ts
var BoundedLruCache = class {
  constructor(maximumEntries) {
    this.maximumEntries = maximumEntries;
    if (!Number.isSafeInteger(maximumEntries) || maximumEntries < 1) {
      throw new Error("The cache entry limit must be a positive integer.");
    }
  }
  maximumEntries;
  entries = /* @__PURE__ */ new Map();
  get size() {
    return this.entries.size;
  }
  has(key) {
    return this.entries.has(key);
  }
  get(key) {
    const entry = this.entries.get(key);
    if (!entry) return void 0;
    this.entries.delete(key);
    this.entries.set(key, entry);
    return entry.value;
  }
  set(key, value) {
    const existing = this.entries.get(key);
    if (existing) {
      if (existing.pins > 0) {
        existing.pendingValue = value;
        existing.hasPendingValue = true;
      } else existing.value = value;
      this.entries.delete(key);
      this.entries.set(key, existing);
    } else {
      this.entries.set(key, { value, pins: 0, hasPendingValue: false });
    }
    this.trim(key);
  }
  delete(key) {
    return this.entries.delete(key);
  }
  deleteIfUnpinned(key, expectedValue) {
    const entry = this.entries.get(key);
    if (!entry || entry.pins > 0 || expectedValue !== void 0 && entry.value !== expectedValue) {
      return false;
    }
    return this.entries.delete(key);
  }
  isPinned(key) {
    return (this.entries.get(key)?.pins ?? 0) > 0;
  }
  oldestUnpinnedKey() {
    for (const [key, entry] of this.entries) {
      if (entry.pins === 0) return key;
    }
    return void 0;
  }
  keys() {
    return this.entries.keys();
  }
  clear() {
    this.entries.clear();
  }
  pin(key) {
    const value = this.get(key);
    if (value === void 0) return null;
    const entry = this.entries.get(key);
    if (!entry) return null;
    entry.pins += 1;
    let active = true;
    return {
      value,
      release: () => {
        if (!active) return;
        active = false;
        if (this.entries.get(key) === entry) {
          entry.pins -= 1;
          if (entry.pins === 0 && entry.hasPendingValue) {
            entry.value = entry.pendingValue;
            entry.pendingValue = void 0;
            entry.hasPendingValue = false;
          }
          this.trim();
        }
      }
    };
  }
  trim(protectedKey) {
    while (this.entries.size > this.maximumEntries) {
      let removed = false;
      for (const [key, entry] of this.entries) {
        if (entry.pins > 0 || key === protectedKey) continue;
        this.entries.delete(key);
        removed = true;
        break;
      }
      if (!removed) return;
    }
  }
};

// node_modules/@noble/hashes/_u64.js
var fromNumH = (n2) => n2 / 2 ** 32 | 0;
var fromNumL = (n2) => n2 >>> 0;
function setU64FromNum(view, byteOffset, n2, isLE2) {
  const h2 = fromNumH(n2);
  const l2 = fromNumL(n2);
  view.setUint32(byteOffset, isLE2 ? l2 : h2, isLE2);
  view.setUint32(byteOffset + 4, isLE2 ? h2 : l2, isLE2);
}

// node_modules/@noble/hashes/utils.js
function isBytes3(a2) {
  return a2 instanceof Uint8Array || ArrayBuffer.isView(a2) && a2.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a2 && a2.BYTES_PER_ELEMENT === 1;
}
var atitle = (title) => title ? `"${title}" ` : "";
function anumber2(n2, title = "") {
  if (typeof n2 !== "number")
    throw new TypeError(atitle(title) + "expected number, got " + typeof n2);
  if (!Number.isSafeInteger(n2) || n2 < 0)
    throw new RangeError(atitle(title) + "expected integer >= 0, got " + n2);
  return n2;
}
function abytes3(value, length, title = "") {
  if (isBytes3(value) && (length === void 0 || value.length === length))
    return value;
  if (length !== void 0)
    anumber2(length, "length");
  const bytes = isBytes3(value);
  const ofLen = length !== void 0 ? ` of length ${length}` : "";
  const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
  const message = atitle(title) + "expected Uint8Array" + ofLen + ", got " + got;
  if (!bytes)
    throw new TypeError(message);
  throw new RangeError(message);
}
var aobject = (value, label) => {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new TypeError((label === "object" ? "" : `"${label}" `) + "expected object, got type=" + typeof value);
};
var aopts = (value, label) => {
  aobject(value, label);
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null)
    throw new TypeError(`"${label}" expected plain object`);
  if (Object.hasOwn(value, "__proto__"))
    throw new TypeError(`"${label}.__proto__" is not allowed`);
};
function aexists3(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("hash was destroyed");
  if (checkFinished && instance.finished)
    throw new Error("digest() was already called");
}
function aoutput3(out, instance) {
  abytes3(out, void 0, "output");
  const min = instance.outputLen;
  if (!(out.length >= min)) {
    throw new RangeError('"output" expected length >= ' + min);
  }
}
function clean3(...arrays) {
  for (let i2 = 0; i2 < arrays.length; i2++) {
    arrays[i2].fill(0);
  }
}
function createView3(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr3(word, shift) {
  return word << 32 - shift | word >>> shift;
}
function checkOpts(defaults, opts, title = "opts") {
  aopts(defaults, "defaults");
  if (opts !== void 0)
    aopts(opts, title);
  const merged = Object.assign(/* @__PURE__ */ Object.create(null), defaults, opts);
  return merged;
}
function createHasher3(hashCons, info = {}) {
  if (typeof hashCons !== "function")
    throw new TypeError('"hashCons" expected function, got type=' + typeof hashCons);
  info = checkOpts({}, info, "info");
  const hashC = (msg, opts) => hashCons(opts).update(msg).digest();
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.canXOF = tmp.canXOF;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
var oidNist2 = (suffix) => ({
  // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
  // Larger suffix values would need base-128 OID encoding and a different length byte.
  oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
});

// node_modules/@noble/hashes/_md.js
function Chi3(a2, b2, c2) {
  return a2 & b2 ^ ~a2 & c2;
}
function Maj3(a2, b2, c2) {
  return a2 & b2 ^ a2 & c2 ^ b2 & c2;
}
var HashMD3 = class {
  blockLen;
  outputLen;
  canXOF = false;
  padOffset;
  isLE;
  // For partial updates less than block size
  buffer;
  view;
  finished = false;
  length = 0;
  pos = 0;
  destroyed = false;
  constructor(blockLen, outputLen, padOffset, isLE2) {
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE2;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView3(this.buffer);
  }
  update(data) {
    aexists3(this);
    abytes3(data);
    const { view, buffer, blockLen } = this;
    const len = data.length;
    let processed = false;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView3(data);
        for (; blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        processed = true;
        continue;
      }
      buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
        processed = true;
      }
    }
    this.length += data.length;
    if (processed)
      this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists3(this);
    aoutput3(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE: isLE2 } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    buffer.fill(0, pos);
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      buffer.fill(0);
    }
    setU64FromNum(view, blockLen - 8, this.length * 8, isLE2);
    this.process(view, 0);
    this.roundClean();
    const oview = out === buffer ? view : createView3(out);
    const len = this.outputLen;
    const outLen = len / 4;
    const state = this.get();
    if (len % 4 || outLen > state.length)
      throw new Error("invalid outputLen");
    for (let i2 = 0; i2 < outLen; i2++)
      oview.setUint32(4 * i2, state[i2], isLE2);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneIntoMeta(to) {
    const { buffer, length, finished, destroyed, pos } = this;
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    if (pos)
      to.buffer.set(buffer);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};
var SHA256_IV3 = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);

// node_modules/@noble/hashes/sha2.js
var SHA256_K3 = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var SHA256_W3 = /* @__PURE__ */ new Uint32Array(64);
var SHA2_32B2 = class extends HashMD3 {
  // We cannot use array here since array allows indexing by variable
  // which means optimizer/compiler cannot use registers.
  // Numeric initializers matter: starting the fields as `undefined` changes
  // V8's field representation and makes sha256 3x slower (measured).
  A = 0;
  B = 0;
  C = 0;
  D = 0;
  E = 0;
  F = 0;
  G = 0;
  H = 0;
  constructor(outputLen, IV) {
    super(64, outputLen, 8, false);
    this.A = IV[0] | 0;
    this.B = IV[1] | 0;
    this.C = IV[2] | 0;
    this.D = IV[3] | 0;
    this.E = IV[4] | 0;
    this.F = IV[5] | 0;
    this.G = IV[6] | 0;
    this.H = IV[7] | 0;
  }
  get() {
    const { A: A3, B: B2, C: C2, D: D2, E: E2, F: F2, G: G2, H: H2 } = this;
    return [A3, B2, C2, D2, E2, F2, G2, H2];
  }
  // prettier-ignore
  set(A3, B2, C2, D2, E2, F2, G2, H2) {
    this.A = A3 | 0;
    this.B = B2 | 0;
    this.C = C2 | 0;
    this.D = D2 | 0;
    this.E = E2 | 0;
    this.F = F2 | 0;
    this.G = G2 | 0;
    this.H = H2 | 0;
  }
  _cloneInto(to) {
    (to ||= new this.constructor()).set(...this.get());
    return this._cloneIntoMeta(to);
  }
  process(view, offset) {
    for (let i2 = 0; i2 < 16; i2++, offset += 4)
      SHA256_W3[i2] = view.getUint32(offset, false);
    for (let i2 = 16; i2 < 64; i2++) {
      const W15 = SHA256_W3[i2 - 15];
      const W2 = SHA256_W3[i2 - 2];
      const s0 = rotr3(W15, 7) ^ rotr3(W15, 18) ^ W15 >>> 3;
      const s1 = rotr3(W2, 17) ^ rotr3(W2, 19) ^ W2 >>> 10;
      SHA256_W3[i2] = s1 + SHA256_W3[i2 - 7] + s0 + SHA256_W3[i2 - 16] | 0;
    }
    let { A: A3, B: B2, C: C2, D: D2, E: E2, F: F2, G: G2, H: H2 } = this;
    for (let i2 = 0; i2 < 64; i2++) {
      const sigma1 = rotr3(E2, 6) ^ rotr3(E2, 11) ^ rotr3(E2, 25);
      const T1 = H2 + sigma1 + Chi3(E2, F2, G2) + SHA256_K3[i2] + SHA256_W3[i2] | 0;
      const sigma0 = rotr3(A3, 2) ^ rotr3(A3, 13) ^ rotr3(A3, 22);
      const T2 = sigma0 + Maj3(A3, B2, C2) | 0;
      H2 = G2;
      G2 = F2;
      F2 = E2;
      E2 = D2 + T1 | 0;
      D2 = C2;
      C2 = B2;
      B2 = A3;
      A3 = T1 + T2 | 0;
    }
    A3 = A3 + this.A | 0;
    B2 = B2 + this.B | 0;
    C2 = C2 + this.C | 0;
    D2 = D2 + this.D | 0;
    E2 = E2 + this.E | 0;
    F2 = F2 + this.F | 0;
    G2 = G2 + this.G | 0;
    H2 = H2 + this.H | 0;
    this.set(A3, B2, C2, D2, E2, F2, G2, H2);
  }
  roundClean() {
    clean3(SHA256_W3);
  }
  destroy() {
    this.destroyed = true;
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    clean3(this.buffer);
  }
};
var _SHA2562 = class extends SHA2_32B2 {
  constructor() {
    super(32, SHA256_IV3);
  }
};
var sha2564 = /* @__PURE__ */ createHasher3(
  () => new _SHA2562(),
  /* @__PURE__ */ oidNist2(1)
);

// src/features/vault/protocol.ts
var VAULT_FORMAT_VERSION = 1;
var VAULT_SHARE_ENVELOPE_VERSION = 2;
var VAULT_SHARE_DIRECTORY_VERSION = 1;
var MAX_SHARE_WRAPPERS = 1e5;
var VAULT_SUITE_ID = 1;
var VAULT_AAD_SCHEMA_ID = 1;
var VAULT_CRYPTO_CHUNK_BYTES = 4 * 1024 * 1024;
var PROTOCOL_HASH_CONCURRENCY = detectedCryptoConcurrency(16);
var ARGON2ID_PROFILE = Object.freeze({
  algorithm: "argon2id13",
  operations: 3,
  memoryBytes: 256 * 1024 * 1024,
  outputBytes: 32
});
var WEB_CRYPTO_RANDOM_BYTES_LIMIT = 65536;
function assertArgon2idProfile(kdf) {
  if (kdf.algorithm !== ARGON2ID_PROFILE.algorithm || kdf.operations !== ARGON2ID_PROFILE.operations || kdf.memoryBytes !== ARGON2ID_PROFILE.memoryBytes || kdf.outputBytes !== ARGON2ID_PROFILE.outputBytes) {
    throw new Error("The server returned an unsupported vault KDF profile.");
  }
}
function fillRandomBytes(output) {
  for (let offset = 0; offset < output.length; offset += WEB_CRYPTO_RANDOM_BYTES_LIMIT) {
    crypto.getRandomValues(
      output.subarray(offset, offset + WEB_CRYPTO_RANDOM_BYTES_LIMIT)
    );
  }
  return output;
}
function randomBytes(length) {
  return fillRandomBytes(new Uint8Array(length));
}
function randomPrefixedId(prefix) {
  return `${prefix}${toBase64Url(randomBytes(18))}`;
}
function toBase64Url(value) {
  const bytes = value instanceof Uint8Array ? value : new Uint8Array(value);
  let binary = "";
  const blockSize = 32768;
  for (let offset = 0; offset < bytes.length; offset += blockSize) {
    binary += String.fromCharCode(
      ...bytes.subarray(offset, offset + blockSize)
    );
  }
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
}
function fromBase64Url(value) {
  if (!/^[A-Za-z0-9_-]*$/u.test(value)) {
    throw new Error("Invalid base64url value.");
  }
  const padded = value.replaceAll("-", "+").replaceAll("_", "/") + "=".repeat((4 - value.length % 4) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}
function concatBytes(...values) {
  const length = values.reduce((total, value) => total + value.length, 0);
  const output = new Uint8Array(length);
  let offset = 0;
  for (const value of values) {
    output.set(value, offset);
    offset += value.length;
  }
  return output;
}
function encodeVaultRewrapProof(payload) {
  assertArgon2idProfile(payload.kdf);
  const accountStateRecordId = fromBase64Url(payload.accountStateRecordId);
  const fields = [
    utf8("aeralyth/vault-rewrap-proof/v1"),
    encodeUnsigned64(VAULT_FORMAT_VERSION),
    encodeUnsigned64(payload.expectedVaultVersion),
    Uint8Array.of(payload.recovery ? 1 : 0),
    encodeLengthPrefixed(utf8(payload.kdf.algorithm)),
    encodeLengthPrefixed(fromBase64Url(payload.kdf.salt)),
    encodeUnsigned64(payload.kdf.operations),
    encodeUnsigned64(payload.kdf.memoryBytes),
    encodeUnsigned64(payload.kdf.outputBytes),
    encodeLengthPrefixed(fromBase64Url(payload.passwordWrapper.id)),
    encodeLengthPrefixed(fromBase64Url(payload.passwordWrapper.ciphertext)),
    encodeLengthPrefixed(fromBase64Url(payload.recoveryWrapper.salt)),
    encodeLengthPrefixed(fromBase64Url(payload.recoveryWrapper.id)),
    encodeLengthPrefixed(fromBase64Url(payload.recoveryWrapper.ciphertext)),
    Uint8Array.of(1),
    encodeLengthPrefixed(accountStateRecordId),
    encodeLengthPrefixed(fromBase64Url(payload.encryptedAccountState))
  ];
  try {
    return concatBytes(...fields);
  } finally {
    wipe(accountStateRecordId, ...fields.slice(4));
  }
}
function encodeVaultPasswordRewrapProof(payload) {
  assertArgon2idProfile(payload.kdf);
  const fields = [
    utf8("aeralyth/vault-password-rewrap-proof/v1"),
    encodeUnsigned64(VAULT_FORMAT_VERSION),
    encodeUnsigned64(payload.expectedVaultVersion),
    encodeLengthPrefixed(utf8(payload.kdf.algorithm)),
    encodeLengthPrefixed(fromBase64Url(payload.kdf.salt)),
    encodeUnsigned64(payload.kdf.operations),
    encodeUnsigned64(payload.kdf.memoryBytes),
    encodeUnsigned64(payload.kdf.outputBytes),
    encodeLengthPrefixed(fromBase64Url(payload.passwordWrapper.id)),
    encodeLengthPrefixed(fromBase64Url(payload.passwordWrapper.ciphertext))
  ];
  try {
    return concatBytes(...fields);
  } finally {
    wipe(...fields.slice(3));
  }
}
function encodeUnsigned64(value) {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new Error("Invalid unsigned protocol integer.");
  }
  const output = new Uint8Array(8);
  new DataView(output.buffer).setBigUint64(0, BigInt(value), false);
  return output;
}
function encodeLengthPrefixed(value) {
  return concatBytes(encodeUnsigned64(value.length), value);
}
function utf8(value) {
  return new TextEncoder().encode(value);
}
function equalBytes(left, right) {
  if (left.length !== right.length) {
    return false;
  }
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left[index] ^ right[index];
  }
  return difference === 0;
}
function wipe(...values) {
  for (const value of values) {
    value?.fill(0);
  }
}
function chunkNonce(chunkIndex) {
  if (!Number.isSafeInteger(chunkIndex) || chunkIndex < 0) {
    throw new Error("Invalid encryption chunk index.");
  }
  const nonce = new Uint8Array(12);
  const view = new DataView(nonce.buffer);
  const high = Math.floor(chunkIndex / 4294967296);
  const low = chunkIndex >>> 0;
  view.setUint32(4, high, false);
  view.setUint32(8, low, false);
  return nonce;
}
function zeroNonce() {
  return new Uint8Array(12);
}
function encodeChunkAad(input) {
  const node = utf8(input.nodeId);
  if (node.length > 96 || input.generationId.length !== 16) {
    throw new Error("Invalid chunk AAD fields.");
  }
  const fixed = new Uint8Array(2 + node.length + 8 + 16 + 8 + 4 + 2);
  const view = new DataView(fixed.buffer);
  let offset = 0;
  view.setUint16(offset, VAULT_AAD_SCHEMA_ID, false);
  offset += 2;
  fixed.set(node, offset);
  offset += node.length;
  view.setBigUint64(offset, BigInt(input.generationNumber), false);
  offset += 8;
  fixed.set(input.generationId, offset);
  offset += 16;
  view.setBigUint64(offset, BigInt(input.chunkIndex), false);
  offset += 8;
  view.setUint32(offset, input.plaintextLength, false);
  offset += 4;
  view.setUint16(offset, node.length, false);
  return fixed;
}
function encodeRecordAad(purpose, recordId, recordVersion) {
  const purposeBytes = utf8(purpose);
  const idBytes = utf8(recordId);
  const output = new Uint8Array(
    2 + 2 + purposeBytes.length + 2 + idBytes.length + 8
  );
  const view = new DataView(output.buffer);
  let offset = 0;
  view.setUint16(offset, VAULT_AAD_SCHEMA_ID, false);
  offset += 2;
  view.setUint16(offset, purposeBytes.length, false);
  offset += 2;
  output.set(purposeBytes, offset);
  offset += purposeBytes.length;
  view.setUint16(offset, idBytes.length, false);
  offset += 2;
  output.set(idBytes, offset);
  offset += idBytes.length;
  view.setBigUint64(offset, BigInt(recordVersion), false);
  return output;
}
function padmeLength(plaintextBytes) {
  if (!Number.isSafeInteger(plaintextBytes) || plaintextBytes < 0) {
    throw new Error("Invalid plaintext length.");
  }
  const minimum = Math.max(plaintextBytes, 1, 4096);
  const exponent = Math.floor(Math.log2(minimum));
  const significantBits = Math.max(1, Math.floor(Math.log2(exponent)));
  const quantum = 2 ** Math.max(0, exponent - significantBits);
  return Math.ceil(minimum / quantum) * quantum;
}
function encryptedLength(paddedBytes) {
  if (!Number.isSafeInteger(paddedBytes) || paddedBytes < 4096) {
    throw new Error("Invalid padded payload length.");
  }
  const chunkCount = Math.ceil(paddedBytes / VAULT_CRYPTO_CHUNK_BYTES);
  return {
    chunkCount,
    ciphertextBytes: paddedBytes + chunkCount * 16
  };
}
async function sha2565(value) {
  return new Uint8Array(
    await crypto.subtle.digest("SHA-256", asBufferSource(value))
  );
}
async function sha256Parts(...values) {
  const hasher = sha2564.create();
  let digested = false;
  try {
    for (const value of values) hasher.update(value);
    const digest = hasher.digest();
    digested = true;
    return digest;
  } finally {
    if (!digested) hasher.destroy();
  }
}
async function shareAuthorizationVersion(input) {
  const shareId = utf8(input.shareId);
  const recipientId = utf8(input.recipientId);
  return sha256Parts(
    utf8("aeralyth/share-authorization/v1"),
    encodeUnsigned32(shareId.length),
    shareId,
    encodeUnsigned64(input.epoch),
    encodeUnsigned32(recipientId.length),
    recipientId,
    encodeUnsigned64(input.recipientKeyVersion),
    encodeUnsigned64(input.shareRecordVersion),
    encodeUnsigned32(input.envelopeHash.length),
    input.envelopeHash
  );
}
function encodeUnsigned32(value) {
  if (!Number.isSafeInteger(value) || value < 0 || value > 4294967295) {
    throw new Error("Invalid unsigned protocol length.");
  }
  const output = new Uint8Array(4);
  new DataView(output.buffer).setUint32(0, value, false);
  return output;
}
async function merkleRootFromLeaves(leaves) {
  if (leaves.length === 0) {
    return sha2565(new Uint8Array());
  }
  let level = leaves.map((leaf) => Uint8Array.from(leaf));
  while (level.length > 1) {
    const next = await mapWithConcurrency(
      Array.from({ length: Math.ceil(level.length / 2) }, (_2, index) => index),
      PROTOCOL_HASH_CONCURRENCY,
      async (pairIndex) => {
        const index = pairIndex * 2;
        if (index + 1 === level.length) {
          return level[index];
        }
        return sha256Parts(Uint8Array.of(1), level[index], level[index + 1]);
      }
    );
    level = next;
  }
  return level[0];
}
var WRAPPER_LEAF_DOMAIN = utf8("aeralyth/share-wrapper-leaf/v2");
var WRAPPER_BRANCH_DOMAIN = utf8("aeralyth/share-wrapper-branch/v2");
var WRAPPER_ROOT_DOMAIN = utf8("aeralyth/share-wrapper-root/v2");
async function wrapperSetRoot(wrapperHashes) {
  if (wrapperHashes.length === 0 || wrapperHashes.length > MAX_SHARE_WRAPPERS) {
    throw new Error("Invalid share wrapper count.");
  }
  const ordered = wrapperHashes.map((hash) => {
    if (hash.length !== 32) throw new Error("Invalid share wrapper hash.");
    return Uint8Array.from(hash);
  }).sort(compareBytes);
  for (let index = 1; index < ordered.length; index += 1) {
    if (equalBytes(ordered[index - 1], ordered[index])) {
      throw new Error("Duplicate share wrapper hash.");
    }
  }
  let level = await mapWithConcurrency(
    ordered,
    PROTOCOL_HASH_CONCURRENCY,
    (hash) => sha256Parts(WRAPPER_LEAF_DOMAIN, hash)
  );
  while (level.length > 1) {
    level = await mapWithConcurrency(
      Array.from({ length: Math.ceil(level.length / 2) }, (_2, index) => index),
      PROTOCOL_HASH_CONCURRENCY,
      (pairIndex) => {
        const index = pairIndex * 2;
        const right = level[index + 1] ?? level[index];
        return sha256Parts(WRAPPER_BRANCH_DOMAIN, level[index], right);
      }
    );
  }
  return sha256Parts(
    WRAPPER_ROOT_DOMAIN,
    encodeUnsigned64(wrapperHashes.length),
    level[0]
  );
}
async function verifyWrapperSetProof(input) {
  if (input.wrapperHash.length !== 32 || input.expectedRoot.length !== 32 || !Number.isSafeInteger(input.leafIndex) || input.leafIndex < 0 || !Number.isSafeInteger(input.wrapperCount) || input.wrapperCount < 1 || input.wrapperCount > MAX_SHARE_WRAPPERS || input.leafIndex >= input.wrapperCount) {
    return false;
  }
  const depth = Math.ceil(Math.log2(input.wrapperCount));
  if (input.proof.length !== depth * 32) return false;
  let index = input.leafIndex;
  let node = await sha256Parts(WRAPPER_LEAF_DOMAIN, input.wrapperHash);
  for (let level = 0; level < depth; level += 1) {
    const sibling = input.proof.subarray(level * 32, (level + 1) * 32);
    node = index % 2 === 0 ? await sha256Parts(WRAPPER_BRANCH_DOMAIN, node, sibling) : await sha256Parts(WRAPPER_BRANCH_DOMAIN, sibling, node);
    index = Math.floor(index / 2);
  }
  const root = await sha256Parts(
    WRAPPER_ROOT_DOMAIN,
    encodeUnsigned64(input.wrapperCount),
    node
  );
  return equalBytes(root, input.expectedRoot);
}
function compareBytes(left, right) {
  for (let index = 0; index < Math.min(left.length, right.length); index += 1) {
    if (left[index] !== right[index]) return left[index] - right[index];
  }
  return left.length - right.length;
}
function asBufferSource(value) {
  if (value.buffer instanceof ArrayBuffer) {
    return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
  }
  return Uint8Array.from(value);
}
function toArrayBuffer2(value) {
  const source = asBufferSource(value);
  if (source.byteOffset === 0 && source.byteLength === source.buffer.byteLength) {
    return source.buffer;
  }
  return source.buffer.slice(
    source.byteOffset,
    source.byteOffset + source.byteLength
  );
}

// src/features/vault/cbor.ts
function encodeBootstrap(record) {
  return encodeMap([
    [1, record.formatVersion],
    [2, record.suiteId],
    [3, record.aadSchemaId],
    [4, record.nodeId],
    [5, record.generationNumber],
    [6, record.generationId],
    [7, record.manifestIv],
    [8, record.wrapperIds],
    [9, record.ciphertextLength],
    [10, record.signerKeyVersion],
    [11, record.recordVersion],
    [12, record.previousRecordHash],
    [13, record.manifestHash],
    [14, record.wrapperHashes],
    [15, record.ciphertextMerkleRoot]
  ]);
}
function decodeBootstrap(value) {
  const map = decodeExactMap(value, 15);
  return {
    formatVersion: requiredNumber(map, 1),
    suiteId: requiredNumber(map, 2),
    aadSchemaId: requiredNumber(map, 3),
    nodeId: requiredString(map, 4),
    generationNumber: requiredNumber(map, 5),
    generationId: fixedBytes(map, 6, 16),
    manifestIv: fixedBytes(map, 7, 12),
    wrapperIds: fixedBytesArray(map, 8, 16),
    ciphertextLength: requiredNumber(map, 9),
    signerKeyVersion: requiredNumber(map, 10),
    recordVersion: requiredNumber(map, 11),
    previousRecordHash: nullableFixedBytes(map, 12, 32),
    manifestHash: fixedBytes(map, 13, 32),
    wrapperHashes: fixedBytesArray(map, 14, 32),
    ciphertextMerkleRoot: fixedBytes(map, 15, 32)
  };
}
function encodeShareDirectory(record) {
  return encodeMap([
    [1, record.formatVersion],
    [2, record.suiteId],
    [3, record.aadSchemaId],
    [4, record.nodeId],
    [5, record.recordVersion],
    [6, record.recordHash],
    [7, record.generationNumber],
    [8, record.generationId],
    [9, record.signerKeyVersion],
    [10, record.wrapperSetRoot],
    [11, record.wrapperCount]
  ]);
}
function decodeShareDirectory(value) {
  const map = decodeExactMap(value, 11);
  return {
    formatVersion: requiredNumber(map, 1),
    suiteId: requiredNumber(map, 2),
    aadSchemaId: requiredNumber(map, 3),
    nodeId: requiredString(map, 4),
    recordVersion: requiredNumber(map, 5),
    recordHash: fixedBytes(map, 6, 32),
    generationNumber: requiredNumber(map, 7),
    generationId: fixedBytes(map, 8, 16),
    signerKeyVersion: requiredNumber(map, 9),
    wrapperSetRoot: fixedBytes(map, 10, 32),
    wrapperCount: requiredNumber(map, 11)
  };
}
function encodeWrapper(record) {
  return encodeMap([
    [1, record.formatVersion],
    [2, record.wrapperId],
    [3, record.kind],
    [4, record.nodeId],
    [5, record.parentNodeId],
    [6, record.generationId],
    [7, record.shareId],
    [8, record.epoch],
    [9, record.recordVersion],
    [10, record.ciphertext],
    [11, record.aadSchemaId]
  ]);
}
function decodeWrapper(value) {
  const map = decodeExactMap(value, 11);
  const kind = requiredNumber(map, 3);
  if (kind !== 1 && kind !== 2 && kind !== 3 && kind !== 4) {
    throw new Error("Unsupported vault wrapper kind.");
  }
  return {
    formatVersion: requiredNumber(map, 1),
    wrapperId: fixedBytes(map, 2, 16),
    kind,
    nodeId: requiredString(map, 4),
    parentNodeId: nullableString(map, 5),
    generationId: nullableFixedBytes(map, 6, 16),
    shareId: nullableString(map, 7),
    epoch: nullableNumber(map, 8),
    recordVersion: requiredNumber(map, 9),
    ciphertext: requiredBytes(map, 10),
    aadSchemaId: requiredNumber(map, 11)
  };
}
function encodeManifest(manifest) {
  return encodeMap([
    [1, manifest.name],
    [2, manifest.mimeType],
    [3, manifest.entryType === "file" ? 1 : 2],
    [4, manifest.plaintextBytes],
    [5, manifest.paddedBytes],
    [6, manifest.lastModified],
    [7, manifest.parentId],
    [8, manifest.chunkCount],
    [9, manifest.generationId],
    [10, manifest.createdAt]
  ]);
}
function decodeManifest(value) {
  const map = decodeExactMap(value, 10);
  const entryType = requiredNumber(map, 3);
  if (entryType !== 1 && entryType !== 2) {
    throw new Error("Invalid vault manifest entry type.");
  }
  return {
    name: requiredString(map, 1),
    mimeType: nullableString(map, 2),
    entryType: entryType === 1 ? "file" : "folder",
    plaintextBytes: requiredNumber(map, 4),
    paddedBytes: requiredNumber(map, 5),
    lastModified: requiredNumber(map, 6),
    parentId: nullableString(map, 7),
    chunkCount: requiredNumber(map, 8),
    generationId: fixedBytes(map, 9, 16),
    createdAt: requiredNumber(map, 10)
  };
}
function encodeShareEnvelope(record) {
  const shared = [
    [1, record.formatVersion],
    [2, record.suiteId],
    [3, record.envelopeId],
    [4, record.shareId],
    [5, record.epoch],
    [6, record.senderId],
    [7, record.senderKeyVersion],
    [8, record.recipientId],
    [9, record.recipientKeyVersion],
    [10, record.nodeId],
    [11, record.permissions],
    [12, record.generationScope],
    [13, record.recordVersion],
    [14, record.previousRecordHash],
    [15, record.encapsulatedKey],
    [16, record.ciphertext],
    [17, record.aadSchemaId]
  ];
  if (record.formatVersion === VAULT_FORMAT_VERSION) {
    return encodeMap([...shared, [18, record.wrapperHashes]]);
  }
  if (record.formatVersion !== VAULT_SHARE_ENVELOPE_VERSION || record.wrapperSetRoot?.length !== 32 || !Number.isSafeInteger(record.wrapperCount) || record.wrapperCount < 1 || record.wrapperCount > MAX_SHARE_WRAPPERS) {
    throw new Error("Unsupported share envelope version.");
  }
  return encodeMap([
    ...shared,
    [18, record.wrapperSetRoot],
    [19, record.wrapperCount]
  ]);
}
function decodeShareEnvelope(value) {
  const map = decodeMap(value);
  const formatVersion = requiredNumber(map, 1);
  if (!(formatVersion === VAULT_FORMAT_VERSION && map.size === 18 || formatVersion === VAULT_SHARE_ENVELOPE_VERSION && map.size === 19)) {
    throw new Error("Unsupported share envelope version.");
  }
  const permissions = requiredNumber(map, 11);
  if (permissions !== 1) throw new Error("Unsupported share permissions.");
  const wrapperHashes = formatVersion === VAULT_FORMAT_VERSION ? fixedBytesArray(map, 18, 32) : [];
  const wrapperCount = formatVersion === VAULT_SHARE_ENVELOPE_VERSION ? requiredNumber(map, 19) : wrapperHashes.length;
  if (wrapperCount < 1 || wrapperCount > MAX_SHARE_WRAPPERS) {
    throw new Error("Invalid share wrapper count.");
  }
  return {
    formatVersion,
    suiteId: requiredNumber(map, 2),
    envelopeId: fixedBytes(map, 3, 16),
    shareId: requiredString(map, 4),
    epoch: requiredNumber(map, 5),
    senderId: requiredString(map, 6),
    senderKeyVersion: requiredNumber(map, 7),
    recipientId: requiredString(map, 8),
    recipientKeyVersion: requiredNumber(map, 9),
    nodeId: requiredString(map, 10),
    permissions,
    generationScope: nullableNumber(map, 12),
    recordVersion: requiredNumber(map, 13),
    previousRecordHash: nullableFixedBytes(map, 14, 32),
    encapsulatedKey: fixedBytes(map, 15, 32),
    ciphertext: requiredBytes(map, 16),
    aadSchemaId: requiredNumber(map, 17),
    wrapperHashes,
    wrapperSetRoot: formatVersion === VAULT_SHARE_ENVELOPE_VERSION ? fixedBytes(map, 18, 32) : null,
    wrapperCount
  };
}
function encodeMap(entries) {
  const output = [];
  writeHead(output, 5, entries.length);
  let previous = 0;
  for (const [key, value] of entries) {
    if (!Number.isSafeInteger(key) || key <= previous) {
      throw new Error("CBOR map keys must be positive and strictly ordered.");
    }
    writeUnsigned(output, key);
    writeValue(output, value);
    previous = key;
  }
  return Uint8Array.from(output);
}
var Reader = class {
  constructor(input) {
    this.input = input;
  }
  input;
  offset = 0;
  finish() {
    if (this.offset !== this.input.length) {
      throw new Error("CBOR value has trailing bytes.");
    }
  }
  value() {
    const initial = this.byte();
    if (initial === 246) {
      return null;
    }
    const major = initial >>> 5;
    const additional = initial & 31;
    if (major === 0) {
      return this.length(additional);
    }
    if (major === 2 || major === 3) {
      const length = this.length(additional);
      const bytes = this.take(length);
      return major === 2 ? bytes : new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    }
    if (major === 4) {
      const length = this.length(additional);
      return Array.from({ length }, () => this.value());
    }
    if (major === 5) {
      const length = this.length(additional);
      const map = /* @__PURE__ */ new Map();
      let previous = 0;
      for (let index = 0; index < length; index += 1) {
        const key = this.value();
        if (typeof key !== "number" || key <= previous || map.has(key)) {
          throw new Error("CBOR map keys are not canonically ordered.");
        }
        map.set(key, this.value());
        previous = key;
      }
      return map;
    }
    throw new Error("Unsupported CBOR type.");
  }
  byte() {
    const value = this.input[this.offset];
    if (value === void 0) {
      throw new Error("Unexpected end of CBOR value.");
    }
    this.offset += 1;
    return value;
  }
  take(length) {
    if (!Number.isSafeInteger(length) || length < 0 || this.offset + length > this.input.length) {
      throw new Error("Invalid CBOR length.");
    }
    const value = this.input.slice(this.offset, this.offset + length);
    this.offset += length;
    return value;
  }
  length(additional) {
    if (additional < 24) {
      return additional;
    }
    if (additional === 24) {
      const value = this.byte();
      if (value < 24) throw new Error("Non-minimal CBOR integer.");
      return value;
    }
    if (additional === 25) {
      const bytes = this.take(2);
      const value = new DataView(bytes.buffer, bytes.byteOffset, 2).getUint16(
        0,
        false
      );
      if (value <= 255) throw new Error("Non-minimal CBOR integer.");
      return value;
    }
    if (additional === 26) {
      const bytes = this.take(4);
      const value = new DataView(bytes.buffer, bytes.byteOffset, 4).getUint32(
        0,
        false
      );
      if (value <= 65535) throw new Error("Non-minimal CBOR integer.");
      return value;
    }
    if (additional === 27) {
      const bytes = this.take(8);
      const value = new DataView(
        bytes.buffer,
        bytes.byteOffset,
        8
      ).getBigUint64(0, false);
      if (value <= 0xffffffffn || value > BigInt(Number.MAX_SAFE_INTEGER)) {
        throw new Error("Unsupported CBOR integer.");
      }
      return Number(value);
    }
    throw new Error("Indefinite-length CBOR is forbidden.");
  }
};
function decodeExactMap(value, fieldCount) {
  const decoded = decodeMap(value);
  if (decoded.size !== fieldCount) {
    throw new Error("CBOR record has an invalid field count.");
  }
  return decoded;
}
function decodeMap(value) {
  const reader = new Reader(value);
  const decoded = reader.value();
  reader.finish();
  if (!(decoded instanceof Map)) {
    throw new Error("CBOR record has an invalid field count.");
  }
  for (let key = 1; key <= decoded.size; key += 1) {
    if (!decoded.has(key)) {
      throw new Error("CBOR record is missing a required field.");
    }
  }
  return decoded;
}
function writeValue(output, value) {
  if (value === null) {
    output.push(246);
  } else if (typeof value === "number") {
    writeUnsigned(output, value);
  } else if (typeof value === "string") {
    const encoded = new TextEncoder().encode(value);
    writeHead(output, 3, encoded.length);
    output.push(...encoded);
  } else if (value instanceof Uint8Array) {
    writeHead(output, 2, value.length);
    output.push(...value);
  } else if (Array.isArray(value)) {
    writeHead(output, 4, value.length);
    for (const item of value) writeValue(output, item);
  } else if (value instanceof Map) {
    writeHead(output, 5, value.size);
    let previous = 0;
    for (const [key, item] of value) {
      if (key <= previous) throw new Error("CBOR map keys are not ordered.");
      writeUnsigned(output, key);
      writeValue(output, item);
      previous = key;
    }
  } else {
    const neverValue = value;
    throw new Error(`Unsupported CBOR value: ${String(neverValue)}`);
  }
}
function writeUnsigned(output, value) {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new Error("CBOR only supports non-negative safe integers.");
  }
  writeHead(output, 0, value);
}
function writeHead(output, major, value) {
  if (value < 24) {
    output.push(major << 5 | value);
  } else if (value <= 255) {
    output.push(major << 5 | 24, value);
  } else if (value <= 65535) {
    output.push(major << 5 | 25, value >>> 8, value & 255);
  } else if (value <= 4294967295) {
    output.push(major << 5 | 26);
    for (let shift = 24; shift >= 0; shift -= 8)
      output.push(value >>> shift & 255);
  } else {
    output.push(major << 5 | 27);
    let remaining = BigInt(value);
    const bytes = new Array(8);
    for (let index = 7; index >= 0; index -= 1) {
      bytes[index] = Number(remaining & 0xffn);
      remaining >>= 8n;
    }
    output.push(...bytes);
  }
}
function field(map, key) {
  const value = map.get(key);
  if (value === void 0) throw new Error(`Missing CBOR field ${key}.`);
  return value;
}
function requiredNumber(map, key) {
  const value = field(map, key);
  if (typeof value !== "number")
    throw new Error(`CBOR field ${key} is not an integer.`);
  return value;
}
function nullableNumber(map, key) {
  const value = field(map, key);
  if (value === null) return null;
  if (typeof value !== "number")
    throw new Error(`CBOR field ${key} is not an integer.`);
  return value;
}
function requiredString(map, key) {
  const value = field(map, key);
  if (typeof value !== "string")
    throw new Error(`CBOR field ${key} is not text.`);
  return value;
}
function nullableString(map, key) {
  const value = field(map, key);
  if (value === null) return null;
  if (typeof value !== "string")
    throw new Error(`CBOR field ${key} is not text.`);
  return value;
}
function requiredBytes(map, key) {
  const value = field(map, key);
  if (!(value instanceof Uint8Array))
    throw new Error(`CBOR field ${key} is not bytes.`);
  return value;
}
function fixedBytes(map, key, length) {
  const value = requiredBytes(map, key);
  if (value.length !== length)
    throw new Error(`CBOR field ${key} has an invalid length.`);
  return value;
}
function nullableFixedBytes(map, key, length) {
  const value = field(map, key);
  if (value === null) return null;
  if (!(value instanceof Uint8Array) || value.length !== length) {
    throw new Error(`CBOR field ${key} has an invalid length.`);
  }
  return value;
}
function fixedBytesArray(map, key, length) {
  const value = field(map, key);
  if (!Array.isArray(value))
    throw new Error(`CBOR field ${key} is not an array.`);
  return value.map((item) => {
    if (!(item instanceof Uint8Array) || item.length !== length) {
      throw new Error(`CBOR field ${key} contains an invalid byte string.`);
    }
    return item;
  });
}

// src/features/vault/incremental-ciphertext-hash.ts
var CIPHERTEXT_LEAF_DOMAIN = 0;
function incrementalCiphertextLeafHash(chunkIndex, ciphertext) {
  if (!Number.isSafeInteger(chunkIndex) || chunkIndex < 0) {
    throw new Error("Invalid ciphertext chunk index.");
  }
  const prefix = new Uint8Array(9);
  prefix[0] = CIPHERTEXT_LEAF_DOMAIN;
  new DataView(prefix.buffer).setBigUint64(1, BigInt(chunkIndex), false);
  const state = libsodium_wrappers_default.crypto_hash_sha256_init();
  let finalized = false;
  try {
    libsodium_wrappers_default.crypto_hash_sha256_update(state, prefix);
    libsodium_wrappers_default.crypto_hash_sha256_update(state, ciphertext);
    const digest = libsodium_wrappers_default.crypto_hash_sha256_final(state);
    finalized = true;
    return digest;
  } finally {
    if (!finalized) {
      wipe(libsodium_wrappers_default.crypto_hash_sha256_final(state));
    }
    wipe(prefix);
  }
}

// src/features/vault/node-id.ts
var MODERN_VAULT_NODE_ID = /^fil_[A-Za-z0-9_-]{4,92}$/u;
var LEGACY_UUID_VAULT_NODE_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u;
function isVaultNodeId(value) {
  return MODERN_VAULT_NODE_ID.test(value) || LEGACY_UUID_VAULT_NODE_ID.test(value);
}

// src/features/vault/session-operation-queue.ts
var SessionOperationQueue = class {
  tails = /* @__PURE__ */ new Map();
  run(sessionId, operation) {
    const previous = this.tails.get(sessionId) ?? Promise.resolve();
    const result = previous.catch(() => void 0).then(operation);
    const tail = result.then(
      () => void 0,
      () => void 0
    );
    this.tails.set(sessionId, tail);
    void tail.then(() => {
      if (this.tails.get(sessionId) === tail) this.tails.delete(sessionId);
    });
    return result;
  }
};

// src/features/vault/vault-preferences.ts
function validVaultResumeExpiration(value, now = Date.now()) {
  return value === 0 || typeof value === "number" && Number.isSafeInteger(value) && value > now && value <= now + 61 * 6e4;
}

// src/features/vault/vault.worker.ts
var scope = globalThis;
var rootKey = null;
var identity = null;
var vaultSessionGeneration = 0;
var MAX_NODE_KEY_ENTRIES = 8192;
var nodeKeys = new BoundedLruCache(MAX_NODE_KEY_ENTRIES);
var nodeOpenFlights = /* @__PURE__ */ new Map();
var metadataMemoryCache = /* @__PURE__ */ new Map();
var metadataMemorySizes = /* @__PURE__ */ new Map();
var metadataMemoryBytes = 0;
var metadataCacheKey = null;
var metadataCacheNamespace = null;
var activeResumeSessionId = null;
var encryptionSessions = /* @__PURE__ */ new Map();
var decryptionSessions = /* @__PURE__ */ new Map();
var sessionOperations = new SessionOperationQueue();
var metadataOperations = /* @__PURE__ */ new Map();
var shareContextCache = new BatchScopedValueCache();
var SHARE_WRAPPER_CRYPTO_CONCURRENCY = detectedCryptoConcurrency(16);
var SHARE_HASH_CRYPTO_CONCURRENCY = detectedCryptoConcurrency(16);
var SHARE_ENVELOPE_CRYPTO_CONCURRENCY = detectedCryptoConcurrency(8, 2);
var SHARE_SIDECAR_CRYPTO_CONCURRENCY = SHARE_WRAPPER_CRYPTO_CONCURRENCY;
var MAX_METADATA_DECRYPTION_CONCURRENCY = 4;
var MAX_SHARE_PREPARATION_CONCURRENCY = 4;
var MAX_METADATA_MEMORY_ENTRIES = 1024;
var MAX_METADATA_MEMORY_BYTES = 16 * 1024 * 1024;
var NODE_KEY_ACCOUNTED_BYTES = 32;
var METADATA_CACHE_DATABASE = "aeralyth-vault-metadata-v1";
var METADATA_CACHE_DATABASE_VERSION = 3;
var METADATA_CACHE_STORE = "metadata";
var VAULT_RESUME_SESSION_STORE = "resume-sessions";
var VAULT_RESUME_SESSION_ID_PATTERN = /^vrs_[A-Za-z0-9_-]{24}$/u;
var metadataDatabasePromise = null;
var hpkeSuite = new CipherSuite({
  kem: new DhkemX25519HkdfSha2562(),
  kdf: new HkdfSha256(),
  aead: new Aes256Gcm()
});
scope.onmessage = (event) => {
  const request = event.data;
  void dispatch(request).then(({ result, transfer = [] }) => {
    scope.postMessage({ id: request.id, ok: true, result }, transfer);
  }).catch((failure) => {
    const error = normalizeError(failure);
    scope.postMessage({
      id: request.id,
      ok: false,
      error: error.message,
      ...error.code ? { code: error.code } : {}
    });
  });
};
async function dispatch(request) {
  await libsodium_wrappers_default.ready;
  switch (request.type) {
    case "preflight":
      await preflightArgon2id();
      return { result: { type: "preflight", supported: true } };
    case "deriveAuthCredential":
      return {
        result: {
          type: "deriveAuthCredential",
          credential: deriveAuthCredential(
            request.username,
            request.password,
            request.salt
          )
        }
      };
    case "setup":
      return {
        result: { type: "setup", result: await setupVault(request.password) }
      };
    case "unlock":
      return {
        result: {
          type: "unlock",
          result: await unlockVault(request.password, request.material)
        }
      };
    case "resume":
      return {
        result: {
          type: "resume",
          result: await resumeVaultSession(
            request.sessionId,
            request.sessionBinding,
            request.material
          )
        }
      };
    case "persistSession":
      await persistVaultResumeSession(
        request.sessionId,
        request.sessionBinding,
        request.expiresAt,
        request.vaultVersion
      );
      return { result: { type: "persistSession" } };
    case "extendSession":
      await extendVaultResumeSession(request.sessionId, request.expiresAt);
      return { result: { type: "extendSession" } };
    case "recover":
      return {
        result: {
          type: "recover",
          result: await recoverVault(
            request.recoveryCode,
            request.newPassword,
            request.material
          )
        }
      };
    case "rewrapPassword":
      return {
        result: {
          type: "rewrapPassword",
          result: await rewrapVaultPassword(
            request.currentPassword,
            request.newPassword,
            request.material
          )
        }
      };
    case "lock": {
      const resumeSessionId = activeResumeSessionId;
      lockVault();
      if (resumeSessionId) {
        await deleteVaultResumeSession(resumeSessionId).catch(() => void 0);
      }
      return { result: { type: "lock" } };
    }
    case "openPlan":
      return {
        result: { type: "openPlan", result: await openPlan(request.plan) }
      };
    case "getCachedMetadata":
      return {
        result: {
          type: "getCachedMetadata",
          results: await getCachedMetadata(request.references)
        }
      };
    case "openMetadataPlans":
      return {
        result: {
          type: "openMetadataPlans",
          results: await openMetadataPlans(
            request.id,
            request.plans,
            request.concurrency,
            request.priorityCount,
            (results) => {
              scope.postMessage({
                id: request.id,
                ok: true,
                progress: { type: "openMetadataPlans", results }
              });
            }
          )
        }
      };
    case "cancelMetadataOperation":
      cancelMetadataOperation(request.operationId);
      return { result: { type: "cancelMetadataOperation" } };
    case "startEncryption":
      return {
        result: {
          type: "startEncryption",
          result: await startEncryption(request.input)
        }
      };
    case "encryptChunk": {
      const encrypted = await sessionOperations.run(
        request.sessionId,
        () => encryptChunk(
          request.sessionId,
          request.chunkIndex,
          new Uint8Array(request.plaintext)
        )
      );
      return {
        result: { type: "encryptChunk", result: encrypted },
        transfer: [encrypted.ciphertext]
      };
    }
    case "finalizeEncryption": {
      const complete = await sessionOperations.run(
        request.sessionId,
        () => finalizeEncryption(request.sessionId)
      );
      return {
        result: {
          type: "finalizeEncryption",
          result: complete
        },
        transfer: transferableBuffers([
          complete.record.bootstrapCbor,
          complete.record.bootstrapSignature,
          complete.record.encryptedManifest,
          ...complete.record.wrappers
        ])
      };
    }
    case "abortEncryption":
      await sessionOperations.run(request.sessionId, async () => {
        abortEncryption(request.sessionId, request.nodeId);
      });
      return { result: { type: "abortEncryption" } };
    case "createShareDirectory": {
      const directory = await createShareDirectory(request.input);
      return {
        result: {
          type: "createShareDirectory",
          result: directory
        },
        transfer: transferableBuffers([
          directory.directoryCbor,
          directory.directorySignature,
          ...directory.wrappers
        ])
      };
    }
    case "clearShareContextCache":
      shareContextCache.delete(request.cacheKey);
      return { result: { type: "clearShareContextCache" } };
    case "startDecryption":
      return {
        result: {
          type: "startDecryption",
          result: await startDecryption(request.plan)
        }
      };
    case "decryptChunk": {
      const decrypted = await sessionOperations.run(
        request.sessionId,
        () => decryptChunk(
          request.sessionId,
          request.chunkIndex,
          new Uint8Array(request.ciphertext)
        )
      );
      return {
        result: { type: "decryptChunk", result: decrypted },
        transfer: [decrypted.plaintext]
      };
    }
    case "finalizeDecryption":
      await sessionOperations.run(
        request.sessionId,
        () => finalizeDecryption(request.sessionId)
      );
      return { result: { type: "finalizeDecryption" } };
    case "abortDecryption":
      await sessionOperations.run(request.sessionId, async () => {
        abortDecryption(request.sessionId);
      });
      return { result: { type: "abortDecryption" } };
    case "createShareMaterial": {
      const material = await createShareMaterial(request.input, (chunk) => {
        scope.postMessage(
          {
            id: request.id,
            ok: true,
            progress: { type: "shareMaterial", ...chunk }
          },
          transferableBuffers(chunk.wrappers)
        );
      });
      return {
        result: {
          type: "createShareMaterial",
          result: material
        },
        transfer: shareMaterialTransferables(material)
      };
    }
    case "rotateShareMaterial": {
      const material = await rotateShareMaterial(request.input, (chunk) => {
        scope.postMessage(
          {
            id: request.id,
            ok: true,
            progress: { type: "shareMaterial", ...chunk }
          },
          transferableBuffers(chunk.wrappers)
        );
      });
      return {
        result: {
          type: "rotateShareMaterial",
          result: material
        },
        transfer: shareMaterialTransferables(material)
      };
    }
  }
}
function shareMaterialTransferables(material) {
  return transferableBuffers([
    ...material.wrappers,
    ...material.envelopes.flatMap((envelope) => [
      envelope.canonicalCbor,
      envelope.signature
    ]),
    material.ownerEpochKey.wrapperId,
    material.ownerEpochKey.ciphertext
  ]);
}
function transferableBuffers(values) {
  return [...new Set(values.map((value) => value.buffer))];
}
async function preflightArgon2id() {
  const salt = randomBytes(16);
  let result = null;
  try {
    result = libsodium_wrappers_default.crypto_pwhash(
      ARGON2ID_PROFILE.outputBytes,
      "aeralyth-device-preflight-v1",
      salt,
      ARGON2ID_PROFILE.operations,
      ARGON2ID_PROFILE.memoryBytes,
      libsodium_wrappers_default.crypto_pwhash_ALG_ARGON2ID13
    );
    if (result.length !== ARGON2ID_PROFILE.outputBytes) {
      throw new Error("Argon2id preflight returned an invalid key.");
    }
  } catch {
    throw vaultError(
      "UNSUPPORTED_DEVICE",
      "This device cannot allocate the 256 MiB required by the vault KDF."
    );
  } finally {
    wipe(salt, result);
  }
}
function deriveAuthCredential(username, password, encodedSalt) {
  const salt = fromBase64Url(encodedSalt);
  const normalizedUsername = normalizeAccountUsername(username);
  const passwordBytes = utf8(
    `aeralyth/account-auth/v1/${normalizedUsername}\0${password}`
  );
  let credential = null;
  try {
    if (salt.length !== 16 || !normalizedUsername) {
      throw new Error("The account authentication parameters are invalid.");
    }
    credential = libsodium_wrappers_default.crypto_pwhash(
      ACCOUNT_AUTH_KDF.outputBytes,
      passwordBytes,
      salt,
      ACCOUNT_AUTH_KDF.operations,
      ACCOUNT_AUTH_KDF.memoryBytes,
      libsodium_wrappers_default.crypto_pwhash_ALG_ARGON2ID13
    );
    return toBase64Url(credential);
  } finally {
    wipe(salt, passwordBytes, credential);
  }
}
async function setupVault(password) {
  validatePassword(password);
  await preflightArgon2id();
  lockVault();
  const rootMaterial = randomBytes(32);
  const recoveryMaterial = randomBytes(32);
  const kdfSalt = randomBytes(16);
  const recoverySalt = randomBytes(16);
  const passwordWrapperId = randomBytes(16);
  const recoveryWrapperId = randomBytes(16);
  const identityRecordId = randomBytes(16);
  const accountStateRecordId = randomBytes(16);
  let passwordKeyMaterial = null;
  let importedRoot = null;
  try {
    passwordKeyMaterial = derivePasswordMaterial(password, kdfSalt);
    const passwordBase = await importHkdf(passwordKeyMaterial);
    const recoveryBase = await importHkdf(recoveryMaterial);
    const [passwordCiphertext, recoveryCiphertext] = await Promise.all([
      wrapRootMaterial(
        rootMaterial,
        passwordBase,
        "password-root",
        passwordWrapperId,
        passwordWrapperId,
        1
      ),
      wrapRootMaterial(
        rootMaterial,
        recoveryBase,
        "recovery-root",
        concatBytes(recoverySalt, recoveryWrapperId),
        recoveryWrapperId,
        1
      )
    ]);
    importedRoot = await importHkdf(rootMaterial);
    const x255192 = libsodium_wrappers_default.crypto_box_keypair();
    const ed25519 = libsodium_wrappers_default.crypto_sign_keypair();
    const [fingerprint, privateCiphertext, accountStateCiphertext] = await Promise.all([
      sha256Parts(x255192.publicKey, ed25519.publicKey),
      encryptRootRecord(
        importedRoot,
        "identity-private",
        identityRecordId,
        1,
        concatBytes(x255192.privateKey, ed25519.privateKey)
      ),
      encryptRootRecord(
        importedRoot,
        "account-state",
        accountStateRecordId,
        1,
        utf8('{"formatVersion":1,"nodeKeyVersion":1}')
      )
    ]);
    identity = {
      keyVersion: 1,
      x25519PublicKey: x255192.publicKey,
      x25519PrivateKey: x255192.privateKey,
      ed25519PublicKey: ed25519.publicKey,
      ed25519PrivateKey: ed25519.privateKey,
      fingerprint
    };
    rootKey = importedRoot;
    const kdf = {
      algorithm: ARGON2ID_PROFILE.algorithm,
      salt: toBase64Url(kdfSalt),
      operations: ARGON2ID_PROFILE.operations,
      memoryBytes: ARGON2ID_PROFILE.memoryBytes,
      outputBytes: ARGON2ID_PROFILE.outputBytes
    };
    const payload = {
      formatVersion: VAULT_FORMAT_VERSION,
      kdf,
      passwordWrapper: {
        id: toBase64Url(passwordWrapperId),
        ciphertext: toBase64Url(passwordCiphertext)
      },
      recoveryWrapper: {
        salt: toBase64Url(recoverySalt),
        id: toBase64Url(recoveryWrapperId),
        ciphertext: toBase64Url(recoveryCiphertext)
      },
      identity: {
        keyVersion: 1,
        x25519PublicKey: toBase64Url(x255192.publicKey),
        ed25519PublicKey: toBase64Url(ed25519.publicKey),
        fingerprintSha256: toBase64Url(fingerprint),
        privateRecordId: toBase64Url(identityRecordId),
        privateCiphertext: toBase64Url(privateCiphertext)
      },
      accountStateRecordId: toBase64Url(accountStateRecordId),
      encryptedAccountState: toBase64Url(accountStateCiphertext)
    };
    return {
      payload,
      recoveryCode: esm_default3.encode(recoveryMaterial)
    };
  } catch (error) {
    if (!rootKey) {
      lockVault();
    }
    throw error;
  } finally {
    wipe(
      rootMaterial,
      recoveryMaterial,
      passwordKeyMaterial,
      kdfSalt,
      recoverySalt,
      passwordWrapperId,
      recoveryWrapperId,
      identityRecordId,
      accountStateRecordId
    );
  }
}
async function unlockVault(password, material) {
  assertUnlockMaterial(material);
  lockVault();
  const salt = fromBase64Url(material.kdf.salt);
  const wrapperId = fromBase64Url(material.passwordWrapper.id);
  let passwordMaterial = null;
  let rootMaterial = null;
  try {
    passwordMaterial = derivePasswordMaterial(password, salt);
    const passwordBase = await importHkdf(passwordMaterial);
    rootMaterial = await unwrapRootMaterial(
      fromBase64Url(material.passwordWrapper.ciphertext),
      passwordBase,
      "password-root",
      wrapperId,
      wrapperId,
      material.vaultVersion
    );
    await installUnlockedMaterial(rootMaterial, material);
    return {
      vaultVersion: material.vaultVersion,
      identityFingerprint: material.identity.fingerprintSha256
    };
  } catch (error) {
    lockVault();
    if (error instanceof DOMException && error.name === "OperationError") {
      throw vaultError("INVALID_PASSWORD", "The vault password is incorrect.");
    }
    throw error;
  } finally {
    wipe(salt, wrapperId, passwordMaterial, rootMaterial);
  }
}
async function rewrapVaultPassword(currentPassword, newPassword, material) {
  assertUnlockMaterial(material);
  validatePassword(newPassword);
  lockVault();
  const currentSalt = fromBase64Url(material.kdf.salt);
  const currentWrapperId = fromBase64Url(material.passwordWrapper.id);
  const nextSalt = randomBytes(16);
  const nextWrapperId = randomBytes(16);
  let currentPasswordMaterial = null;
  let nextPasswordMaterial = null;
  let rootMaterial = null;
  try {
    currentPasswordMaterial = derivePasswordMaterial(
      currentPassword,
      currentSalt
    );
    const currentPasswordBase = await importHkdf(currentPasswordMaterial);
    rootMaterial = await unwrapRootMaterial(
      fromBase64Url(material.passwordWrapper.ciphertext),
      currentPasswordBase,
      "password-root",
      currentWrapperId,
      currentWrapperId,
      material.vaultVersion
    );
    await installUnlockedMaterial(rootMaterial, material);
    nextPasswordMaterial = derivePasswordMaterial(newPassword, nextSalt);
    const nextPasswordBase = await importHkdf(nextPasswordMaterial);
    const unsignedPayload = {
      expectedVaultVersion: material.vaultVersion,
      kdf: {
        algorithm: ARGON2ID_PROFILE.algorithm,
        salt: toBase64Url(nextSalt),
        operations: ARGON2ID_PROFILE.operations,
        memoryBytes: ARGON2ID_PROFILE.memoryBytes,
        outputBytes: ARGON2ID_PROFILE.outputBytes
      },
      passwordWrapper: {
        id: toBase64Url(nextWrapperId),
        ciphertext: toBase64Url(
          await wrapRootMaterial(
            rootMaterial,
            nextPasswordBase,
            "password-root",
            nextWrapperId,
            nextWrapperId,
            material.vaultVersion
          )
        )
      }
    };
    const proof = encodeVaultPasswordRewrapProof(unsignedPayload);
    const proofSignature = libsodium_wrappers_default.crypto_sign_detached(
      proof,
      requireIdentity().ed25519PrivateKey
    );
    try {
      return {
        payload: {
          ...unsignedPayload,
          proofSignature: toBase64Url(proofSignature)
        }
      };
    } finally {
      wipe(proof, proofSignature);
    }
  } catch (error) {
    lockVault();
    if (error instanceof DOMException && error.name === "OperationError") {
      throw vaultError(
        "INVALID_PASSWORD",
        "The current password is incorrect."
      );
    }
    throw error;
  } finally {
    wipe(
      currentSalt,
      currentWrapperId,
      nextSalt,
      nextWrapperId,
      currentPasswordMaterial,
      nextPasswordMaterial,
      rootMaterial
    );
  }
}
async function resumeVaultSession(sessionId, sessionBinding, material) {
  assertUnlockMaterial(material);
  assertVaultResumeSessionId(sessionId);
  const now = Date.now();
  const stored = await readVaultResumeSession(sessionId);
  const sessionBindingHash = await hashVaultSessionBinding(sessionBinding);
  if (!stored || !isStoredVaultResumeSession(stored) || !validVaultResumeExpiration(stored.expiresAt, now) || stored.sessionBindingHash !== sessionBindingHash || stored.identityFingerprint !== material.identity.fingerprintSha256 || stored.vaultVersion !== material.vaultVersion) {
    await deleteVaultResumeSession(sessionId).catch(() => void 0);
    return { resumed: false };
  }
  lockVault();
  try {
    await installUnlockedRoot(stored.rootKey, material);
    activeResumeSessionId = sessionId;
    return { resumed: true, expiresAt: stored.expiresAt };
  } catch {
    lockVault();
    await deleteVaultResumeSession(sessionId).catch(() => void 0);
    return { resumed: false };
  }
}
async function persistVaultResumeSession(sessionId, sessionBinding, expiresAt, vaultVersion) {
  assertVaultResumeSessionId(sessionId);
  assertVaultResumeExpiration(expiresAt);
  if (!Number.isSafeInteger(vaultVersion) || vaultVersion < 1) {
    throw new Error("The vault resume version is invalid.");
  }
  const activeRoot = requireRootKey();
  const activeIdentity = requireIdentity();
  const stored = {
    sessionId,
    sessionBindingHash: await hashVaultSessionBinding(sessionBinding),
    identityFingerprint: toBase64Url(activeIdentity.fingerprint),
    vaultVersion,
    expiresAt,
    rootKey: activeRoot
  };
  await writeVaultResumeSession(stored);
  activeResumeSessionId = sessionId;
}
async function extendVaultResumeSession(sessionId, expiresAt) {
  assertVaultResumeSessionId(sessionId);
  assertVaultResumeExpiration(expiresAt);
  if (activeResumeSessionId !== sessionId) {
    throw vaultError("VAULT_LOCKED", "Unlock the vault first.");
  }
  const activeRoot = requireRootKey();
  const activeIdentity = requireIdentity();
  const stored = await readVaultResumeSession(sessionId);
  if (!stored || !isStoredVaultResumeSession(stored) || stored.identityFingerprint !== toBase64Url(activeIdentity.fingerprint)) {
    throw new Error("The vault resume session is unavailable.");
  }
  await writeVaultResumeSession({
    ...stored,
    expiresAt,
    rootKey: activeRoot
  });
}
async function recoverVault(recoveryCode, newPassword, material) {
  assertUnlockMaterial(material);
  validatePassword(newPassword);
  let recoveryMaterial;
  try {
    recoveryMaterial = esm_default3.decode(recoveryCode.trim());
  } catch {
    throw vaultError("INVALID_RECOVERY_CODE", "The recovery key is invalid.");
  }
  if (recoveryMaterial.length !== 32) {
    wipe(recoveryMaterial);
    throw vaultError("INVALID_RECOVERY_CODE", "The recovery key is invalid.");
  }
  const wrapperId = fromBase64Url(material.recoveryWrapper.id);
  let rootMaterial = null;
  try {
    const recoveryBase = await importHkdf(recoveryMaterial);
    rootMaterial = await unwrapRootMaterial(
      fromBase64Url(material.recoveryWrapper.ciphertext),
      recoveryBase,
      "recovery-root",
      concatBytes(fromBase64Url(material.recoveryWrapper.salt), wrapperId),
      wrapperId,
      material.vaultVersion
    );
    await installUnlockedMaterial(rootMaterial, material);
    const payload = await buildRewrapPayload(
      newPassword,
      rootMaterial,
      material.vaultVersion,
      true
    );
    return payload;
  } catch (error) {
    lockVault();
    if (error instanceof DOMException && error.name === "OperationError") {
      throw vaultError("INVALID_RECOVERY_CODE", "The recovery key is invalid.");
    }
    throw error;
  } finally {
    wipe(recoveryMaterial, wrapperId, rootMaterial);
  }
}
async function buildRewrapPayload(password, rootMaterial, currentVaultVersion, recovery) {
  const newVersion = currentVaultVersion + 1;
  const kdfSalt = randomBytes(16);
  const recoverySalt = randomBytes(16);
  const passwordWrapperId = randomBytes(16);
  const recoveryWrapperId = randomBytes(16);
  const accountStateRecordId = randomBytes(16);
  const newRecoveryMaterial = randomBytes(32);
  let passwordMaterial = null;
  try {
    passwordMaterial = derivePasswordMaterial(password, kdfSalt);
    const passwordBase = await importHkdf(passwordMaterial);
    const recoveryBase = await importHkdf(newRecoveryMaterial);
    const activeRoot = requireRootKey();
    const unsignedPayload = {
      expectedVaultVersion: currentVaultVersion,
      recovery,
      kdf: {
        algorithm: ARGON2ID_PROFILE.algorithm,
        salt: toBase64Url(kdfSalt),
        operations: ARGON2ID_PROFILE.operations,
        memoryBytes: ARGON2ID_PROFILE.memoryBytes,
        outputBytes: ARGON2ID_PROFILE.outputBytes
      },
      passwordWrapper: {
        id: toBase64Url(passwordWrapperId),
        ciphertext: toBase64Url(
          await wrapRootMaterial(
            rootMaterial,
            passwordBase,
            "password-root",
            passwordWrapperId,
            passwordWrapperId,
            newVersion
          )
        )
      },
      recoveryWrapper: {
        salt: toBase64Url(recoverySalt),
        id: toBase64Url(recoveryWrapperId),
        ciphertext: toBase64Url(
          await wrapRootMaterial(
            rootMaterial,
            recoveryBase,
            "recovery-root",
            concatBytes(recoverySalt, recoveryWrapperId),
            recoveryWrapperId,
            newVersion
          )
        )
      },
      accountStateRecordId: toBase64Url(accountStateRecordId),
      encryptedAccountState: toBase64Url(
        await encryptRootRecord(
          activeRoot,
          "account-state",
          accountStateRecordId,
          newVersion,
          utf8('{"formatVersion":1,"nodeKeyVersion":1}')
        )
      )
    };
    const proof = encodeVaultRewrapProof(unsignedPayload);
    const proofSignature = libsodium_wrappers_default.crypto_sign_detached(
      proof,
      requireIdentity().ed25519PrivateKey
    );
    const payload = {
      ...unsignedPayload,
      proofSignature: toBase64Url(proofSignature)
    };
    wipe(proof, proofSignature);
    return {
      payload,
      recoveryCode: esm_default3.encode(newRecoveryMaterial)
    };
  } finally {
    wipe(
      kdfSalt,
      recoverySalt,
      passwordWrapperId,
      recoveryWrapperId,
      accountStateRecordId,
      newRecoveryMaterial,
      passwordMaterial
    );
  }
}
async function installUnlockedMaterial(rootMaterial, material) {
  const importedRoot = await importHkdf(rootMaterial);
  await installUnlockedRoot(importedRoot, material);
}
async function installUnlockedRoot(importedRoot, material) {
  const privateRecordId = fromBase64Url(material.identity.privateRecordId);
  const privateBytes = await decryptRootRecord(
    importedRoot,
    "identity-private",
    privateRecordId,
    material.identity.keyVersion,
    fromBase64Url(material.identity.privateCiphertext)
  );
  if (privateBytes.length !== 96) {
    wipe(privateBytes, privateRecordId);
    throw new Error("The encrypted identity record is invalid.");
  }
  const x25519PrivateKey = privateBytes.slice(0, 32);
  const ed25519PrivateKey = privateBytes.slice(32);
  const x25519PublicKey = fromBase64Url(material.identity.x25519PublicKey);
  const ed25519PublicKey = fromBase64Url(material.identity.ed25519PublicKey);
  const fingerprint = await sha256Parts(x25519PublicKey, ed25519PublicKey);
  const expectedFingerprint = fromBase64Url(
    material.identity.fingerprintSha256
  );
  if (!equalBytes(fingerprint, expectedFingerprint)) {
    wipe(
      privateBytes,
      privateRecordId,
      x25519PrivateKey,
      ed25519PrivateKey,
      x25519PublicKey,
      ed25519PublicKey,
      fingerprint,
      expectedFingerprint
    );
    throw new Error("The identity fingerprint does not match its public keys.");
  }
  const derivedX25519PublicKey = libsodium_wrappers_default.crypto_scalarmult_base(x25519PrivateKey);
  const derivedEd25519PublicKey = libsodium_wrappers_default.crypto_sign_ed25519_sk_to_pk(ed25519PrivateKey);
  if (!equalBytes(derivedX25519PublicKey, x25519PublicKey) || !equalBytes(derivedEd25519PublicKey, ed25519PublicKey)) {
    wipe(derivedX25519PublicKey, derivedEd25519PublicKey);
    throw new Error(
      "The encrypted identity private keys do not match their public keys."
    );
  }
  wipe(derivedX25519PublicKey, derivedEd25519PublicKey);
  const cacheKey = await deriveAesKey(
    importedRoot,
    utf8("aeralyth/metadata-cache/salt/v1"),
    "aeralyth/metadata-cache/key/v1"
  );
  rootKey = importedRoot;
  metadataCacheKey = cacheKey;
  metadataCacheNamespace = toBase64Url(fingerprint);
  vaultSessionGeneration += 1;
  identity = {
    keyVersion: material.identity.keyVersion,
    x25519PublicKey,
    x25519PrivateKey,
    ed25519PublicKey,
    ed25519PrivateKey,
    fingerprint
  };
  wipe(privateBytes, privateRecordId, expectedFingerprint);
}
function lockVault() {
  vaultSessionGeneration += 1;
  if (identity) {
    wipe(
      identity.x25519PublicKey,
      identity.x25519PrivateKey,
      identity.ed25519PublicKey,
      identity.ed25519PrivateKey,
      identity.fingerprint
    );
  }
  identity = null;
  rootKey = null;
  metadataCacheKey = null;
  metadataCacheNamespace = null;
  activeResumeSessionId = null;
  nodeKeys.clear();
  nodeOpenFlights.clear();
  shareContextCache.clear();
  for (const operation of metadataOperations.values()) {
    operation.cancelled = true;
  }
  metadataOperations.clear();
  metadataMemoryCache.clear();
  metadataMemorySizes.clear();
  metadataMemoryBytes = 0;
  for (const [sessionId, session] of encryptionSessions) {
    abortEncryption(sessionId, session.nodeId);
  }
  for (const sessionId of decryptionSessions.keys()) {
    abortDecryption(sessionId);
  }
}
async function decryptShareContexts(contexts, cacheKey) {
  if (cacheKey) {
    const fingerprint = JSON.stringify(
      contexts.map(({ shareId, epoch, wrapperId, ciphertext }) => [
        shareId,
        epoch,
        wrapperId,
        ciphertext
      ])
    );
    return shareContextCache.getOrLoad(
      cacheKey,
      fingerprint,
      () => decryptShareContexts(contexts)
    );
  }
  const root = requireRootKey();
  const loadedEntries = await mapWithConcurrency(
    contexts,
    SHARE_SIDECAR_CRYPTO_CONCURRENCY,
    async (context) => {
      if (context.epoch < 1 || !/^shr_[A-Za-z0-9_-]+$/u.test(context.shareId)) {
        throw new Error("The server returned an invalid active share context.");
      }
      const wrapperId = fromBase64Url(context.wrapperId);
      if (wrapperId.length !== 16) {
        throw new Error("The owner share wrapper is invalid.");
      }
      const raw = await decryptDerivedRecord(
        root,
        wrapperId,
        shareOwnerPurpose(context.shareId, context.epoch),
        toBase64Url(wrapperId),
        context.epoch,
        fromBase64Url(context.ciphertext)
      );
      try {
        if (raw.length !== 32) {
          throw new Error("The share epoch key is invalid.");
        }
        return [
          context.shareId,
          { epoch: context.epoch, key: await importHkdf(raw) }
        ];
      } finally {
        wipe(wrapperId, raw);
      }
    }
  );
  const loaded = new Map(loadedEntries);
  if (loaded.size !== contexts.length) {
    throw new Error("The active share context set contains duplicates.");
  }
  return Array.from(loaded);
}
async function startEncryption(input) {
  requireRootKey();
  const sessionGeneration = vaultSessionGeneration;
  const nodeId = input.nodeId ?? randomPrefixedId("fil_");
  validateNodeId(nodeId);
  const generationNumber = input.generationNumber ?? 1;
  const recordVersion = input.recordVersion ?? 1;
  const generationId = randomBytes(16);
  const previousRecordHash = input.previousRecordHash ? fromBase64Url(input.previousRecordHash) : null;
  if (recordVersion === 1 !== (previousRecordHash === null)) {
    wipe(generationId, previousRecordHash);
    throw new Error("The node record chain is invalid.");
  }
  if (input.parentId && !nodeKeys.has(input.parentId)) {
    wipe(generationId, previousRecordHash);
    throw vaultError(
      "PARENT_KEY_REQUIRED",
      `Unlock the parent folder first:${input.parentId}`
    );
  }
  const nodeMaterial = randomBytes(32);
  let wrapperId = null;
  let wrapperCiphertext = null;
  let ownerWrapper = null;
  let manifest = null;
  let sessionStored = false;
  try {
    const nodeKey = await importHkdf(nodeMaterial);
    const paddedBytes = input.entryType === "file" ? padmeLength(input.plaintextBytes) : 0;
    const layout = input.entryType === "file" ? encryptedLength(paddedBytes) : { chunkCount: 0, ciphertextBytes: 0 };
    const contentKey = input.entryType === "file" ? await deriveAesKey(
      nodeKey,
      generationId,
      `aeralyth/content/v1/${nodeId}/${generationNumber}`
    ) : null;
    assertVaultSession(sessionGeneration);
    wrapperId = randomBytes(16);
    const wrapperKind = input.parentId ? 2 : 1;
    const parentLease = input.parentId ? pinNodeKey(input.parentId) : null;
    const wrappingKey = input.parentId ? parentLease?.value ?? null : requireRootKey();
    if (!wrappingKey) {
      throw vaultError("PARENT_KEY_REQUIRED", "The parent folder is locked.");
    }
    const wrapperPurpose = nodeWrapperPurpose(wrapperKind, nodeId);
    try {
      wrapperCiphertext = await encryptDerivedRecord(
        wrappingKey,
        wrapperId,
        wrapperPurpose,
        toBase64Url(wrapperId),
        recordVersion,
        nodeMaterial
      );
      assertVaultSession(sessionGeneration);
    } finally {
      parentLease?.release();
    }
    ownerWrapper = encodeWrapper({
      formatVersion: VAULT_FORMAT_VERSION,
      wrapperId,
      kind: wrapperKind,
      nodeId,
      parentNodeId: input.parentId,
      generationId: null,
      shareId: null,
      epoch: null,
      recordVersion,
      ciphertext: wrapperCiphertext,
      aadSchemaId: VAULT_AAD_SCHEMA_ID
    });
    manifest = {
      name: normalizeName(input.name),
      mimeType: input.mimeType?.slice(0, 255) || null,
      entryType: input.entryType,
      plaintextBytes: input.entryType === "file" ? input.plaintextBytes : 0,
      paddedBytes,
      lastModified: Math.max(0, Math.trunc(input.lastModified)),
      parentId: input.parentId,
      chunkCount: layout.chunkCount,
      generationId: new Uint8Array(generationId),
      createdAt: Date.now()
    };
    const sessionId = randomPrefixedId("ves_");
    assertVaultSession(sessionGeneration);
    encryptionSessions.set(sessionId, {
      id: sessionId,
      sessionGeneration,
      nodeId,
      parentId: input.parentId,
      nodeKey,
      contentKey,
      generationNumber,
      generationId,
      recordVersion,
      previousRecordHash,
      manifest,
      ciphertextLength: layout.ciphertextBytes,
      chunkCount: layout.chunkCount,
      encryptedChunks: 0,
      consumedPlaintext: 0,
      leaves: [],
      ownerWrapper
    });
    sessionStored = true;
    return {
      sessionId,
      nodeId,
      generationNumber,
      generationId: toBase64Url(generationId),
      recordVersion,
      paddedBytes,
      ciphertextLength: layout.ciphertextBytes,
      chunkCount: layout.chunkCount
    };
  } finally {
    wipe(nodeMaterial, wrapperId, wrapperCiphertext);
    if (!sessionStored) {
      wipe(
        generationId,
        previousRecordHash,
        ownerWrapper,
        manifest?.generationId
      );
    }
  }
}
async function encryptChunk(sessionId, chunkIndex, plaintext) {
  let session;
  try {
    session = requireEncryptionSession(sessionId);
  } catch (error) {
    wipe(plaintext);
    throw error;
  }
  if (!session.contentKey || chunkIndex !== session.encryptedChunks || chunkIndex >= session.chunkCount) {
    wipe(plaintext);
    throw new Error(
      "Encryption chunks must be submitted exactly once and in order."
    );
  }
  const expectedPaddedLength = Math.min(
    VAULT_CRYPTO_CHUNK_BYTES,
    session.manifest.paddedBytes - chunkIndex * VAULT_CRYPTO_CHUNK_BYTES
  );
  const remainingPlaintext = session.manifest.plaintextBytes - session.consumedPlaintext;
  const expectedSourceLength = Math.min(
    expectedPaddedLength,
    Math.max(0, remainingPlaintext)
  );
  if (plaintext.length !== expectedSourceLength) {
    wipe(plaintext);
    throw new Error("The plaintext chunk has an unexpected length.");
  }
  const padded = expectedSourceLength === expectedPaddedLength ? plaintext : new Uint8Array(expectedPaddedLength);
  if (padded !== plaintext) {
    padded.set(plaintext);
    fillRandomBytes(padded.subarray(expectedSourceLength));
  }
  const aad = encodeChunkAad({
    nodeId: session.nodeId,
    generationNumber: session.generationNumber,
    generationId: session.generationId,
    chunkIndex,
    plaintextLength: expectedPaddedLength
  });
  try {
    const ciphertext = new Uint8Array(
      await crypto.subtle.encrypt(
        {
          name: "AES-GCM",
          iv: asBufferSource(chunkNonce(chunkIndex)),
          additionalData: asBufferSource(aad),
          tagLength: 128
        },
        session.contentKey,
        asBufferSource(padded)
      )
    );
    try {
      assertEncryptionSessionActive(sessionId, session);
      const leaf = incrementalCiphertextLeafHash(chunkIndex, ciphertext);
      try {
        assertEncryptionSessionActive(sessionId, session);
        session.leaves.push(leaf);
      } catch (error) {
        wipe(leaf);
        throw error;
      }
      session.encryptedChunks += 1;
      session.consumedPlaintext += plaintext.length;
      return {
        ciphertext: ciphertext.buffer,
        ciphertextBytes: ciphertext.length
      };
    } catch (error) {
      wipe(ciphertext);
      throw error;
    }
  } finally {
    wipe(plaintext, padded, aad);
  }
}
async function finalizeEncryption(sessionId) {
  const session = requireEncryptionSession(sessionId);
  const activeIdentity = requireIdentity();
  if (session.encryptedChunks !== session.chunkCount || session.consumedPlaintext !== session.manifest.plaintextBytes) {
    throw new Error("Not all plaintext chunks were encrypted.");
  }
  const manifestPlaintext = encodeManifest(session.manifest);
  const manifestAad = encodeRecordAad(
    "manifest",
    session.nodeId,
    session.recordVersion
  );
  let encryptedManifest = null;
  let manifestHash = null;
  let ciphertextMerkleRoot = null;
  let wrapperHashes = [];
  let completed = false;
  try {
    const manifestKey = await deriveAesKey(
      session.nodeKey,
      session.generationId,
      `aeralyth/manifest/v1/${session.nodeId}/${session.recordVersion}`
    );
    assertEncryptionSessionActive(sessionId, session);
    encryptedManifest = new Uint8Array(
      await crypto.subtle.encrypt(
        {
          name: "AES-GCM",
          iv: asBufferSource(zeroNonce()),
          additionalData: asBufferSource(manifestAad),
          tagLength: 128
        },
        manifestKey,
        asBufferSource(manifestPlaintext)
      )
    );
    assertEncryptionSessionActive(sessionId, session);
    const canonicalWrappers = [session.ownerWrapper];
    const decodedWrappers = canonicalWrappers.map(decodeWrapper);
    wrapperHashes = await Promise.all(canonicalWrappers.map(sha2565));
    assertEncryptionSessionActive(sessionId, session);
    manifestHash = await sha2565(encryptedManifest);
    assertEncryptionSessionActive(sessionId, session);
    ciphertextMerkleRoot = await merkleRootFromLeaves(session.leaves);
    assertEncryptionSessionActive(sessionId, session);
    const bootstrap = {
      formatVersion: VAULT_FORMAT_VERSION,
      suiteId: VAULT_SUITE_ID,
      aadSchemaId: VAULT_AAD_SCHEMA_ID,
      nodeId: session.nodeId,
      generationNumber: session.generationNumber,
      generationId: session.generationId,
      manifestIv: zeroNonce(),
      wrapperIds: decodedWrappers.map((wrapper) => wrapper.wrapperId),
      ciphertextLength: session.ciphertextLength,
      signerKeyVersion: activeIdentity.keyVersion,
      recordVersion: session.recordVersion,
      previousRecordHash: session.previousRecordHash,
      manifestHash,
      wrapperHashes,
      ciphertextMerkleRoot
    };
    const bootstrapCbor = encodeBootstrap(bootstrap);
    const signature = libsodium_wrappers_default.crypto_sign_detached(
      bootstrapCbor,
      activeIdentity.ed25519PrivateKey
    );
    const complete = {
      nodeId: session.nodeId,
      generationNumber: session.generationNumber,
      generationId: toBase64Url(session.generationId),
      recordVersion: session.recordVersion,
      ciphertextLength: session.ciphertextLength,
      chunkCount: session.chunkCount,
      record: {
        bootstrapCbor,
        bootstrapSignature: signature,
        encryptedManifest,
        wrappers: canonicalWrappers
      }
    };
    assertEncryptionSessionActive(sessionId, session);
    nodeKeys.set(session.nodeId, session.nodeKey);
    encryptionSessions.delete(sessionId);
    completed = true;
    return complete;
  } finally {
    wipe(
      manifestPlaintext,
      manifestAad,
      manifestHash,
      ciphertextMerkleRoot,
      ...wrapperHashes,
      ...session.leaves
    );
    if (!completed) wipe(encryptedManifest);
  }
}
function abortEncryption(sessionId, nodeId) {
  validateNodeId(nodeId);
  const session = encryptionSessions.get(sessionId);
  if (session && session.nodeId !== nodeId) {
    throw new Error("The encryption session does not match the node.");
  }
  encryptionSessions.delete(sessionId);
  if (!session || nodeKeys.get(nodeId) === session.nodeKey) {
    nodeKeys.delete(nodeId);
  }
  if (session) {
    wipe(
      session.generationId,
      session.manifest.generationId,
      session.previousRecordHash,
      session.ownerWrapper,
      ...session.leaves
    );
  }
}
async function createShareDirectory(input) {
  const sessionGeneration = vaultSessionGeneration;
  const activeIdentity = requireIdentity();
  const nodeKey = nodeKeys.get(input.nodeId);
  if (!nodeKey) {
    throw vaultError(
      "NODE_KEY_REQUIRED",
      `Unlock the node before synchronizing its share directory:${input.nodeId}`
    );
  }
  if (input.shareContexts.length < 1 || input.shareContexts.length > 4096 || !Number.isSafeInteger(input.recordVersion) || input.recordVersion < 1 || !Number.isSafeInteger(input.generationNumber) || input.generationNumber < 1) {
    throw new Error("The share-directory request is invalid.");
  }
  const generationId = fromBase64Url(input.generationId);
  const recordHash = fromBase64Url(input.recordHash);
  if (generationId.length !== 16 || recordHash.length !== 32) {
    throw new Error("The share-directory record binding is invalid.");
  }
  const contexts = await decryptShareContexts(
    input.shareContexts,
    input.shareContextCacheKey
  );
  assertVaultSession(sessionGeneration);
  const wrappersByShare = await mapWithConcurrency(
    contexts,
    SHARE_SIDECAR_CRYPTO_CONCURRENCY,
    async ([shareId, value]) => {
      const context = { shareId, epoch: value.epoch, epochKey: value.key };
      const metadata = createShareWrapperFromNode(
        input.nodeId,
        input.recordVersion,
        input.generationNumber,
        generationId,
        nodeKey,
        context,
        4
      );
      if (input.entryType === "folder") return [await metadata];
      return Promise.all([
        metadata,
        createShareWrapperFromNode(
          input.nodeId,
          input.recordVersion,
          input.generationNumber,
          generationId,
          nodeKey,
          context,
          3
        )
      ]);
    }
  );
  assertVaultSession(sessionGeneration);
  const wrappers = wrappersByShare.flat();
  const wrapperHashes = await mapWithConcurrency(
    wrappers,
    SHARE_SIDECAR_CRYPTO_CONCURRENCY,
    sha2565
  );
  assertVaultSession(sessionGeneration);
  const wrapperRoot = await wrapperSetRoot(wrapperHashes);
  assertVaultSession(sessionGeneration);
  const directory = {
    formatVersion: VAULT_SHARE_DIRECTORY_VERSION,
    suiteId: VAULT_SUITE_ID,
    aadSchemaId: VAULT_AAD_SCHEMA_ID,
    nodeId: input.nodeId,
    recordVersion: input.recordVersion,
    recordHash,
    generationNumber: input.generationNumber,
    generationId,
    signerKeyVersion: activeIdentity.keyVersion,
    wrapperSetRoot: wrapperRoot,
    wrapperCount: wrappers.length
  };
  const canonical = encodeShareDirectory(directory);
  const signature = libsodium_wrappers_default.crypto_sign_detached(
    canonical,
    activeIdentity.ed25519PrivateKey
  );
  const result = {
    directoryCbor: canonical,
    directorySignature: signature,
    wrappers
  };
  wipe(generationId, recordHash, wrapperRoot, ...wrapperHashes);
  return result;
}
async function openPlan(plan) {
  const { manifest } = await openAndVerifyPlanSingleFlight(plan);
  const cached = {
    status: "ready",
    nodeId: plan.nodeId,
    recordHash: plan.recordHash,
    manifest
  };
  rememberMetadata(cached);
  void writePersistentMetadata([cached]).catch(() => void 0);
  return { manifest };
}
async function getCachedMetadata(references) {
  requireRootKey();
  const sessionGeneration = vaultSessionGeneration;
  const unique = /* @__PURE__ */ new Map();
  for (const reference of references) {
    assertMetadataReference(reference);
    unique.set(
      metadataCacheEntryKey(reference.nodeId, reference.recordHash),
      reference
    );
  }
  const resolved = /* @__PURE__ */ new Map();
  const persistentMisses = [];
  for (const [key, reference] of unique) {
    const cached = metadataMemoryCache.get(key);
    if (cached && toBase64Url(cached.manifest.generationId) === reference.generationId) {
      metadataMemoryCache.delete(key);
      metadataMemoryCache.set(key, cached);
      resolved.set(key, cached);
    } else {
      persistentMisses.push(reference);
    }
  }
  if (persistentMisses.length > 0) {
    const persisted = await readPersistentMetadata(persistentMisses).catch(
      () => []
    );
    assertVaultSession(sessionGeneration);
    for (const cached of persisted) {
      rememberMetadata(cached);
      resolved.set(
        metadataCacheEntryKey(cached.nodeId, cached.recordHash),
        cached
      );
    }
  }
  assertVaultSession(sessionGeneration);
  return references.flatMap((reference) => {
    const cached = resolved.get(
      metadataCacheEntryKey(reference.nodeId, reference.recordHash)
    );
    return cached ? [cached] : [];
  });
}
async function openMetadataPlans(operationId, plans, concurrency, priorityCount, onPriority) {
  requireRootKey();
  const sessionGeneration = vaultSessionGeneration;
  if (!Number.isSafeInteger(concurrency) || concurrency < 1 || concurrency > MAX_METADATA_DECRYPTION_CONCURRENCY) {
    throw new Error("Metadata decryption concurrency is out of range.");
  }
  if (!Number.isSafeInteger(priorityCount) || priorityCount < 0) {
    throw new Error("Metadata priority count is invalid.");
  }
  const uniquePlanKeys = /* @__PURE__ */ new Set();
  for (const plan of plans) {
    const key = metadataCacheEntryKey(plan.nodeId, plan.recordHash);
    if (uniquePlanKeys.has(key)) {
      throw new Error("The metadata batch contains a duplicate node revision.");
    }
    uniquePlanKeys.add(key);
  }
  const operation = {
    cancelled: false,
    nodeIds: new Set(plans.map((plan) => plan.nodeId))
  };
  metadataOperations.set(operationId, operation);
  try {
    assertMetadataOperationActive(operation, sessionGeneration);
    const priorityBoundary = Math.min(priorityCount, plans.length);
    const priorityResults = await openMetadataPlanSet(
      plans.slice(0, priorityBoundary),
      concurrency,
      operation,
      sessionGeneration
    );
    assertMetadataOperationActive(operation, sessionGeneration);
    const priorityReady = readyMetadataResults(priorityResults);
    for (const result of priorityReady) rememberMetadata(result);
    if (priorityResults.length > 0) onPriority(priorityResults);
    const remainingResults = await openMetadataPlanSet(
      plans.slice(priorityBoundary),
      concurrency,
      operation,
      sessionGeneration
    );
    assertMetadataOperationActive(operation, sessionGeneration);
    const remainingReady = readyMetadataResults(remainingResults);
    for (const result of remainingReady) rememberMetadata(result);
    assertMetadataOperationActive(operation, sessionGeneration);
    persistCompletedMetadataOperation(operation, sessionGeneration, [
      ...priorityReady,
      ...remainingReady
    ]);
    return [...priorityResults, ...remainingResults];
  } finally {
    if (operation.cancelled && metadataOperations.get(operationId) === operation) {
      metadataOperations.delete(operationId);
    } else {
      setTimeout(() => {
        if (metadataOperations.get(operationId) === operation) {
          metadataOperations.delete(operationId);
        }
      }, 1e3);
    }
    if (operation.cancelled) evictMetadataOperation(operation);
  }
}
function persistCompletedMetadataOperation(operation, sessionGeneration, results) {
  setTimeout(() => {
    if (!operation.cancelled && sessionGeneration === vaultSessionGeneration && results.length > 0) {
      void writePersistentMetadata(results).catch(() => void 0);
    }
  }, 1e3);
}
async function openMetadataPlanSet(plans, concurrency, operation, sessionGeneration) {
  if (plans.length === 0) return [];
  const results = new Array(plans.length);
  let pending = plans.map((plan, index) => ({ plan, index }));
  while (pending.length > 0) {
    const round = await mapWithConcurrency(
      pending,
      concurrency,
      async ({ plan, index }) => {
        assertMetadataOperationActive(operation, sessionGeneration);
        try {
          const { manifest } = await openAndVerifyPlan(plan, () => {
            assertMetadataOperationActive(operation, sessionGeneration);
          });
          assertMetadataOperationActive(operation, sessionGeneration);
          return {
            index,
            result: {
              status: "ready",
              nodeId: plan.nodeId,
              recordHash: plan.recordHash,
              manifest
            },
            parentRequired: false
          };
        } catch (failure) {
          assertMetadataOperationActive(operation, sessionGeneration);
          const normalized = normalizeError(failure);
          return {
            index,
            result: {
              status: "unavailable",
              nodeId: plan.nodeId,
              recordHash: plan.recordHash,
              error: normalized.message,
              ...normalized.code ? { code: normalized.code } : {}
            },
            parentRequired: normalized.code === "PARENT_KEY_REQUIRED"
          };
        }
      }
    );
    assertMetadataOperationActive(operation, sessionGeneration);
    const madeProgress = round.some(({ result }) => result.status === "ready");
    const retry = [];
    for (let offset = 0; offset < round.length; offset += 1) {
      const outcome = round[offset];
      if (outcome.parentRequired && madeProgress) {
        retry.push(pending[offset]);
      } else {
        results[outcome.index] = outcome.result;
      }
    }
    if (retry.length === pending.length) {
      for (let offset = 0; offset < round.length; offset += 1) {
        results[round[offset].index] = round[offset].result;
      }
      break;
    }
    pending = retry;
  }
  return results;
}
function assertMetadataOperationActive(operation, sessionGeneration) {
  assertVaultSession(sessionGeneration);
  if (operation.cancelled) {
    throw new DOMException(
      "The metadata operation was cancelled.",
      "AbortError"
    );
  }
}
function cancelMetadataOperation(operationId) {
  const operation = metadataOperations.get(operationId);
  if (!operation) return;
  operation.cancelled = true;
  evictMetadataOperation(operation);
}
function evictMetadataOperation(operation) {
  for (const nodeId of operation.nodeIds) {
    for (const key of metadataMemoryCache.keys()) {
      if (key.startsWith(`${nodeId}:`)) evictMetadata(key);
    }
    nodeKeys.deleteIfUnpinned(nodeId);
  }
}
function readyMetadataResults(results) {
  return results.filter(
    (result) => result.status === "ready"
  );
}
function rememberMetadata(result) {
  const key = metadataCacheEntryKey(result.nodeId, result.recordHash);
  for (const existingKey of metadataMemoryCache.keys()) {
    if (existingKey !== key && existingKey.startsWith(`${result.nodeId}:`)) {
      evictMetadata(existingKey);
    }
  }
  evictMetadata(key);
  metadataMemoryCache.set(key, result);
  const bytes = estimateMetadataBytes(result);
  metadataMemorySizes.set(key, bytes);
  metadataMemoryBytes += bytes;
  trimCombinedMetadataCaches();
}
function trimCombinedMetadataCaches() {
  while (combinedMetadataEntryCount() > MAX_METADATA_MEMORY_ENTRIES || metadataMemoryBytes + nodeKeys.size * NODE_KEY_ACCOUNTED_BYTES > MAX_METADATA_MEMORY_BYTES) {
    let evicted = false;
    for (const oldest of metadataMemoryCache.keys()) {
      const nodeId = metadataNodeId(oldest);
      if (nodeKeys.isPinned(nodeId)) continue;
      evictMetadata(oldest);
      nodeKeys.deleteIfUnpinned(nodeId);
      evicted = true;
      break;
    }
    if (!evicted) {
      const oldestNodeKey = nodeKeys.oldestUnpinnedKey();
      if (oldestNodeKey === void 0) break;
      nodeKeys.deleteIfUnpinned(oldestNodeKey);
      evicted = true;
    }
    if (!evicted) break;
  }
}
function combinedMetadataEntryCount() {
  const nodeIds = new Set(nodeKeys.keys());
  for (const key of metadataMemoryCache.keys())
    nodeIds.add(metadataNodeId(key));
  return nodeIds.size;
}
function pinNodeKey(nodeId) {
  const lease = nodeKeys.pin(nodeId);
  if (!lease) return null;
  return {
    value: lease.value,
    release() {
      lease.release();
      trimCombinedMetadataCaches();
    }
  };
}
function metadataNodeId(key) {
  const separator = key.indexOf(":");
  return separator === -1 ? key : key.slice(0, separator);
}
function evictMetadata(key) {
  metadataMemoryCache.delete(key);
  const bytes = metadataMemorySizes.get(key);
  if (bytes !== void 0) {
    metadataMemoryBytes -= bytes;
    metadataMemorySizes.delete(key);
  }
}
function estimateMetadataBytes(result) {
  const manifest = result.manifest;
  return 256 + result.nodeId.length * 2 + result.recordHash.length * 2 + manifest.name.length * 2 + (manifest.mimeType?.length ?? 0) * 2 + (manifest.parentId?.length ?? 0) * 2 + manifest.generationId.byteLength;
}
function assertMetadataReference(reference) {
  if (!isVaultNodeId(reference.nodeId) || !Number.isSafeInteger(reference.recordVersion) || reference.recordVersion < 1 || fromBase64Url(reference.recordHash).length !== 32 || fromBase64Url(reference.generationId).length !== 16) {
    throw new Error("The metadata cache reference is invalid.");
  }
}
function metadataCacheEntryKey(nodeId, recordHash) {
  return `${nodeId}:${recordHash}`;
}
async function readPersistentMetadata(references) {
  if (typeof indexedDB === "undefined" || references.length === 0) return [];
  const { key, namespace } = requireMetadataCacheMaterial();
  const database = await openMetadataDatabase();
  const transaction = database.transaction(METADATA_CACHE_STORE, "readonly");
  const store = transaction.objectStore(METADATA_CACHE_STORE);
  const stored = await Promise.all(
    references.map(
      (reference) => requestResult(
        store.get(persistentMetadataKey(namespace, reference))
      )
    )
  );
  await transactionComplete(transaction);
  const cached = await mapWithConcurrency(
    references.map((reference, index) => ({
      reference,
      stored: stored[index]
    })),
    MAX_METADATA_DECRYPTION_CONCURRENCY,
    async ({ reference, stored: record }) => {
      if (!record || record.namespace !== namespace || record.nodeId !== reference.nodeId || record.recordHash !== reference.recordHash) {
        return null;
      }
      const aad = metadataCacheAad(
        namespace,
        reference.nodeId,
        reference.recordHash
      );
      try {
        const plaintext = new Uint8Array(
          await crypto.subtle.decrypt(
            {
              name: "AES-GCM",
              iv: record.iv,
              additionalData: asBufferSource(aad),
              tagLength: 128
            },
            key,
            record.ciphertext
          )
        );
        try {
          const manifest = deserializeCachedManifest(plaintext);
          if (toBase64Url(manifest.generationId) !== reference.generationId) {
            wipe(manifest.generationId);
            return null;
          }
          return {
            status: "ready",
            nodeId: reference.nodeId,
            recordHash: reference.recordHash,
            manifest
          };
        } finally {
          wipe(plaintext);
        }
      } catch {
        return null;
      } finally {
        wipe(aad);
      }
    }
  );
  return cached.filter(
    (result) => result !== null
  );
}
async function writePersistentMetadata(results) {
  if (typeof indexedDB === "undefined" || results.length === 0) return;
  const { key, namespace } = requireMetadataCacheMaterial();
  const databasePromise = openMetadataDatabase();
  const records = await mapWithConcurrency(
    results,
    MAX_METADATA_DECRYPTION_CONCURRENCY,
    async (result) => {
      const iv = randomBytes(12);
      const aad = metadataCacheAad(namespace, result.nodeId, result.recordHash);
      const plaintext = utf8(
        JSON.stringify(serializeCachedManifest(result.manifest))
      );
      try {
        const ciphertext = await crypto.subtle.encrypt(
          {
            name: "AES-GCM",
            iv: asBufferSource(iv),
            additionalData: asBufferSource(aad),
            tagLength: 128
          },
          key,
          asBufferSource(plaintext)
        );
        return {
          key: persistentMetadataKey(namespace, result),
          namespace,
          nodeId: result.nodeId,
          recordHash: result.recordHash,
          iv: toArrayBuffer2(iv),
          ciphertext
        };
      } finally {
        wipe(iv, aad, plaintext);
      }
    }
  );
  const database = await databasePromise;
  const transaction = database.transaction(METADATA_CACHE_STORE, "readwrite");
  const store = transaction.objectStore(METADATA_CACHE_STORE);
  for (const record of records) store.put(record);
  await transactionComplete(transaction);
}
function requireMetadataCacheMaterial() {
  if (!metadataCacheKey || !metadataCacheNamespace) {
    throw new Error(
      "The encrypted metadata cache is unavailable while locked."
    );
  }
  return { key: metadataCacheKey, namespace: metadataCacheNamespace };
}
function persistentMetadataKey(namespace, reference) {
  return `${namespace}:${reference.nodeId}`;
}
function metadataCacheAad(namespace, nodeId, recordHash) {
  return utf8(
    `aeralyth/metadata-cache/record/v1/${namespace}/${nodeId}/${recordHash}`
  );
}
function serializeCachedManifest(manifest) {
  return {
    ...manifest,
    generationId: toBase64Url(manifest.generationId)
  };
}
function deserializeCachedManifest(plaintext) {
  const value = JSON.parse(new TextDecoder().decode(plaintext));
  const generationId = typeof value.generationId === "string" ? fromBase64Url(value.generationId) : new Uint8Array();
  if (typeof value.name !== "string" || !(typeof value.mimeType === "string" || value.mimeType === null) || value.entryType !== "file" && value.entryType !== "folder" || typeof value.plaintextBytes !== "number" || typeof value.paddedBytes !== "number" || typeof value.lastModified !== "number" || !(typeof value.parentId === "string" || value.parentId === null) || typeof value.chunkCount !== "number" || typeof value.createdAt !== "number" || generationId.length !== 16) {
    wipe(generationId);
    throw new Error("The encrypted metadata cache record is invalid.");
  }
  return {
    name: value.name,
    mimeType: value.mimeType,
    entryType: value.entryType,
    plaintextBytes: value.plaintextBytes,
    paddedBytes: value.paddedBytes,
    lastModified: value.lastModified,
    parentId: value.parentId,
    chunkCount: value.chunkCount,
    generationId,
    createdAt: value.createdAt
  };
}
function openMetadataDatabase() {
  if (metadataDatabasePromise) return metadataDatabasePromise;
  const opening = new Promise((resolve, reject) => {
    const request = indexedDB.open(
      METADATA_CACHE_DATABASE,
      METADATA_CACHE_DATABASE_VERSION
    );
    request.addEventListener("upgradeneeded", (event) => {
      if (!request.result.objectStoreNames.contains(METADATA_CACHE_STORE)) {
        const store = request.result.createObjectStore(METADATA_CACHE_STORE, {
          keyPath: "key"
        });
        store.createIndex("namespace-node", ["namespace", "nodeId"]);
      } else if (event.oldVersion < 2) {
        request.transaction?.objectStore(METADATA_CACHE_STORE).clear();
      }
      if (!request.result.objectStoreNames.contains(VAULT_RESUME_SESSION_STORE)) {
        request.result.createObjectStore(VAULT_RESUME_SESSION_STORE, {
          keyPath: "sessionId"
        });
      }
    });
    request.addEventListener(
      "success",
      () => {
        const database = request.result;
        database.addEventListener("versionchange", () => {
          database.close();
          metadataDatabasePromise = null;
        });
        resolve(database);
      },
      { once: true }
    );
    request.addEventListener(
      "error",
      () => reject(request.error ?? new Error("Metadata cache open failed.")),
      { once: true }
    );
    request.addEventListener(
      "blocked",
      () => reject(new Error("Metadata cache upgrade is blocked.")),
      { once: true }
    );
  });
  metadataDatabasePromise = opening;
  void opening.catch(() => {
    if (metadataDatabasePromise === opening) metadataDatabasePromise = null;
  });
  return opening;
}
async function readVaultResumeSession(sessionId) {
  if (typeof indexedDB === "undefined") return null;
  const database = await openMetadataDatabase();
  const transaction = database.transaction(
    VAULT_RESUME_SESSION_STORE,
    "readonly"
  );
  const completion = transactionComplete(transaction);
  const stored = await requestResult(
    transaction.objectStore(VAULT_RESUME_SESSION_STORE).get(sessionId)
  );
  await completion;
  return stored ?? null;
}
async function writeVaultResumeSession(stored) {
  if (typeof indexedDB === "undefined") {
    throw new Error("Vault resume storage is unavailable.");
  }
  await pruneExpiredVaultResumeSessions(Date.now());
  const database = await openMetadataDatabase();
  const transaction = database.transaction(
    VAULT_RESUME_SESSION_STORE,
    "readwrite"
  );
  transaction.objectStore(VAULT_RESUME_SESSION_STORE).put(stored);
  await transactionComplete(transaction);
}
async function deleteVaultResumeSession(sessionId) {
  if (typeof indexedDB === "undefined") return;
  const database = await openMetadataDatabase();
  const transaction = database.transaction(
    VAULT_RESUME_SESSION_STORE,
    "readwrite"
  );
  transaction.objectStore(VAULT_RESUME_SESSION_STORE).delete(sessionId);
  await transactionComplete(transaction);
}
async function pruneExpiredVaultResumeSessions(now) {
  const database = await openMetadataDatabase();
  const transaction = database.transaction(
    VAULT_RESUME_SESSION_STORE,
    "readwrite"
  );
  const cursorRequest = transaction.objectStore(VAULT_RESUME_SESSION_STORE).openCursor();
  cursorRequest.addEventListener("success", () => {
    const cursor = cursorRequest.result;
    if (!cursor) return;
    const stored = cursor.value;
    if (!isStoredVaultResumeSession(stored) || !validVaultResumeExpiration(stored.expiresAt, now)) {
      cursor.delete();
    }
    cursor.continue();
  });
  await transactionComplete(transaction);
}
function isStoredVaultResumeSession(value) {
  if (!value || typeof value !== "object") return false;
  const stored = value;
  const rootKey2 = stored.rootKey;
  return typeof stored.sessionId === "string" && VAULT_RESUME_SESSION_ID_PATTERN.test(stored.sessionId) && typeof stored.sessionBindingHash === "string" && typeof stored.identityFingerprint === "string" && typeof stored.vaultVersion === "number" && Number.isSafeInteger(stored.vaultVersion) && typeof stored.expiresAt === "number" && Number.isSafeInteger(stored.expiresAt) && !!rootKey2 && rootKey2.type === "secret" && rootKey2.extractable === false && rootKey2.algorithm?.name === "HKDF" && Array.isArray(rootKey2.usages) && rootKey2.usages.length === 1 && rootKey2.usages[0] === "deriveBits";
}
function assertVaultResumeSessionId(sessionId) {
  if (!VAULT_RESUME_SESSION_ID_PATTERN.test(sessionId)) {
    throw new Error("The vault resume session is invalid.");
  }
}
function assertVaultResumeExpiration(expiresAt) {
  const now = Date.now();
  if (!validVaultResumeExpiration(expiresAt, now)) {
    throw new Error("The vault resume expiration is invalid.");
  }
}
async function hashVaultSessionBinding(binding) {
  if (binding.length < 16 || binding.length > 1024) {
    throw new Error("The vault session binding is invalid.");
  }
  const bindingBytes = utf8(binding);
  const digest = await sha2565(bindingBytes);
  try {
    return toBase64Url(digest);
  } finally {
    wipe(bindingBytes, digest);
  }
}
function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.addEventListener("success", () => resolve(request.result), {
      once: true
    });
    request.addEventListener(
      "error",
      () => reject(request.error ?? new Error("Metadata cache request failed.")),
      { once: true }
    );
  });
}
function transactionComplete(transaction) {
  return new Promise((resolve, reject) => {
    transaction.addEventListener("complete", () => resolve(), { once: true });
    transaction.addEventListener(
      "error",
      () => reject(
        transaction.error ?? new Error("Metadata cache transaction failed.")
      ),
      { once: true }
    );
    transaction.addEventListener(
      "abort",
      () => reject(
        transaction.error ?? new Error("Metadata cache transaction aborted.")
      ),
      { once: true }
    );
  });
}
async function startDecryption(plan) {
  requireRootKey();
  const sessionGeneration = vaultSessionGeneration;
  const opened = await openAndVerifyPlanSingleFlight(plan);
  assertVaultSession(sessionGeneration);
  if (opened.manifest.entryType !== "file") {
    throw new Error("Folders do not have encrypted content streams.");
  }
  const contentKey = opened.contentKey ?? (opened.nodeKey ? await deriveAesKey(
    opened.nodeKey,
    opened.manifest.generationId,
    `aeralyth/content/v1/${plan.nodeId}/${plan.generationNumber}`
  ) : null);
  assertVaultSession(sessionGeneration);
  if (!contentKey) throw new Error("The shared generation key is unavailable.");
  const sessionId = randomPrefixedId("vds_");
  assertVaultSession(sessionGeneration);
  decryptionSessions.set(sessionId, {
    id: sessionId,
    sessionGeneration,
    nodeId: plan.nodeId,
    contentKey,
    generationNumber: plan.generationNumber,
    generationId: opened.manifest.generationId,
    manifest: opened.manifest,
    ciphertextLength: plan.ciphertextLength,
    chunkCount: plan.chunkCount,
    decryptedChunks: 0,
    leaves: [],
    expectedMerkleRoot: fromBase64Url(plan.ciphertextMerkleRoot)
  });
  return { sessionId, manifest: opened.manifest };
}
async function decryptChunk(sessionId, chunkIndex, ciphertext) {
  const session = decryptionSessions.get(sessionId);
  if (!session) {
    wipe(ciphertext);
    throw new Error("The decryption session is no longer available.");
  }
  assertDecryptionSessionActive(sessionId, session);
  if (chunkIndex !== session.decryptedChunks || chunkIndex >= session.chunkCount) {
    wipe(ciphertext);
    throw new Error(
      "Ciphertext chunks must be submitted exactly once and in order."
    );
  }
  const expectedPlaintextLength = Math.min(
    VAULT_CRYPTO_CHUNK_BYTES,
    session.manifest.paddedBytes - chunkIndex * VAULT_CRYPTO_CHUNK_BYTES
  );
  if (ciphertext.length !== expectedPlaintextLength + 16) {
    wipe(ciphertext);
    throw new Error("The ciphertext chunk has an invalid length.");
  }
  const aad = encodeChunkAad({
    nodeId: session.nodeId,
    generationNumber: session.generationNumber,
    generationId: session.generationId,
    chunkIndex,
    plaintextLength: expectedPlaintextLength
  });
  let leaf = null;
  let padded = null;
  try {
    leaf = incrementalCiphertextLeafHash(chunkIndex, ciphertext);
    assertDecryptionSessionActive(sessionId, session);
    session.leaves.push(leaf);
    leaf = null;
    padded = new Uint8Array(
      await crypto.subtle.decrypt(
        {
          name: "AES-GCM",
          iv: asBufferSource(chunkNonce(chunkIndex)),
          additionalData: asBufferSource(aad),
          tagLength: 128
        },
        session.contentKey,
        asBufferSource(ciphertext)
      )
    );
    assertDecryptionSessionActive(sessionId, session);
    const offset = chunkIndex * VAULT_CRYPTO_CHUNK_BYTES;
    const usefulLength = Math.max(
      0,
      Math.min(padded.length, session.manifest.plaintextBytes - offset)
    );
    const plaintext = usefulLength === padded.length ? padded : padded.slice(0, usefulLength);
    if (plaintext === padded) padded = null;
    session.decryptedChunks += 1;
    return { plaintext: plaintext.buffer, plaintextBytes: plaintext.length };
  } catch (error) {
    abortDecryption(sessionId);
    if (isCryptoLifecycleError(error)) throw error;
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "Encrypted file authentication failed.",
      error
    );
  } finally {
    wipe(ciphertext, aad, leaf, padded);
  }
}
async function finalizeDecryption(sessionId) {
  const session = decryptionSessions.get(sessionId);
  if (!session || session.decryptedChunks !== session.chunkCount) {
    throw new Error("Not all ciphertext chunks were decrypted.");
  }
  assertDecryptionSessionActive(sessionId, session);
  const actualRoot = await merkleRootFromLeaves(session.leaves);
  try {
    assertDecryptionSessionActive(sessionId, session);
    if (!equalBytes(actualRoot, session.expectedMerkleRoot)) {
      abortDecryption(sessionId);
      throw vaultError(
        "AUTHENTICATION_FAILED",
        "The encrypted file Merkle root is invalid."
      );
    }
    abortDecryption(sessionId);
  } finally {
    wipe(actualRoot);
  }
}
function abortDecryption(sessionId) {
  const session = decryptionSessions.get(sessionId);
  if (!session) return;
  decryptionSessions.delete(sessionId);
  wipe(
    session.generationId,
    session.manifest.generationId,
    session.expectedMerkleRoot,
    ...session.leaves
  );
}
function openAndVerifyPlanSingleFlight(plan) {
  const key = planFlightKey(plan);
  const existing = nodeOpenFlights.get(key);
  if (existing) return existing;
  const operation = openAndVerifyPlan(plan);
  nodeOpenFlights.set(key, operation);
  const clearFlight = () => {
    if (nodeOpenFlights.get(key) === operation) nodeOpenFlights.delete(key);
  };
  void operation.then(clearFlight, clearFlight);
  return operation;
}
function planFlightKey(plan) {
  const authorization = plan.share?.authorizationVersion ?? "owner";
  return `${metadataCacheEntryKey(plan.nodeId, plan.recordHash)}:${authorization}`;
}
function isDownloadPlan(plan) {
  return "downloadUrl" in plan;
}
async function openAndVerifyPlan(plan, assertActive = () => void 0) {
  requireRootKey();
  assertActive();
  const sessionGeneration = vaultSessionGeneration;
  const downloadPlan = isDownloadPlan(plan) ? plan : null;
  const bootstrapBytes = fromBase64Url(plan.bootstrapCbor);
  const signature = fromBase64Url(plan.bootstrapSignature);
  const bootstrap = decodeBootstrap(bootstrapBytes);
  const publicKey = fromBase64Url(plan.signerEd25519PublicKey);
  const expectedChunkCount = plan.ciphertextLength === 0 ? 0 : Math.ceil(plan.ciphertextLength / (VAULT_CRYPTO_CHUNK_BYTES + 16));
  if (!libsodium_wrappers_default.crypto_sign_verify_detached(signature, bootstrapBytes, publicKey)) {
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "The node record signature is invalid."
    );
  }
  const signedHash = await sha256Parts(bootstrapBytes, signature);
  if (bootstrap.formatVersion !== VAULT_FORMAT_VERSION || bootstrap.suiteId !== VAULT_SUITE_ID || bootstrap.aadSchemaId !== VAULT_AAD_SCHEMA_ID || bootstrap.nodeId !== plan.nodeId || bootstrap.generationNumber !== plan.generationNumber || bootstrap.recordVersion !== plan.recordVersion || bootstrap.signerKeyVersion !== plan.signerKeyVersion || bootstrap.recordVersion === 1 !== (bootstrap.previousRecordHash === null) || !equalBytes(bootstrap.manifestIv, zeroNonce()) || !equalBytes(bootstrap.generationId, fromBase64Url(plan.generationId)) || bootstrap.ciphertextLength !== plan.ciphertextLength || plan.cryptoChunkBytes !== VAULT_CRYPTO_CHUNK_BYTES || plan.chunkCount !== expectedChunkCount || plan.entryType === "folder" !== (plan.ciphertextLength === 0) || bootstrap.wrapperIds.length !== plan.wrappers.length || !equalBytes(
    bootstrap.ciphertextMerkleRoot,
    fromBase64Url(plan.ciphertextMerkleRoot)
  ) || !equalBytes(signedHash, fromBase64Url(plan.recordHash))) {
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "The node record head is inconsistent."
    );
  }
  const encryptedManifest = fromBase64Url(plan.encryptedManifest);
  if (!equalBytes(await sha2565(encryptedManifest), bootstrap.manifestHash)) {
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "The encrypted manifest commitment is invalid."
    );
  }
  const wrapperBytes = plan.wrappers.map(fromBase64Url);
  const wrappers = [];
  for (let index = 0; index < wrapperBytes.length; index += 1) {
    const wrapper = decodeWrapper(wrapperBytes[index]);
    wrappers.push(wrapper);
  }
  const wrapperHashes = await mapWithConcurrency(
    wrapperBytes,
    SHARE_HASH_CRYPTO_CONCURRENCY,
    sha2565
  );
  const verifiedMaterial = {
    bootstrap,
    wrappers,
    wrapperBytes,
    wrapperHashes
  };
  let nodeKey = null;
  let manifestKey = null;
  let contentKey = null;
  if (plan.share) {
    const shared = await openSharedKeys(plan, verifiedMaterial);
    manifestKey = shared.manifestKey;
    contentKey = shared.contentKey;
  } else {
    if (wrapperBytes.length !== bootstrap.wrapperIds.length || wrapperBytes.length !== bootstrap.wrapperHashes.length) {
      throw vaultError(
        "AUTHENTICATION_FAILED",
        "The wrapper commitment count is invalid."
      );
    }
    for (let index = 0; index < wrappers.length; index += 1) {
      const wrapper = wrappers[index];
      if (wrapper.nodeId !== plan.nodeId || wrapper.recordVersion !== plan.recordVersion || !equalBytes(wrapper.wrapperId, bootstrap.wrapperIds[index]) || !equalBytes(wrapperHashes[index], bootstrap.wrapperHashes[index])) {
        throw vaultError(
          "AUTHENTICATION_FAILED",
          "A node-key wrapper commitment is invalid."
        );
      }
    }
    nodeKey = nodeKeys.get(plan.nodeId) ?? null;
  }
  if (!plan.share && !nodeKey) {
    const ownerWrapper = wrappers.find(
      (wrapper) => wrapper.kind === 1 || wrapper.kind === 2
    );
    if (!ownerWrapper) {
      throw vaultError(
        "AUTHENTICATION_FAILED",
        "No owner node-key wrapper is available."
      );
    }
    const parentLease = ownerWrapper.kind === 2 && ownerWrapper.parentNodeId ? pinNodeKey(ownerWrapper.parentNodeId) : null;
    const wrappingKey = ownerWrapper.kind === 1 ? requireRootKey() : parentLease?.value ?? null;
    if (!wrappingKey) {
      throw vaultError(
        "PARENT_KEY_REQUIRED",
        `Unlock the parent folder first:${ownerWrapper.parentNodeId ?? ""}`
      );
    }
    const purpose = nodeWrapperPurpose(ownerWrapper.kind, ownerWrapper.nodeId);
    try {
      const raw = await decryptDerivedRecord(
        wrappingKey,
        ownerWrapper.wrapperId,
        purpose,
        toBase64Url(ownerWrapper.wrapperId),
        ownerWrapper.recordVersion,
        ownerWrapper.ciphertext
      );
      try {
        if (raw.length !== 32)
          throw new Error("The node key has an invalid length.");
        nodeKey = await importHkdf(raw);
        assertActive();
        assertVaultSession(sessionGeneration);
        nodeKeys.set(plan.nodeId, nodeKey);
        trimCombinedMetadataCaches();
      } finally {
        wipe(raw);
      }
    } finally {
      parentLease?.release();
    }
  }
  if (!plan.share) {
    if (!nodeKey) throw new Error("The owner node key is unavailable.");
    manifestKey = await deriveAesKey(
      nodeKey,
      bootstrap.generationId,
      `aeralyth/manifest/v1/${plan.nodeId}/${plan.recordVersion}`
    );
  }
  if (!manifestKey) throw new Error("The manifest key is unavailable.");
  const manifestAad = encodeRecordAad(
    "manifest",
    plan.nodeId,
    plan.recordVersion
  );
  let manifestPlaintext;
  try {
    manifestPlaintext = new Uint8Array(
      await crypto.subtle.decrypt(
        {
          name: "AES-GCM",
          iv: asBufferSource(zeroNonce()),
          additionalData: asBufferSource(manifestAad),
          tagLength: 128
        },
        manifestKey,
        asBufferSource(encryptedManifest)
      )
    );
  } catch (error) {
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "The encrypted manifest is invalid.",
      error
    );
  }
  const manifest = decodeManifest(manifestPlaintext);
  const validManifestLayout = manifest.entryType === "folder" ? manifest.plaintextBytes === 0 && manifest.paddedBytes === 0 && manifest.chunkCount === 0 && bootstrap.ciphertextLength === 0 : validFileManifestLayout(manifest, bootstrap.ciphertextLength);
  if (manifest.entryType !== plan.entryType || downloadPlan !== null && manifest.chunkCount !== downloadPlan.chunkCount || !validManifestLayout || !equalBytes(manifest.generationId, bootstrap.generationId)) {
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "The manifest does not match the node head."
    );
  }
  wipe(
    bootstrapBytes,
    signature,
    publicKey,
    signedHash,
    encryptedManifest,
    manifestAad,
    manifestPlaintext,
    ...wrapperBytes,
    ...wrapperHashes
  );
  assertActive();
  assertVaultSession(sessionGeneration);
  return { manifest, nodeKey, contentKey };
}
async function createShareMaterial(input, onWrapperChunk) {
  await validateShareIdentity(input.recipient);
  return buildShareMaterial(
    {
      shareId: input.shareId,
      rootNodeId: input.rootNodeId,
      senderId: input.senderId,
      epoch: 1,
      recordVersion: 1,
      previousRecordHash: null,
      recipients: [
        {
          userId: input.recipient.userId,
          keyVersion: input.recipient.keyVersion,
          x25519PublicKey: input.recipient.x25519PublicKey
        }
      ],
      nodes: input.nodes,
      plans: input.plans
    },
    onWrapperChunk
  );
}
async function rotateShareMaterial(input, onWrapperChunk) {
  return buildShareMaterial(
    {
      ...input,
      previousRecordHash: fromBase64Url(input.previousRecordHash)
    },
    onWrapperChunk
  );
}
async function buildShareMaterial(input, onWrapperChunk) {
  const root = requireRootKey();
  if (!/^shr_[A-Za-z0-9_-]{4,92}$/u.test(input.shareId) || input.epoch < 1) {
    throw new Error("The share ID or epoch is invalid.");
  }
  const epochMaterial = randomBytes(32);
  const epochKey = await importHkdf(epochMaterial);
  const wrapperId = randomBytes(16);
  try {
    const wrapperHashes = await createSubtreeShareWrappers(
      input.nodes,
      input.plans,
      input.rootNodeId,
      input.shareId,
      input.epoch,
      epochKey,
      onWrapperChunk
    );
    try {
      const wrapperRoot = await wrapperSetRoot(wrapperHashes);
      const envelopes = await mapWithConcurrency(
        input.recipients,
        SHARE_ENVELOPE_CRYPTO_CONCURRENCY,
        (recipient) => createHpkeEnvelope({
          shareId: input.shareId,
          rootNodeId: input.rootNodeId,
          senderId: input.senderId,
          epoch: input.epoch,
          recordVersion: input.recordVersion,
          previousRecordHash: input.previousRecordHash,
          recipient,
          wrapperSetRoot: wrapperRoot,
          wrapperCount: wrapperHashes.length,
          epochMaterial
        })
      );
      const ownerCiphertext = await encryptDerivedRecord(
        root,
        wrapperId,
        shareOwnerPurpose(input.shareId, input.epoch),
        toBase64Url(wrapperId),
        input.epoch,
        epochMaterial
      );
      return {
        wrappers: [],
        envelopes,
        ownerEpochKey: {
          wrapperId: wrapperId.slice(),
          ciphertext: ownerCiphertext
        }
      };
    } finally {
      wipe(...wrapperHashes);
    }
  } finally {
    wipe(epochMaterial, wrapperId);
  }
}
async function createSubtreeShareWrappers(nodes, plans, rootNodeId, shareId, epoch, epochKey, onWrapperChunk) {
  const context = { shareId, epoch, epochKey };
  if (nodes.length === 0 || plans.length !== nodes.length) {
    throw new Error("The share-preparation plan is incomplete.");
  }
  const snapshots = new Map(nodes.map((node) => [node.nodeId, node]));
  const preparations = new Map(
    plans.map((plan) => [plan.snapshot.nodeId, plan])
  );
  const children = /* @__PURE__ */ new Map();
  for (const preparation of plans) {
    const snapshot = snapshots.get(preparation.snapshot.nodeId);
    if (!snapshot || preparation.snapshot.parentId !== snapshot.parentId || preparation.snapshot.depth !== snapshot.depth || preparation.snapshot.entryType !== snapshot.entryType || preparation.snapshot.generationNumber !== snapshot.generationNumber || preparation.snapshot.generationId !== snapshot.generationId || preparation.metadata.nodeId !== snapshot.nodeId || preparation.metadata.recordVersion !== snapshot.recordVersion || preparation.metadata.recordHash !== snapshot.recordHash || preparation.metadata.generationId !== snapshot.generationId) {
      throw new Error("The share-preparation snapshot is inconsistent.");
    }
    if (snapshot.parentId) {
      const siblings = children.get(snapshot.parentId) ?? [];
      siblings.push(preparation);
      children.set(snapshot.parentId, siblings);
    }
  }
  const root = preparations.get(rootNodeId);
  if (!root || root.snapshot.parentId !== null || root.snapshot.depth !== 0) {
    throw new Error("The share-preparation root is invalid.");
  }
  for (const siblings of children.values()) {
    siblings.sort(
      (left, right) => left.snapshot.nodeId.localeCompare(right.snapshot.nodeId)
    );
  }
  const wrapperHashes = [];
  const visited = /* @__PURE__ */ new Set();
  let completedNodes = 0;
  const activeLeases = /* @__PURE__ */ new Set();
  const openAndWrap = async (preparation) => {
    const node = preparation.snapshot;
    const opened = await openAndVerifyPlan(preparation.metadata);
    const nodeKey = opened.nodeKey;
    if (!nodeKey) {
      throw vaultError(
        "NODE_KEY_REQUIRED",
        `The share-preparation node key is unavailable:${node.nodeId}`
      );
    }
    const generationId = node.generationId ? fromBase64Url(node.generationId) : new Uint8Array(16);
    if (generationId.length !== 16) {
      throw new Error("A share generation ID is invalid.");
    }
    const kinds = node.entryType === "file" ? [4, 3] : [4];
    const wrappers = await mapWithConcurrency(
      kinds,
      SHARE_WRAPPER_CRYPTO_CONCURRENCY,
      (kind) => createShareWrapperFromNode(
        node.nodeId,
        node.recordVersion,
        node.generationNumber,
        generationId,
        nodeKey,
        context,
        kind
      )
    );
    const hashes = await mapWithConcurrency(
      wrappers,
      SHARE_HASH_CRYPTO_CONCURRENCY,
      sha2565
    );
    wrapperHashes.push(...hashes);
    visited.add(node.nodeId);
    wipe(generationId);
    const hasChildren = (children.get(node.nodeId)?.length ?? 0) > 0;
    const lease = hasChildren ? pinNodeKey(node.nodeId) : null;
    if (hasChildren && !lease) {
      throw new Error("A share-preparation parent key could not be pinned.");
    }
    if (lease) activeLeases.add(lease);
    if (!hasChildren) nodeKeys.deleteIfUnpinned(node.nodeId, nodeKey);
    completedNodes += 1;
    onWrapperChunk({
      nodeId: node.nodeId,
      wrappers,
      completedNodes,
      totalNodes: nodes.length
    });
    return { preparation, lease };
  };
  const visitChildren = async (parent) => {
    try {
      const descendants = children.get(parent.preparation.snapshot.nodeId) ?? [];
      for (let offset = 0; offset < descendants.length; offset += MAX_SHARE_PREPARATION_CONCURRENCY) {
        const opened = await mapWithConcurrency(
          descendants.slice(offset, offset + MAX_SHARE_PREPARATION_CONCURRENCY),
          MAX_SHARE_PREPARATION_CONCURRENCY,
          openAndWrap
        );
        for (const child of opened) await visitChildren(child);
      }
    } finally {
      if (parent.lease) {
        activeLeases.delete(parent.lease);
        parent.lease.release();
      }
      nodeKeys.deleteIfUnpinned(parent.preparation.snapshot.nodeId);
    }
  };
  try {
    await visitChildren(await openAndWrap(root));
    if (visited.size !== nodes.length) {
      throw new Error("The share-preparation hierarchy is disconnected.");
    }
    return wrapperHashes;
  } finally {
    for (const lease of activeLeases) lease.release();
  }
}
async function createShareWrapperFromNode(nodeId, recordVersion, generationNumber, generationId, nodeKey, context, kind) {
  const keyMaterial = await deriveKeyMaterial(
    nodeKey,
    generationId,
    kind === 3 ? `aeralyth/content/v1/${nodeId}/${generationNumber}` : `aeralyth/manifest/v1/${nodeId}/${recordVersion}`
  );
  const wrapperId = randomBytes(16);
  try {
    const purpose = shareWrapperPurpose(
      context.shareId,
      context.epoch,
      nodeId,
      kind
    );
    const ciphertext = await encryptDerivedRecord(
      context.epochKey,
      wrapperId,
      purpose,
      toBase64Url(wrapperId),
      recordVersion,
      keyMaterial
    );
    return encodeWrapper({
      formatVersion: VAULT_FORMAT_VERSION,
      wrapperId,
      kind,
      nodeId,
      parentNodeId: null,
      generationId: kind === 3 ? generationId : null,
      shareId: context.shareId,
      epoch: context.epoch,
      recordVersion,
      ciphertext,
      aadSchemaId: VAULT_AAD_SCHEMA_ID
    });
  } finally {
    wipe(keyMaterial, wrapperId);
  }
}
async function createHpkeEnvelope(input) {
  const activeIdentity = requireIdentity();
  const envelopeId = randomBytes(16);
  const [recipientPublic, senderPrivate] = await Promise.all([
    hpkeSuite.kem.importKey(
      "raw",
      toArrayBuffer2(fromBase64Url(input.recipient.x25519PublicKey)),
      true
    ),
    hpkeSuite.kem.importKey(
      "raw",
      toArrayBuffer2(activeIdentity.x25519PrivateKey),
      false
    )
  ]);
  const info = hpkeInfo(
    input.shareId,
    input.epoch,
    input.rootNodeId,
    envelopeId
  );
  const aad = encodeRecordAad(
    `share-envelope-${input.shareId}-${input.epoch}`,
    toBase64Url(envelopeId),
    input.recordVersion
  );
  const sender = await hpkeSuite.createSenderContext({
    recipientPublicKey: recipientPublic,
    senderKey: senderPrivate,
    info: asBufferSource(info)
  });
  const ciphertext = new Uint8Array(
    await sender.seal(asBufferSource(input.epochMaterial), asBufferSource(aad))
  );
  const encapsulatedKey = new Uint8Array(sender.enc);
  if (encapsulatedKey.length !== 32 || ciphertext.length !== 48) {
    throw new Error("The HPKE suite returned invalid envelope material.");
  }
  const envelope = {
    formatVersion: VAULT_SHARE_ENVELOPE_VERSION,
    suiteId: VAULT_SUITE_ID,
    envelopeId,
    shareId: input.shareId,
    epoch: input.epoch,
    senderId: input.senderId,
    senderKeyVersion: activeIdentity.keyVersion,
    recipientId: input.recipient.userId,
    recipientKeyVersion: input.recipient.keyVersion,
    nodeId: input.rootNodeId,
    permissions: 1,
    generationScope: null,
    recordVersion: input.recordVersion,
    previousRecordHash: input.previousRecordHash,
    encapsulatedKey,
    ciphertext,
    aadSchemaId: VAULT_AAD_SCHEMA_ID,
    wrapperHashes: [],
    wrapperSetRoot: input.wrapperSetRoot,
    wrapperCount: input.wrapperCount
  };
  const canonical = encodeShareEnvelope(envelope);
  const signature = libsodium_wrappers_default.crypto_sign_detached(
    canonical,
    activeIdentity.ed25519PrivateKey
  );
  wipe(envelopeId, info, aad, encapsulatedKey, ciphertext);
  return {
    canonicalCbor: canonical,
    signature
  };
}
async function openSharedKeys(plan, material) {
  const { bootstrap, wrappers, wrapperBytes, wrapperHashes } = material;
  const share = plan.share;
  const activeIdentity = requireIdentity();
  if (!share) throw new Error("Shared key material is missing.");
  const envelopeBytes = fromBase64Url(share.envelopeCbor);
  const envelopeSignature = fromBase64Url(share.envelopeSignature);
  const senderEd25519 = fromBase64Url(share.senderEd25519PublicKey);
  if (!libsodium_wrappers_default.crypto_sign_verify_detached(
    envelopeSignature,
    envelopeBytes,
    senderEd25519
  )) {
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "The share envelope signature is invalid."
    );
  }
  const envelope = decodeShareEnvelope(envelopeBytes);
  const senderX25519 = fromBase64Url(share.senderX25519PublicKey);
  const [envelopeHash, senderFingerprint] = await Promise.all([
    sha256Parts(envelopeBytes, envelopeSignature),
    sha256Parts(senderX25519, senderEd25519)
  ]);
  const authorizationVersion = await shareAuthorizationVersion({
    shareId: share.shareId,
    epoch: share.epoch,
    recipientId: share.recipientId,
    recipientKeyVersion: share.recipientKeyVersion,
    shareRecordVersion: share.recordVersion,
    envelopeHash
  });
  const expectedPreviousRecordHash = share.previousRecordHash ? fromBase64Url(share.previousRecordHash) : null;
  if (!equalBytes(envelopeHash, fromBase64Url(share.envelopeHash)) || !equalBytes(
    authorizationVersion,
    fromBase64Url(share.authorizationVersion)
  ) || envelope.formatVersion !== VAULT_FORMAT_VERSION && envelope.formatVersion !== VAULT_SHARE_ENVELOPE_VERSION || envelope.shareId !== share.shareId || envelope.epoch !== share.epoch || envelope.senderId !== share.senderId || envelope.recipientId !== share.recipientId || envelope.nodeId !== share.rootNodeId || envelope.senderKeyVersion !== share.senderKeyVersion || envelope.recipientKeyVersion !== activeIdentity.keyVersion || envelope.recipientKeyVersion !== share.recipientKeyVersion || envelope.recordVersion !== share.recordVersion || envelope.generationScope !== null || !nullableEqualBytes(
    envelope.previousRecordHash,
    expectedPreviousRecordHash
  ) || !equalBytes(
    senderFingerprint,
    fromBase64Url(share.senderFingerprintSha256)
  ) || envelope.aadSchemaId !== VAULT_AAD_SCHEMA_ID || envelope.suiteId !== VAULT_SUITE_ID) {
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "The share envelope scope is invalid."
    );
  }
  const wrapperProofs = share.wrapperProofs ?? [];
  if (envelope.formatVersion === VAULT_SHARE_ENVELOPE_VERSION && (envelope.wrapperSetRoot === null || envelope.wrapperCount < 1 || wrapperProofs.length !== wrapperBytes.length)) {
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "The share wrapper commitment is invalid."
    );
  }
  const directoryMaterial = share.directory;
  const directoryCbor = directoryMaterial ? fromBase64Url(directoryMaterial.canonicalCbor) : null;
  const directory = directoryCbor ? decodeShareDirectory(directoryCbor) : null;
  if (directory && directoryMaterial) {
    const directorySignature = fromBase64Url(directoryMaterial.signature);
    if (!libsodium_wrappers_default.crypto_sign_verify_detached(
      directorySignature,
      directoryCbor,
      fromBase64Url(plan.signerEd25519PublicKey)
    ) || directory.formatVersion !== VAULT_SHARE_DIRECTORY_VERSION || directory.suiteId !== VAULT_SUITE_ID || directory.aadSchemaId !== VAULT_AAD_SCHEMA_ID || directory.nodeId !== plan.nodeId || directory.recordVersion !== plan.recordVersion || directory.generationNumber !== plan.generationNumber || directory.signerKeyVersion !== plan.signerKeyVersion || directory.wrapperCount < wrapperBytes.length || directoryMaterial.wrapperProofs.length !== wrapperBytes.length || !equalBytes(directory.recordHash, fromBase64Url(plan.recordHash)) || !equalBytes(directory.generationId, fromBase64Url(plan.generationId))) {
      throw vaultError(
        "AUTHENTICATION_FAILED",
        "The share-wrapper directory is invalid."
      );
    }
  }
  const commitments = await mapWithConcurrency(
    wrapperHashes,
    SHARE_HASH_CRYPTO_CONCURRENCY,
    async (hashBytes, index) => {
      let committed = containsFixedHash(bootstrap.wrapperHashes, hashBytes);
      if (!committed && envelope.formatVersion === VAULT_FORMAT_VERSION) {
        committed = containsFixedHash(envelope.wrapperHashes, hashBytes);
      }
      if (!committed && envelope.formatVersion === VAULT_SHARE_ENVELOPE_VERSION) {
        const proof = wrapperProofs[index];
        if (proof !== null) {
          const proofBytes = fromBase64Url(proof.proof);
          try {
            committed = await verifyWrapperSetProof({
              wrapperHash: hashBytes,
              leafIndex: proof.leafIndex,
              proof: proofBytes,
              wrapperCount: envelope.wrapperCount,
              expectedRoot: envelope.wrapperSetRoot
            });
          } finally {
            wipe(proofBytes);
          }
        }
      }
      if (!committed && directory && directoryMaterial) {
        const proof = directoryMaterial.wrapperProofs[index];
        const proofBytes = fromBase64Url(proof.proof);
        try {
          committed = await verifyWrapperSetProof({
            wrapperHash: hashBytes,
            leafIndex: proof.leafIndex,
            proof: proofBytes,
            wrapperCount: directory.wrapperCount,
            expectedRoot: directory.wrapperSetRoot
          });
        } finally {
          wipe(proofBytes);
        }
      }
      return { committed, hashBytes };
    }
  );
  const seenWrapperHashes = [];
  for (const { committed, hashBytes } of commitments) {
    if (committed && !containsFixedHash(seenWrapperHashes, hashBytes)) {
      seenWrapperHashes.push(hashBytes);
    } else {
      throw vaultError(
        "AUTHENTICATION_FAILED",
        "A share wrapper is not committed."
      );
    }
  }
  if (wrappers.length !== (plan.entryType === "file" ? 2 : 1)) {
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "The share wrapper count is invalid."
    );
  }
  for (const wrapper of wrappers) {
    if (wrapper.kind !== 3 && wrapper.kind !== 4 || wrapper.formatVersion !== VAULT_FORMAT_VERSION || wrapper.aadSchemaId !== VAULT_AAD_SCHEMA_ID || wrapper.nodeId !== plan.nodeId || wrapper.shareId !== share.shareId || wrapper.epoch !== share.epoch || wrapper.recordVersion !== plan.recordVersion) {
      throw vaultError(
        "AUTHENTICATION_FAILED",
        "A share wrapper has an invalid scope."
      );
    }
  }
  const [recipientPrivate, senderPublic] = await Promise.all([
    hpkeSuite.kem.importKey(
      "raw",
      toArrayBuffer2(activeIdentity.x25519PrivateKey),
      false
    ),
    hpkeSuite.kem.importKey("raw", toArrayBuffer2(senderX25519), true)
  ]);
  const info = hpkeInfo(
    envelope.shareId,
    envelope.epoch,
    envelope.nodeId,
    envelope.envelopeId
  );
  const aad = encodeRecordAad(
    `share-envelope-${envelope.shareId}-${envelope.epoch}`,
    toBase64Url(envelope.envelopeId),
    envelope.recordVersion
  );
  const recipient = await hpkeSuite.createRecipientContext({
    recipientKey: recipientPrivate,
    senderPublicKey: senderPublic,
    enc: asBufferSource(envelope.encapsulatedKey),
    info: asBufferSource(info)
  });
  const epochMaterial = new Uint8Array(
    await recipient.open(
      asBufferSource(envelope.ciphertext),
      asBufferSource(aad)
    )
  );
  if (epochMaterial.length !== 32)
    throw new Error("The share epoch key is invalid.");
  const epochKey = await importHkdf(epochMaterial);
  const metadataWrapper = wrappers.find(
    (wrapper) => wrapper.kind === 4 && wrapper.nodeId === plan.nodeId && wrapper.shareId === share.shareId && wrapper.epoch === share.epoch
  );
  const generationWrapper = wrappers.find(
    (wrapper) => wrapper.kind === 3 && wrapper.nodeId === plan.nodeId && wrapper.shareId === share.shareId && wrapper.epoch === share.epoch && wrapper.generationId !== null && equalBytes(wrapper.generationId, fromBase64Url(plan.generationId))
  );
  if (!metadataWrapper || plan.entryType === "file" && !generationWrapper) {
    throw vaultError(
      "AUTHENTICATION_FAILED",
      "The share wrappers are incomplete."
    );
  }
  const metadataRaw = await decryptShareWrapper(epochKey, metadataWrapper);
  const generationRaw = generationWrapper ? await decryptShareWrapper(epochKey, generationWrapper) : null;
  try {
    return {
      manifestKey: await importAesKey(metadataRaw),
      contentKey: generationRaw ? await importAesKey(generationRaw) : null
    };
  } finally {
    wipe(
      envelopeBytes,
      envelopeSignature,
      senderEd25519,
      senderX25519,
      senderFingerprint,
      expectedPreviousRecordHash,
      envelopeHash,
      authorizationVersion,
      directoryCbor,
      info,
      aad,
      epochMaterial,
      metadataRaw,
      generationRaw
    );
  }
}
function nullableEqualBytes(left, right) {
  if (left === null || right === null) return left === right;
  return equalBytes(left, right);
}
function containsFixedHash(hashes, expected) {
  return hashes.some((hash) => equalBytes(hash, expected));
}
function validFileManifestLayout(manifest, ciphertextLength) {
  if (manifest.plaintextBytes < 0 || manifest.plaintextBytes > manifest.paddedBytes) {
    return false;
  }
  try {
    const layout = encryptedLength(manifest.paddedBytes);
    return layout.chunkCount === manifest.chunkCount && layout.ciphertextBytes === ciphertextLength;
  } catch {
    return false;
  }
}
async function decryptShareWrapper(epochKey, wrapper) {
  if (wrapper.kind !== 3 && wrapper.kind !== 4) {
    throw new Error("The share wrapper kind is invalid.");
  }
  return decryptDerivedRecord(
    epochKey,
    wrapper.wrapperId,
    shareWrapperPurpose(
      wrapper.shareId ?? "",
      wrapper.epoch ?? 0,
      wrapper.nodeId,
      wrapper.kind
    ),
    toBase64Url(wrapper.wrapperId),
    wrapper.recordVersion,
    wrapper.ciphertext
  );
}
async function validateShareIdentity(recipient) {
  const x255192 = fromBase64Url(recipient.x25519PublicKey);
  const ed25519 = fromBase64Url(recipient.ed25519PublicKey);
  if (x255192.length !== 32 || ed25519.length !== 32) {
    throw new Error("The recipient identity keys are invalid.");
  }
  const fingerprint = await sha256Parts(x255192, ed25519);
  if (!equalBytes(fingerprint, fromBase64Url(recipient.fingerprintSha256))) {
    throw new Error("The recipient identity fingerprint is invalid.");
  }
  wipe(x255192, ed25519, fingerprint);
}
function hpkeInfo(shareId, epoch, rootNodeId, envelopeId) {
  return utf8(
    `aeralyth/hpke-auth/v1/${shareId}/${epoch}/${rootNodeId}/${toBase64Url(envelopeId)}`
  );
}
function shareOwnerPurpose(shareId, epoch) {
  return `share-epoch-owner-${shareId}-${epoch}`;
}
function shareWrapperPurpose(shareId, epoch, nodeId, kind) {
  return `share-wrapper-${kind}-${shareId}-${epoch}-${nodeId}`;
}
function derivePasswordMaterial(password, salt) {
  return libsodium_wrappers_default.crypto_pwhash(
    ARGON2ID_PROFILE.outputBytes,
    password,
    salt,
    ARGON2ID_PROFILE.operations,
    ARGON2ID_PROFILE.memoryBytes,
    libsodium_wrappers_default.crypto_pwhash_ALG_ARGON2ID13
  );
}
async function importHkdf(material) {
  return crypto.subtle.importKey(
    "raw",
    asBufferSource(material),
    "HKDF",
    false,
    ["deriveBits"]
  );
}
async function deriveAesKey(base2, salt, info) {
  const material = await deriveKeyMaterial(base2, salt, info);
  try {
    return await importAesKey(material);
  } finally {
    wipe(material);
  }
}
async function deriveKeyMaterial(base2, salt, info) {
  return new Uint8Array(
    await crypto.subtle.deriveBits(
      {
        name: "HKDF",
        hash: "SHA-256",
        salt: asBufferSource(salt),
        info: asBufferSource(utf8(info))
      },
      base2,
      256
    )
  );
}
async function importAesKey(material) {
  return crypto.subtle.importKey(
    "raw",
    asBufferSource(material),
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}
async function wrapRootMaterial(rootMaterial, wrappingBase, purpose, derivationSalt, wrapperId, version) {
  return encryptDerivedRecord(
    wrappingBase,
    derivationSalt,
    purpose,
    toBase64Url(wrapperId),
    version,
    rootMaterial
  );
}
async function unwrapRootMaterial(ciphertext, wrappingBase, purpose, derivationSalt, wrapperId, version) {
  return decryptDerivedRecord(
    wrappingBase,
    derivationSalt,
    purpose,
    toBase64Url(wrapperId),
    version,
    ciphertext
  );
}
async function encryptRootRecord(root, purpose, recordId, version, plaintext) {
  return encryptDerivedRecord(
    root,
    recordId,
    purpose,
    toBase64Url(recordId),
    version,
    plaintext
  );
}
async function decryptRootRecord(root, purpose, recordId, version, ciphertext) {
  return decryptDerivedRecord(
    root,
    recordId,
    purpose,
    toBase64Url(recordId),
    version,
    ciphertext
  );
}
async function encryptDerivedRecord(base2, salt, purpose, recordId, version, plaintext) {
  const key = await deriveAesKey(
    base2,
    salt,
    `aeralyth/${purpose}/v1/${recordId}/${version}`
  );
  const aad = encodeRecordAad(purpose, recordId, version);
  try {
    return new Uint8Array(
      await crypto.subtle.encrypt(
        {
          name: "AES-GCM",
          iv: asBufferSource(zeroNonce()),
          additionalData: asBufferSource(aad),
          tagLength: 128
        },
        key,
        asBufferSource(plaintext)
      )
    );
  } finally {
    wipe(aad);
  }
}
async function decryptDerivedRecord(base2, salt, purpose, recordId, version, ciphertext) {
  const key = await deriveAesKey(
    base2,
    salt,
    `aeralyth/${purpose}/v1/${recordId}/${version}`
  );
  const aad = encodeRecordAad(purpose, recordId, version);
  try {
    return new Uint8Array(
      await crypto.subtle.decrypt(
        {
          name: "AES-GCM",
          iv: asBufferSource(zeroNonce()),
          additionalData: asBufferSource(aad),
          tagLength: 128
        },
        key,
        asBufferSource(ciphertext)
      )
    );
  } finally {
    wipe(aad);
  }
}
function nodeWrapperPurpose(kind, nodeId) {
  return `node-wrapper-${kind}-${nodeId}`;
}
function assertUnlockMaterial(material) {
  if (material.formatVersion !== VAULT_FORMAT_VERSION || material.vaultVersion < 1) {
    throw new Error("The server returned an unsupported vault format.");
  }
  assertArgon2idProfile(material.kdf);
  if (fromBase64Url(material.kdf.salt).length !== 16 || fromBase64Url(material.passwordWrapper.id).length !== 16 || fromBase64Url(material.passwordWrapper.ciphertext).length !== 48 || fromBase64Url(material.recoveryWrapper.salt).length !== 16 || fromBase64Url(material.recoveryWrapper.id).length !== 16 || fromBase64Url(material.recoveryWrapper.ciphertext).length !== 48) {
    throw new Error("The server returned invalid vault wrapping material.");
  }
  if (material.accountState && (fromBase64Url(material.accountState.recordId).length !== 16 || material.accountState.version !== material.vaultVersion || !Number.isSafeInteger(material.accountState.ciphertextBytes) || material.accountState.ciphertextBytes < 16 || material.accountState.ciphertextBytes > 4 * 1024 * 1024)) {
    throw new Error("The server returned an invalid account-state manifest.");
  }
}
function requireRootKey() {
  if (!rootKey) throw vaultError("VAULT_LOCKED", "Unlock the vault first.");
  return rootKey;
}
function assertVaultSession(generation) {
  if (generation !== vaultSessionGeneration || !rootKey) {
    throw vaultError(
      "VAULT_LOCKED",
      "The vault was locked during this operation."
    );
  }
}
function requireIdentity() {
  if (!identity) throw vaultError("VAULT_LOCKED", "Unlock the vault first.");
  return identity;
}
function requireEncryptionSession(sessionId) {
  const session = encryptionSessions.get(sessionId);
  if (!session)
    throw new Error("The encryption session is no longer available.");
  assertEncryptionSessionActive(sessionId, session);
  return session;
}
function assertEncryptionSessionActive(sessionId, session) {
  if (session.sessionGeneration !== vaultSessionGeneration) {
    throw vaultError("VAULT_LOCKED", "The vault locked during encryption.");
  }
  if (encryptionSessions.get(sessionId) !== session) {
    throw vaultError(
      "CRYPTO_SESSION_ABORTED",
      "The encryption session was aborted."
    );
  }
}
function assertDecryptionSessionActive(sessionId, session) {
  if (session.sessionGeneration !== vaultSessionGeneration) {
    throw vaultError("VAULT_LOCKED", "The vault locked during decryption.");
  }
  if (decryptionSessions.get(sessionId) !== session) {
    throw vaultError(
      "CRYPTO_SESSION_ABORTED",
      "The decryption session was aborted."
    );
  }
}
function isCryptoLifecycleError(error) {
  const code = error?.code;
  return code === "VAULT_LOCKED" || code === "CRYPTO_SESSION_ABORTED";
}
function validatePassword(password) {
  const passwordBytes = utf8(password);
  try {
    if (passwordBytes.length < 8 || passwordBytes.length > 1024) {
      throw new Error("Use a password between 8 and 1024 bytes.");
    }
  } finally {
    wipe(passwordBytes);
  }
}
function validateNodeId(nodeId) {
  if (!isVaultNodeId(nodeId)) {
    throw new Error("The vault node ID is invalid.");
  }
}
function normalizeName(name) {
  const normalized = name.normalize("NFC").trim();
  if (!normalized || normalized.length > 1024 || normalized.includes("\0")) {
    throw new Error("The file or folder name is invalid.");
  }
  return normalized;
}
function vaultError(code, message, cause) {
  const error = new Error(
    message,
    cause === void 0 ? void 0 : { cause }
  );
  error.code = code;
  return error;
}
function normalizeError(error) {
  if (error instanceof Error) {
    const coded = error;
    return {
      message: error.message || "Vault operation failed.",
      ...typeof coded.code === "string" ? { code: coded.code } : {}
    };
  }
  return { message: "Vault operation failed." };
}
/*! Bundled license information:

@hpke/common/esm/src/curve/modular.js:
@hpke/common/esm/src/curve/montgomery.js:
@hpke/dhkem-x25519/esm/src/primitives/x25519.js:
  (*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) *)

@noble/hashes/esm/utils.js:
  (*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) *)
*/
