var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e2) {
    throw err = [e2], e2;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// node_modules/@zip.js/zip.js/lib/core/constants.js
var MAX_32_BITS, MAX_16_BITS, MAX_8_BITS, COMPRESSION_METHOD_DEFLATE, COMPRESSION_METHOD_DEFLATE_64, COMPRESSION_METHOD_STORE, COMPRESSION_METHOD_AES, LOCAL_FILE_HEADER_SIGNATURE, SPLIT_ZIP_FILE_SIGNATURE, TEMPORARY_SPLIT_ZIP_FILE_SIGNATURE, DATA_DESCRIPTOR_RECORD_SIGNATURE, ARCHIVE_EXTRA_DATA_SIGNATURE, DIGITAL_SIGNATURE_RECORD_SIGNATURE, CENTRAL_FILE_HEADER_SIGNATURE, END_OF_CENTRAL_DIR_SIGNATURE, ZIP64_END_OF_CENTRAL_DIR_SIGNATURE, ZIP64_END_OF_CENTRAL_DIR_LOCATOR_SIGNATURE, CENTRAL_FILE_HEADER_LENGTH, END_OF_CENTRAL_DIR_LENGTH, ZIP64_END_OF_CENTRAL_DIR_LOCATOR_LENGTH, ZIP64_END_OF_CENTRAL_DIR_LENGTH, ZIP64_END_OF_CENTRAL_DIR_TOTAL_LENGTH, DATA_DESCRIPTOR_RECORD_LENGTH, DATA_DESCRIPTOR_RECORD_ZIP_64_LENGTH, DATA_DESCRIPTOR_RECORD_SIGNATURE_LENGTH, SPLIT_ZIP_FILE_SIGNATURE_LENGTH, EXTRAFIELD_TYPE_ZIP64, EXTRAFIELD_TYPE_AES, EXTRAFIELD_TYPE_NTFS, EXTRAFIELD_TYPE_NTFS_TAG1, EXTRAFIELD_TYPE_EXTENDED_TIMESTAMP, EXTRAFIELD_TYPE_UNICODE_PATH, EXTRAFIELD_TYPE_UNICODE_COMMENT, EXTRAFIELD_TYPE_USDZ, EXTRAFIELD_TYPE_INFOZIP, EXTRAFIELD_TYPE_UNIX, EXTRAFIELD_TYPE_UNIX_TYPE1, EXTRAFIELD_TYPE_PKWARE_UNIX, BITFLAG_ENCRYPTED, BITFLAG_LEVEL, BITFLAG_LEVEL_MAX_MASK, BITFLAG_LEVEL_FAST_MASK, BITFLAG_LEVEL_SUPER_FAST_MASK, BITFLAG_DATA_DESCRIPTOR, BITFLAG_COMPRESSED_PATCHED_DATA, BITFLAG_STRONG_ENCRYPTION, BITFLAG_LANG_ENCODING_FLAG, BITFLAG_MASKED_LOCAL_HEADERS, FILE_ATTR_MSDOS_DIR_MASK, FILE_ATTR_MSDOS_READONLY_MASK, FILE_ATTR_MSDOS_HIDDEN_MASK, FILE_ATTR_MSDOS_SYSTEM_MASK, FILE_ATTR_MSDOS_ARCHIVE_MASK, FILE_ATTR_UNIX_TYPE_MASK, FILE_ATTR_UNIX_TYPE_DIR, FILE_ATTR_UNIX_TYPE_SYMLINK, FILE_ATTR_UNIX_TYPE_FILE, FILE_ATTR_UNIX_EXECUTABLE_MASK, FILE_ATTR_UNIX_DEFAULT_MASK, FILE_ATTR_UNIX_SETUID_MASK, FILE_ATTR_UNIX_SETGID_MASK, FILE_ATTR_UNIX_STICKY_MASK, VERSION_STORE, VERSION_DEFLATE, VERSION_ZIP64, VERSION_AES, VERSION_MADE_BY_MSDOS, VERSION_MADE_BY_UNIX, DIRECTORY_SIGNATURE, HEADER_SIZE, HEADER_OFFSET_VERSION, HEADER_OFFSET_SIGNATURE, HEADER_OFFSET_COMPRESSED_SIZE, HEADER_OFFSET_UNCOMPRESSED_SIZE, HEADER_OFFSET_FILENAME_LENGTH, HEADER_OFFSET_EXTRAFIELD_LENGTH, LOCAL_HEADER_COMMON_OFFSET, MAX_DATE, MIN_DATE, UNDEFINED_VALUE, INFINITY_VALUE, UNDEFINED_TYPE, FUNCTION_TYPE, OBJECT_TYPE, STRING_TYPE, NUMBER_TYPE, BOOLEAN_TYPE, EMPTY_UINT8_ARRAY, SYMBOL_ASYNC_DISPOSE;
var init_constants = __esm({
  "node_modules/@zip.js/zip.js/lib/core/constants.js"() {
    MAX_32_BITS = 4294967295;
    MAX_16_BITS = 65535;
    MAX_8_BITS = 255;
    COMPRESSION_METHOD_DEFLATE = 8;
    COMPRESSION_METHOD_DEFLATE_64 = 9;
    COMPRESSION_METHOD_STORE = 0;
    COMPRESSION_METHOD_AES = 99;
    LOCAL_FILE_HEADER_SIGNATURE = 67324752;
    SPLIT_ZIP_FILE_SIGNATURE = 134695760;
    TEMPORARY_SPLIT_ZIP_FILE_SIGNATURE = 808471376;
    DATA_DESCRIPTOR_RECORD_SIGNATURE = SPLIT_ZIP_FILE_SIGNATURE;
    ARCHIVE_EXTRA_DATA_SIGNATURE = 134630224;
    DIGITAL_SIGNATURE_RECORD_SIGNATURE = 84233040;
    CENTRAL_FILE_HEADER_SIGNATURE = 33639248;
    END_OF_CENTRAL_DIR_SIGNATURE = 101010256;
    ZIP64_END_OF_CENTRAL_DIR_SIGNATURE = 101075792;
    ZIP64_END_OF_CENTRAL_DIR_LOCATOR_SIGNATURE = 117853008;
    CENTRAL_FILE_HEADER_LENGTH = 46;
    END_OF_CENTRAL_DIR_LENGTH = 22;
    ZIP64_END_OF_CENTRAL_DIR_LOCATOR_LENGTH = 20;
    ZIP64_END_OF_CENTRAL_DIR_LENGTH = 56;
    ZIP64_END_OF_CENTRAL_DIR_TOTAL_LENGTH = END_OF_CENTRAL_DIR_LENGTH + ZIP64_END_OF_CENTRAL_DIR_LOCATOR_LENGTH + ZIP64_END_OF_CENTRAL_DIR_LENGTH;
    DATA_DESCRIPTOR_RECORD_LENGTH = 12;
    DATA_DESCRIPTOR_RECORD_ZIP_64_LENGTH = 20;
    DATA_DESCRIPTOR_RECORD_SIGNATURE_LENGTH = 4;
    SPLIT_ZIP_FILE_SIGNATURE_LENGTH = 4;
    EXTRAFIELD_TYPE_ZIP64 = 1;
    EXTRAFIELD_TYPE_AES = 39169;
    EXTRAFIELD_TYPE_NTFS = 10;
    EXTRAFIELD_TYPE_NTFS_TAG1 = 1;
    EXTRAFIELD_TYPE_EXTENDED_TIMESTAMP = 21589;
    EXTRAFIELD_TYPE_UNICODE_PATH = 28789;
    EXTRAFIELD_TYPE_UNICODE_COMMENT = 25461;
    EXTRAFIELD_TYPE_USDZ = 6534;
    EXTRAFIELD_TYPE_INFOZIP = 30837;
    EXTRAFIELD_TYPE_UNIX = 30805;
    EXTRAFIELD_TYPE_UNIX_TYPE1 = 22613;
    EXTRAFIELD_TYPE_PKWARE_UNIX = 13;
    BITFLAG_ENCRYPTED = 1;
    BITFLAG_LEVEL = 6;
    BITFLAG_LEVEL_MAX_MASK = 2;
    BITFLAG_LEVEL_FAST_MASK = 4;
    BITFLAG_LEVEL_SUPER_FAST_MASK = 6;
    BITFLAG_DATA_DESCRIPTOR = 8;
    BITFLAG_COMPRESSED_PATCHED_DATA = 32;
    BITFLAG_STRONG_ENCRYPTION = 64;
    BITFLAG_LANG_ENCODING_FLAG = 2048;
    BITFLAG_MASKED_LOCAL_HEADERS = 8192;
    FILE_ATTR_MSDOS_DIR_MASK = 16;
    FILE_ATTR_MSDOS_READONLY_MASK = 1;
    FILE_ATTR_MSDOS_HIDDEN_MASK = 2;
    FILE_ATTR_MSDOS_SYSTEM_MASK = 4;
    FILE_ATTR_MSDOS_ARCHIVE_MASK = 32;
    FILE_ATTR_UNIX_TYPE_MASK = 61440;
    FILE_ATTR_UNIX_TYPE_DIR = 16384;
    FILE_ATTR_UNIX_TYPE_SYMLINK = 40960;
    FILE_ATTR_UNIX_TYPE_FILE = 32768;
    FILE_ATTR_UNIX_EXECUTABLE_MASK = 73;
    FILE_ATTR_UNIX_DEFAULT_MASK = 420;
    FILE_ATTR_UNIX_SETUID_MASK = 2048;
    FILE_ATTR_UNIX_SETGID_MASK = 1024;
    FILE_ATTR_UNIX_STICKY_MASK = 512;
    VERSION_STORE = 10;
    VERSION_DEFLATE = 20;
    VERSION_ZIP64 = 45;
    VERSION_AES = 51;
    VERSION_MADE_BY_MSDOS = 20;
    VERSION_MADE_BY_UNIX = 768;
    DIRECTORY_SIGNATURE = "/";
    HEADER_SIZE = 30;
    HEADER_OFFSET_VERSION = 0;
    HEADER_OFFSET_SIGNATURE = 10;
    HEADER_OFFSET_COMPRESSED_SIZE = 14;
    HEADER_OFFSET_UNCOMPRESSED_SIZE = 18;
    HEADER_OFFSET_FILENAME_LENGTH = 22;
    HEADER_OFFSET_EXTRAFIELD_LENGTH = 24;
    LOCAL_HEADER_COMMON_OFFSET = 4;
    MAX_DATE = new Date(2107, 11, 31, 23, 59, 58);
    MIN_DATE = new Date(1980, 0, 1);
    UNDEFINED_VALUE = void 0;
    INFINITY_VALUE = Infinity;
    UNDEFINED_TYPE = "undefined";
    FUNCTION_TYPE = "function";
    OBJECT_TYPE = "object";
    STRING_TYPE = "string";
    NUMBER_TYPE = "number";
    BOOLEAN_TYPE = "boolean";
    EMPTY_UINT8_ARRAY = new Uint8Array();
    SYMBOL_ASYNC_DISPOSE = Symbol.asyncDispose || /* @__PURE__ */ Symbol();
  }
});

// node_modules/@zip.js/zip.js/lib/core/options.js
function checkFunctionOption(value) {
  if (value && typeof value != FUNCTION_TYPE) {
    throw new Error(ERR_INVALID_FUNCTION_OPTION);
  }
  return value;
}
function checkSignalOption(signal) {
  if (signal && (typeof signal.addEventListener != FUNCTION_TYPE || typeof signal.aborted != BOOLEAN_TYPE)) {
    throw new Error(ERR_INVALID_SIGNAL);
  }
  return signal || UNDEFINED_VALUE;
}
function throwIfAborted(signal) {
  if (signal && signal.aborted) {
    throw signal.reason === UNDEFINED_VALUE ? new DOMException(ERR_ABORTED, ABORT_ERROR_NAME) : signal.reason;
  }
}
function checkPasswordOption(password, rawPassword) {
  if (password && typeof password != STRING_TYPE || rawPassword && !(rawPassword instanceof Uint8Array)) {
    throw new Error(ERR_INVALID_PASSWORD_TYPE);
  }
}
function checkPassThroughOption(passThrough) {
  if (passThrough !== UNDEFINED_VALUE && typeof passThrough != BOOLEAN_TYPE && passThrough !== PASS_THROUGH_COMPRESSED) {
    throw new Error(ERR_INVALID_PASS_THROUGH_VALUE);
  }
  return passThrough;
}
function checkInteger(value, maxValue, errorMessage) {
  if (!Number.isInteger(value) || value < 0 || value > maxValue) {
    throw new Error(errorMessage);
  }
}
function checkIntegerOption(value, maxValue, errorMessage) {
  if (value !== UNDEFINED_VALUE) {
    checkInteger(value, maxValue, errorMessage);
  }
}
function toNumber(value) {
  return typeof value == STRING_TYPE && value.trim() ? Number(value) : value;
}
var OPTION_FILENAME_ENCODING, OPTION_COMMENT_ENCODING, OPTION_DECODE_TEXT, OPTION_EXTRACT_PREPENDED_DATA, OPTION_EXTRACT_APPENDED_DATA, OPTION_PASSWORD, OPTION_RAW_PASSWORD, OPTION_PASS_THROUGH, OPTION_SIGNAL, OPTION_CHECK_PASSWORD_ONLY, OPTION_CHECK_OVERLAPPING_ENTRY_ONLY, OPTION_CHECK_OVERLAPPING_ENTRY, OPTION_CHECK_AMBIGUITY, OPTION_CHECK_LOCAL_DIRECTORY, OPTION_CHECK_LOCAL_FILENAME, OPTION_CHECK_SIGNATURE, OPTION_CHECK_CRC32, OPTION_CHECK_AUTHENTICATION_CODE, OPTION_USE_WEB_WORKERS, OPTION_USE_COMPRESSION_STREAM, OPTION_TRANSFER_STREAMS, OPTION_PREVENT_CLOSE, OPTION_ENCRYPTION_STRENGTH, OPTION_EXTENDED_TIMESTAMP, OPTION_NTFS_TIMESTAMP, OPTION_KEEP_ORDER, OPTION_LEVEL, OPTION_BUFFERED_WRITE, OPTION_CREATE_TEMP_STREAM, OPTION_DATA_DESCRIPTOR_SIGNATURE, OPTION_USE_UNICODE_FILE_NAMES, OPTION_DATA_DESCRIPTOR, OPTION_SUPPORT_ZIP64_SPLIT_FILE, OPTION_ENCODE_TEXT, OPTION_OFFSET, OPTION_USDZ, OPTION_UNIX_EXTRA_FIELD_TYPE, OPTION_LOCAL_EXTRA_FIELD, OPTION_CENTRAL_EXTRA_FIELD, OPTION_STRICTNESS, OPTION_FILENAME_VALIDATION, OPTION_NORMALIZE_FILENAME, OPTION_MAX_APPENDED_DATA_SIZE, OPTION_DECRYPT_CENTRAL_DIRECTORY, OPTION_SIGN_CENTRAL_DIRECTORY, OPTION_ENTRY, TEXT_TYPE_FILENAME, TEXT_TYPE_COMMENT, STRICTNESS_STRICT, STRICTNESS_BALANCED, STRICTNESS_TOLERANT, PASS_THROUGH_COMPRESSED, ERR_INVALID_FUNCTION_OPTION, ERR_INVALID_SIGNAL, ERR_INVALID_PASSWORD_TYPE, ERR_INVALID_PASS_THROUGH_VALUE, ERR_ABORTED, ABORT_ERROR_NAME;
var init_options = __esm({
  "node_modules/@zip.js/zip.js/lib/core/options.js"() {
    init_constants();
    OPTION_FILENAME_ENCODING = "filenameEncoding";
    OPTION_COMMENT_ENCODING = "commentEncoding";
    OPTION_DECODE_TEXT = "decodeText";
    OPTION_EXTRACT_PREPENDED_DATA = "extractPrependedData";
    OPTION_EXTRACT_APPENDED_DATA = "extractAppendedData";
    OPTION_PASSWORD = "password";
    OPTION_RAW_PASSWORD = "rawPassword";
    OPTION_PASS_THROUGH = "passThrough";
    OPTION_SIGNAL = "signal";
    OPTION_CHECK_PASSWORD_ONLY = "checkPasswordOnly";
    OPTION_CHECK_OVERLAPPING_ENTRY_ONLY = "checkOverlappingEntryOnly";
    OPTION_CHECK_OVERLAPPING_ENTRY = "checkOverlappingEntry";
    OPTION_CHECK_AMBIGUITY = "checkAmbiguity";
    OPTION_CHECK_LOCAL_DIRECTORY = "checkLocalDirectory";
    OPTION_CHECK_LOCAL_FILENAME = "checkLocalFilename";
    OPTION_CHECK_SIGNATURE = "checkSignature";
    OPTION_CHECK_CRC32 = "checkCrc32";
    OPTION_CHECK_AUTHENTICATION_CODE = "checkAuthenticationCode";
    OPTION_USE_WEB_WORKERS = "useWebWorkers";
    OPTION_USE_COMPRESSION_STREAM = "useCompressionStream";
    OPTION_TRANSFER_STREAMS = "transferStreams";
    OPTION_PREVENT_CLOSE = "preventClose";
    OPTION_ENCRYPTION_STRENGTH = "encryptionStrength";
    OPTION_EXTENDED_TIMESTAMP = "extendedTimestamp";
    OPTION_NTFS_TIMESTAMP = "ntfsTimestamp";
    OPTION_KEEP_ORDER = "keepOrder";
    OPTION_LEVEL = "level";
    OPTION_BUFFERED_WRITE = "bufferedWrite";
    OPTION_CREATE_TEMP_STREAM = "createTempStream";
    OPTION_DATA_DESCRIPTOR_SIGNATURE = "dataDescriptorSignature";
    OPTION_USE_UNICODE_FILE_NAMES = "useUnicodeFileNames";
    OPTION_DATA_DESCRIPTOR = "dataDescriptor";
    OPTION_SUPPORT_ZIP64_SPLIT_FILE = "supportZip64SplitFile";
    OPTION_ENCODE_TEXT = "encodeText";
    OPTION_OFFSET = "offset";
    OPTION_USDZ = "usdz";
    OPTION_UNIX_EXTRA_FIELD_TYPE = "unixExtraFieldType";
    OPTION_LOCAL_EXTRA_FIELD = "localExtraField";
    OPTION_CENTRAL_EXTRA_FIELD = "centralExtraField";
    OPTION_STRICTNESS = "strictness";
    OPTION_FILENAME_VALIDATION = "filenameValidation";
    OPTION_NORMALIZE_FILENAME = "normalizeFilename";
    OPTION_MAX_APPENDED_DATA_SIZE = "maxAppendedDataSize";
    OPTION_DECRYPT_CENTRAL_DIRECTORY = "decryptCentralDirectory";
    OPTION_SIGN_CENTRAL_DIRECTORY = "signCentralDirectory";
    OPTION_ENTRY = "entry";
    TEXT_TYPE_FILENAME = "filename";
    TEXT_TYPE_COMMENT = "comment";
    STRICTNESS_STRICT = "strict";
    STRICTNESS_BALANCED = "balanced";
    STRICTNESS_TOLERANT = "tolerant";
    PASS_THROUGH_COMPRESSED = "compressed";
    ERR_INVALID_FUNCTION_OPTION = "Invalid option (must be a function)";
    ERR_INVALID_SIGNAL = "Invalid signal (must be an AbortSignal instance)";
    ERR_INVALID_PASSWORD_TYPE = "Invalid password (password must be a string, rawPassword must be a Uint8Array)";
    ERR_INVALID_PASS_THROUGH_VALUE = "Invalid passThrough option (must be a boolean or 'compressed')";
    ERR_ABORTED = "The operation was aborted";
    ABORT_ERROR_NAME = "AbortError";
  }
});

// node_modules/@zip.js/zip.js/lib/core/configuration.js
function getConfiguration() {
  return config;
}
function getChunkSize(config2) {
  return normalizeChunkSize(config2.chunkSize);
}
function normalizeChunkSize(chunkSize) {
  chunkSize = toNumber(chunkSize);
  return Number.isInteger(chunkSize) && chunkSize >= MINIMUM_PROPERTY_VALUE ? Math.max(chunkSize, MINIMUM_CHUNK_SIZE) : DEFAULT_CHUNK_SIZE;
}
function configure(configuration) {
  Object.assign(config, checkConfiguration(normalizeConfiguration(configuration)));
}
function checkConfiguration(configuration) {
  const checkedConfiguration = {};
  for (const propertyName of CONFIGURABLE_PROPERTY_NAMES) {
    const propertyValue = configuration[propertyName];
    if (propertyValue !== UNDEFINED_VALUE) {
      checkedConfiguration[propertyName] = checkPropertyValue(propertyName, propertyValue);
    }
  }
  return checkedConfiguration;
}
function checkPropertyValue(propertyName, propertyValue) {
  if (NUMBER_PROPERTY_NAMES.includes(propertyName)) {
    propertyValue = toNumber(propertyValue);
    if (propertyName == PROPERTY_NAME_MAX_WORKERS && (!Number.isInteger(propertyValue) || propertyValue < MINIMUM_PROPERTY_VALUE)) {
      throw new Error(ERR_INVALID_MAX_WORKERS);
    }
  } else if (FUNCTION_PROPERTY_NAMES.includes(propertyName)) {
    checkFunctionOption(propertyValue);
  } else if (propertyName == PROPERTY_NAME_BASE_URI) {
    if (propertyValue && typeof propertyValue != STRING_TYPE) {
      throw new Error(ERR_INVALID_BASE_URI);
    }
  } else if (URI_PROPERTY_NAMES.includes(propertyName)) {
    if (propertyValue && typeof propertyValue != STRING_TYPE && typeof propertyValue != FUNCTION_TYPE) {
      throw new Error(ERR_INVALID_URI);
    }
  }
  return propertyValue;
}
function normalizeConfiguration(configuration) {
  configuration = configuration || {};
  const { CompressionStreamZlib: CompressionStreamZlib2, DecompressionStreamZlib: DecompressionStreamZlib2 } = configuration;
  if (CompressionStreamZlib2 === UNDEFINED_VALUE && DecompressionStreamZlib2 === UNDEFINED_VALUE) {
    return configuration;
  }
  const normalizedConfiguration = Object.assign({}, configuration);
  if (normalizedConfiguration.CompressionStreamFallback === UNDEFINED_VALUE) {
    normalizedConfiguration.CompressionStreamFallback = CompressionStreamZlib2;
  }
  if (normalizedConfiguration.DecompressionStreamFallback === UNDEFINED_VALUE) {
    normalizedConfiguration.DecompressionStreamFallback = DecompressionStreamZlib2;
  }
  return normalizedConfiguration;
}
function setDefaultConfiguration(configuration) {
  const checkedConfiguration = checkConfiguration(normalizeConfiguration(configuration));
  Object.assign(DEFAULT_CONFIGURATION, checkedConfiguration);
  Object.assign(config, checkedConfiguration);
}
var DEFAULT_CHUNK_SIZE, MINIMUM_CHUNK_SIZE, MINIMUM_PROPERTY_VALUE, ERR_INVALID_MAX_WORKERS, ERR_INVALID_BASE_URI, ERR_INVALID_URI, maxWorkers, DEFAULT_CONFIGURATION, PROPERTY_NAME_MAX_WORKERS, PROPERTY_NAME_BASE_URI, URI_PROPERTY_NAMES, BOOLEAN_PROPERTY_NAMES, NUMBER_PROPERTY_NAMES, FUNCTION_PROPERTY_NAMES, CONFIGURABLE_PROPERTY_NAMES, config;
var init_configuration = __esm({
  "node_modules/@zip.js/zip.js/lib/core/configuration.js"() {
    init_constants();
    init_options();
    DEFAULT_CHUNK_SIZE = 64 * 1024;
    MINIMUM_CHUNK_SIZE = 64;
    MINIMUM_PROPERTY_VALUE = 1;
    ERR_INVALID_MAX_WORKERS = "Invalid maxWorkers (must be an integer greater than 0)";
    ERR_INVALID_BASE_URI = "Invalid baseURI (must be a string)";
    ERR_INVALID_URI = "Invalid URI (must be a string or a function returning a string)";
    maxWorkers = 2;
    try {
      if (typeof navigator != UNDEFINED_TYPE && navigator.hardwareConcurrency) {
        maxWorkers = navigator.hardwareConcurrency;
      }
    } catch {
    }
    DEFAULT_CONFIGURATION = {
      workerURI: "./core/web-worker-wasm.js",
      wasmURI: "./core/streams/zlib-wasm/zlib-streams.wasm",
      chunkSize: DEFAULT_CHUNK_SIZE,
      maxWorkers,
      terminateWorkerTimeout: 5e3,
      workerStarvationTimeout: 5e3,
      workerStartupTimeout: 5e3,
      useWebWorkers: true,
      useCompressionStream: true,
      transferStreams: true,
      CompressionStream: typeof CompressionStream != UNDEFINED_TYPE && CompressionStream,
      DecompressionStream: typeof DecompressionStream != UNDEFINED_TYPE && DecompressionStream
    };
    PROPERTY_NAME_MAX_WORKERS = "maxWorkers";
    PROPERTY_NAME_BASE_URI = "baseURI";
    URI_PROPERTY_NAMES = [
      "wasmURI",
      "workerURI"
    ];
    BOOLEAN_PROPERTY_NAMES = [
      "useCompressionStream",
      "useWebWorkers",
      "transferStreams"
    ];
    NUMBER_PROPERTY_NAMES = [
      "chunkSize",
      PROPERTY_NAME_MAX_WORKERS,
      "terminateWorkerTimeout",
      "workerStarvationTimeout",
      "workerStartupTimeout"
    ];
    FUNCTION_PROPERTY_NAMES = [
      "createWorker",
      "CompressionStream",
      "DecompressionStream",
      "CompressionStreamFallback",
      "DecompressionStreamFallback"
    ];
    CONFIGURABLE_PROPERTY_NAMES = [
      PROPERTY_NAME_BASE_URI,
      ...URI_PROPERTY_NAMES,
      ...BOOLEAN_PROPERTY_NAMES,
      ...NUMBER_PROPERTY_NAMES,
      ...FUNCTION_PROPERTY_NAMES
    ];
    config = { ...DEFAULT_CONFIGURATION };
  }
});

// node_modules/@zip.js/zip.js/lib/core/util/array.js
function concat(first, second) {
  const result = new Uint8Array(first.length + second.length);
  result.set(first);
  result.set(second, first.length);
  return result;
}
function toExactUint8Array(array) {
  return array.byteOffset || array.byteLength != array.buffer.byteLength ? new Uint8Array(array) : array;
}
function getDataView(array) {
  return new DataView(array.buffer, array.byteOffset, array.byteLength);
}
var init_array = __esm({
  "node_modules/@zip.js/zip.js/lib/core/util/array.js"() {
  }
});

// node_modules/@zip.js/zip.js/lib/core/util/error.js
function isErrorObject(error) {
  return Boolean(error) && typeof error == "object";
}
var init_error = __esm({
  "node_modules/@zip.js/zip.js/lib/core/util/error.js"() {
  }
});

// node_modules/@zip.js/zip.js/lib/core/streams/codecs/crc32.js
var T, T0, T1, T2, T3, T4, T5, T6, T7, Crc32;
var init_crc32 = __esm({
  "node_modules/@zip.js/zip.js/lib/core/streams/codecs/crc32.js"() {
    T = [[], [], [], [], [], [], [], []];
    for (let n2 = 0; n2 < 256; n2++) {
      let t2 = n2;
      for (let j = 0; j < 8; j++) {
        t2 = t2 & 1 ? t2 >>> 1 ^ 3988292384 : t2 >>> 1;
      }
      T[0][n2] = t2;
    }
    for (let n2 = 0; n2 < 256; n2++) {
      for (let k = 1; k < 8; k++) {
        const previous = T[k - 1][n2];
        T[k][n2] = previous >>> 8 ^ T[0][previous & 255];
      }
    }
    [T0, T1, T2, T3, T4, T5, T6, T7] = T;
    Crc32 = class {
      constructor(crc) {
        this.crc = crc || -1;
      }
      append(data) {
        let crc = this.crc | 0;
        const length = data.length | 0;
        let offset = 0;
        if (length >= 8 && data.buffer) {
          const view = new DataView(data.buffer, data.byteOffset, length);
          const end = length - 8;
          for (; offset <= end; offset += 8) {
            const a2 = crc ^ view.getInt32(offset, true);
            const b = view.getInt32(offset + 4, true);
            crc = T7[a2 & 255] ^ T6[a2 >>> 8 & 255] ^ T5[a2 >>> 16 & 255] ^ T4[a2 >>> 24 & 255] ^ T3[b & 255] ^ T2[b >>> 8 & 255] ^ T1[b >>> 16 & 255] ^ T0[b >>> 24 & 255];
          }
        }
        for (; offset < length; offset++) {
          crc = crc >>> 8 ^ T0[(crc ^ data[offset]) & 255];
        }
        this.crc = crc;
      }
      get() {
        return ~this.crc;
      }
    };
  }
});

// node_modules/@zip.js/zip.js/lib/core/streams/crc32-stream.js
var Crc32Stream;
var init_crc32_stream = __esm({
  "node_modules/@zip.js/zip.js/lib/core/streams/crc32-stream.js"() {
    init_crc32();
    Crc32Stream = class extends TransformStream {
      constructor() {
        let stream;
        const crc32 = new Crc32();
        super({
          transform(chunk, controller) {
            crc32.append(chunk);
            controller.enqueue(chunk);
          },
          flush() {
            const value = new Uint8Array(4);
            const dataView = new DataView(value.buffer);
            dataView.setUint32(0, crc32.get());
            stream.value = value;
          }
        });
        stream = this;
      }
    };
  }
});

// node_modules/@zip.js/zip.js/lib/core/util/encode-text.js
function encodeText(value) {
  if (typeof TextEncoder == UNDEFINED_TYPE) {
    value = unescape(encodeURIComponent(value));
    const result = new Uint8Array(value.length);
    for (let i = 0; i < result.length; i++) {
      result[i] = value.charCodeAt(i);
    }
    return result;
  } else {
    return new TextEncoder().encode(value);
  }
}
var init_encode_text = __esm({
  "node_modules/@zip.js/zip.js/lib/core/util/encode-text.js"() {
    init_constants();
  }
});

// node_modules/@zip.js/zip.js/lib/core/streams/codecs/sjcl.js
var bitArray, codec, hash, cipher, mode, misc;
var init_sjcl = __esm({
  "node_modules/@zip.js/zip.js/lib/core/streams/codecs/sjcl.js"() {
    bitArray = {
      /**
       * Concatenate two bit arrays.
       * @param {bitArray} a1 The first array.
       * @param {bitArray} a2 The second array.
       * @return {bitArray} The concatenation of a1 and a2.
       */
      concat(a1, a2) {
        if (a1.length === 0 || a2.length === 0) {
          return a1.concat(a2);
        }
        const last = a1[a1.length - 1], shift = bitArray.getPartial(last);
        if (shift === 32) {
          return a1.concat(a2);
        } else {
          return bitArray._shiftRight(a2, shift, last | 0, a1.slice(0, a1.length - 1));
        }
      },
      /**
       * Find the length of an array of bits.
       * @param {bitArray} a The array.
       * @return {Number} The length of a, in bits.
       */
      bitLength(a2) {
        const l2 = a2.length;
        if (l2 === 0) {
          return 0;
        }
        const x = a2[l2 - 1];
        return (l2 - 1) * 32 + bitArray.getPartial(x);
      },
      /**
       * Truncate an array.
       * @param {bitArray} a The array.
       * @param {Number} len The length to truncate to, in bits.
       * @return {bitArray} A new array, truncated to len bits.
       */
      clamp(a2, len) {
        if (a2.length * 32 < len) {
          return a2;
        }
        a2 = a2.slice(0, Math.ceil(len / 32));
        const l2 = a2.length;
        len = len & 31;
        if (l2 > 0 && len) {
          a2[l2 - 1] = bitArray.partial(len, a2[l2 - 1] & 2147483648 >> len - 1, 1);
        }
        return a2;
      },
      /**
       * Make a partial word for a bit array.
       * @param {Number} len The number of bits in the word.
       * @param {Number} x The bits.
       * @param {Number} [_end=0] Pass 1 if x has already been shifted to the high side.
       * @return {Number} The partial word.
       */
      partial(len, x, _end) {
        if (len === 32) {
          return x;
        }
        return (_end ? x | 0 : x << 32 - len) + len * 1099511627776;
      },
      /**
       * Get the number of bits used by a partial word.
       * @param {Number} x The partial word.
       * @return {Number} The number of bits used by the partial word.
       */
      getPartial(x) {
        return Math.round(x / 1099511627776) || 32;
      },
      /** Shift an array right.
       * @param {bitArray} a The array to shift.
       * @param {Number} shift The number of bits to shift.
       * @param {Number} [carry=0] A byte to carry in
       * @param {bitArray} [out=[]] An array to prepend to the output.
       * @private
       */
      _shiftRight(a2, shift, carry, out) {
        if (out === void 0) {
          out = [];
        }
        for (; shift >= 32; shift -= 32) {
          out.push(carry);
          carry = 0;
        }
        if (shift === 0) {
          return out.concat(a2);
        }
        for (let i = 0; i < a2.length; i++) {
          out.push(carry | a2[i] >>> shift);
          carry = a2[i] << 32 - shift;
        }
        const last2 = a2.length ? a2[a2.length - 1] : 0;
        const shift2 = bitArray.getPartial(last2);
        out.push(bitArray.partial(shift + shift2 & 31, shift + shift2 > 32 ? carry : out.pop(), 1));
        return out;
      }
    };
    codec = {
      bytes: {
        /** Convert from a bitArray to an array of bytes. */
        fromBits(arr) {
          const bl = bitArray.bitLength(arr);
          const byteLength = bl / 8;
          const out = new Uint8Array(byteLength);
          let tmp;
          for (let i = 0; i < byteLength; i++) {
            if ((i & 3) === 0) {
              tmp = arr[i / 4];
            }
            out[i] = tmp >>> 24;
            tmp <<= 8;
          }
          return out;
        },
        /** Convert from an array of bytes to a bitArray. */
        toBits(bytes) {
          const out = [];
          let i;
          let tmp = 0;
          for (i = 0; i < bytes.length; i++) {
            tmp = tmp << 8 | bytes[i];
            if ((i & 3) === 3) {
              out.push(tmp);
              tmp = 0;
            }
          }
          if (i & 3) {
            out.push(bitArray.partial(8 * (i & 3), tmp));
          }
          return out;
        }
      }
    };
    hash = {};
    hash.sha1 = class {
      constructor(hash2) {
        const sha1 = this;
        sha1.blockSize = 512;
        sha1._init = [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
        sha1._key = [1518500249, 1859775393, 2400959708, 3395469782];
        if (hash2) {
          sha1._h = hash2._h.slice(0);
          sha1._buffer = hash2._buffer.slice(0);
          sha1._length = hash2._length;
        } else {
          sha1.reset();
        }
      }
      /**
       * Reset the hash state.
       * @return this
       */
      reset() {
        const sha1 = this;
        sha1._h = sha1._init.slice(0);
        sha1._buffer = [];
        sha1._length = 0;
        return sha1;
      }
      /**
       * Input several words to the hash.
       * @param {bitArray|String} data the data to hash.
       * @return this
       */
      update(data) {
        const sha1 = this;
        if (typeof data === "string") {
          data = codec.utf8String.toBits(data);
        }
        const b = sha1._buffer = bitArray.concat(sha1._buffer, data);
        const ol = sha1._length;
        const nl = sha1._length = ol + bitArray.bitLength(data);
        if (nl > 9007199254740991) {
          throw new Error("Cannot hash more than 2^53 - 1 bits");
        }
        const c = new Uint32Array(b);
        let j = 0;
        for (let i = sha1.blockSize + ol - (sha1.blockSize + ol & sha1.blockSize - 1); i <= nl; i += sha1.blockSize) {
          sha1._block(c.subarray(16 * j, 16 * (j + 1)));
          j += 1;
        }
        b.splice(0, 16 * j);
        return sha1;
      }
      /**
       * Complete hashing and output the hash value.
       * @return {bitArray} The hash value, an array of 5 big-endian words. TODO
       */
      finalize() {
        const sha1 = this;
        let b = sha1._buffer;
        const h = sha1._h;
        b = bitArray.concat(b, [bitArray.partial(1, 1)]);
        for (let i = b.length + 2; i & 15; i++) {
          b.push(0);
        }
        b.push(Math.floor(sha1._length / 4294967296));
        b.push(sha1._length | 0);
        while (b.length) {
          sha1._block(b.splice(0, 16));
        }
        sha1.reset();
        return h;
      }
      /**
       * The SHA-1 logical functions f(0), f(1), ..., f(79).
       * @private
       */
      _f(t2, b, c, d) {
        if (t2 <= 19) {
          return b & c | ~b & d;
        } else if (t2 <= 39) {
          return b ^ c ^ d;
        } else if (t2 <= 59) {
          return b & c | b & d | c & d;
        } else if (t2 <= 79) {
          return b ^ c ^ d;
        }
      }
      /**
       * Circular left-shift operator.
       * @private
       */
      _S(n2, x) {
        return x << n2 | x >>> 32 - n2;
      }
      /**
       * Perform one cycle of SHA-1.
       * @param {Uint32Array|bitArray} words one block of words.
       * @private
       */
      _block(words) {
        const sha1 = this;
        const h = sha1._h;
        const w = Array(80);
        for (let j = 0; j < 16; j++) {
          w[j] = words[j];
        }
        let a2 = h[0];
        let b = h[1];
        let c = h[2];
        let d = h[3];
        let e2 = h[4];
        for (let t2 = 0; t2 <= 79; t2++) {
          if (t2 >= 16) {
            w[t2] = sha1._S(1, w[t2 - 3] ^ w[t2 - 8] ^ w[t2 - 14] ^ w[t2 - 16]);
          }
          const tmp = sha1._S(5, a2) + sha1._f(t2, b, c, d) + e2 + w[t2] + sha1._key[Math.floor(t2 / 20)] | 0;
          e2 = d;
          d = c;
          c = sha1._S(30, b);
          b = a2;
          a2 = tmp;
        }
        h[0] = h[0] + a2 | 0;
        h[1] = h[1] + b | 0;
        h[2] = h[2] + c | 0;
        h[3] = h[3] + d | 0;
        h[4] = h[4] + e2 | 0;
      }
    };
    cipher = {};
    cipher.aes = class {
      constructor(key) {
        const aes = this;
        aes._tables = [[[], [], [], [], []], [[], [], [], [], []]];
        if (!aes._tables[0][0][0]) {
          aes._precompute();
        }
        const sbox = aes._tables[0][4];
        const decTable = aes._tables[1];
        const keyLen = key.length;
        let i, encKey, decKey, rcon = 1;
        if (keyLen !== 4 && keyLen !== 6 && keyLen !== 8) {
          throw new Error("invalid aes key size");
        }
        aes._key = [encKey = key.slice(0), decKey = []];
        for (i = keyLen; i < 4 * keyLen + 28; i++) {
          let tmp = encKey[i - 1];
          if (i % keyLen === 0 || keyLen === 8 && i % keyLen === 4) {
            tmp = sbox[tmp >>> 24] << 24 ^ sbox[tmp >> 16 & 255] << 16 ^ sbox[tmp >> 8 & 255] << 8 ^ sbox[tmp & 255];
            if (i % keyLen === 0) {
              tmp = tmp << 8 ^ tmp >>> 24 ^ rcon << 24;
              rcon = rcon << 1 ^ (rcon >> 7) * 283;
            }
          }
          encKey[i] = encKey[i - keyLen] ^ tmp;
        }
        for (let j = 0; i; j++, i--) {
          const tmp = encKey[j & 3 ? i : i - 4];
          if (i <= 4 || j < 4) {
            decKey[j] = tmp;
          } else {
            decKey[j] = decTable[0][sbox[tmp >>> 24]] ^ decTable[1][sbox[tmp >> 16 & 255]] ^ decTable[2][sbox[tmp >> 8 & 255]] ^ decTable[3][sbox[tmp & 255]];
          }
        }
      }
      // public
      /* Something like this might appear here eventually
      name: "AES",
      blockSize: 4,
      keySizes: [4,6,8],
      */
      /**
       * Encrypt an array of 4 big-endian words.
       * @param {Array} data The plaintext.
       * @return {Array} The ciphertext.
       */
      encrypt(data) {
        return this._crypt(data, 0);
      }
      /**
       * Decrypt an array of 4 big-endian words.
       * @param {Array} data The ciphertext.
       * @return {Array} The plaintext.
       */
      decrypt(data) {
        return this._crypt(data, 1);
      }
      /**
       * Expand the S-box tables.
       *
       * @private
       */
      _precompute() {
        const encTable = this._tables[0];
        const decTable = this._tables[1];
        const sbox = encTable[4];
        const sboxInv = decTable[4];
        const d = [];
        const th = [];
        let xInv, x2, x4, x8;
        for (let i = 0; i < 256; i++) {
          th[(d[i] = i << 1 ^ (i >> 7) * 283) ^ i] = i;
        }
        for (let x = xInv = 0; !sbox[x]; x ^= x2 || 1, xInv = th[xInv] || 1) {
          let s2 = xInv ^ xInv << 1 ^ xInv << 2 ^ xInv << 3 ^ xInv << 4;
          s2 = s2 >> 8 ^ s2 & 255 ^ 99;
          sbox[x] = s2;
          sboxInv[s2] = x;
          x8 = d[x4 = d[x2 = d[x]]];
          let tDec = x8 * 16843009 ^ x4 * 65537 ^ x2 * 257 ^ x * 16843008;
          let tEnc = d[s2] * 257 ^ s2 * 16843008;
          for (let i = 0; i < 4; i++) {
            encTable[i][x] = tEnc = tEnc << 24 ^ tEnc >>> 8;
            decTable[i][s2] = tDec = tDec << 24 ^ tDec >>> 8;
          }
        }
        for (let i = 0; i < 5; i++) {
          encTable[i] = encTable[i].slice(0);
          decTable[i] = decTable[i].slice(0);
        }
      }
      /**
       * Encryption and decryption core.
       * @param {Array} input Four words to be encrypted or decrypted.
       * @param dir The direction, 0 for encrypt and 1 for decrypt.
       * @return {Array} The four encrypted or decrypted words.
       * @private
       */
      _crypt(input, dir) {
        if (input.length !== 4) {
          throw new Error("invalid aes block size");
        }
        const key = this._key[dir];
        const nInnerRounds = key.length / 4 - 2;
        const out = [0, 0, 0, 0];
        const table = this._tables[dir];
        const t0 = table[0];
        const t1 = table[1];
        const t2 = table[2];
        const t3 = table[3];
        const sbox = table[4];
        let a2 = input[0] ^ key[0];
        let b = input[dir ? 3 : 1] ^ key[1];
        let c = input[2] ^ key[2];
        let d = input[dir ? 1 : 3] ^ key[3];
        let kIndex = 4;
        let a22, b2, c2;
        for (let i = 0; i < nInnerRounds; i++) {
          a22 = t0[a2 >>> 24] ^ t1[b >> 16 & 255] ^ t2[c >> 8 & 255] ^ t3[d & 255] ^ key[kIndex];
          b2 = t0[b >>> 24] ^ t1[c >> 16 & 255] ^ t2[d >> 8 & 255] ^ t3[a2 & 255] ^ key[kIndex + 1];
          c2 = t0[c >>> 24] ^ t1[d >> 16 & 255] ^ t2[a2 >> 8 & 255] ^ t3[b & 255] ^ key[kIndex + 2];
          d = t0[d >>> 24] ^ t1[a2 >> 16 & 255] ^ t2[b >> 8 & 255] ^ t3[c & 255] ^ key[kIndex + 3];
          kIndex += 4;
          a2 = a22;
          b = b2;
          c = c2;
        }
        for (let i = 0; i < 4; i++) {
          out[dir ? 3 & -i : i] = sbox[a2 >>> 24] << 24 ^ sbox[b >> 16 & 255] << 16 ^ sbox[c >> 8 & 255] << 8 ^ sbox[d & 255] ^ key[kIndex++];
          a22 = a2;
          a2 = b;
          b = c;
          c = d;
          d = a22;
        }
        return out;
      }
    };
    mode = {};
    mode.ctrGladman = class {
      constructor(prf, iv) {
        this._prf = prf;
        this._initIv = iv;
        this._iv = iv;
      }
      reset() {
        this._iv = this._initIv;
      }
      /** Input some data to calculate.
       * @param {bitArray} data the data to process, it must be intergral multiple of 128 bits unless it's the last.
       */
      update(data) {
        return this.calculate(this._prf, data, this._iv);
      }
      incWord(word) {
        if ((word >> 24 & 255) === 255) {
          let b1 = word >> 16 & 255;
          let b2 = word >> 8 & 255;
          let b3 = word & 255;
          if (b1 === 255) {
            b1 = 0;
            if (b2 === 255) {
              b2 = 0;
              if (b3 === 255) {
                b3 = 0;
              } else {
                ++b3;
              }
            } else {
              ++b2;
            }
          } else {
            ++b1;
          }
          word = 0;
          word += b1 << 16;
          word += b2 << 8;
          word += b3;
        } else {
          word += 1 << 24;
        }
        return word;
      }
      incCounter(counter) {
        if ((counter[0] = this.incWord(counter[0])) === 0) {
          counter[1] = this.incWord(counter[1]);
        }
      }
      calculate(prf, data, iv) {
        let l2;
        if (!(l2 = data.length)) {
          return [];
        }
        const bl = bitArray.bitLength(data);
        for (let i = 0; i < l2; i += 4) {
          this.incCounter(iv);
          const e2 = prf.encrypt(iv);
          data[i] ^= e2[0];
          data[i + 1] ^= e2[1];
          data[i + 2] ^= e2[2];
          data[i + 3] ^= e2[3];
        }
        return bitArray.clamp(data, bl);
      }
    };
    misc = {
      importKey(password) {
        return new misc.hmacSha1(codec.bytes.toBits(password));
      },
      pbkdf2(prf, salt, count, length) {
        count = count || 1e4;
        if (length < 0 || count < 0) {
          throw new Error("invalid params to pbkdf2");
        }
        const byteLength = (length >> 5) + 1 << 2;
        let u, ui, i, j, k;
        const arrayBuffer = new ArrayBuffer(byteLength);
        const out = new DataView(arrayBuffer);
        let outLength = 0;
        const b = bitArray;
        salt = codec.bytes.toBits(salt);
        for (k = 1; outLength < (byteLength || 1); k++) {
          u = ui = prf.encrypt(b.concat(salt, [k]));
          for (i = 1; i < count; i++) {
            ui = prf.encrypt(ui);
            for (j = 0; j < ui.length; j++) {
              u[j] ^= ui[j];
            }
          }
          for (i = 0; outLength < (byteLength || 1) && i < u.length; i++) {
            out.setInt32(outLength, u[i]);
            outLength += 4;
          }
        }
        return arrayBuffer.slice(0, length / 8);
      }
    };
    misc.hmacSha1 = class {
      constructor(key) {
        const hmac = this;
        const Hash = hmac._hash = hash.sha1;
        const exKey = [[], []];
        hmac._baseHash = [new Hash(), new Hash()];
        const bs = hmac._baseHash[0].blockSize / 32;
        if (key.length > bs) {
          key = new Hash().update(key).finalize();
        }
        for (let i = 0; i < bs; i++) {
          exKey[0][i] = key[i] ^ 909522486;
          exKey[1][i] = key[i] ^ 1549556828;
        }
        hmac._baseHash[0].update(exKey[0]);
        hmac._baseHash[1].update(exKey[1]);
        hmac._resultHash = new Hash(hmac._baseHash[0]);
      }
      reset() {
        const hmac = this;
        hmac._resultHash = new hmac._hash(hmac._baseHash[0]);
        hmac._updated = false;
      }
      update(data) {
        const hmac = this;
        hmac._updated = true;
        hmac._resultHash.update(data);
      }
      digest() {
        const hmac = this;
        const w = hmac._resultHash.finalize();
        const result = new hmac._hash(hmac._baseHash[1]).update(w).finalize();
        hmac.reset();
        return result;
      }
      encrypt(data) {
        if (!this._updated) {
          this.update(data);
          return this.digest(data);
        } else {
          throw new Error("encrypt on already updated hmac called!");
        }
      }
    };
  }
});

// node_modules/@zip.js/zip.js/lib/core/streams/common-crypto.js
function getRandomValues(array) {
  if (GET_RANDOM_VALUES_SUPPORTED) {
    return crypto.getRandomValues(array);
  } else {
    throw new Error(ERR_UNSUPPORTED_CRYPTO_API);
  }
}
var GET_RANDOM_VALUES_SUPPORTED, ERR_INVALID_PASSWORD, ERR_INVALID_AUTHENTICATION_CODE, ERR_ABORT_CHECK_PASSWORD, ERR_UNSUPPORTED_CRYPTO_API;
var init_common_crypto = __esm({
  "node_modules/@zip.js/zip.js/lib/core/streams/common-crypto.js"() {
    init_constants();
    GET_RANDOM_VALUES_SUPPORTED = typeof crypto != UNDEFINED_TYPE && typeof crypto.getRandomValues == FUNCTION_TYPE;
    ERR_INVALID_PASSWORD = "Invalid password";
    ERR_INVALID_AUTHENTICATION_CODE = "Invalid authentication code";
    ERR_ABORT_CHECK_PASSWORD = "zipjs-abort-check-password";
    ERR_UNSUPPORTED_CRYPTO_API = "Crypto API not supported";
  }
});

// node_modules/@zip.js/zip.js/lib/core/streams/aes-crypto-stream.js
function initAesCrypto(aesCrypto, password, rawPassword, encryptionStrength) {
  Object.assign(aesCrypto, {
    ready: new Promise((resolve) => aesCrypto.resolveReady = resolve),
    password: encodePassword(password, rawPassword),
    strength: encryptionStrength - 1,
    pendingInput: EMPTY_UINT8_ARRAY
  });
}
function append(aesCrypto, input, output, paddingStart, paddingEnd, verifyAuthenticationCode) {
  const {
    ctr,
    hmac,
    pendingInput
  } = aesCrypto;
  if (pendingInput.length) {
    input = concat(pendingInput, input);
  }
  const inputLength = input.length - paddingEnd;
  output = expand(output, paddingStart + (inputLength - inputLength % BLOCK_LENGTH));
  let offset;
  for (offset = 0; offset <= inputLength - BLOCK_LENGTH; offset += BLOCK_LENGTH) {
    const inputChunk = toBits(codecBytes, subarray(input, offset, offset + BLOCK_LENGTH));
    if (verifyAuthenticationCode) {
      hmac.update(inputChunk);
    }
    const outputChunk = ctr.update(inputChunk);
    if (!verifyAuthenticationCode) {
      hmac.update(outputChunk);
    }
    output.set(fromBits(codecBytes, outputChunk), offset + paddingStart);
  }
  aesCrypto.pendingInput = subarray(input, offset);
  return output;
}
async function createDecryptionKeys(decrypt2, strength, password, preamble) {
  const passwordVerificationKey = await createKeys(decrypt2, strength, password, subarray(preamble, 0, SALT_LENGTH[strength]));
  const passwordVerification = subarray(preamble, SALT_LENGTH[strength]);
  if (passwordVerificationKey[0] != passwordVerification[0] || passwordVerificationKey[1] != passwordVerification[1]) {
    throw new Error(ERR_INVALID_PASSWORD);
  }
}
async function createEncryptionKeys(encrypt2, strength, password) {
  const salt = getRandomValues(new Uint8Array(SALT_LENGTH[strength]));
  const passwordVerification = await createKeys(encrypt2, strength, password, salt);
  return concat(salt, passwordVerification);
}
async function createKeys(aesCrypto, strength, password, salt) {
  aesCrypto.password = null;
  const baseKey = await importKey(RAW_FORMAT, password, BASE_KEY_ALGORITHM, false, DERIVED_BITS_USAGE);
  const derivedBits = await deriveBits(Object.assign({ salt }, DERIVED_BITS_ALGORITHM), baseKey, 8 * (KEY_LENGTH[strength] * 2 + 2));
  const compositeKey = new Uint8Array(derivedBits);
  const key = toBits(codecBytes, subarray(compositeKey, 0, KEY_LENGTH[strength]));
  const authentication = toBits(codecBytes, subarray(compositeKey, KEY_LENGTH[strength], KEY_LENGTH[strength] * 2));
  const passwordVerification = subarray(compositeKey, KEY_LENGTH[strength] * 2);
  Object.assign(aesCrypto, {
    keys: {
      key,
      authentication,
      passwordVerification
    },
    ctr: new CtrGladman(new Aes(key), Array.from(COUNTER_DEFAULT_VALUE)),
    hmac: new HmacSha1(authentication)
  });
  return passwordVerification;
}
async function importKey(format, password, algorithm, extractable, keyUsages) {
  if (IMPORT_KEY_SUPPORTED) {
    try {
      return await subtle.importKey(format, password, algorithm, extractable, keyUsages);
    } catch {
      IMPORT_KEY_SUPPORTED = false;
      return misc.importKey(password);
    }
  } else {
    return misc.importKey(password);
  }
}
async function deriveBits(algorithm, baseKey, length) {
  if (DERIVE_BITS_SUPPORTED) {
    try {
      return await subtle.deriveBits(algorithm, baseKey, length);
    } catch {
      DERIVE_BITS_SUPPORTED = false;
      return misc.pbkdf2(baseKey, algorithm.salt, DERIVED_BITS_ALGORITHM.iterations, length);
    }
  } else {
    return misc.pbkdf2(baseKey, algorithm.salt, DERIVED_BITS_ALGORITHM.iterations, length);
  }
}
function encodePassword(password, rawPassword) {
  if (rawPassword === UNDEFINED_VALUE) {
    return encodeText(password);
  } else {
    return rawPassword;
  }
}
function expand(inputArray, length) {
  if (length && length > inputArray.length) {
    const array = inputArray;
    inputArray = new Uint8Array(length);
    inputArray.set(array, 0);
  }
  return inputArray;
}
function subarray(array, begin, end) {
  return array.subarray(begin, end);
}
function fromBits(codecBytes2, chunk) {
  return codecBytes2.fromBits(chunk);
}
function toBits(codecBytes2, chunk) {
  return codecBytes2.toBits(chunk);
}
var BLOCK_LENGTH, RAW_FORMAT, PBKDF2_ALGORITHM, HASH_ALGORITHM, HASH_FUNCTION, BASE_KEY_ALGORITHM, DERIVED_BITS_ALGORITHM, DERIVED_BITS_USAGE, SALT_LENGTH, KEY_LENGTH, AUTHENTICATION_CODE_LENGTH, COUNTER_DEFAULT_VALUE, CRYPTO_API_SUPPORTED, subtle, SUBTLE_API_SUPPORTED, codecBytes, Aes, CtrGladman, HmacSha1, IMPORT_KEY_SUPPORTED, DERIVE_BITS_SUPPORTED, AESDecryptionStream, AESEncryptionStream;
var init_aes_crypto_stream = __esm({
  "node_modules/@zip.js/zip.js/lib/core/streams/aes-crypto-stream.js"() {
    init_constants();
    init_encode_text();
    init_array();
    init_sjcl();
    init_common_crypto();
    BLOCK_LENGTH = 16;
    RAW_FORMAT = "raw";
    PBKDF2_ALGORITHM = { name: "PBKDF2" };
    HASH_ALGORITHM = { name: "HMAC" };
    HASH_FUNCTION = "SHA-1";
    BASE_KEY_ALGORITHM = Object.assign({ hash: HASH_ALGORITHM }, PBKDF2_ALGORITHM);
    DERIVED_BITS_ALGORITHM = Object.assign({ iterations: 1e3, hash: { name: HASH_FUNCTION } }, PBKDF2_ALGORITHM);
    DERIVED_BITS_USAGE = ["deriveBits"];
    SALT_LENGTH = [8, 12, 16];
    KEY_LENGTH = [16, 24, 32];
    AUTHENTICATION_CODE_LENGTH = 10;
    COUNTER_DEFAULT_VALUE = [0, 0, 0, 0];
    CRYPTO_API_SUPPORTED = typeof crypto != UNDEFINED_TYPE;
    subtle = CRYPTO_API_SUPPORTED && crypto.subtle;
    SUBTLE_API_SUPPORTED = CRYPTO_API_SUPPORTED && typeof subtle != UNDEFINED_TYPE;
    codecBytes = codec.bytes;
    Aes = cipher.aes;
    CtrGladman = mode.ctrGladman;
    HmacSha1 = misc.hmacSha1;
    IMPORT_KEY_SUPPORTED = CRYPTO_API_SUPPORTED && SUBTLE_API_SUPPORTED && typeof subtle.importKey == FUNCTION_TYPE;
    DERIVE_BITS_SUPPORTED = CRYPTO_API_SUPPORTED && SUBTLE_API_SUPPORTED && typeof subtle.deriveBits == FUNCTION_TYPE;
    AESDecryptionStream = class extends TransformStream {
      constructor({ password, rawPassword, encryptionStrength, checkPasswordOnly, checkAuthenticationCode = true }) {
        super({
          start() {
            initAesCrypto(this, password, rawPassword, encryptionStrength);
          },
          async transform(chunk, controller) {
            const aesCrypto = this;
            const {
              password: password2,
              strength,
              resolveReady,
              ready
            } = aesCrypto;
            if (password2) {
              await createDecryptionKeys(aesCrypto, strength, password2, subarray(chunk, 0, SALT_LENGTH[strength] + 2));
              chunk = subarray(chunk, SALT_LENGTH[strength] + 2);
              if (checkPasswordOnly) {
                controller.error(new Error(ERR_ABORT_CHECK_PASSWORD));
              } else {
                resolveReady();
              }
            } else {
              await ready;
            }
            const output = new Uint8Array(chunk.length - AUTHENTICATION_CODE_LENGTH - (chunk.length - AUTHENTICATION_CODE_LENGTH) % BLOCK_LENGTH);
            controller.enqueue(append(aesCrypto, chunk, output, 0, AUTHENTICATION_CODE_LENGTH, true));
          },
          async flush(controller) {
            const {
              ctr,
              hmac,
              pendingInput,
              ready
            } = this;
            if (hmac && ctr) {
              await ready;
              const chunkToDecrypt = subarray(pendingInput, 0, pendingInput.length - AUTHENTICATION_CODE_LENGTH);
              const originalAuthenticationCode = subarray(pendingInput, pendingInput.length - AUTHENTICATION_CODE_LENGTH);
              let decryptedChunkArray = EMPTY_UINT8_ARRAY;
              if (chunkToDecrypt.length) {
                const encryptedChunk = toBits(codecBytes, chunkToDecrypt);
                hmac.update(encryptedChunk);
                const decryptedChunk = ctr.update(encryptedChunk);
                decryptedChunkArray = fromBits(codecBytes, decryptedChunk);
              }
              const authenticationCode = subarray(fromBits(codecBytes, hmac.digest()), 0, AUTHENTICATION_CODE_LENGTH);
              let invalidAuthenticationCode = pendingInput.length < AUTHENTICATION_CODE_LENGTH ? 1 : 0;
              for (let indexByte = 0; indexByte < AUTHENTICATION_CODE_LENGTH; indexByte++) {
                invalidAuthenticationCode |= authenticationCode[indexByte] ^ originalAuthenticationCode[indexByte];
              }
              if (invalidAuthenticationCode && checkAuthenticationCode) {
                throw new Error(ERR_INVALID_AUTHENTICATION_CODE);
              }
              controller.enqueue(decryptedChunkArray);
            }
          }
        });
      }
    };
    AESEncryptionStream = class extends TransformStream {
      constructor({ password, rawPassword, encryptionStrength }) {
        super({
          start() {
            initAesCrypto(this, password, rawPassword, encryptionStrength);
          },
          async transform(chunk, controller) {
            const aesCrypto = this;
            const {
              password: password2,
              strength,
              resolveReady,
              ready
            } = aesCrypto;
            let preamble = EMPTY_UINT8_ARRAY;
            if (password2) {
              preamble = await createEncryptionKeys(aesCrypto, strength, password2);
              resolveReady();
            } else {
              await ready;
            }
            const output = new Uint8Array(preamble.length + chunk.length - chunk.length % BLOCK_LENGTH);
            output.set(preamble, 0);
            controller.enqueue(append(aesCrypto, chunk, output, preamble.length, 0));
          },
          async flush(controller) {
            const {
              ctr,
              hmac,
              pendingInput,
              ready
            } = this;
            if (hmac && ctr) {
              await ready;
              let encryptedChunkArray = EMPTY_UINT8_ARRAY;
              if (pendingInput.length) {
                const encryptedChunk = ctr.update(toBits(codecBytes, pendingInput));
                hmac.update(encryptedChunk);
                encryptedChunkArray = fromBits(codecBytes, encryptedChunk);
              }
              const authenticationCode = fromBits(codecBytes, hmac.digest()).slice(0, AUTHENTICATION_CODE_LENGTH);
              controller.enqueue(concat(encryptedChunkArray, authenticationCode));
            }
          }
        });
      }
    };
  }
});

// node_modules/@zip.js/zip.js/lib/core/streams/zip-crypto-stream.js
function initZipCrypto(zipCrypto, password, rawPassword, passwordVerification) {
  Object.assign(zipCrypto, {
    password,
    rawPassword,
    passwordVerification
  });
  createKeys2(zipCrypto, password, rawPassword);
}
function decrypt(target, input) {
  const output = new Uint8Array(input.length);
  for (let index = 0; index < input.length; index++) {
    output[index] = getByte(target) ^ input[index];
    updateKeys(target, output[index]);
  }
  return output;
}
function encrypt(target, input) {
  const output = new Uint8Array(input.length);
  for (let index = 0; index < input.length; index++) {
    output[index] = getByte(target) ^ input[index];
    updateKeys(target, input[index]);
  }
  return output;
}
function createKeys2(target, password, rawPassword) {
  const keys = [305419896, 591751049, 878082192];
  Object.assign(target, {
    keys,
    crcKey0: new Crc32(keys[0]),
    crcKey2: new Crc32(keys[2])
  });
  if (rawPassword) {
    for (let index = 0; index < rawPassword.length; index++) {
      updateKeys(target, rawPassword[index]);
    }
  } else {
    for (let index = 0; index < password.length; index++) {
      updateKeys(target, password.charCodeAt(index));
    }
  }
}
function updateKeys(target, byte) {
  let [, key1] = target.keys;
  target.crcKey0.append([byte]);
  const key0 = ~target.crcKey0.get();
  key1 = getInt32(Math.imul(getInt32(key1 + getInt8(key0)), 134775813) + 1);
  target.crcKey2.append([key1 >>> 24]);
  const key2 = ~target.crcKey2.get();
  target.keys = [key0, key1, key2];
}
function getByte(target) {
  const temp = target.keys[2] | 2;
  return getInt8(Math.imul(temp, temp ^ 1) >>> 8);
}
function getInt8(number) {
  return number & 255;
}
function getInt32(number) {
  return number & 4294967295;
}
var HEADER_LENGTH, ZipCryptoDecryptionStream, ZipCryptoEncryptionStream;
var init_zip_crypto_stream = __esm({
  "node_modules/@zip.js/zip.js/lib/core/streams/zip-crypto-stream.js"() {
    init_crc32();
    init_common_crypto();
    HEADER_LENGTH = 12;
    ZipCryptoDecryptionStream = class extends TransformStream {
      constructor({ password, rawPassword, passwordVerification, checkPasswordOnly }) {
        super({
          start() {
            initZipCrypto(this, password, rawPassword, passwordVerification);
          },
          transform(chunk, controller) {
            const zipCrypto = this;
            if (zipCrypto.password || zipCrypto.rawPassword) {
              const decryptedHeader = decrypt(zipCrypto, chunk.subarray(0, HEADER_LENGTH));
              zipCrypto.password = zipCrypto.rawPassword = null;
              if ((decryptedHeader[HEADER_LENGTH - 1] ^ zipCrypto.passwordVerification) != 0) {
                throw new Error(ERR_INVALID_PASSWORD);
              }
              chunk = chunk.subarray(HEADER_LENGTH);
            }
            if (checkPasswordOnly) {
              controller.error(new Error(ERR_ABORT_CHECK_PASSWORD));
            } else {
              controller.enqueue(decrypt(zipCrypto, chunk));
            }
          }
        });
      }
    };
    ZipCryptoEncryptionStream = class extends TransformStream {
      constructor({ password, rawPassword, passwordVerification }) {
        super({
          start() {
            initZipCrypto(this, password, rawPassword, passwordVerification);
          },
          transform(chunk, controller) {
            const zipCrypto = this;
            let output;
            let offset;
            if (zipCrypto.password || zipCrypto.rawPassword) {
              zipCrypto.password = zipCrypto.rawPassword = null;
              const header = getRandomValues(new Uint8Array(HEADER_LENGTH));
              header[HEADER_LENGTH - 1] = zipCrypto.passwordVerification;
              output = new Uint8Array(chunk.length + header.length);
              output.set(encrypt(zipCrypto, header), 0);
              offset = HEADER_LENGTH;
            } else {
              output = new Uint8Array(chunk.length);
              offset = 0;
            }
            output.set(encrypt(zipCrypto, chunk), offset);
            controller.enqueue(output);
          }
        });
      }
    };
  }
});

// node_modules/@zip.js/zip.js/lib/core/util/compatible-streams.js
function toCompatibleReadable(readable) {
  if (readable instanceof ReadableStream) {
    return readable;
  }
  const reader = readable.getReader();
  return new ReadableStream({
    async pull(controller) {
      const { value, done } = await reader.read();
      if (done) {
        controller.close();
      } else {
        controller.enqueue(value);
      }
    },
    cancel(reason) {
      return reader.cancel(reason);
    }
  });
}
function streamToBlob(readable, contentType) {
  readable = toCompatibleReadable(readable);
  const blobOptions = contentType ? { type: contentType } : {};
  if (responseSupportsGlobalReadable()) {
    return new Response(readable).blob().then((blob) => contentType ? new Blob([blob], blobOptions) : blob);
  }
  const chunks = [];
  return readable.pipeTo(new WritableStream({
    write(chunk) {
      chunks.push(chunk);
    }
  })).then(() => new Blob(chunks, blobOptions));
}
function responseSupportsGlobalReadable() {
  return typeof Blob.prototype.stream != FUNCTION_TYPE || new Blob([]).stream() instanceof ReadableStream;
}
function toCompatibleWritable(writable) {
  if (writable instanceof WritableStream) {
    return writable;
  }
  const writer = writable.getWriter();
  return new WritableStream({
    write(chunk) {
      return writer.write(chunk);
    },
    close() {
      return writer.close();
    },
    abort(reason) {
      return writer.abort(reason);
    }
  });
}
var init_compatible_streams = __esm({
  "node_modules/@zip.js/zip.js/lib/core/util/compatible-streams.js"() {
    init_constants();
  }
});

// node_modules/@zip.js/zip.js/lib/core/codec-registry.js
function getRegisteredCodec(compressionMethod) {
  return registeredCodecs.get(compressionMethod);
}
function getCodecStreams(format) {
  return codecStreams.get(format);
}
function setCodecStreams(format, streams) {
  const { CompressionStream: CompressionStream2, DecompressionStream: DecompressionStream2 } = streams;
  if (typeof CompressionStream2 != FUNCTION_TYPE && typeof DecompressionStream2 != FUNCTION_TYPE) {
    throw new Error(ERR_INVALID_CODEC_MODULE);
  }
  codecStreams.set(format, { CompressionStream: CompressionStream2, DecompressionStream: DecompressionStream2 });
}
async function ensureCodecStreams(format, codecURI) {
  if (!codecStreams.has(format) && codecURI) {
    setCodecStreams(format, await import(
      /* webpackIgnore: true */
      /* @vite-ignore */
      codecURI
    ));
  }
}
var ERR_INVALID_CODEC_MODULE, ERR_UNSUPPORTED_COMPRESSION, registeredCodecs, codecStreams;
var init_codec_registry = __esm({
  "node_modules/@zip.js/zip.js/lib/core/codec-registry.js"() {
    init_constants();
    ERR_INVALID_CODEC_MODULE = "Invalid codec module";
    ERR_UNSUPPORTED_COMPRESSION = "Compression method not supported";
    registeredCodecs = /* @__PURE__ */ new Map();
    codecStreams = /* @__PURE__ */ new Map();
  }
});

// node_modules/@zip.js/zip.js/lib/core/streams/zip-entry-stream.js
function pipeThroughGzipDecompressionStream(readable, gzipStream, outputSize) {
  const crc32 = new Crc32();
  let outputLength = 0;
  let inputDone = false;
  let watchdogTimeout;
  let resolveTrailerReady, rejectTrailerReady;
  const trailerReady = new Promise((resolve, reject) => {
    resolveTrailerReady = resolve;
    rejectTrailerReady = reject;
  });
  trailerReady.catch(() => {
  });
  if (!outputSize) {
    resolveTrailerReady();
  }
  const gzipWrapStream = new TransformStream({
    start(controller) {
      const header = new Uint8Array(GZIP_HEADER_LENGTH);
      header.set(GZIP_HEADER_BYTES);
      controller.enqueue(header);
    },
    transform(chunk, controller) {
      controller.enqueue(chunk);
    },
    async flush(controller) {
      inputDone = true;
      startWatchdog();
      try {
        await trailerReady;
      } finally {
        stopWatchdog();
      }
      const trailer = new Uint8Array(GZIP_TRAILER_LENGTH);
      const dataView = getDataView(trailer);
      dataView.setUint32(0, crc32.get(), true);
      dataView.setUint32(4, outputSize, true);
      controller.enqueue(trailer);
    },
    cancel(reason) {
      rejectTrailerReady(reason);
    }
  });
  const outputStream = new TransformStream({
    transform(chunk, controller) {
      crc32.append(chunk);
      outputLength += chunk.length;
      if (outputLength >= outputSize) {
        resolveTrailerReady();
      } else if (inputDone) {
        startWatchdog();
      }
      controller.enqueue(chunk);
    },
    cancel(reason) {
      rejectTrailerReady(reason);
    }
  });
  readable = pipeThrough(readable, gzipWrapStream);
  readable = pipeThroughBackpressured(readable, gzipStream);
  return pipeThrough(readable, outputStream);
  function startWatchdog() {
    stopWatchdog();
    watchdogTimeout = setTimeout(() => rejectTrailerReady(new Error(ERR_INVALID_UNCOMPRESSED_SIZE)), GZIP_OUTPUT_STALL_TIMEOUT);
  }
  function stopWatchdog() {
    clearTimeout(watchdogTimeout);
  }
}
function supportsFormat(StreamClass, format) {
  if (!StreamClass) {
    return false;
  }
  let supportByFormat = formatSupportByStream.get(StreamClass);
  if (!supportByFormat) {
    supportByFormat = /* @__PURE__ */ new Map();
    formatSupportByStream.set(StreamClass, supportByFormat);
  }
  let supported = supportByFormat.get(format);
  if (supported === UNDEFINED_VALUE) {
    try {
      new StreamClass(format);
      supported = true;
    } catch {
      supported = false;
    }
    supportByFormat.set(format, supported);
  }
  return supported;
}
function supportsDeflateRaw(StreamClass) {
  return supportsFormat(StreamClass, FORMAT_DEFLATE_RAW);
}
function supportsGzip(StreamClass) {
  return supportsFormat(StreamClass, FORMAT_GZIP);
}
function setReadable(stream, readable, flush) {
  readable = pipeThrough(readable, new TransformStream({ flush }));
  Object.defineProperty(stream, "readable", {
    get() {
      return readable;
    }
  });
}
function createCodecStream(CodecStreamClass, format, options) {
  if (!CodecStreamClass) {
    throw new Error(ERR_UNSUPPORTED_COMPRESSION);
  }
  return new CodecStreamClass(format, options);
}
function pipeThroughCompressionStream(readable, useCompressionStream, options, CompressionStreamNative, CompressionStreamFallback) {
  const Stream2 = useCompressionStream && CompressionStreamNative ? CompressionStreamNative : CompressionStreamFallback || CompressionStreamNative;
  const format = options.deflate64 ? FORMAT_DEFLATE64_RAW : FORMAT_DEFLATE_RAW;
  let codecStream;
  try {
    codecStream = new Stream2(format, options);
  } catch (error) {
    if (useCompressionStream && CompressionStreamFallback && Stream2 != CompressionStreamFallback) {
      codecStream = new CompressionStreamFallback(format, options);
    } else {
      throw error;
    }
  }
  return pipeThroughBackpressured(readable, codecStream);
}
function pipeThrough(readable, transformStream) {
  return toCompatibleReadable(readable).pipeThrough(transformStream);
}
function pipeThroughBackpressured(readable, transformStream) {
  const writer = transformStream.writable.getWriter();
  const reader = readable.getReader();
  pump();
  return transformStream.readable;
  async function pump() {
    try {
      for (; ; ) {
        await writer.ready;
        const result = await reader.read();
        if (result.done) {
          await writer.close();
          break;
        }
        await writer.write(result.value);
      }
    } catch (error) {
      await abort(writer, error);
      await cancel(reader, error);
    }
  }
}
async function abort(writer, error) {
  try {
    await writer.abort(error);
  } catch {
  }
}
async function cancel(reader, error) {
  try {
    await reader.cancel(error);
  } catch {
  }
}
function mapInflateStreamError(readable) {
  const reader = readable.getReader();
  return new ReadableStream({
    async pull(controller) {
      let result;
      try {
        result = await reader.read();
      } catch (error) {
        if (error && error.message) {
          throw error;
        }
        const mappedError = new Error(ERR_INVALID_COMPRESSED_DATA);
        mappedError.cause = error;
        throw mappedError;
      }
      const { value, done } = result;
      if (done) {
        controller.close();
      } else {
        controller.enqueue(value);
      }
    },
    cancel(reason) {
      return reader.cancel(reason);
    }
  });
}
var ERR_INVALID_UNCOMPRESSED_SIZE, ERR_INVALID_COMPRESSED_DATA, ERR_INVALID_CRC32, FORMAT_DEFLATE_RAW, FORMAT_DEFLATE64_RAW, FORMAT_GZIP, GZIP_HEADER_LENGTH, GZIP_TRAILER_LENGTH, GZIP_HEADER_BYTES, GZIP_OUTPUT_STALL_TIMEOUT, DeflateStream, GzipToRawDeflateStream, InflateStream, formatSupportByStream;
var init_zip_entry_stream = __esm({
  "node_modules/@zip.js/zip.js/lib/core/streams/zip-entry-stream.js"() {
    init_crc32();
    init_crc32_stream();
    init_aes_crypto_stream();
    init_zip_crypto_stream();
    init_common_crypto();
    init_constants();
    init_array();
    init_compatible_streams();
    init_codec_registry();
    ERR_INVALID_UNCOMPRESSED_SIZE = "Invalid uncompressed size";
    ERR_INVALID_COMPRESSED_DATA = "Invalid compressed data";
    ERR_INVALID_CRC32 = "Invalid CRC32";
    FORMAT_DEFLATE_RAW = "deflate-raw";
    FORMAT_DEFLATE64_RAW = "deflate64-raw";
    FORMAT_GZIP = "gzip";
    GZIP_HEADER_LENGTH = 10;
    GZIP_TRAILER_LENGTH = 8;
    GZIP_HEADER_BYTES = [31, 139, 8];
    GZIP_OUTPUT_STALL_TIMEOUT = 5e3;
    DeflateStream = class extends TransformStream {
      constructor(options, { chunkSize, CompressionStreamFallback, CompressionStream: CompressionStream2 }) {
        super({});
        const { compressed, encrypted, useCompressionStream, zipCrypto, computeCrc32, level, deflate64, format, compressionMethod, inputSize } = options;
        const stream = this;
        let crc32Stream, encryptionStream, gzipCrc32Stream;
        let readable = super.readable;
        const codecStreams2 = format && getCodecStreams(format);
        const useGzipCrc32 = computeCrc32 && compressed && !deflate64 && !codecStreams2 && (!encrypted || zipCrypto) && Boolean(useCompressionStream && CompressionStream2);
        if ((!encrypted || zipCrypto) && computeCrc32 && !useGzipCrc32) {
          crc32Stream = new Crc32Stream();
          readable = pipeThrough(readable, crc32Stream);
        }
        if (compressed) {
          if (codecStreams2) {
            readable = pipeThroughBackpressured(readable, createCodecStream(codecStreams2.CompressionStream, format, { level, chunkSize, compressionMethod, uncompressedSize: inputSize }));
          } else if (useGzipCrc32) {
            gzipCrc32Stream = new GzipToRawDeflateStream();
            readable = pipeThroughBackpressured(readable, new CompressionStream2(FORMAT_GZIP));
            readable = pipeThrough(readable, gzipCrc32Stream);
          } else {
            try {
              readable = pipeThroughCompressionStream(readable, useCompressionStream, { level, chunkSize }, CompressionStream2, CompressionStreamFallback);
            } catch (error) {
              let gzipStream;
              try {
                gzipStream = new CompressionStream2(FORMAT_GZIP);
              } catch {
                throw error;
              }
              readable = pipeThroughBackpressured(readable, gzipStream);
              readable = pipeThrough(readable, new GzipToRawDeflateStream());
            }
          }
        }
        if (encrypted) {
          if (zipCrypto) {
            readable = pipeThrough(readable, new ZipCryptoEncryptionStream(options));
          } else {
            encryptionStream = new AESEncryptionStream(options);
            readable = pipeThrough(readable, encryptionStream);
          }
        }
        setReadable(stream, readable, () => {
          if ((!encrypted || zipCrypto) && computeCrc32) {
            stream.crc32 = useGzipCrc32 ? gzipCrc32Stream.crc32 : new DataView(crc32Stream.value.buffer).getUint32(0);
          }
        });
      }
    };
    GzipToRawDeflateStream = class extends TransformStream {
      constructor() {
        let stream;
        let headerBytesLeft = GZIP_HEADER_LENGTH;
        let trailerCandidate = new Uint8Array(0);
        super({
          transform(chunk, controller) {
            if (headerBytesLeft) {
              const droppedLength = Math.min(headerBytesLeft, chunk.length);
              headerBytesLeft -= droppedLength;
              chunk = chunk.subarray(droppedLength);
              if (!chunk.length) {
                return;
              }
            }
            const availableLength = trailerCandidate.length + chunk.length;
            if (availableLength <= GZIP_TRAILER_LENGTH) {
              trailerCandidate = concat(trailerCandidate, chunk);
              return;
            }
            const emitLength = availableLength - GZIP_TRAILER_LENGTH;
            const emittedFromTrailer = Math.min(emitLength, trailerCandidate.length);
            controller.enqueue(concat(
              trailerCandidate.subarray(0, emittedFromTrailer),
              chunk.subarray(0, emitLength - emittedFromTrailer)
            ));
            trailerCandidate = concat(
              trailerCandidate.subarray(emittedFromTrailer),
              chunk.subarray(emitLength - emittedFromTrailer)
            );
          },
          flush() {
            const dataView = getDataView(trailerCandidate);
            stream.crc32 = dataView.getUint32(0, true);
            stream.uncompressedSize = dataView.getUint32(4, true);
          }
        });
        stream = this;
      }
    };
    InflateStream = class extends TransformStream {
      constructor(options, { chunkSize, DecompressionStreamFallback, DecompressionStream: DecompressionStream2 }) {
        super({});
        const { zipCrypto, encrypted, checkCrc32, crc32, compressed, useCompressionStream, deflate64, format, compressionMethod, rawBitFlag, outputSize } = options;
        let crc32Stream, decryptionStream;
        let readable = super.readable;
        if (encrypted) {
          if (zipCrypto) {
            readable = pipeThrough(readable, new ZipCryptoDecryptionStream(options));
          } else {
            decryptionStream = new AESDecryptionStream(options);
            readable = pipeThrough(readable, decryptionStream);
          }
        }
        if (compressed) {
          const codecStreams2 = format && getCodecStreams(format);
          if (codecStreams2) {
            readable = pipeThroughBackpressured(readable, createCodecStream(codecStreams2.DecompressionStream, format, { chunkSize, compressionMethod, rawBitFlag, uncompressedSize: outputSize }));
          } else {
            try {
              readable = pipeThroughCompressionStream(readable, useCompressionStream, { chunkSize, deflate64 }, DecompressionStream2, DecompressionStreamFallback);
            } catch (error) {
              if (deflate64 || outputSize === UNDEFINED_VALUE) {
                throw error;
              }
              let gzipStream;
              try {
                gzipStream = new DecompressionStream2(FORMAT_GZIP);
              } catch {
                throw error;
              }
              readable = pipeThroughGzipDecompressionStream(readable, gzipStream, outputSize);
            }
          }
          readable = mapInflateStreamError(readable);
        }
        if (checkCrc32) {
          crc32Stream = new Crc32Stream();
          readable = pipeThrough(readable, crc32Stream);
        }
        setReadable(this, readable, () => {
          if (checkCrc32) {
            const computedCrc32View = new DataView(crc32Stream.value.buffer);
            if (crc32 != computedCrc32View.getUint32(0, false)) {
              throw new Error(ERR_INVALID_CRC32);
            }
          }
        });
      }
    };
    formatSupportByStream = /* @__PURE__ */ new Map();
  }
});

// node_modules/@zip.js/zip.js/lib/core/streams/codec-stream.js
var DEFAULT_CHUNK_SIZE2, MESSAGE_EVENT_TYPE, MESSAGE_START, MESSAGE_PULL, MESSAGE_DATA, MESSAGE_ACK_DATA, MESSAGE_CLOSE, CODEC_DEFLATE, CODEC_INFLATE, CodecStream, ChunkStream;
var init_codec_stream = __esm({
  "node_modules/@zip.js/zip.js/lib/core/streams/codec-stream.js"() {
    init_constants();
    init_zip_entry_stream();
    DEFAULT_CHUNK_SIZE2 = 64 * 1024;
    MESSAGE_EVENT_TYPE = "message";
    MESSAGE_START = "start";
    MESSAGE_PULL = "pull";
    MESSAGE_DATA = "data";
    MESSAGE_ACK_DATA = "ack";
    MESSAGE_CLOSE = "close";
    CODEC_DEFLATE = "deflate";
    CODEC_INFLATE = "inflate";
    CodecStream = class extends TransformStream {
      constructor(options, config2) {
        super({});
        const codec2 = this;
        const { codecType } = options;
        let Stream2;
        if (codecType.startsWith(CODEC_DEFLATE)) {
          Stream2 = DeflateStream;
        } else if (codecType.startsWith(CODEC_INFLATE)) {
          Stream2 = InflateStream;
        }
        codec2.outputSize = 0;
        let inputSize = 0;
        const stream = new Stream2(options, config2);
        const readable = super.readable;
        const inputSizeStream = new TransformStream({
          transform(chunk, controller) {
            if (chunk && chunk.length) {
              inputSize += chunk.length;
              controller.enqueue(chunk);
            }
          },
          flush() {
            Object.assign(codec2, {
              inputSize
            });
          }
        });
        const outputSizeStream = new TransformStream({
          transform(chunk, controller) {
            if (chunk && chunk.length) {
              controller.enqueue(chunk);
              codec2.outputSize += chunk.length;
              if (options.outputSize !== UNDEFINED_VALUE && codec2.outputSize > options.outputSize) {
                throw new Error(ERR_INVALID_UNCOMPRESSED_SIZE);
              }
            }
          },
          flush() {
            const { crc32 } = stream;
            Object.assign(codec2, {
              crc32,
              inputSize
            });
          }
        });
        Object.defineProperty(codec2, "readable", {
          get() {
            return readable.pipeThrough(inputSizeStream).pipeThrough(stream).pipeThrough(outputSizeStream);
          }
        });
      }
    };
    ChunkStream = class extends TransformStream {
      constructor(chunkSize) {
        const pendingChunks = [];
        let pendingLength = 0;
        let outputSize = 0;
        if (!Number.isFinite(chunkSize) || chunkSize < 1) {
          chunkSize = DEFAULT_CHUNK_SIZE2;
        }
        super({
          transform(chunk, controller) {
            pendingChunks.push(chunk);
            pendingLength += chunk.length;
            while (pendingLength > chunkSize) {
              outputSize += chunkSize;
              controller.enqueue(shiftChunk());
            }
          },
          flush(controller) {
            if (pendingLength) {
              outputSize += pendingLength;
              controller.enqueue(concatChunks(pendingChunks, pendingLength));
            }
          }
        });
        Object.defineProperty(this, "outputSize", {
          get: () => outputSize
        });
        function shiftChunk() {
          const result = new Uint8Array(chunkSize);
          let resultOffset = 0;
          while (resultOffset < chunkSize) {
            const firstChunk = pendingChunks[0];
            const remainingLength = chunkSize - resultOffset;
            if (firstChunk.length <= remainingLength) {
              result.set(firstChunk, resultOffset);
              resultOffset += firstChunk.length;
              pendingChunks.shift();
            } else {
              result.set(firstChunk.subarray(0, remainingLength), resultOffset);
              pendingChunks[0] = firstChunk.subarray(remainingLength);
              resultOffset += remainingLength;
            }
          }
          pendingLength -= chunkSize;
          return result;
        }
        function concatChunks(chunks, length) {
          const result = new Uint8Array(length);
          let offset = 0;
          for (const chunk of chunks) {
            result.set(chunk, offset);
            offset += chunk.length;
          }
          return result;
        }
      }
    };
  }
});

// node_modules/@zip.js/zip.js/lib/core/codec-worker.js
function configureWorker({ initModule: initModuleFunction }) {
  initModule = initModuleFunction;
}
function setWebWorkerBackend(backend) {
  webWorkerBackend = backend;
}
async function supportsDeflate(config2) {
  const { CompressionStream: NativeStream, CompressionStreamFallback: FallbackStream } = config2;
  if (FallbackStream && !FallbackStream.requiresModule) {
    return true;
  }
  if (supportsDeflateRaw(NativeStream) || supportsGzip(NativeStream)) {
    return true;
  }
  if (FallbackStream) {
    try {
      await initModule(config2);
      return true;
    } catch {
      return false;
    }
  }
  return false;
}
function disableWebWorker(workerData) {
  if (workerData.createWorker) {
    createWorkerFailed = true;
  } else {
    webWorkerSupported = false;
  }
}
async function callHandler(handler, ...parameters) {
  try {
    await handler(...parameters);
  } catch {
  }
}
function createWorkerInterface(workerData, config2) {
  return {
    run: () => runWorker(workerData, config2)
  };
}
async function runWorker({ options, readable, writable, onTaskFinished, workerOptions }, config2) {
  let codecStream, chunkStream;
  try {
    if (options.compressed && !options.format) {
      const deflate = options.codecType.startsWith(CODEC_DEFLATE);
      const FallbackStream = deflate ? config2.CompressionStreamFallback : config2.DecompressionStreamFallback;
      const NativeStream = deflate ? config2.CompressionStream : config2.DecompressionStream;
      if (!options.useCompressionStream) {
        try {
          await initModule(config2);
        } catch {
          if (!FallbackStream || FallbackStream.requiresModule) {
            options.useCompressionStream = true;
          }
        }
      } else if (FallbackStream && FallbackStream.requiresModule && !supportsDeflateRaw(NativeStream)) {
        try {
          await initModule(config2);
        } catch {
        }
      }
    }
    codecStream = new CodecStream(options, config2);
    chunkStream = new ChunkStream(getChunkSize(config2));
    await readable.pipeThrough(codecStream).pipeThrough(chunkStream).pipeTo(writable, { preventClose: true, preventAbort: true });
    const {
      crc32,
      inputSize,
      outputSize
    } = codecStream;
    return {
      crc32,
      inputSize,
      outputSize
    };
  } catch (error) {
    if (codecStream) {
      const outputSize = chunkStream ? chunkStream.outputSize : 0;
      workerOptions.outputSize = outputSize;
      if (isErrorObject(error)) {
        try {
          error.outputSize = outputSize;
        } catch {
        }
      }
    }
    throw error;
  } finally {
    onTaskFinished();
  }
}
var ERR_WORKER_STARTUP_TIMEOUT, webWorkerSupported, createWorkerFailed, webWorkerBackend, initModule, CodecWorker, ProgressWatcherStream;
var init_codec_worker = __esm({
  "node_modules/@zip.js/zip.js/lib/core/codec-worker.js"() {
    init_constants();
    init_configuration();
    init_error();
    init_codec_stream();
    ERR_WORKER_STARTUP_TIMEOUT = "Worker startup timeout";
    initModule = () => {
    };
    CodecWorker = class {
      constructor(workerData, { readable, writable }, workerOptions, onTaskFinished) {
        const { options, config: config2, streamOptions, useWebWorkers, transferStreams, workerURI } = workerOptions;
        let { createWorker } = workerOptions;
        const { signal } = streamOptions;
        if (createWorkerFailed) {
          createWorker = UNDEFINED_VALUE;
        }
        Object.assign(workerData, {
          busy: true,
          generation: (workerData.generation || 0) + 1,
          readable: readable.pipeThrough(new ChunkStream(getChunkSize(config2))).pipeThrough(new ProgressWatcherStream(streamOptions), { signal }),
          writable,
          options: Object.assign({}, options),
          workerOptions,
          workerURI,
          createWorker,
          transferStreams,
          terminate() {
            return new Promise((resolve) => {
              const { worker, busy } = workerData;
              if (worker) {
                if (busy) {
                  workerData.resolveTerminated = resolve;
                } else {
                  worker.terminate();
                  resolve();
                }
                workerData.interface = null;
              } else {
                resolve();
              }
            });
          },
          onTaskFinished() {
            if (workerData.busy) {
              const { resolveTerminated } = workerData;
              if (resolveTerminated) {
                workerData.resolveTerminated = null;
                workerData.terminated = true;
                workerData.worker.terminate();
                resolveTerminated();
              }
              workerData.busy = false;
              onTaskFinished(workerData);
            }
          }
        });
        if (webWorkerSupported === UNDEFINED_VALUE) {
          webWorkerSupported = typeof Worker != UNDEFINED_TYPE;
        }
        return (useWebWorkers && webWorkerBackend && (webWorkerSupported && workerURI || createWorker) ? webWorkerBackend : createWorkerInterface)(workerData, config2);
      }
    };
    ProgressWatcherStream = class extends TransformStream {
      constructor({ onstart, onprogress, size, onend }) {
        let chunkOffset = 0;
        super({
          async start() {
            if (onstart) {
              await callHandler(onstart, size);
            }
          },
          async transform(chunk, controller) {
            chunkOffset += chunk.length;
            if (onprogress) {
              await callHandler(onprogress, chunkOffset, size);
            }
            controller.enqueue(chunk);
          },
          async flush() {
            if (onend) {
              await callHandler(onend, chunkOffset);
            }
          }
        });
      }
    };
  }
});

// node_modules/@zip.js/zip.js/lib/core/codec-pool.js
async function runWorker2(stream, workerOptions) {
  const { options, config: config2 } = workerOptions;
  const { transferStreams, useWebWorkers, useCompressionStream, compressed, checkCrc32, computeCrc32, encrypted, format, codecURI } = options;
  const { workerURI, createWorker, maxWorkers: maxWorkers2 } = config2;
  if (format) {
    if (codecURI) {
      options.codecURI = resolveCodecURI(codecURI, config2.baseURI);
    }
    await ensureCodecStreams(format, options.codecURI);
  }
  workerOptions.transferStreams = !format && (transferStreams || transferStreams === UNDEFINED_VALUE && config2.transferStreams);
  const streamCopy = !compressed && !checkCrc32 && !computeCrc32 && !encrypted;
  const workerSupported = format === UNDEFINED_VALUE || Boolean(options.codecURI);
  workerOptions.useWebWorkers = !streamCopy && workerSupported && (useWebWorkers || useWebWorkers === UNDEFINED_VALUE && config2.useWebWorkers);
  workerOptions.workerURI = workerOptions.useWebWorkers && workerURI ? workerURI : UNDEFINED_VALUE;
  workerOptions.createWorker = workerOptions.useWebWorkers && createWorker ? createWorker : UNDEFINED_VALUE;
  options.useCompressionStream = useCompressionStream || useCompressionStream === UNDEFINED_VALUE && config2.useCompressionStream;
  return (await getWorker()).run();
  async function getWorker() {
    const workerData = pool.find((workerData2) => !workerData2.busy);
    if (workerData) {
      clearTerminateTimeout(workerData);
      return new CodecWorker(workerData, stream, workerOptions, onTaskFinished);
    } else if (pool.length < maxWorkers2) {
      const workerData2 = { indexWorker };
      indexWorker++;
      pool.push(workerData2);
      return new CodecWorker(workerData2, stream, workerOptions, onTaskFinished);
    } else {
      return new Promise((resolve) => {
        pendingRequests.push({ resolve, stream, workerOptions });
        starvationDelay = config2.workerStarvationTimeout;
        armStarvationTimeout();
      });
    }
  }
  function onTaskFinished(workerData) {
    clearStarvationTimeout();
    if (pendingRequests.length) {
      const [{ resolve, stream: stream2, workerOptions: workerOptions2 }] = pendingRequests.splice(0, 1);
      resolve(new CodecWorker(workerData, stream2, workerOptions2, onTaskFinished));
      armStarvationTimeout();
    } else if (workerData.worker) {
      clearTerminateTimeout(workerData);
      terminateWorker2(workerData, workerOptions);
    } else {
      pool = pool.filter((data) => data != workerData);
    }
  }
}
function resolveCodecURI(codecURI, baseURI) {
  try {
    return new URL(codecURI, baseURI).toString();
  } catch {
    return codecURI;
  }
}
function armStarvationTimeout() {
  if (!starvationTimeout && pendingRequests.length && Number.isFinite(starvationDelay) && starvationDelay >= 0) {
    starvationTimeout = setTimeout(onWorkerStarvation, starvationDelay);
  }
}
function clearStarvationTimeout() {
  if (starvationTimeout) {
    clearTimeout(starvationTimeout);
    starvationTimeout = null;
  }
}
function onWorkerStarvation() {
  starvationTimeout = null;
  if (pendingRequests.length) {
    const [{ resolve, stream, workerOptions }] = pendingRequests.splice(0, 1);
    const inlineWorkerOptions = Object.assign({}, workerOptions, { useWebWorkers: false, workerURI: UNDEFINED_VALUE, createWorker: UNDEFINED_VALUE });
    resolve(new CodecWorker({}, stream, inlineWorkerOptions, onInlineTaskFinished));
    armStarvationTimeout();
  }
}
function onInlineTaskFinished() {
  clearStarvationTimeout();
  armStarvationTimeout();
}
function terminateWorker2(workerData, workerOptions) {
  const { config: config2 } = workerOptions;
  const { terminateWorkerTimeout } = config2;
  if (Number.isFinite(terminateWorkerTimeout) && terminateWorkerTimeout >= 0) {
    if (workerData.terminated) {
      workerData.terminated = false;
    } else {
      workerData.terminateTimeout = setTimeout(async () => {
        pool = pool.filter((data) => data != workerData);
        try {
          await workerData.terminate();
        } catch {
        }
      }, terminateWorkerTimeout);
    }
  }
}
function clearTerminateTimeout(workerData) {
  const { terminateTimeout } = workerData;
  if (terminateTimeout) {
    clearTimeout(terminateTimeout);
    workerData.terminateTimeout = null;
  }
}
var pool, pendingRequests, starvationTimeout, starvationDelay, indexWorker;
var init_codec_pool = __esm({
  "node_modules/@zip.js/zip.js/lib/core/codec-pool.js"() {
    init_constants();
    init_codec_stream();
    init_codec_registry();
    init_codec_worker();
    pool = [];
    pendingRequests = [];
    indexWorker = 0;
  }
});

// node_modules/@zip.js/zip.js/lib/core/util/decode-cp437.js
function decodeCP437(stringValue) {
  let result = "";
  for (let indexCharacter = 0; indexCharacter < stringValue.length; indexCharacter++) {
    result += CP437[stringValue[indexCharacter]];
  }
  return result;
}
var CP437;
var init_decode_cp437 = __esm({
  "node_modules/@zip.js/zip.js/lib/core/util/decode-cp437.js"() {
    CP437 = "\0\u263A\u263B\u2665\u2666\u2663\u2660\u2022\u25D8\u25CB\u25D9\u2642\u2640\u266A\u266B\u263C\u25BA\u25C4\u2195\u203C\xB6\xA7\u25AC\u21A8\u2191\u2193\u2192\u2190\u221F\u2194\u25B2\u25BC !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u2302\xC7\xFC\xE9\xE2\xE4\xE0\xE5\xE7\xEA\xEB\xE8\xEF\xEE\xEC\xC4\xC5\xC9\xE6\xC6\xF4\xF6\xF2\xFB\xF9\xFF\xD6\xDC\xA2\xA3\xA5\u20A7\u0192\xE1\xED\xF3\xFA\xF1\xD1\xAA\xBA\xBF\u2310\xAC\xBD\xBC\xA1\xAB\xBB\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255D\u255C\u255B\u2510\u2514\u2534\u252C\u251C\u2500\u253C\u255E\u255F\u255A\u2554\u2569\u2566\u2560\u2550\u256C\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256B\u256A\u2518\u250C\u2588\u2584\u258C\u2590\u2580\u03B1\xDF\u0393\u03C0\u03A3\u03C3\xB5\u03C4\u03A6\u0398\u03A9\u03B4\u221E\u03C6\u03B5\u2229\u2261\xB1\u2265\u2264\u2320\u2321\xF7\u2248\xB0\u2219\xB7\u221A\u207F\xB2\u25A0\xA0".split("");
  }
});

// node_modules/@zip.js/zip.js/lib/core/util/decode-text.js
function decodeText(value, encoding) {
  return decode(value, encoding, true);
}
function decode(value, encoding, ignoreBOM) {
  if (encoding && encoding.trim().toLowerCase() == "cp437") {
    return decodeCP437(value);
  } else {
    return new TextDecoder(encoding, { ignoreBOM }).decode(value);
  }
}
var init_decode_text = __esm({
  "node_modules/@zip.js/zip.js/lib/core/util/decode-text.js"() {
    init_decode_cp437();
  }
});

// node_modules/@zip.js/zip.js/lib/core/io.js
function probeBlobSliceReliability() {
  blobSliceProbe = (async () => {
    try {
      const slicedBlob = new Blob([new Uint8Array(3)]).slice(1, 2);
      const streamReader = slicedBlob.stream().getReader();
      let streamedLength = 0;
      let result = await streamReader.read();
      while (!result.done) {
        streamedLength += result.value.length;
        result = await streamReader.read();
      }
      blobSliceReliable = streamedLength == 1;
    } catch {
      blobSliceReliable = false;
    }
  })();
}
function ownsWritable(writer) {
  return Boolean(writer && writer.getData);
}
async function initStream(stream, initSize) {
  if (stream.init && !stream.initialized) {
    await stream.init(initSize);
  } else {
    return Promise.resolve();
  }
}
async function initDiskReader(diskReader) {
  diskReader = new GenericReader(diskReader);
  await initStream(diskReader);
  if (diskReader.size === UNDEFINED_VALUE || !diskReader.readUint8Array) {
    diskReader = new BlobReader(await streamToBlob(diskReader.readable));
    await initStream(diskReader);
  }
  return diskReader;
}
function readUint8Array(reader, offset, size) {
  return reader.readUint8Array(offset, size);
}
function createReadable(reader, options) {
  if (reader.createReadable) {
    return reader.createReadable(options);
  } else if (reader.readUint8Array) {
    return Reader.prototype.createReadable.call(reader, options);
  } else {
    return reader.readable;
  }
}
var ERR_ITERATOR_COMPLETED_TOO_SOON, ERR_WRITER_NOT_INITIALIZED, ERR_WRITER_SIZE_NOT_WRITABLE, DEFAULT_BUFFER_SIZE, DEFAULT_MAXIMUM_RANGE_SIZE, PROPERTY_NAME_WRITABLE, DISK_BOUNDARY, Stream, Reader, Writer, blobSliceReliable, blobSliceProbe, BlobReader, BlobWriter, SplitDataReader, SplitDataWriter, GenericReader, GenericWriter;
var init_io = __esm({
  "node_modules/@zip.js/zip.js/lib/core/io.js"() {
    init_constants();
    init_configuration();
    init_array();
    init_compatible_streams();
    init_decode_text();
    ERR_ITERATOR_COMPLETED_TOO_SOON = "Writer iterator completed too soon";
    ERR_WRITER_NOT_INITIALIZED = "Writer not initialized";
    ERR_WRITER_SIZE_NOT_WRITABLE = "Invalid writer (size must be writable)";
    DEFAULT_BUFFER_SIZE = 256 * 1024;
    DEFAULT_MAXIMUM_RANGE_SIZE = 16 * 1024 * 1024;
    PROPERTY_NAME_WRITABLE = "writable";
    DISK_BOUNDARY = /* @__PURE__ */ Symbol();
    Stream = class {
      constructor() {
        this.size = 0;
      }
      init() {
        this.initialized = true;
      }
    };
    Reader = class extends Stream {
      get readable() {
        return this.createReadable();
      }
      createReadable({ offset = 0, size, chunkSize = getChunkSize(getConfiguration()) } = {}) {
        const reader = this;
        let chunkOffset = 0;
        chunkSize = normalizeChunkSize(chunkSize);
        return new ReadableStream({
          async pull(controller) {
            const dataSize = size === UNDEFINED_VALUE ? chunkSize : Math.min(chunkSize, size - chunkOffset);
            const data = await readUint8Array(reader, offset + chunkOffset, dataSize);
            if (data.length) {
              controller.enqueue(data);
              chunkOffset += data.length;
            }
            if (size !== UNDEFINED_VALUE && chunkOffset >= size || !data.length && dataSize) {
              controller.close();
            }
          }
        });
      }
    };
    Writer = class extends Stream {
      constructor() {
        super();
        const writer = this;
        const writable = new WritableStream({
          write(chunk) {
            if (!writer.initialized) {
              throw new Error(ERR_WRITER_NOT_INITIALIZED);
            }
            return writer.writeUint8Array(toExactUint8Array(chunk));
          }
        });
        Object.defineProperty(writer, PROPERTY_NAME_WRITABLE, {
          get() {
            return writable;
          }
        });
      }
      writeUint8Array() {
      }
    };
    BlobReader = class extends Reader {
      constructor(blob) {
        super();
        Object.assign(this, {
          sourceBlob: blob,
          size: blob.size
        });
        if (!blobSliceProbe) {
          probeBlobSliceReliability();
        }
      }
      createReadable(options) {
        const reader = this;
        const { sourceBlob, size } = reader;
        const { offset = 0, size: readSize = size - offset } = options || {};
        if (typeof sourceBlob.stream == FUNCTION_TYPE) {
          if (!offset && readSize >= size) {
            return toCompatibleReadable(sourceBlob.stream());
          }
          if (blobSliceReliable) {
            return toCompatibleReadable(sourceBlob.slice(offset, offset + readSize).stream());
          }
        }
        return super.createReadable(options);
      }
      async readUint8Array(offset, length) {
        const reader = this;
        const offsetEnd = offset + length;
        const readsWholeBlob = !offset && offsetEnd >= reader.size;
        const blob = readsWholeBlob ? reader.sourceBlob : reader.sourceBlob.slice(offset, offsetEnd);
        let arrayBuffer = await blob.arrayBuffer();
        const sliceIgnoredByBuggyImplementation = arrayBuffer.byteLength > length;
        if (sliceIgnoredByBuggyImplementation) {
          arrayBuffer = arrayBuffer.slice(offset, offsetEnd);
        }
        return new Uint8Array(arrayBuffer);
      }
    };
    BlobWriter = class extends Stream {
      constructor(contentType) {
        super();
        const writer = this;
        const transformStream = new TransformStream();
        Object.defineProperty(writer, PROPERTY_NAME_WRITABLE, {
          get() {
            return transformStream.writable;
          }
        });
        writer.contentType = contentType;
        writer.blobPromise = streamToBlob(transformStream.readable, contentType);
        writer.blobPromise.catch(() => {
        });
      }
      getData() {
        return this.blobPromise;
      }
    };
    SplitDataReader = class extends Reader {
      constructor(readers) {
        super();
        this.readers = readers;
      }
      async init() {
        const reader = this;
        reader.lastDiskNumber = 0;
        const readers = reader.readers = await Promise.all(reader.readers.map(initDiskReader));
        reader.diskOffsets = readers.map((diskReader) => {
          const diskOffset = reader.size;
          reader.size += diskReader.size;
          return diskOffset;
        });
        super.init();
      }
      getDiskOffset(diskNumber) {
        const { diskOffsets, size } = this;
        const diskOffset = diskOffsets[diskNumber];
        return diskOffset === UNDEFINED_VALUE ? size : diskOffset;
      }
      async readUint8Array(offset, length) {
        const reader = this;
        const { readers } = this;
        let result;
        let currentDiskNumber = 0;
        let currentReaderOffset = offset;
        while (readers[currentDiskNumber] && currentReaderOffset >= readers[currentDiskNumber].size) {
          currentReaderOffset -= readers[currentDiskNumber].size;
          currentDiskNumber++;
        }
        const currentReader = readers[currentDiskNumber];
        if (currentReader) {
          const currentReaderSize = currentReader.size;
          if (currentReaderOffset + length <= currentReaderSize) {
            result = await readUint8Array(currentReader, currentReaderOffset, length);
          } else {
            const chunkLength = currentReaderSize - currentReaderOffset;
            const firstPart = await readUint8Array(currentReader, currentReaderOffset, chunkLength);
            const secondPart = await reader.readUint8Array(offset + chunkLength, length - chunkLength);
            result = concat(firstPart, secondPart);
          }
        } else {
          result = EMPTY_UINT8_ARRAY;
        }
        reader.lastDiskNumber = Math.max(currentDiskNumber, reader.lastDiskNumber);
        return result;
      }
    };
    SplitDataWriter = class extends Stream {
      constructor(writerGenerator, maxSize = 4294967295) {
        super();
        const writer = this;
        Object.assign(writer, {
          diskNumber: 0,
          diskOffset: 0,
          size: 0,
          maxSize,
          availableSize: maxSize
        });
        let diskSourceWriter, diskWritable, diskWriter;
        const writable = new WritableStream({
          async write(chunk) {
            if (chunk === DISK_BOUNDARY) {
              if (diskWriter) {
                await endDisk();
              }
              return;
            }
            const { availableSize } = writer;
            if (!diskWriter) {
              const { value, done } = await writerGenerator.next();
              if (done && !value) {
                throw new Error(ERR_ITERATOR_COMPLETED_TOO_SOON);
              } else {
                diskSourceWriter = value;
                diskSourceWriter.size = 0;
                if (diskSourceWriter.maxSize) {
                  writer.maxSize = diskSourceWriter.maxSize;
                }
                writer.availableSize = writer.maxSize;
                await initStream(diskSourceWriter);
                diskWritable = value.writable;
                diskWriter = diskWritable.getWriter();
              }
              await this.write(chunk);
            } else if (chunk.length >= availableSize) {
              await writeChunk(chunk.subarray(0, availableSize));
              await endDisk();
              if (chunk.length > availableSize) {
                await this.write(chunk.subarray(availableSize));
              }
            } else {
              await writeChunk(chunk);
            }
          },
          async close() {
            if (diskWriter) {
              await diskWriter.ready;
              await closeDiskWriter();
            }
          },
          async abort(reason) {
            if (diskWriter) {
              await diskWriter.abort(reason);
            }
          }
        });
        Object.defineProperty(writer, PROPERTY_NAME_WRITABLE, {
          get() {
            return writable;
          }
        });
        async function writeChunk(chunk) {
          const chunkLength = chunk.length;
          if (chunkLength) {
            await diskWriter.ready;
            await diskWriter.write(chunk);
            diskSourceWriter.size += chunkLength;
            writer.availableSize -= chunkLength;
          }
        }
        async function endDisk() {
          await closeDiskWriter();
          writer.diskOffset += diskSourceWriter.size;
          writer.diskNumber++;
          diskWriter = null;
          writer.availableSize = writer.maxSize;
        }
        async function closeDiskWriter() {
          await diskWriter.close();
        }
      }
      async closeDisk() {
        const streamWriter = this.writable.getWriter();
        try {
          await streamWriter.ready;
          await streamWriter.write(DISK_BOUNDARY);
        } finally {
          streamWriter.releaseLock();
        }
      }
    };
    GenericReader = class {
      constructor(reader) {
        if (Array.isArray(reader)) {
          reader = new SplitDataReader(reader);
        }
        if (reader instanceof ReadableStream || typeof reader.getReader == FUNCTION_TYPE) {
          reader = {
            readable: toCompatibleReadable(reader)
          };
        }
        return reader;
      }
    };
    GenericWriter = class {
      constructor(writer) {
        if (writer.writable === UNDEFINED_VALUE && typeof writer.next == FUNCTION_TYPE) {
          writer = new SplitDataWriter(writer);
        }
        if (writer instanceof WritableStream || typeof writer.getWriter == FUNCTION_TYPE) {
          writer = {
            writable: toCompatibleWritable(writer)
          };
        }
        try {
          writer.size = writer.size === UNDEFINED_VALUE ? 0 : writer.size;
        } catch {
          throw new Error(ERR_WRITER_SIZE_NOT_WRITABLE);
        }
        return writer;
      }
    };
  }
});

// node_modules/@zip.js/zip.js/lib/core/util/warnings.js
function addWarning(warnings, reason, filename) {
  if (!warnings.some((warning) => warning.reason == reason)) {
    const warning = { reason };
    if (filename !== UNDEFINED_VALUE) {
      warning.filename = filename;
    }
    warnings.push(warning);
  }
}
var init_warnings = __esm({
  "node_modules/@zip.js/zip.js/lib/core/util/warnings.js"() {
    init_constants();
  }
});

// node_modules/@zip.js/zip.js/lib/core/zip-entry.js
function getUserExtraField(extraField) {
  if (extraField) {
    const userExtraField = /* @__PURE__ */ new Map();
    extraField.forEach((field, type) => {
      if (!INTERPRETED_EXTRA_FIELD_TYPES.has(type)) {
        userExtraField.set(type, field.data);
      }
    });
    if (userExtraField.size) {
      return userExtraField;
    }
  }
}
function getEncryptionOverhead(encrypted, zipCrypto, encryptionStrength) {
  return encrypted ? zipCrypto ? 12 : 16 + encryptionStrength * 4 : 0;
}
var PROPERTY_NAME_FILENAME, PROPERTY_NAME_RAW_FILENAME, PROPERTY_NAME_COMMENT, PROPERTY_NAME_RAW_COMMENT, PROPERTY_NAME_UNCOMPRESSED_SIZE, PROPERTY_NAME_COMPRESSED_SIZE, PROPERTY_NAME_OFFSET, PROPERTY_NAME_DISK_NUMBER_START, PROPERTY_NAME_LAST_MODIFICATION_DATE, PROPERTY_NAME_RAW_LAST_MODIFICATION_DATE, PROPERTY_NAME_LAST_ACCESS_DATE, PROPERTY_NAME_RAW_LAST_ACCESS_DATE, PROPERTY_NAME_CREATION_DATE, PROPERTY_NAME_RAW_CREATION_DATE, PROPERTY_NAME_INTERNAL_FILE_ATTRIBUTES, PROPERTY_NAME_EXTERNAL_FILE_ATTRIBUTES, PROPERTY_NAME_MSDOS_ATTRIBUTES_RAW, PROPERTY_NAME_MSDOS_ATTRIBUTES, PROPERTY_NAME_MS_DOS_COMPATIBLE, PROPERTY_NAME_ZIP64, PROPERTY_NAME_ENCRYPTED, PROPERTY_NAME_VERSION, PROPERTY_NAME_VERSION_MADE_BY, PROPERTY_NAME_ZIPCRYPTO, PROPERTY_NAME_DIRECTORY, PROPERTY_NAME_EXECUTABLE, PROPERTY_NAME_SYMLINK, PROPERTY_NAME_COMPRESSION_METHOD, PROPERTY_NAME_SIGNATURE, PROPERTY_NAME_CRC32, PROPERTY_NAME_EXTRA_FIELD, PROPERTY_NAME_EXTRA_FIELD_INFOZIP, PROPERTY_NAME_EXTRA_FIELD_UNIX, PROPERTY_NAME_EXTRA_FIELD_UNIX_TYPE1, PROPERTY_NAME_EXTRA_FIELD_PKWARE_UNIX, PROPERTY_NAME_UID, PROPERTY_NAME_GID, PROPERTY_NAME_UNIX_MODE, PROPERTY_NAME_SETUID, PROPERTY_NAME_SETGID, PROPERTY_NAME_STICKY, PROPERTY_NAME_BITFLAG, PROPERTY_NAME_RAW_BITFLAG, PROPERTY_NAME_FILENAME_LENGTH, PROPERTY_NAME_EXTRA_FIELD_LENGTH, PROPERTY_NAME_UNIX_EXTERNAL_UPPER, PROPERTY_NAME_FILENAME_UTF8, PROPERTY_NAME_COMMENT_UTF8, PROPERTY_NAME_RAW_EXTRA_FIELD, PROPERTY_NAME_EXTRA_FIELD_ZIP64, PROPERTY_NAME_EXTRA_FIELD_UNICODE_PATH, PROPERTY_NAME_EXTRA_FIELD_UNICODE_COMMENT, PROPERTY_NAME_EXTRA_FIELD_AES, PROPERTY_NAME_EXTRA_FIELD_NTFS, PROPERTY_NAME_EXTRA_FIELD_EXTENDED_TIMESTAMP, PROPERTY_NAME_EXTRA_FIELD_USDZ, PROPERTY_NAMES, Entry, INTERPRETED_EXTRA_FIELD_TYPES;
var init_zip_entry = __esm({
  "node_modules/@zip.js/zip.js/lib/core/zip-entry.js"() {
    init_constants();
    PROPERTY_NAME_FILENAME = "filename";
    PROPERTY_NAME_RAW_FILENAME = "rawFilename";
    PROPERTY_NAME_COMMENT = "comment";
    PROPERTY_NAME_RAW_COMMENT = "rawComment";
    PROPERTY_NAME_UNCOMPRESSED_SIZE = "uncompressedSize";
    PROPERTY_NAME_COMPRESSED_SIZE = "compressedSize";
    PROPERTY_NAME_OFFSET = "offset";
    PROPERTY_NAME_DISK_NUMBER_START = "diskNumberStart";
    PROPERTY_NAME_LAST_MODIFICATION_DATE = "lastModDate";
    PROPERTY_NAME_RAW_LAST_MODIFICATION_DATE = "rawLastModDate";
    PROPERTY_NAME_LAST_ACCESS_DATE = "lastAccessDate";
    PROPERTY_NAME_RAW_LAST_ACCESS_DATE = "rawLastAccessDate";
    PROPERTY_NAME_CREATION_DATE = "creationDate";
    PROPERTY_NAME_RAW_CREATION_DATE = "rawCreationDate";
    PROPERTY_NAME_INTERNAL_FILE_ATTRIBUTES = "internalFileAttributes";
    PROPERTY_NAME_EXTERNAL_FILE_ATTRIBUTES = "externalFileAttributes";
    PROPERTY_NAME_MSDOS_ATTRIBUTES_RAW = "msdosAttributesRaw";
    PROPERTY_NAME_MSDOS_ATTRIBUTES = "msdosAttributes";
    PROPERTY_NAME_MS_DOS_COMPATIBLE = "msDosCompatible";
    PROPERTY_NAME_ZIP64 = "zip64";
    PROPERTY_NAME_ENCRYPTED = "encrypted";
    PROPERTY_NAME_VERSION = "version";
    PROPERTY_NAME_VERSION_MADE_BY = "versionMadeBy";
    PROPERTY_NAME_ZIPCRYPTO = "zipCrypto";
    PROPERTY_NAME_DIRECTORY = "directory";
    PROPERTY_NAME_EXECUTABLE = "executable";
    PROPERTY_NAME_SYMLINK = "symlink";
    PROPERTY_NAME_COMPRESSION_METHOD = "compressionMethod";
    PROPERTY_NAME_SIGNATURE = "signature";
    PROPERTY_NAME_CRC32 = "crc32";
    PROPERTY_NAME_EXTRA_FIELD = "extraField";
    PROPERTY_NAME_EXTRA_FIELD_INFOZIP = "extraFieldInfoZip";
    PROPERTY_NAME_EXTRA_FIELD_UNIX = "extraFieldUnix";
    PROPERTY_NAME_EXTRA_FIELD_UNIX_TYPE1 = "extraFieldUnixType1";
    PROPERTY_NAME_EXTRA_FIELD_PKWARE_UNIX = "extraFieldPkwareUnix";
    PROPERTY_NAME_UID = "uid";
    PROPERTY_NAME_GID = "gid";
    PROPERTY_NAME_UNIX_MODE = "unixMode";
    PROPERTY_NAME_SETUID = "setuid";
    PROPERTY_NAME_SETGID = "setgid";
    PROPERTY_NAME_STICKY = "sticky";
    PROPERTY_NAME_BITFLAG = "bitFlag";
    PROPERTY_NAME_RAW_BITFLAG = "rawBitFlag";
    PROPERTY_NAME_FILENAME_LENGTH = "filenameLength";
    PROPERTY_NAME_EXTRA_FIELD_LENGTH = "extraFieldLength";
    PROPERTY_NAME_UNIX_EXTERNAL_UPPER = "unixExternalUpper";
    PROPERTY_NAME_FILENAME_UTF8 = "filenameUTF8";
    PROPERTY_NAME_COMMENT_UTF8 = "commentUTF8";
    PROPERTY_NAME_RAW_EXTRA_FIELD = "rawExtraField";
    PROPERTY_NAME_EXTRA_FIELD_ZIP64 = "extraFieldZip64";
    PROPERTY_NAME_EXTRA_FIELD_UNICODE_PATH = "extraFieldUnicodePath";
    PROPERTY_NAME_EXTRA_FIELD_UNICODE_COMMENT = "extraFieldUnicodeComment";
    PROPERTY_NAME_EXTRA_FIELD_AES = "extraFieldAES";
    PROPERTY_NAME_EXTRA_FIELD_NTFS = "extraFieldNTFS";
    PROPERTY_NAME_EXTRA_FIELD_EXTENDED_TIMESTAMP = "extraFieldExtendedTimestamp";
    PROPERTY_NAME_EXTRA_FIELD_USDZ = "extraFieldUSDZ";
    PROPERTY_NAMES = [
      PROPERTY_NAME_FILENAME,
      PROPERTY_NAME_RAW_FILENAME,
      PROPERTY_NAME_UNCOMPRESSED_SIZE,
      PROPERTY_NAME_COMPRESSED_SIZE,
      PROPERTY_NAME_LAST_MODIFICATION_DATE,
      PROPERTY_NAME_RAW_LAST_MODIFICATION_DATE,
      PROPERTY_NAME_COMMENT,
      PROPERTY_NAME_RAW_COMMENT,
      PROPERTY_NAME_LAST_ACCESS_DATE,
      PROPERTY_NAME_RAW_LAST_ACCESS_DATE,
      PROPERTY_NAME_CREATION_DATE,
      PROPERTY_NAME_RAW_CREATION_DATE,
      PROPERTY_NAME_OFFSET,
      PROPERTY_NAME_DISK_NUMBER_START,
      PROPERTY_NAME_INTERNAL_FILE_ATTRIBUTES,
      PROPERTY_NAME_EXTERNAL_FILE_ATTRIBUTES,
      PROPERTY_NAME_MSDOS_ATTRIBUTES_RAW,
      PROPERTY_NAME_MSDOS_ATTRIBUTES,
      PROPERTY_NAME_MS_DOS_COMPATIBLE,
      PROPERTY_NAME_ZIP64,
      PROPERTY_NAME_ENCRYPTED,
      PROPERTY_NAME_VERSION,
      PROPERTY_NAME_VERSION_MADE_BY,
      PROPERTY_NAME_ZIPCRYPTO,
      PROPERTY_NAME_DIRECTORY,
      PROPERTY_NAME_EXECUTABLE,
      PROPERTY_NAME_SYMLINK,
      PROPERTY_NAME_COMPRESSION_METHOD,
      PROPERTY_NAME_SIGNATURE,
      PROPERTY_NAME_CRC32,
      PROPERTY_NAME_EXTRA_FIELD,
      PROPERTY_NAME_EXTRA_FIELD_UNIX,
      PROPERTY_NAME_EXTRA_FIELD_INFOZIP,
      PROPERTY_NAME_EXTRA_FIELD_UNIX_TYPE1,
      PROPERTY_NAME_EXTRA_FIELD_PKWARE_UNIX,
      PROPERTY_NAME_UID,
      PROPERTY_NAME_GID,
      PROPERTY_NAME_UNIX_MODE,
      PROPERTY_NAME_UNIX_EXTERNAL_UPPER,
      PROPERTY_NAME_SETUID,
      PROPERTY_NAME_SETGID,
      PROPERTY_NAME_STICKY,
      PROPERTY_NAME_BITFLAG,
      PROPERTY_NAME_RAW_BITFLAG,
      PROPERTY_NAME_FILENAME_LENGTH,
      PROPERTY_NAME_EXTRA_FIELD_LENGTH,
      PROPERTY_NAME_FILENAME_UTF8,
      PROPERTY_NAME_COMMENT_UTF8,
      PROPERTY_NAME_RAW_EXTRA_FIELD,
      PROPERTY_NAME_EXTRA_FIELD_ZIP64,
      PROPERTY_NAME_EXTRA_FIELD_UNICODE_PATH,
      PROPERTY_NAME_EXTRA_FIELD_UNICODE_COMMENT,
      PROPERTY_NAME_EXTRA_FIELD_AES,
      PROPERTY_NAME_EXTRA_FIELD_NTFS,
      PROPERTY_NAME_EXTRA_FIELD_EXTENDED_TIMESTAMP,
      PROPERTY_NAME_EXTRA_FIELD_USDZ
    ];
    Entry = class {
      constructor(data) {
        PROPERTY_NAMES.forEach((name) => this[name] = data[name]);
      }
    };
    INTERPRETED_EXTRA_FIELD_TYPES = /* @__PURE__ */ new Set([
      EXTRAFIELD_TYPE_ZIP64,
      EXTRAFIELD_TYPE_AES,
      EXTRAFIELD_TYPE_NTFS,
      EXTRAFIELD_TYPE_EXTENDED_TIMESTAMP,
      EXTRAFIELD_TYPE_UNICODE_PATH,
      EXTRAFIELD_TYPE_UNICODE_COMMENT,
      EXTRAFIELD_TYPE_USDZ,
      EXTRAFIELD_TYPE_INFOZIP,
      EXTRAFIELD_TYPE_UNIX,
      EXTRAFIELD_TYPE_UNIX_TYPE1,
      EXTRAFIELD_TYPE_PKWARE_UNIX
    ]);
  }
});

// node_modules/@zip.js/zip.js/lib/core/zip-reader.js
var zip_reader_exports = {};
__export(zip_reader_exports, {
  ERR_AMBIGUOUS_ARCHIVE: () => ERR_AMBIGUOUS_ARCHIVE,
  ERR_BAD_FORMAT: () => ERR_BAD_FORMAT,
  ERR_CENTRAL_DIRECTORY_NOT_FOUND: () => ERR_CENTRAL_DIRECTORY_NOT_FOUND,
  ERR_ENCRYPTED: () => ERR_ENCRYPTED,
  ERR_ENCRYPTED_CENTRAL_DIRECTORY: () => ERR_ENCRYPTED_CENTRAL_DIRECTORY,
  ERR_ENTRY_DATA_OUT_OF_BOUNDS: () => ERR_ENTRY_DATA_OUT_OF_BOUNDS,
  ERR_EOCDR_LOCATOR_ZIP64_NOT_FOUND: () => ERR_EOCDR_LOCATOR_ZIP64_NOT_FOUND,
  ERR_EOCDR_NOT_FOUND: () => ERR_EOCDR_NOT_FOUND,
  ERR_EXTRAFIELD_ZIP64_NOT_FOUND: () => ERR_EXTRAFIELD_ZIP64_NOT_FOUND,
  ERR_INVALID_AUTHENTICATION_CODE: () => ERR_INVALID_AUTHENTICATION_CODE,
  ERR_INVALID_COMPRESSED_DATA: () => ERR_INVALID_COMPRESSED_DATA,
  ERR_INVALID_CRC32: () => ERR_INVALID_CRC32,
  ERR_INVALID_FILENAME_VALIDATION: () => ERR_INVALID_FILENAME_VALIDATION,
  ERR_INVALID_MAX_APPENDED_DATA_SIZE: () => ERR_INVALID_MAX_APPENDED_DATA_SIZE,
  ERR_INVALID_PASSWORD: () => ERR_INVALID_PASSWORD,
  ERR_INVALID_STRICTNESS: () => ERR_INVALID_STRICTNESS,
  ERR_INVALID_UNCOMPRESSED_SIZE: () => ERR_INVALID_UNCOMPRESSED_SIZE,
  ERR_LOCAL_FILE_HEADER_NOT_FOUND: () => ERR_LOCAL_FILE_HEADER_NOT_FOUND,
  ERR_OVERLAPPING_ENTRY: () => ERR_OVERLAPPING_ENTRY,
  ERR_SPLIT_ZIP_FILE: () => ERR_SPLIT_ZIP_FILE,
  ERR_UNSAFE_FILENAME: () => ERR_UNSAFE_FILENAME,
  ERR_UNSUPPORTED_COMPRESSION: () => ERR_UNSUPPORTED_COMPRESSION,
  ERR_UNSUPPORTED_ENCRYPTION: () => ERR_UNSUPPORTED_ENCRYPTION,
  ERR_UNSUPPORTED_UINT64: () => ERR_UNSUPPORTED_UINT64,
  ERR_WORKER_STARTUP_TIMEOUT: () => ERR_WORKER_STARTUP_TIMEOUT,
  WARNING_APPENDED_DATA: () => WARNING_APPENDED_DATA,
  WARNING_COMPRESSED_PATCHED_DATA: () => WARNING_COMPRESSED_PATCHED_DATA,
  WARNING_DUPLICATE_FILENAME: () => WARNING_DUPLICATE_FILENAME,
  WARNING_MALFORMED_EXTRA_FIELD: () => WARNING_MALFORMED_EXTRA_FIELD,
  WARNING_MISMATCHED_LOCAL_FILE_HEADER_BIT_FLAG: () => WARNING_MISMATCHED_LOCAL_FILE_HEADER_BIT_FLAG,
  WARNING_MISMATCHED_LOCAL_FILE_HEADER_COMPRESSION_METHOD: () => WARNING_MISMATCHED_LOCAL_FILE_HEADER_COMPRESSION_METHOD,
  WARNING_MISMATCHED_LOCAL_FILE_HEADER_CRC32_OR_SIZES: () => WARNING_MISMATCHED_LOCAL_FILE_HEADER_CRC32_OR_SIZES,
  WARNING_MISMATCHED_LOCAL_FILE_HEADER_FILENAME: () => WARNING_MISMATCHED_LOCAL_FILE_HEADER_FILENAME,
  WARNING_MISMATCHED_ZIP64_END_OF_CENTRAL_DIRECTORY: () => WARNING_MISMATCHED_ZIP64_END_OF_CENTRAL_DIRECTORY,
  WARNING_MULTIPLE_END_OF_CENTRAL_DIRECTORY: () => WARNING_MULTIPLE_END_OF_CENTRAL_DIRECTORY,
  WARNING_PREPENDED_CENTRAL_DIRECTORY: () => WARNING_PREPENDED_CENTRAL_DIRECTORY,
  WARNING_PREPENDED_DATA: () => WARNING_PREPENDED_DATA,
  WARNING_TRAILING_CENTRAL_DIRECTORY_DATA: () => WARNING_TRAILING_CENTRAL_DIRECTORY_DATA,
  WARNING_UNKNOWN_VERSION: () => WARNING_UNKNOWN_VERSION,
  WARNING_UNKNOWN_ZIP64_EXTENSIBLE_DATA: () => WARNING_UNKNOWN_ZIP64_EXTENSIBLE_DATA,
  WARNING_UNSORTED_CENTRAL_DIRECTORY: () => WARNING_UNSORTED_CENTRAL_DIRECTORY,
  WARNING_WRAPPED_ENTRIES_COUNT: () => WARNING_WRAPPED_ENTRIES_COUNT,
  ZipReader: () => ZipReader,
  ZipReaderStream: () => ZipReaderStream,
  isZipFile: () => isZipFile
});
function createEntryStream(entry, pendingEntries2) {
  const { readable, writable } = new TransformStream();
  let dataReader;
  const entryStream = {
    cancel: async (reason) => {
      pendingEntries2.delete(entryStream);
      await (dataReader ? dataReader.cancel(reason) : readable.cancel(reason));
    }
  };
  entryStream.readable = new ReadableStream({
    async pull(controller) {
      if (!dataReader) {
        dataReader = readable.getReader();
        pendingEntries2.add(entryStream);
        getData();
      }
      const { done, value } = await dataReader.read();
      if (done) {
        controller.close();
      } else {
        controller.enqueue(value);
      }
    },
    cancel: (reason) => entryStream.cancel(reason)
  }, { highWaterMark: 0 });
  return entryStream;
  async function getData() {
    try {
      await entry.getData(writable, { preventClose: false });
    } catch (error) {
      try {
        await writable.abort(error);
      } catch {
      }
    } finally {
      pendingEntries2.delete(entryStream);
    }
  }
}
async function isZipFile(reader, options = {}) {
  reader = new GenericReader(reader);
  await initStream(reader);
  if (reader.size === UNDEFINED_VALUE || !reader.readUint8Array) {
    reader = new BlobReader(await streamToBlob(reader.readable));
    await initStream(reader);
  }
  if (reader.size < END_OF_CENTRAL_DIR_LENGTH) {
    return false;
  }
  const strictness = getStrictness(options, {});
  const rejectAmbiguousEndOfDirectory = strictness != STRICTNESS_TOLERANT;
  const maxAppendedDataSize = getMaxAppendedDataSize(options[OPTION_MAX_APPENDED_DATA_SIZE], strictness);
  const { endOfDirectoryInfo, endOfDirectoryReachingEndCount } = await findEndOfCentralDirectory(reader, rejectAmbiguousEndOfDirectory, maxAppendedDataSize);
  if (!endOfDirectoryInfo || strictness == STRICTNESS_STRICT && endOfDirectoryReachingEndCount > 1) {
    return false;
  }
  const commentLength = getUint16(getDataView(endOfDirectoryInfo), 20);
  const appendedDataOffset = endOfDirectoryInfo.offset + END_OF_CENTRAL_DIR_LENGTH + commentLength;
  return reader.size - appendedDataOffset <= maxAppendedDataSize;
}
function detectEncryptedCentralDirectory(directoryView) {
  const maxOffset = Math.min(directoryView.byteLength, 1024) - 3;
  for (let offset = 0; offset < maxOffset; offset++) {
    if (getUint32(directoryView, offset) == ARCHIVE_EXTRA_DATA_SIGNATURE) {
      return true;
    }
  }
  return false;
}
function getWrappedFilesLength(directoryView, directoryArray, offset) {
  let wrappedFilesLength = 0;
  while (offset + CENTRAL_FILE_HEADER_LENGTH <= directoryArray.length && getUint32(directoryView, offset) == CENTRAL_FILE_HEADER_SIGNATURE) {
    offset += CENTRAL_FILE_HEADER_LENGTH + getUint16(directoryView, offset + 28) + getUint16(directoryView, offset + 30) + getUint16(directoryView, offset + 32);
    wrappedFilesLength++;
  }
  return wrappedFilesLength % (MAX_16_BITS + 1) ? 0 : wrappedFilesLength;
}
function readDigitalSignature(signatureRecordArray) {
  if (signatureRecordArray.length >= 6) {
    const signatureRecordView = getDataView(signatureRecordArray);
    if (getUint32(signatureRecordView, 0) == DIGITAL_SIGNATURE_RECORD_SIGNATURE) {
      const signatureDataLength = getUint16(signatureRecordView, 4);
      if (6 + signatureDataLength <= signatureRecordArray.length) {
        return signatureRecordArray.subarray(6, 6 + signatureDataLength);
      }
    }
  }
}
function getEncryptedDirectoryDataLength(directoryEncryptionInfo, declaredDirectoryDataLength, directoryDataLength) {
  const encryptedDirectoryDataLength = directoryEncryptionInfo && directoryEncryptionInfo.compressedSize ? directoryEncryptionInfo.compressedSize : declaredDirectoryDataLength;
  return encryptedDirectoryDataLength > 0 && encryptedDirectoryDataLength <= directoryDataLength ? encryptedDirectoryDataLength : directoryDataLength;
}
function getDirectoryEncryptionInfo(rawExtensibleData) {
  const directoryEncryptionInfo = { rawExtensibleData };
  if (rawExtensibleData.length >= 28) {
    const extensibleDataView = getDataView(rawExtensibleData);
    const hashDataLength = getUint16(extensibleDataView, 26);
    Object.assign(directoryEncryptionInfo, {
      compressionMethod: getUint16(extensibleDataView, 0),
      compressedSize: getBigUint64(extensibleDataView, 2),
      uncompressedSize: getBigUint64(extensibleDataView, 10),
      encryptionAlgorithm: getUint16(extensibleDataView, 18),
      bitLength: getUint16(extensibleDataView, 20),
      flags: getUint16(extensibleDataView, 22),
      hashAlgorithm: getUint16(extensibleDataView, 24),
      hashData: rawExtensibleData.subarray(28, 28 + hashDataLength)
    });
  }
  return directoryEncryptionInfo;
}
function readCommonHeader(directory, dataView, offset) {
  const rawBitFlag = directory.rawBitFlag = getUint16(dataView, offset + 2);
  const encrypted = (rawBitFlag & BITFLAG_ENCRYPTED) == BITFLAG_ENCRYPTED;
  const rawLastModDate = getUint32(dataView, offset + 6);
  Object.assign(directory, {
    encrypted,
    version: getUint16(dataView, offset),
    bitFlag: {
      level: (rawBitFlag & BITFLAG_LEVEL) >> 1,
      dataDescriptor: (rawBitFlag & BITFLAG_DATA_DESCRIPTOR) == BITFLAG_DATA_DESCRIPTOR,
      languageEncodingFlag: (rawBitFlag & BITFLAG_LANG_ENCODING_FLAG) == BITFLAG_LANG_ENCODING_FLAG
    },
    rawLastModDate,
    lastModDate: getDate(rawLastModDate),
    filenameLength: getUint16(dataView, offset + 22),
    extraFieldLength: getUint16(dataView, offset + 24)
  });
}
function readCommonFooter(fileEntry, directory, dataView, offset, localDirectory) {
  const { rawExtraField } = directory;
  const extraField = directory.extraField = /* @__PURE__ */ new Map();
  const rawExtraFieldView = getDataView(rawExtraField);
  let offsetExtraField = 0;
  let malformedExtraField = false;
  try {
    while (offsetExtraField < rawExtraField.length) {
      const type = getUint16(rawExtraFieldView, offsetExtraField);
      const size = getUint16(rawExtraFieldView, offsetExtraField + 2);
      extraField.set(type, {
        type,
        data: rawExtraField.slice(offsetExtraField + 4, offsetExtraField + 4 + size)
      });
      offsetExtraField += 4 + size;
    }
  } catch {
    malformedExtraField = true;
  }
  if (offsetExtraField > rawExtraField.length) {
    malformedExtraField = true;
  }
  const compressionMethod = getUint16(dataView, offset + 4);
  Object.assign(directory, {
    signature: getUint32(dataView, offset + HEADER_OFFSET_SIGNATURE),
    crc32: getUint32(dataView, offset + HEADER_OFFSET_SIGNATURE),
    compressedSize: getUint32(dataView, offset + HEADER_OFFSET_COMPRESSED_SIZE),
    uncompressedSize: getUint32(dataView, offset + HEADER_OFFSET_UNCOMPRESSED_SIZE)
  });
  const extraFieldZip64 = extraField.get(EXTRAFIELD_TYPE_ZIP64);
  if (extraFieldZip64) {
    readExtraFieldZip64(extraFieldZip64, directory);
    directory.extraFieldZip64 = extraFieldZip64;
  }
  const extraFieldUnicodePath = extraField.get(EXTRAFIELD_TYPE_UNICODE_PATH);
  if (extraFieldUnicodePath) {
    readExtraFieldUnicode(extraFieldUnicodePath, PROPERTY_NAME_FILENAME, PROPERTY_NAME_RAW_FILENAME, directory, fileEntry);
    directory.extraFieldUnicodePath = extraFieldUnicodePath;
  }
  const extraFieldUnicodeComment = extraField.get(EXTRAFIELD_TYPE_UNICODE_COMMENT);
  if (extraFieldUnicodeComment) {
    readExtraFieldUnicode(extraFieldUnicodeComment, PROPERTY_NAME_COMMENT, PROPERTY_NAME_RAW_COMMENT, directory, fileEntry);
    directory.extraFieldUnicodeComment = extraFieldUnicodeComment;
  }
  const extraFieldAES = extraField.get(EXTRAFIELD_TYPE_AES);
  if (extraFieldAES && extraFieldAES.data.length >= 7) {
    readExtraFieldAES(extraFieldAES, directory, compressionMethod);
    directory.extraFieldAES = extraFieldAES;
  } else {
    directory.compressionMethod = compressionMethod;
  }
  const extraFieldPkwareUnix = extraField.get(EXTRAFIELD_TYPE_PKWARE_UNIX);
  if (extraFieldPkwareUnix) {
    readExtraFieldUnixDates(extraFieldPkwareUnix, directory);
    directory.extraFieldPkwareUnix = extraFieldPkwareUnix;
  }
  const extraFieldUnixType1 = extraField.get(EXTRAFIELD_TYPE_UNIX_TYPE1);
  if (extraFieldUnixType1) {
    readExtraFieldUnixDates(extraFieldUnixType1, directory);
    directory.extraFieldUnixType1 = extraFieldUnixType1;
  }
  const extraFieldNTFS = extraField.get(EXTRAFIELD_TYPE_NTFS);
  if (extraFieldNTFS) {
    readExtraFieldNTFS(extraFieldNTFS, directory);
    directory.extraFieldNTFS = extraFieldNTFS;
  }
  const extraFieldUnix = extraField.get(EXTRAFIELD_TYPE_UNIX);
  let unixIdsRead;
  if (extraFieldUnix) {
    unixIdsRead = readExtraFieldUnix(extraFieldUnix, directory, false);
    directory.extraFieldUnix = extraFieldUnix;
  }
  if (!unixIdsRead) {
    const extraFieldInfoZip = extraField.get(EXTRAFIELD_TYPE_INFOZIP);
    if (extraFieldInfoZip) {
      readExtraFieldUnix(extraFieldInfoZip, directory, true);
      directory.extraFieldInfoZip = extraFieldInfoZip;
    }
  }
  const extraFieldExtendedTimestamp = extraField.get(EXTRAFIELD_TYPE_EXTENDED_TIMESTAMP);
  if (extraFieldExtendedTimestamp) {
    readExtraFieldExtendedTimestamp(extraFieldExtendedTimestamp, directory, localDirectory);
    directory.extraFieldExtendedTimestamp = extraFieldExtendedTimestamp;
  }
  const extraFieldUSDZ = extraField.get(EXTRAFIELD_TYPE_USDZ);
  if (extraFieldUSDZ) {
    directory.extraFieldUSDZ = extraFieldUSDZ;
  }
  return malformedExtraField;
}
function readExtraFieldZip64(extraFieldZip64, directory) {
  directory.zip64 = true;
  const extraFieldView = getDataView(extraFieldZip64.data);
  const missingProperties = ZIP64_PROPERTIES.filter(([propertyName, max]) => directory[propertyName] == max);
  const requiredLength = missingProperties.reduce((length, [, max]) => length + ZIP64_EXTRACTION[max].bytes, 0);
  if (extraFieldZip64.data.length < requiredLength) {
    throw new Error(ERR_EXTRAFIELD_ZIP64_NOT_FOUND);
  }
  for (let indexMissingProperty = 0, offset = 0; indexMissingProperty < missingProperties.length; indexMissingProperty++) {
    const [propertyName, max] = missingProperties[indexMissingProperty];
    const extraction = ZIP64_EXTRACTION[max];
    directory[propertyName] = extraFieldZip64[propertyName] = extraction.getValue(extraFieldView, offset);
    offset += extraction.bytes;
  }
}
function readExtraFieldUnicode(extraFieldUnicode, propertyName, rawPropertyName, directory, fileEntry) {
  if (extraFieldUnicode.data.length < 5) {
    extraFieldUnicode.valid = false;
    return;
  }
  const extraFieldView = getDataView(extraFieldUnicode.data);
  const computedCrc32 = new Crc32();
  computedCrc32.append(fileEntry[rawPropertyName]);
  const computedCrc32View = getDataView(new Uint8Array(4));
  computedCrc32View.setUint32(0, computedCrc32.get(), true);
  const nameCrc32 = getUint32(extraFieldView, 1);
  const version = getUint8(extraFieldView, 0);
  Object.assign(extraFieldUnicode, {
    version,
    [propertyName]: decodeText(extraFieldUnicode.data.subarray(5)),
    valid: version == 1 && !fileEntry.bitFlag.languageEncodingFlag && nameCrc32 == getUint32(computedCrc32View, 0)
  });
  if (extraFieldUnicode.valid) {
    directory[propertyName] = extraFieldUnicode[propertyName];
    directory[propertyName + PROPERTY_NAME_UTF8_SUFFIX] = true;
  }
}
function readExtraFieldAES(extraFieldAES, directory, compressionMethod) {
  const extraFieldView = getDataView(extraFieldAES.data);
  const strength = getUint8(extraFieldView, 4);
  Object.assign(extraFieldAES, {
    vendorVersion: getUint8(extraFieldView, 0),
    vendorId: getUint8(extraFieldView, 2),
    strength,
    originalCompressionMethod: compressionMethod,
    compressionMethod: getUint16(extraFieldView, 5)
  });
  directory.compressionMethod = extraFieldAES.compressionMethod;
  if (extraFieldAES.vendorVersion != VENDOR_VERSION_AE_1) {
    directory.crc32 = UNDEFINED_VALUE;
  }
}
function readExtraFieldNTFS(extraFieldNTFS, directory) {
  const extraFieldView = getDataView(extraFieldNTFS.data);
  let offsetExtraField = 4;
  let tag1Data;
  try {
    while (offsetExtraField < extraFieldNTFS.data.length && !tag1Data) {
      const tagValue = getUint16(extraFieldView, offsetExtraField);
      const attributeSize = getUint16(extraFieldView, offsetExtraField + 2);
      if (tagValue == EXTRAFIELD_TYPE_NTFS_TAG1) {
        tag1Data = extraFieldNTFS.data.slice(offsetExtraField + 4, offsetExtraField + 4 + attributeSize);
      }
      offsetExtraField += 4 + attributeSize;
    }
  } catch {
  }
  if (tag1Data && tag1Data.length == 24) {
    const tag1View = getDataView(tag1Data);
    const rawLastModDate = tag1View.getBigUint64(0, true);
    const rawLastAccessDate = tag1View.getBigUint64(8, true);
    const rawCreationDate = tag1View.getBigUint64(16, true);
    Object.assign(extraFieldNTFS, {
      rawLastModDate,
      rawLastAccessDate,
      rawCreationDate
    });
    const lastModDate = getDateNTFS(rawLastModDate);
    const lastAccessDate = getDateNTFS(rawLastAccessDate);
    const creationDate = getDateNTFS(rawCreationDate);
    const extraFieldData = { lastModDate, lastAccessDate, creationDate };
    Object.assign(extraFieldNTFS, extraFieldData);
    Object.assign(directory, extraFieldData, { rawLastAccessDate, rawCreationDate });
  }
}
function readExtraFieldUnixDates(extraField, directory) {
  if (extraField.data.length < 8) {
    return;
  }
  const extraFieldView = getDataView(extraField.data);
  const lastAccessDate = new Date((getUint32(extraFieldView, 0) | 0) * 1e3);
  const lastModDate = new Date((getUint32(extraFieldView, 4) | 0) * 1e3);
  const extraFieldData = { lastAccessDate, lastModDate };
  if (extraField.data.length >= 12) {
    extraFieldData.uid = getUint16(extraFieldView, 8);
    extraFieldData.gid = getUint16(extraFieldView, 10);
  }
  Object.assign(extraField, extraFieldData);
  Object.assign(directory, extraFieldData);
}
function readExtraFieldUnix(extraField, directory, isInfoZip) {
  try {
    const view = getDataView(extraField.data);
    let uid, gid;
    if (isInfoZip) {
      let offset = 0;
      const version = getUint8(view, offset++);
      const uidSize = getUint8(view, offset++);
      uid = unpackUnixId(extraField.data.subarray(offset, offset + uidSize));
      offset += uidSize;
      const gidSize = getUint8(view, offset++);
      gid = unpackUnixId(extraField.data.subarray(offset, offset + gidSize));
      Object.assign(extraField, { version, uid, gid });
    } else if (extraField.data.length >= 4) {
      uid = getUint16(view, 0);
      gid = getUint16(view, 2);
      Object.assign(extraField, { uid, gid });
    }
    if (uid !== UNDEFINED_VALUE) {
      directory.uid = uid;
    }
    if (gid !== UNDEFINED_VALUE) {
      directory.gid = gid;
    }
    return uid !== UNDEFINED_VALUE || gid !== UNDEFINED_VALUE;
  } catch {
  }
}
function unpackUnixId(bytes) {
  const buffer = new Uint8Array(4);
  buffer.set(bytes, 0);
  const view = new DataView(buffer.buffer, buffer.byteOffset, 4);
  return view.getUint32(0, true);
}
function readExtraFieldExtendedTimestamp(extraFieldExtendedTimestamp, directory, localDirectory) {
  if (!extraFieldExtendedTimestamp.data.length) {
    return;
  }
  const extraFieldView = getDataView(extraFieldExtendedTimestamp.data);
  const flags = getUint8(extraFieldView, 0);
  const timeProperties = [];
  const timeRawProperties = [];
  if (localDirectory) {
    if ((flags & 1) == 1) {
      timeProperties.push(PROPERTY_NAME_LAST_MODIFICATION_DATE);
      timeRawProperties.push(PROPERTY_NAME_RAW_LAST_MODIFICATION_DATE);
    }
    if ((flags & 2) == 2) {
      timeProperties.push(PROPERTY_NAME_LAST_ACCESS_DATE);
      timeRawProperties.push(PROPERTY_NAME_RAW_LAST_ACCESS_DATE);
    }
    if ((flags & 4) == 4) {
      timeProperties.push(PROPERTY_NAME_CREATION_DATE);
      timeRawProperties.push(PROPERTY_NAME_RAW_CREATION_DATE);
    }
  } else if (extraFieldExtendedTimestamp.data.length >= 5) {
    timeProperties.push(PROPERTY_NAME_LAST_MODIFICATION_DATE);
    timeRawProperties.push(PROPERTY_NAME_RAW_LAST_MODIFICATION_DATE);
  }
  let offset = 1;
  timeProperties.forEach((propertyName, indexProperty) => {
    if (extraFieldExtendedTimestamp.data.length >= offset + 4) {
      const time = getUint32(extraFieldView, offset);
      directory[propertyName] = extraFieldExtendedTimestamp[propertyName] = new Date((time | 0) * 1e3);
      const rawPropertyName = timeRawProperties[indexProperty];
      extraFieldExtendedTimestamp[rawPropertyName] = time;
    }
    offset += 4;
  });
}
async function detectOverlappingEntry({
  reader,
  fileEntry,
  index,
  offset,
  crc32,
  compressedSize,
  uncompressedSize,
  dataOffset,
  dataDescriptor,
  extraFieldZip64,
  readRanges
}) {
  let dataDescriptorLength = 0;
  if (dataDescriptor) {
    if (extraFieldZip64) {
      dataDescriptorLength = DATA_DESCRIPTOR_RECORD_ZIP_64_LENGTH;
    } else {
      dataDescriptorLength = DATA_DESCRIPTOR_RECORD_LENGTH;
    }
  }
  if (dataDescriptorLength) {
    const dataDescriptorArray = await readUint8Array(reader, dataOffset + compressedSize, dataDescriptorLength + DATA_DESCRIPTOR_RECORD_SIGNATURE_LENGTH);
    const dataDescriptorView = getDataView(dataDescriptorArray);
    let signature = dataDescriptorArray.length == dataDescriptorLength + DATA_DESCRIPTOR_RECORD_SIGNATURE_LENGTH && getUint32(dataDescriptorView, 0) == DATA_DESCRIPTOR_RECORD_SIGNATURE;
    if (signature) {
      const signedDataDescriptor = readDataDescriptor(dataDescriptorView, DATA_DESCRIPTOR_RECORD_SIGNATURE_LENGTH, extraFieldZip64);
      const matchCrc32 = fileEntry.encrypted && !fileEntry.zipCrypto || signedDataDescriptor.crc32 == crc32;
      if (matchCrc32 && signedDataDescriptor.compressedSize == compressedSize && signedDataDescriptor.uncompressedSize == uncompressedSize) {
        dataDescriptorLength += DATA_DESCRIPTOR_RECORD_SIGNATURE_LENGTH;
      } else {
        signature = false;
      }
    }
    if (dataDescriptorArray.length >= dataDescriptorLength) {
      const localDataDescriptor = readDataDescriptor(dataDescriptorView, signature ? DATA_DESCRIPTOR_RECORD_SIGNATURE_LENGTH : 0, extraFieldZip64);
      localDataDescriptor.signature = signature;
      fileEntry.localDirectory.dataDescriptor = localDataDescriptor;
    }
  }
  const range = {
    start: offset,
    end: dataOffset + compressedSize + dataDescriptorLength,
    fileEntry
  };
  for (const [otherIndex, otherRange] of readRanges) {
    if (otherIndex != index && range.start < otherRange.end && otherRange.start < range.end) {
      const error = new Error(ERR_OVERLAPPING_ENTRY);
      error.overlappingEntry = otherRange.fileEntry;
      throw error;
    }
  }
  readRanges.set(index, range);
}
function readDataDescriptor(dataDescriptorView, offset, extraFieldZip64) {
  const crc32 = getUint32(dataDescriptorView, offset);
  let compressedSize;
  let uncompressedSize;
  if (extraFieldZip64) {
    compressedSize = getBigUint64(dataDescriptorView, offset + 4);
    uncompressedSize = getBigUint64(dataDescriptorView, offset + 12);
  } else {
    compressedSize = getUint32(dataDescriptorView, offset + 4);
    uncompressedSize = getUint32(dataDescriptorView, offset + 8);
  }
  return { crc32, compressedSize, uncompressedSize };
}
function getDiskOffset(reader, diskNumber) {
  return reader.getDiskOffset ? reader.getDiskOffset(diskNumber) : 0;
}
async function startsWithSplitZipSignature(reader) {
  return await getFirstSignature(reader) == SPLIT_ZIP_FILE_SIGNATURE;
}
async function startsWithSplitZipMarker(reader) {
  const signature = await getFirstSignature(reader);
  return signature == SPLIT_ZIP_FILE_SIGNATURE || signature == TEMPORARY_SPLIT_ZIP_FILE_SIGNATURE;
}
async function getFirstSignature(reader) {
  const signatureArray = await readUint8Array(reader, 0, SPLIT_ZIP_FILE_SIGNATURE_LENGTH);
  return getUint32(getDataView(signatureArray));
}
function isStrictnessValue(value) {
  return value === STRICTNESS_STRICT || value === STRICTNESS_BALANCED || value === STRICTNESS_TOLERANT;
}
function getDecodableOutputSize(outputSize, compressedSize, compressed) {
  return Math.min(outputSize, compressed ? compressedSize * MAX_DEFLATE_EXPANSION_RATIO : compressedSize);
}
function getStrictness(options, inheritedOptions) {
  return resolveStrictness(options, resolveStrictness(inheritedOptions, STRICTNESS_BALANCED));
}
function resolveStrictness(options, inheritedStrictness) {
  const strictness = options[OPTION_STRICTNESS];
  if (strictness !== UNDEFINED_VALUE) {
    if (!isStrictnessValue(strictness)) {
      throw new Error(ERR_INVALID_STRICTNESS);
    }
    return strictness;
  }
  const checkAmbiguity = options[OPTION_CHECK_AMBIGUITY];
  if (checkAmbiguity === UNDEFINED_VALUE) {
    return inheritedStrictness;
  }
  if (checkAmbiguity) {
    return STRICTNESS_STRICT;
  }
  return inheritedStrictness == STRICTNESS_TOLERANT ? STRICTNESS_TOLERANT : STRICTNESS_BALANCED;
}
function getCheckLocalDirectory(checkLocalDirectory, strictness) {
  if (checkLocalDirectory === UNDEFINED_VALUE) {
    return strictness != STRICTNESS_TOLERANT;
  }
  return Boolean(checkLocalDirectory);
}
function getCheckLocalFilename(checkLocalFilename, strictness) {
  if (checkLocalFilename === UNDEFINED_VALUE) {
    return strictness == STRICTNESS_STRICT;
  }
  return Boolean(checkLocalFilename);
}
function getFilenameValidation(filenameValidation, strictness) {
  if (filenameValidation === UNDEFINED_VALUE) {
    return strictness;
  }
  if (!isStrictnessValue(filenameValidation)) {
    throw new Error(ERR_INVALID_FILENAME_VALIDATION);
  }
  return filenameValidation;
}
function isUnsafeFilename(filename, filenameValidation) {
  if (filenameValidation == STRICTNESS_TOLERANT) {
    return false;
  }
  const pathParts = filename.split("/");
  if (pathParts.length > 1 && pathParts[pathParts.length - 1] === "") {
    pathParts.pop();
  }
  if (pathParts.includes("..") || filename.startsWith("/") || filename.startsWith("\\\\") || DRIVE_LETTER_REGEXP.test(filename)) {
    return true;
  }
  return filenameValidation == STRICTNESS_STRICT && (pathParts.includes(".") || pathParts.includes(""));
}
function getMaxAppendedDataSize(maxAppendedDataSize, strictness) {
  if (maxAppendedDataSize !== UNDEFINED_VALUE) {
    const size = toNumber(maxAppendedDataSize);
    if (typeof size != NUMBER_TYPE || Number.isNaN(size) || size < 0) {
      throw new Error(ERR_INVALID_MAX_APPENDED_DATA_SIZE);
    }
    return size;
  }
  if (strictness == STRICTNESS_STRICT) {
    return 0;
  }
  if (strictness == STRICTNESS_TOLERANT) {
    return Infinity;
  }
  return MAX_16_BITS;
}
async function findEndOfCentralDirectory(reader, rejectAmbiguous, maxAppendedDataSize) {
  const { size } = reader;
  const anchoredLength = Math.min(size, END_OF_CENTRAL_DIR_LENGTH + MAX_16_BITS);
  const remoteProbeBudget = { count: MAX_END_OF_CENTRAL_DIR_PROBES };
  let endOfDirectoryInfo;
  let plausibleEndOfDirectoryInfo;
  let endOfDirectoryReachingEndCount = 0;
  for await (const [anchoredView, anchoredOffset, anchoredArray, indexByte, offset] of scanEndOfCentralDirectory(reader, anchoredLength)) {
    const commentLength = getUint16(anchoredView, indexByte + 20);
    if (offset + END_OF_CENTRAL_DIR_LENGTH + commentLength == size) {
      const reachability = await getCentralDirectoryReachability(reader, anchoredView, anchoredOffset, indexByte, offset, size, remoteProbeBudget);
      if (reachability == CENTRAL_DIRECTORY_REACHABLE) {
        if (!endOfDirectoryInfo) {
          endOfDirectoryInfo = getEndOfCentralDirectoryInfo(anchoredArray, indexByte, offset);
        }
        endOfDirectoryReachingEndCount++;
        if (!rejectAmbiguous || endOfDirectoryReachingEndCount > 1) {
          break;
        }
      } else if (reachability == CENTRAL_DIRECTORY_PLAUSIBLE && !plausibleEndOfDirectoryInfo) {
        plausibleEndOfDirectoryInfo = getEndOfCentralDirectoryInfo(anchoredArray, indexByte, offset);
      }
    }
  }
  if (!endOfDirectoryInfo) {
    endOfDirectoryInfo = plausibleEndOfDirectoryInfo;
  }
  if (!endOfDirectoryInfo) {
    endOfDirectoryInfo = await seekEndOfCentralDirectory(reader, maxAppendedDataSize, remoteProbeBudget);
  }
  return { endOfDirectoryInfo, endOfDirectoryReachingEndCount };
}
async function seekEndOfCentralDirectory(reader, maxAppendedDataSize, remoteProbeBudget) {
  const { size } = reader;
  const searchLength = Math.min(size, maxAppendedDataSize == Infinity ? size : END_OF_CENTRAL_DIR_LENGTH + MAX_16_BITS + maxAppendedDataSize);
  let firstSignatureInfo, plausibleInfo;
  for await (const [searchView, searchOffset, searchArray, indexByte, offset] of scanEndOfCentralDirectory(reader, searchLength)) {
    const record = getEndOfCentralDirectoryInfo(searchArray, indexByte, offset);
    if (!firstSignatureInfo) {
      firstSignatureInfo = record;
    }
    const reachability = await getCentralDirectoryReachability(reader, searchView, searchOffset, indexByte, offset, size, remoteProbeBudget);
    if (reachability == CENTRAL_DIRECTORY_REACHABLE) {
      return record;
    }
    if (reachability == CENTRAL_DIRECTORY_PLAUSIBLE && !plausibleInfo) {
      plausibleInfo = record;
    }
  }
  return plausibleInfo || firstSignatureInfo;
}
async function* scanEndOfCentralDirectory(reader, scanLength) {
  const scanOffset = reader.size - scanLength;
  const scanArray = await readUint8Array(reader, scanOffset, scanLength);
  const scanView = getDataView(scanArray);
  for (let indexByte = scanArray.length - END_OF_CENTRAL_DIR_LENGTH; indexByte >= 0; indexByte--) {
    if (getUint32(scanView, indexByte) == END_OF_CENTRAL_DIR_SIGNATURE) {
      yield [scanView, scanOffset, scanArray, indexByte, scanOffset + indexByte];
    }
  }
}
function getEndOfCentralDirectoryInfo(scanArray, indexByte, offset) {
  return { offset, buffer: scanArray.slice(indexByte, indexByte + END_OF_CENTRAL_DIR_LENGTH).buffer };
}
async function getCentralDirectoryReachability(reader, view, anchoredOffset, indexByte, offset, size, remoteProbeBudget) {
  const filesLength = getUint16(view, indexByte + 10);
  const directoryDataLength = getUint32(view, indexByte + 12);
  const directoryDataOffset = getUint32(view, indexByte + 16);
  if (filesLength == MAX_16_BITS || directoryDataLength == MAX_32_BITS || directoryDataOffset == MAX_32_BITS) {
    const locatorSignature = await readSignature(reader, view, anchoredOffset, offset - ZIP64_END_OF_CENTRAL_DIR_LOCATOR_LENGTH, size, remoteProbeBudget);
    return locatorSignature == ZIP64_END_OF_CENTRAL_DIR_LOCATOR_SIGNATURE ? CENTRAL_DIRECTORY_REACHABLE : CENTRAL_DIRECTORY_UNREACHABLE;
  }
  if (!filesLength && !directoryDataLength) {
    return CENTRAL_DIRECTORY_PLAUSIBLE;
  }
  const directoryDiskNumber = getUint16(view, indexByte + 6);
  for (const centralDirectoryOffset of [offset - directoryDataLength, getDiskOffset(reader, directoryDiskNumber) + directoryDataOffset]) {
    if (await readSignature(reader, view, anchoredOffset, centralDirectoryOffset, size, remoteProbeBudget) == CENTRAL_FILE_HEADER_SIGNATURE) {
      return CENTRAL_DIRECTORY_REACHABLE;
    }
  }
  return CENTRAL_DIRECTORY_UNREACHABLE;
}
async function readSignature(reader, view, anchoredOffset, signatureOffset, size, remoteProbeBudget) {
  if (signatureOffset < 0 || signatureOffset + 4 > size) {
    return UNDEFINED_VALUE;
  }
  if (signatureOffset >= anchoredOffset) {
    return getUint32(view, signatureOffset - anchoredOffset);
  }
  if (remoteProbeBudget.count > 0) {
    remoteProbeBudget.count--;
    const signatureArray = await readUint8Array(reader, signatureOffset, 4);
    return getUint32(getDataView(signatureArray), 0);
  }
  return UNDEFINED_VALUE;
}
function validateLocalDirectory(zipEntry, localDirectory, rawLocalFilename, checkLocalFilename, warnings) {
  const { rawFilename } = zipEntry;
  const reject = !warnings;
  const maskedLocalDirectory = zipEntry.decryptedDirectory && (localDirectory.rawBitFlag & BITFLAG_MASKED_LOCAL_HEADERS) == BITFLAG_MASKED_LOCAL_HEADERS;
  if (checkLocalFilename && !maskedLocalDirectory && (rawLocalFilename.length != rawFilename.length || rawLocalFilename.some((byteValue, indexByte) => byteValue != rawFilename[indexByte]))) {
    reportAmbiguity(reject, warnings, WARNING_MISMATCHED_LOCAL_FILE_HEADER_FILENAME);
  }
  if ((localDirectory.rawBitFlag & BITFLAG_AMBIGUITY_MASK) != (zipEntry.rawBitFlag & BITFLAG_AMBIGUITY_MASK)) {
    reportAmbiguity(reject, warnings, WARNING_MISMATCHED_LOCAL_FILE_HEADER_BIT_FLAG);
  }
  if (localDirectory.compressionMethod != zipEntry.compressionMethod) {
    reportAmbiguity(reject, warnings, WARNING_MISMATCHED_LOCAL_FILE_HEADER_COMPRESSION_METHOD);
  }
  if (!localDirectory.bitFlag.dataDescriptor && !maskedLocalDirectory && (localDirectory.crc32 || localDirectory.compressedSize || localDirectory.uncompressedSize) && (localDirectory.crc32 != zipEntry.crc32 || localDirectory.compressedSize != zipEntry.compressedSize || localDirectory.uncompressedSize != zipEntry.uncompressedSize)) {
    reportAmbiguity(reject, warnings, WARNING_MISMATCHED_LOCAL_FILE_HEADER_CRC32_OR_SIZES);
  }
}
function reportAmbiguity(reject, warnings, reason) {
  if (reject) {
    throwAmbiguousArchive(reason);
  } else {
    addWarning(warnings, reason);
  }
}
function throwAmbiguousArchive(reason) {
  const error = new Error(ERR_AMBIGUOUS_ARCHIVE);
  error.reason = reason;
  throw error;
}
function getOptionValue(zipReader, options, name) {
  return options[name] === UNDEFINED_VALUE ? zipReader.options[name] : options[name];
}
function getFunctionOptionValue(zipReader, options, name) {
  return checkFunctionOption(getOptionValue(zipReader, options, name));
}
function getDate(timeRaw) {
  const date = (timeRaw & 4294901760) >> 16, time = timeRaw & MAX_16_BITS;
  const result = new Date(1980 + ((date & 65024) >> 9), ((date & 480) >> 5) - 1, date & 31, (time & 63488) >> 11, (time & 2016) >> 5, (time & 31) * 2, 0);
  return result < MIN_DATE ? MIN_DATE : result;
}
function getDateNTFS(timeRaw) {
  return new Date(Number(timeRaw / BigInt(1e4) - BigInt(116444736e5)));
}
function getUint8(view, offset) {
  return view.getUint8(offset);
}
function getUint16(view, offset) {
  return view.getUint16(offset, true);
}
function getUint32(view, offset) {
  return view.getUint32(offset, true);
}
function getBigUint64(view, offset) {
  const value = view.getBigUint64(offset, true);
  if (value > MAX_SAFE_UINT64) {
    throw new Error(ERR_UNSUPPORTED_UINT64);
  }
  return Number(value);
}
var ERR_BAD_FORMAT, ERR_EOCDR_NOT_FOUND, ERR_EOCDR_LOCATOR_ZIP64_NOT_FOUND, ERR_CENTRAL_DIRECTORY_NOT_FOUND, ERR_LOCAL_FILE_HEADER_NOT_FOUND, ERR_EXTRAFIELD_ZIP64_NOT_FOUND, ERR_ENCRYPTED, ERR_UNSUPPORTED_ENCRYPTION, ERR_SPLIT_ZIP_FILE, ERR_OVERLAPPING_ENTRY, ERR_ENTRY_DATA_OUT_OF_BOUNDS, ERR_AMBIGUOUS_ARCHIVE, ERR_ENCRYPTED_CENTRAL_DIRECTORY, ERR_UNSAFE_FILENAME, ERR_INVALID_STRICTNESS, ERR_INVALID_FILENAME_VALIDATION, ERR_INVALID_MAX_APPENDED_DATA_SIZE, ERR_UNSUPPORTED_UINT64, WARNING_UNSORTED_CENTRAL_DIRECTORY, WARNING_UNKNOWN_VERSION, WARNING_COMPRESSED_PATCHED_DATA, WARNING_MALFORMED_EXTRA_FIELD, WARNING_UNKNOWN_ZIP64_EXTENSIBLE_DATA, WARNING_WRAPPED_ENTRIES_COUNT, WARNING_APPENDED_DATA, WARNING_PREPENDED_DATA, WARNING_PREPENDED_CENTRAL_DIRECTORY, WARNING_TRAILING_CENTRAL_DIRECTORY_DATA, WARNING_DUPLICATE_FILENAME, WARNING_MISMATCHED_ZIP64_END_OF_CENTRAL_DIRECTORY, WARNING_MULTIPLE_END_OF_CENTRAL_DIRECTORY, WARNING_MISMATCHED_LOCAL_FILE_HEADER_FILENAME, WARNING_MISMATCHED_LOCAL_FILE_HEADER_BIT_FLAG, WARNING_MISMATCHED_LOCAL_FILE_HEADER_COMPRESSION_METHOD, WARNING_MISMATCHED_LOCAL_FILE_HEADER_CRC32_OR_SIZES, MAX_KNOWN_VERSION, DRIVE_LETTER_REGEXP, CHARSET_UTF8, PROPERTY_NAME_UTF8_SUFFIX, CHARSET_CP437, BITFLAG_AMBIGUITY_MASK, VENDOR_VERSION_AE_1, ZIP64_PROPERTIES, ZIP64_EXTRACTION, MAX_SAFE_UINT64, MAX_END_OF_CENTRAL_DIR_PROBES, MAX_DEFLATE_EXPANSION_RATIO, CENTRAL_DIRECTORY_UNREACHABLE, CENTRAL_DIRECTORY_PLAUSIBLE, CENTRAL_DIRECTORY_REACHABLE, ZipReader, ZipReaderStream, ZipEntry;
var init_zip_reader = __esm({
  "node_modules/@zip.js/zip.js/lib/core/zip-reader.js"() {
    init_constants();
    init_configuration();
    init_codec_registry();
    init_codec_pool();
    init_io();
    init_decode_text();
    init_array();
    init_warnings();
    init_compatible_streams();
    init_error();
    init_crc32();
    init_zip_entry();
    init_options();
    ERR_BAD_FORMAT = "File format is not recognized";
    ERR_EOCDR_NOT_FOUND = "End of central directory not found";
    ERR_EOCDR_LOCATOR_ZIP64_NOT_FOUND = "End of Zip64 central directory locator not found";
    ERR_CENTRAL_DIRECTORY_NOT_FOUND = "Central directory header not found";
    ERR_LOCAL_FILE_HEADER_NOT_FOUND = "Local file header not found";
    ERR_EXTRAFIELD_ZIP64_NOT_FOUND = "Zip64 extra field not found";
    ERR_ENCRYPTED = "File contains encrypted entry";
    ERR_UNSUPPORTED_ENCRYPTION = "Encryption method not supported";
    ERR_SPLIT_ZIP_FILE = "Split zip file";
    ERR_OVERLAPPING_ENTRY = "Overlapping entry found";
    ERR_ENTRY_DATA_OUT_OF_BOUNDS = "Entry data out of bounds";
    ERR_AMBIGUOUS_ARCHIVE = "Ambiguous archive";
    ERR_ENCRYPTED_CENTRAL_DIRECTORY = "Encrypted central directory is not supported";
    ERR_UNSAFE_FILENAME = "Unsafe filename";
    ERR_INVALID_STRICTNESS = "Invalid strictness (must be 'strict', 'balanced' or 'tolerant')";
    ERR_INVALID_FILENAME_VALIDATION = "Invalid filenameValidation (must be 'strict', 'balanced' or 'tolerant')";
    ERR_INVALID_MAX_APPENDED_DATA_SIZE = "Invalid maxAppendedDataSize (must be a number greater than or equal to 0)";
    ERR_UNSUPPORTED_UINT64 = "64-bit value exceeds Number.MAX_SAFE_INTEGER";
    WARNING_UNSORTED_CENTRAL_DIRECTORY = "unsorted central directory";
    WARNING_UNKNOWN_VERSION = "unknown version needed to extract";
    WARNING_COMPRESSED_PATCHED_DATA = "compressed patched data";
    WARNING_MALFORMED_EXTRA_FIELD = "malformed extra field";
    WARNING_UNKNOWN_ZIP64_EXTENSIBLE_DATA = "unknown zip64 extensible data";
    WARNING_WRAPPED_ENTRIES_COUNT = "wrapped entries count";
    WARNING_APPENDED_DATA = "appended data";
    WARNING_PREPENDED_DATA = "prepended data";
    WARNING_PREPENDED_CENTRAL_DIRECTORY = "prepended central directory";
    WARNING_TRAILING_CENTRAL_DIRECTORY_DATA = "trailing central directory data";
    WARNING_DUPLICATE_FILENAME = "duplicate filename";
    WARNING_MISMATCHED_ZIP64_END_OF_CENTRAL_DIRECTORY = "mismatched zip64 end of central directory record";
    WARNING_MULTIPLE_END_OF_CENTRAL_DIRECTORY = "multiple end of central directory records";
    WARNING_MISMATCHED_LOCAL_FILE_HEADER_FILENAME = "mismatched local file header (filename)";
    WARNING_MISMATCHED_LOCAL_FILE_HEADER_BIT_FLAG = "mismatched local file header (general purpose bit flag)";
    WARNING_MISMATCHED_LOCAL_FILE_HEADER_COMPRESSION_METHOD = "mismatched local file header (compression method)";
    WARNING_MISMATCHED_LOCAL_FILE_HEADER_CRC32_OR_SIZES = "mismatched local file header (crc32 or sizes)";
    MAX_KNOWN_VERSION = 63;
    DRIVE_LETTER_REGEXP = /^[a-zA-Z]:/;
    CHARSET_UTF8 = "utf-8";
    PROPERTY_NAME_UTF8_SUFFIX = "UTF8";
    CHARSET_CP437 = "cp437";
    BITFLAG_AMBIGUITY_MASK = BITFLAG_ENCRYPTED | BITFLAG_DATA_DESCRIPTOR | BITFLAG_LANG_ENCODING_FLAG;
    VENDOR_VERSION_AE_1 = 1;
    ZIP64_PROPERTIES = [
      [PROPERTY_NAME_UNCOMPRESSED_SIZE, MAX_32_BITS],
      [PROPERTY_NAME_COMPRESSED_SIZE, MAX_32_BITS],
      [PROPERTY_NAME_OFFSET, MAX_32_BITS],
      [PROPERTY_NAME_DISK_NUMBER_START, MAX_16_BITS]
    ];
    ZIP64_EXTRACTION = {
      [MAX_16_BITS]: {
        getValue: getUint32,
        bytes: 4
      },
      [MAX_32_BITS]: {
        getValue: getBigUint64,
        bytes: 8
      }
    };
    MAX_SAFE_UINT64 = BigInt(Number.MAX_SAFE_INTEGER);
    MAX_END_OF_CENTRAL_DIR_PROBES = 64;
    MAX_DEFLATE_EXPANSION_RATIO = 1032;
    CENTRAL_DIRECTORY_UNREACHABLE = 0;
    CENTRAL_DIRECTORY_PLAUSIBLE = 1;
    CENTRAL_DIRECTORY_REACHABLE = 2;
    ZipReader = class {
      constructor(reader, options = {}) {
        Object.assign(this, {
          reader: new GenericReader(reader),
          options,
          readRanges: /* @__PURE__ */ new Map()
        });
      }
      async *getEntriesGenerator(options = {}) {
        const zipReader = this;
        let { reader } = zipReader;
        await initStream(reader);
        if (reader.size === UNDEFINED_VALUE || !reader.readUint8Array) {
          reader = new BlobReader(await streamToBlob(reader.readable));
          await initStream(reader);
        }
        if (reader.size < END_OF_CENTRAL_DIR_LENGTH) {
          throw new Error(ERR_BAD_FORMAT);
        }
        const warnings = zipReader.warnings = [];
        const strictness = getStrictness(options, zipReader.options);
        const checkAmbiguity = strictness == STRICTNESS_STRICT;
        const rejectAmbiguousEndOfDirectory = strictness != STRICTNESS_TOLERANT;
        const maxAppendedDataSize = getMaxAppendedDataSize(getOptionValue(zipReader, options, OPTION_MAX_APPENDED_DATA_SIZE), strictness);
        const filenameValidation = getFilenameValidation(getOptionValue(zipReader, options, OPTION_FILENAME_VALIDATION), strictness);
        const normalizeFilename = getOptionValue(zipReader, options, OPTION_NORMALIZE_FILENAME);
        const { endOfDirectoryInfo, endOfDirectoryReachingEndCount } = await findEndOfCentralDirectory(reader, rejectAmbiguousEndOfDirectory, maxAppendedDataSize);
        if (!endOfDirectoryInfo) {
          if (await startsWithSplitZipSignature(reader)) {
            throw new Error(ERR_SPLIT_ZIP_FILE);
          } else {
            throw new Error(ERR_EOCDR_NOT_FOUND);
          }
        }
        if (rejectAmbiguousEndOfDirectory && endOfDirectoryReachingEndCount > 1) {
          throwAmbiguousArchive(WARNING_MULTIPLE_END_OF_CENTRAL_DIRECTORY);
        }
        const endOfDirectoryView = getDataView(endOfDirectoryInfo);
        let directoryDataLength = getUint32(endOfDirectoryView, 12);
        let directoryDataOffset = getUint32(endOfDirectoryView, 16);
        const commentOffset = endOfDirectoryInfo.offset;
        const commentLength = getUint16(endOfDirectoryView, 20);
        const appendedDataOffset = commentOffset + END_OF_CENTRAL_DIR_LENGTH + commentLength;
        const appendedDataLength = reader.size - appendedDataOffset;
        if (appendedDataLength > maxAppendedDataSize) {
          throwAmbiguousArchive(WARNING_APPENDED_DATA);
        }
        if (appendedDataLength > 0) {
          addWarning(warnings, WARNING_APPENDED_DATA);
        }
        let lastDiskNumber = getUint16(endOfDirectoryView, 4);
        const expectedLastDiskNumber = reader.lastDiskNumber || 0;
        let diskNumber = getUint16(endOfDirectoryView, 6);
        let filesLength = getUint16(endOfDirectoryView, 10);
        let prependedDataLength = 0;
        let prependedCentralDirectory;
        let startOffset;
        let zip64EndOfDirectory;
        let zip64EndOfDirectoryVersion2;
        let zip64EndOfDirectoryLength = ZIP64_END_OF_CENTRAL_DIR_LENGTH;
        let directoryEncryptionInfo;
        const requiresZip64 = directoryDataOffset == MAX_32_BITS || directoryDataLength == MAX_32_BITS || filesLength == MAX_16_BITS || diskNumber == MAX_16_BITS;
        if (directoryDataOffset != MAX_32_BITS && diskNumber != MAX_16_BITS) {
          directoryDataOffset += getDiskOffset(reader, diskNumber);
        }
        if (requiresZip64) {
          const endOfDirectoryLocatorArray = endOfDirectoryInfo.offset >= ZIP64_END_OF_CENTRAL_DIR_LOCATOR_LENGTH ? await readUint8Array(reader, endOfDirectoryInfo.offset - ZIP64_END_OF_CENTRAL_DIR_LOCATOR_LENGTH, ZIP64_END_OF_CENTRAL_DIR_LOCATOR_LENGTH) : EMPTY_UINT8_ARRAY;
          const endOfDirectoryLocatorView = getDataView(endOfDirectoryLocatorArray);
          if (endOfDirectoryLocatorArray.length == ZIP64_END_OF_CENTRAL_DIR_LOCATOR_LENGTH && getUint32(endOfDirectoryLocatorView, 0) == ZIP64_END_OF_CENTRAL_DIR_LOCATOR_SIGNATURE) {
            directoryDataOffset = getDiskOffset(reader, getUint32(endOfDirectoryLocatorView, 4)) + getBigUint64(endOfDirectoryLocatorView, 8);
            let endOfDirectoryArray = await readUint8Array(reader, directoryDataOffset, ZIP64_END_OF_CENTRAL_DIR_LENGTH);
            let endOfDirectoryView2 = getDataView(endOfDirectoryArray);
            const expectedDirectoryDataOffset = endOfDirectoryInfo.offset - ZIP64_END_OF_CENTRAL_DIR_LOCATOR_LENGTH - ZIP64_END_OF_CENTRAL_DIR_LENGTH;
            if ((endOfDirectoryArray.length < ZIP64_END_OF_CENTRAL_DIR_LENGTH || getUint32(endOfDirectoryView2, 0) != ZIP64_END_OF_CENTRAL_DIR_SIGNATURE) && directoryDataOffset != expectedDirectoryDataOffset && expectedDirectoryDataOffset >= 0) {
              const originalDirectoryDataOffset = directoryDataOffset;
              directoryDataOffset = expectedDirectoryDataOffset;
              if (directoryDataOffset > originalDirectoryDataOffset) {
                prependedDataLength = directoryDataOffset - originalDirectoryDataOffset;
              }
              endOfDirectoryArray = await readUint8Array(reader, directoryDataOffset, ZIP64_END_OF_CENTRAL_DIR_LENGTH);
              endOfDirectoryView2 = getDataView(endOfDirectoryArray);
            }
            if (endOfDirectoryArray.length < ZIP64_END_OF_CENTRAL_DIR_LENGTH || getUint32(endOfDirectoryView2, 0) != ZIP64_END_OF_CENTRAL_DIR_SIGNATURE) {
              throw new Error(ERR_EOCDR_LOCATOR_ZIP64_NOT_FOUND);
            }
            zip64EndOfDirectory = true;
            zip64EndOfDirectoryVersion2 = getBigUint64(endOfDirectoryView2, 4) > ZIP64_END_OF_CENTRAL_DIR_LENGTH - 12;
            if (zip64EndOfDirectoryVersion2) {
              const extensibleDataLength = Math.min(
                getBigUint64(endOfDirectoryView2, 4) - (ZIP64_END_OF_CENTRAL_DIR_LENGTH - 12),
                reader.size - directoryDataOffset - ZIP64_END_OF_CENTRAL_DIR_LENGTH
              );
              if (extensibleDataLength > 0) {
                zip64EndOfDirectoryLength += extensibleDataLength;
                const rawExtensibleData = await readUint8Array(reader, directoryDataOffset + ZIP64_END_OF_CENTRAL_DIR_LENGTH, extensibleDataLength);
                directoryEncryptionInfo = getDirectoryEncryptionInfo(rawExtensibleData);
              }
            }
            if (lastDiskNumber == MAX_16_BITS) {
              lastDiskNumber = getUint32(endOfDirectoryView2, 16);
            } else if (lastDiskNumber != getUint32(endOfDirectoryView2, 16)) {
              reportAmbiguity(checkAmbiguity, warnings, WARNING_MISMATCHED_ZIP64_END_OF_CENTRAL_DIRECTORY);
            }
            if (diskNumber == MAX_16_BITS) {
              diskNumber = getUint32(endOfDirectoryView2, 20);
            } else if (diskNumber != getUint32(endOfDirectoryView2, 20)) {
              reportAmbiguity(checkAmbiguity, warnings, WARNING_MISMATCHED_ZIP64_END_OF_CENTRAL_DIRECTORY);
            }
            if (filesLength == MAX_16_BITS) {
              filesLength = getBigUint64(endOfDirectoryView2, 32);
            } else if (filesLength != getBigUint64(endOfDirectoryView2, 32)) {
              reportAmbiguity(checkAmbiguity, warnings, WARNING_MISMATCHED_ZIP64_END_OF_CENTRAL_DIRECTORY);
            }
            if (directoryDataLength == MAX_32_BITS) {
              directoryDataLength = getBigUint64(endOfDirectoryView2, 40);
            } else if (directoryDataLength != getBigUint64(endOfDirectoryView2, 40)) {
              reportAmbiguity(checkAmbiguity, warnings, WARNING_MISMATCHED_ZIP64_END_OF_CENTRAL_DIRECTORY);
            }
            directoryDataOffset = getDiskOffset(reader, diskNumber) + getBigUint64(endOfDirectoryView2, 48) + prependedDataLength;
          }
        }
        let declaredDirectoryDataLength = directoryDataLength;
        const centralDirectoryEndOffset = endOfDirectoryInfo.offset - (zip64EndOfDirectory ? zip64EndOfDirectoryLength + ZIP64_END_OF_CENTRAL_DIR_LOCATOR_LENGTH : 0);
        if (directoryDataOffset >= reader.size) {
          prependedDataLength = reader.size - directoryDataOffset - directoryDataLength - END_OF_CENTRAL_DIR_LENGTH;
          directoryDataOffset = reader.size - directoryDataLength - END_OF_CENTRAL_DIR_LENGTH;
        }
        if (expectedLastDiskNumber != lastDiskNumber) {
          throw new Error(ERR_SPLIT_ZIP_FILE);
        }
        if (directoryDataOffset < 0) {
          throw new Error(ERR_BAD_FORMAT);
        }
        let offset = 0;
        let directoryArray = await readUint8Array(reader, directoryDataOffset, directoryDataLength);
        let directoryView = getDataView(directoryArray);
        if (directoryDataLength) {
          if (directoryArray.length < 4) {
            throw new Error(ERR_BAD_FORMAT);
          }
          const expectedDirectoryDataOffset = centralDirectoryEndOffset - directoryDataLength;
          if (directoryDataOffset != expectedDirectoryDataOffset && diskNumber == lastDiskNumber) {
            const storedPointsAtDirectory = getUint32(directoryView, offset) == CENTRAL_FILE_HEADER_SIGNATURE || Boolean(directoryEncryptionInfo && directoryEncryptionInfo.compressedSize) || detectEncryptedCentralDirectory(directoryView);
            let reconcile = !storedPointsAtDirectory;
            if (!reconcile && expectedDirectoryDataOffset >= 0 && expectedDirectoryDataOffset + 4 <= reader.size) {
              const expectedSignatureArray = await readUint8Array(reader, expectedDirectoryDataOffset, 4);
              reconcile = getUint32(getDataView(expectedSignatureArray), 0) == CENTRAL_FILE_HEADER_SIGNATURE;
            }
            if (reconcile) {
              const originalDirectoryDataOffset = directoryDataOffset;
              directoryDataOffset = expectedDirectoryDataOffset;
              if (directoryDataOffset > originalDirectoryDataOffset) {
                prependedDataLength += directoryDataOffset - originalDirectoryDataOffset;
                prependedCentralDirectory = storedPointsAtDirectory;
              }
              directoryArray = await readUint8Array(reader, directoryDataOffset, directoryDataLength);
              directoryView = getDataView(directoryArray);
            }
          }
        }
        const expectedDirectoryDataLength = centralDirectoryEndOffset - directoryDataOffset;
        if (directoryDataLength != expectedDirectoryDataLength && expectedDirectoryDataLength >= 0 && diskNumber == lastDiskNumber) {
          directoryDataLength = expectedDirectoryDataLength;
          directoryArray = await readUint8Array(reader, directoryDataOffset, directoryDataLength);
          directoryView = getDataView(directoryArray);
        }
        if (directoryDataOffset < 0 || directoryDataOffset >= reader.size) {
          throw new Error(ERR_BAD_FORMAT);
        }
        zipReader.directoryOffset = directoryDataOffset;
        zipReader.directoryLength = declaredDirectoryDataLength;
        const decryptCentralDirectory = getFunctionOptionValue(zipReader, options, OPTION_DECRYPT_CENTRAL_DIRECTORY);
        let decryptedDirectory, dataAfterEncryptedDirectory;
        if (decryptCentralDirectory && filesLength && directoryArray.length >= 4 && getUint32(directoryView, 0) != CENTRAL_FILE_HEADER_SIGNATURE && (zip64EndOfDirectoryVersion2 || detectEncryptedCentralDirectory(directoryView))) {
          const encryptedDirectoryDataLength = getEncryptedDirectoryDataLength(directoryEncryptionInfo, declaredDirectoryDataLength, directoryArray.length);
          dataAfterEncryptedDirectory = directoryArray.subarray(encryptedDirectoryDataLength);
          directoryArray = await decryptCentralDirectory(directoryArray.subarray(0, encryptedDirectoryDataLength), directoryEncryptionInfo);
          directoryView = getDataView(directoryArray);
          declaredDirectoryDataLength = directoryArray.length;
          decryptedDirectory = true;
        }
        if (directoryEncryptionInfo && !decryptedDirectory && (directoryArray.length < 4 || getUint32(directoryView, 0) == CENTRAL_FILE_HEADER_SIGNATURE)) {
          addWarning(warnings, WARNING_UNKNOWN_ZIP64_EXTENSIBLE_DATA);
        }
        startOffset = directoryDataOffset;
        const filenameEncoding = getOptionValue(zipReader, options, OPTION_FILENAME_ENCODING);
        const commentEncoding = getOptionValue(zipReader, options, OPTION_COMMENT_ENCODING);
        const filenames = /* @__PURE__ */ new Set();
        let duplicateFilename;
        let previousEntryPosition = -1;
        const recoverWrappedFilesLength = !checkAmbiguity && !zip64EndOfDirectory;
        if (!filesLength && recoverWrappedFilesLength) {
          filesLength = getWrappedFilesLength(directoryView, directoryArray, offset);
          if (filesLength) {
            addWarning(warnings, WARNING_WRAPPED_ENTRIES_COUNT);
          }
        }
        for (let indexFile = 0; indexFile < filesLength; indexFile++) {
          const fileEntry = new ZipEntry(reader, zipReader.options);
          if (offset + CENTRAL_FILE_HEADER_LENGTH > directoryArray.length || getUint32(directoryView, offset) != CENTRAL_FILE_HEADER_SIGNATURE) {
            if (indexFile == 0 && !decryptedDirectory && (zip64EndOfDirectoryVersion2 || detectEncryptedCentralDirectory(directoryView))) {
              throw new Error(ERR_ENCRYPTED_CENTRAL_DIRECTORY);
            }
            throw new Error(ERR_CENTRAL_DIRECTORY_NOT_FOUND);
          }
          readCommonHeader(fileEntry, directoryView, offset + 6);
          const languageEncodingFlag = Boolean(fileEntry.bitFlag.languageEncodingFlag);
          const filenameOffset = offset + CENTRAL_FILE_HEADER_LENGTH;
          const extraFieldOffset = filenameOffset + fileEntry.filenameLength;
          const commentOffset2 = extraFieldOffset + fileEntry.extraFieldLength;
          const versionMadeBy = getUint16(directoryView, offset + 4);
          const msDosCompatible = versionMadeBy >> 8 == 0;
          const unixCompatible = versionMadeBy >> 8 == 3;
          const rawFilename = directoryArray.subarray(filenameOffset, extraFieldOffset);
          const commentLength2 = getUint16(directoryView, offset + 32);
          const endOffset = commentOffset2 + commentLength2;
          const rawComment = directoryArray.subarray(commentOffset2, endOffset);
          const filenameUTF8 = languageEncodingFlag;
          const commentUTF8 = languageEncodingFlag;
          const externalFileAttributes = getUint32(directoryView, offset + 38);
          const msdosAttributesRaw = externalFileAttributes & MAX_8_BITS;
          const msdosAttributes = {
            readOnly: Boolean(msdosAttributesRaw & FILE_ATTR_MSDOS_READONLY_MASK),
            hidden: Boolean(msdosAttributesRaw & FILE_ATTR_MSDOS_HIDDEN_MASK),
            system: Boolean(msdosAttributesRaw & FILE_ATTR_MSDOS_SYSTEM_MASK),
            directory: Boolean(msdosAttributesRaw & FILE_ATTR_MSDOS_DIR_MASK),
            archive: Boolean(msdosAttributesRaw & FILE_ATTR_MSDOS_ARCHIVE_MASK)
          };
          const offsetFileEntry = getUint32(directoryView, offset + 42);
          const decode2 = getFunctionOptionValue(zipReader, options, OPTION_DECODE_TEXT) || decodeText;
          const rawFilenameEncoding = filenameUTF8 ? CHARSET_UTF8 : filenameEncoding || CHARSET_CP437;
          const rawCommentEncoding = commentUTF8 ? CHARSET_UTF8 : commentEncoding || CHARSET_CP437;
          let filename = decode2(rawFilename, rawFilenameEncoding, TEXT_TYPE_FILENAME);
          if (filename === UNDEFINED_VALUE) {
            filename = decodeText(rawFilename, rawFilenameEncoding);
          }
          if (normalizeFilename) {
            const normalizedFilename = normalizeFilename(filename);
            if (normalizedFilename !== UNDEFINED_VALUE) {
              filename = normalizedFilename;
            }
          }
          if (isUnsafeFilename(filename, filenameValidation)) {
            const error = new Error(ERR_UNSAFE_FILENAME);
            error.filename = filename;
            throw error;
          }
          let comment = decode2(rawComment, rawCommentEncoding, TEXT_TYPE_COMMENT);
          if (comment === UNDEFINED_VALUE) {
            comment = decodeText(rawComment, rawCommentEncoding);
          }
          Object.assign(fileEntry, {
            index: indexFile,
            decryptedDirectory,
            versionMadeBy,
            msDosCompatible,
            zip64: false,
            compressedSize: 0,
            uncompressedSize: 0,
            commentLength: commentLength2,
            offset: offsetFileEntry,
            diskNumberStart: getUint16(directoryView, offset + 34),
            internalFileAttributes: getUint16(directoryView, offset + 36),
            externalFileAttributes,
            msdosAttributesRaw,
            msdosAttributes,
            rawFilename,
            filenameUTF8,
            commentUTF8,
            rawExtraField: directoryArray.subarray(extraFieldOffset, commentOffset2),
            rawComment,
            filename,
            comment
          });
          if (readCommonFooter(fileEntry, fileEntry, directoryView, offset + 6)) {
            addWarning(warnings, WARNING_MALFORMED_EXTRA_FIELD, filename);
          }
          fileEntry.offset += prependedDataLength;
          const entryPosition = getDiskOffset(reader, fileEntry.diskNumberStart) + fileEntry.offset;
          startOffset = Math.min(entryPosition, startOffset);
          if (entryPosition < previousEntryPosition) {
            addWarning(warnings, WARNING_UNSORTED_CENTRAL_DIRECTORY, filename);
          }
          previousEntryPosition = entryPosition;
          if ((fileEntry.version & MAX_8_BITS) > MAX_KNOWN_VERSION) {
            addWarning(warnings, WARNING_UNKNOWN_VERSION, filename);
          }
          if ((fileEntry.rawBitFlag & BITFLAG_COMPRESSED_PATCHED_DATA) == BITFLAG_COMPRESSED_PATCHED_DATA) {
            addWarning(warnings, WARNING_COMPRESSED_PATCHED_DATA, filename);
          }
          if (filenames.has(fileEntry.filename)) {
            duplicateFilename = true;
          }
          filenames.add(fileEntry.filename);
          const unixExternalUpper = fileEntry.externalFileAttributes >> 16 & MAX_16_BITS;
          if (fileEntry.unixMode === UNDEFINED_VALUE && (unixExternalUpper & (FILE_ATTR_UNIX_DEFAULT_MASK | FILE_ATTR_UNIX_EXECUTABLE_MASK | FILE_ATTR_UNIX_TYPE_DIR)) != 0) {
            fileEntry.unixMode = unixExternalUpper;
          }
          const setuid = Boolean(fileEntry.unixMode & FILE_ATTR_UNIX_SETUID_MASK);
          const setgid = Boolean(fileEntry.unixMode & FILE_ATTR_UNIX_SETGID_MASK);
          const sticky = Boolean(fileEntry.unixMode & FILE_ATTR_UNIX_STICKY_MASK);
          const unixType = fileEntry.unixMode === UNDEFINED_VALUE ? unixExternalUpper : fileEntry.unixMode;
          const symlink = (unixType & FILE_ATTR_UNIX_TYPE_MASK) == FILE_ATTR_UNIX_TYPE_SYMLINK;
          const executable = !symlink && (fileEntry.unixMode !== UNDEFINED_VALUE ? (fileEntry.unixMode & FILE_ATTR_UNIX_EXECUTABLE_MASK) != 0 : unixCompatible && (unixExternalUpper & FILE_ATTR_UNIX_EXECUTABLE_MASK) != 0);
          const modeIsDir = fileEntry.unixMode !== UNDEFINED_VALUE && (fileEntry.unixMode & FILE_ATTR_UNIX_TYPE_MASK) == FILE_ATTR_UNIX_TYPE_DIR;
          const upperIsDir = (unixExternalUpper & FILE_ATTR_UNIX_TYPE_MASK) == FILE_ATTR_UNIX_TYPE_DIR;
          Object.assign(fileEntry, {
            setuid,
            setgid,
            sticky,
            symlink,
            unixExternalUpper,
            executable,
            directory: modeIsDir || upperIsDir || msDosCompatible && msdosAttributes.directory || fileEntry.filename.endsWith(DIRECTORY_SIGNATURE),
            zipCrypto: fileEntry.encrypted && !fileEntry.extraFieldAES
          });
          const entry = new Entry(fileEntry);
          entry.getData = (writer, options2) => fileEntry.getData(writer, entry, zipReader.readRanges, options2);
          entry.arrayBuffer = async (options2) => {
            const writer = new TransformStream();
            const arrayBufferPromise = streamToBlob(writer.readable).then((blob) => blob.arrayBuffer());
            arrayBufferPromise.catch(() => {
            });
            await fileEntry.getData(
              writer,
              entry,
              zipReader.readRanges,
              Object.assign({}, options2, { preventClose: false })
            );
            return arrayBufferPromise;
          };
          offset = endOffset;
          if (indexFile == filesLength - 1 && recoverWrappedFilesLength) {
            const wrappedFilesLength = getWrappedFilesLength(directoryView, directoryArray, offset);
            if (wrappedFilesLength) {
              filesLength += wrappedFilesLength;
              addWarning(warnings, WARNING_WRAPPED_ENTRIES_COUNT);
            }
          }
          const { onprogress } = options;
          if (onprogress) {
            try {
              await onprogress(indexFile + 1, filesLength, new Entry(fileEntry));
            } catch {
            }
          }
          yield entry;
        }
        let offsetAfterSignature = offset;
        let digitalSignature = readDigitalSignature(directoryArray.subarray(offset)) || (decryptedDirectory ? readDigitalSignature(dataAfterEncryptedDirectory) : UNDEFINED_VALUE);
        if (!digitalSignature && !decryptedDirectory) {
          const signatureRecordOffset = directoryDataOffset + offset;
          const signatureRecordLength = Math.min(centralDirectoryEndOffset - signatureRecordOffset, 6 + MAX_16_BITS);
          if (signatureRecordLength >= 6) {
            digitalSignature = readDigitalSignature(await readUint8Array(reader, signatureRecordOffset, signatureRecordLength));
          }
        }
        if (digitalSignature) {
          zipReader.digitalSignature = digitalSignature;
          offsetAfterSignature = offset + 6 + digitalSignature.length;
        }
        if (offset != declaredDirectoryDataLength && offsetAfterSignature != declaredDirectoryDataLength || !decryptedDirectory && offset != directoryDataLength && offsetAfterSignature != directoryDataLength) {
          reportAmbiguity(checkAmbiguity, warnings, WARNING_TRAILING_CENTRAL_DIRECTORY_DATA);
        }
        if (duplicateFilename) {
          reportAmbiguity(checkAmbiguity, warnings, WARNING_DUPLICATE_FILENAME);
        }
        const extractPrependedData = getOptionValue(zipReader, options, OPTION_EXTRACT_PREPENDED_DATA);
        const extractAppendedData = getOptionValue(zipReader, options, OPTION_EXTRACT_APPENDED_DATA);
        const splitZipSignatureLength = (checkAmbiguity || extractPrependedData) && filesLength && startOffset == SPLIT_ZIP_FILE_SIGNATURE_LENGTH && await startsWithSplitZipMarker(reader) ? SPLIT_ZIP_FILE_SIGNATURE_LENGTH : 0;
        if (checkAmbiguity && (prependedDataLength || filesLength && startOffset > splitZipSignatureLength)) {
          throwAmbiguousArchive(WARNING_PREPENDED_DATA);
        }
        if (prependedDataLength || filesLength && startOffset > SPLIT_ZIP_FILE_SIGNATURE_LENGTH) {
          addWarning(warnings, WARNING_PREPENDED_DATA);
        }
        if (prependedCentralDirectory) {
          addWarning(warnings, WARNING_PREPENDED_CENTRAL_DIRECTORY);
        }
        if (extractPrependedData) {
          zipReader.prependedData = startOffset > splitZipSignatureLength ? await readUint8Array(reader, splitZipSignatureLength, startOffset - splitZipSignatureLength) : EMPTY_UINT8_ARRAY;
        }
        zipReader.comment = commentLength ? await readUint8Array(reader, commentOffset + END_OF_CENTRAL_DIR_LENGTH, commentLength) : EMPTY_UINT8_ARRAY;
        if (extractAppendedData) {
          zipReader.appendedData = appendedDataOffset < reader.size ? await readUint8Array(reader, appendedDataOffset, reader.size - appendedDataOffset) : EMPTY_UINT8_ARRAY;
        }
        return true;
      }
      async getEntries(options = {}) {
        const entries = [];
        for await (const entry of this.getEntriesGenerator(options)) {
          entries.push(entry);
        }
        return entries;
      }
      async close() {
        const { reader } = this;
        if (!reader.readUint8Array && reader.readable && !reader.readable.locked) {
          await reader.readable.cancel();
        }
      }
      [SYMBOL_ASYNC_DISPOSE]() {
        return this.close();
      }
    };
    ZipReaderStream = class {
      constructor(options = {}) {
        let sourceController;
        const { readable, writable } = new TransformStream({
          start(controller) {
            sourceController = controller;
          }
        });
        const zipReader = new ZipReader(readable, options);
        const gen = zipReader.getEntriesGenerator();
        const pendingEntries2 = /* @__PURE__ */ new Set();
        this.readable = new ReadableStream({
          async pull(controller) {
            const { done, value } = await gen.next();
            if (done)
              return controller.close();
            const entryStream = createEntryStream(value, pendingEntries2);
            const chunk = {
              ...value,
              readable: entryStream.readable
            };
            delete chunk.getData;
            Object.defineProperties(chunk, {
              localDirectory: {
                get: () => value.localDirectory,
                enumerable: true
              },
              warnings: {
                get: () => value.warnings,
                enumerable: true
              }
            });
            controller.enqueue(chunk);
          },
          async cancel(reason) {
            const entryStreams = Array.from(pendingEntries2);
            pendingEntries2.clear();
            sourceController.error(reason);
            await Promise.allSettled(entryStreams.map((entryStream) => entryStream.cancel(reason)));
            await Promise.allSettled([gen.return(), zipReader.close()]);
          }
        });
        this.writable = writable;
      }
    };
    ZipEntry = class {
      constructor(reader, options) {
        Object.assign(this, {
          reader,
          options
        });
      }
      async getData(writer, fileEntry, readRanges, options = {}) {
        const zipEntry = this;
        const config2 = getConfiguration();
        const {
          reader,
          index,
          offset,
          diskNumberStart,
          extraFieldAES,
          extraFieldZip64,
          compressionMethod,
          bitFlag,
          rawBitFlag,
          crc32,
          rawLastModDate,
          uncompressedSize,
          compressedSize
        } = zipEntry;
        const {
          dataDescriptor
        } = bitFlag;
        const localDirectory = fileEntry.localDirectory = {};
        const warnings = fileEntry.warnings = [];
        const localHeaderOffset = getDiskOffset(reader, diskNumberStart) + offset;
        const dataArray = await readUint8Array(reader, localHeaderOffset, HEADER_SIZE);
        const dataView = getDataView(dataArray);
        let password = getOptionValue(zipEntry, options, OPTION_PASSWORD);
        let rawPassword = getOptionValue(zipEntry, options, OPTION_RAW_PASSWORD);
        const passThrough = checkPassThroughOption(getOptionValue(zipEntry, options, OPTION_PASS_THROUGH));
        const passThroughCompression = Boolean(passThrough);
        const passThroughEncryption = passThrough === true;
        checkPasswordOption(password, rawPassword);
        password = password && password.length && password;
        rawPassword = rawPassword && rawPassword.length && rawPassword;
        if (extraFieldAES) {
          if (extraFieldAES.originalCompressionMethod != COMPRESSION_METHOD_AES) {
            throw new Error(ERR_UNSUPPORTED_COMPRESSION);
          }
        }
        if (dataArray.length < HEADER_SIZE || getUint32(dataView, 0) != LOCAL_FILE_HEADER_SIGNATURE) {
          throw new Error(ERR_LOCAL_FILE_HEADER_NOT_FOUND);
        }
        readCommonHeader(localDirectory, dataView, 4);
        const {
          extraFieldLength,
          filenameLength
        } = localDirectory;
        const dataOffset = localDirectory.dataOffset = localHeaderOffset + HEADER_SIZE + filenameLength + extraFieldLength;
        const checkLocalDirectoryOption = getOptionValue(zipEntry, options, OPTION_CHECK_LOCAL_DIRECTORY);
        const entryStrictness = getStrictness(options, zipEntry.options);
        const checkLocalDirectory = getCheckLocalDirectory(checkLocalDirectoryOption, entryStrictness);
        const checkLocalFilenameOption = getOptionValue(zipEntry, options, OPTION_CHECK_LOCAL_FILENAME);
        const checkLocalFilename = getCheckLocalFilename(
          checkLocalFilenameOption === UNDEFINED_VALUE ? checkLocalDirectoryOption : checkLocalFilenameOption,
          entryStrictness
        );
        let rawLocalFilename = EMPTY_UINT8_ARRAY;
        if (checkLocalFilename && (filenameLength || extraFieldLength)) {
          const trailingDataArray = await readUint8Array(reader, localHeaderOffset + HEADER_SIZE, filenameLength + extraFieldLength);
          rawLocalFilename = trailingDataArray.subarray(0, filenameLength);
          localDirectory.rawExtraField = trailingDataArray.subarray(filenameLength);
        } else {
          localDirectory.rawExtraField = extraFieldLength ? await readUint8Array(reader, localHeaderOffset + HEADER_SIZE + filenameLength, extraFieldLength) : EMPTY_UINT8_ARRAY;
        }
        if (checkLocalFilename) {
          localDirectory.rawFilename = rawLocalFilename;
        }
        if (readCommonFooter(zipEntry, localDirectory, dataView, 4, true)) {
          addWarning(warnings, WARNING_MALFORMED_EXTRA_FIELD);
        }
        validateLocalDirectory(zipEntry, localDirectory, rawLocalFilename, checkLocalFilename, checkLocalDirectory ? UNDEFINED_VALUE : warnings);
        const { lastAccessDate, creationDate, uid, gid } = localDirectory;
        if (lastAccessDate) {
          fileEntry.lastAccessDate = lastAccessDate;
        }
        if (creationDate) {
          fileEntry.creationDate = creationDate;
        }
        if (uid !== UNDEFINED_VALUE && fileEntry.uid === UNDEFINED_VALUE) {
          fileEntry.uid = uid;
        }
        if (gid !== UNDEFINED_VALUE && fileEntry.gid === UNDEFINED_VALUE) {
          fileEntry.gid = gid;
        }
        const checkPasswordOnly = getOptionValue(zipEntry, options, OPTION_CHECK_PASSWORD_ONLY);
        const encrypted = zipEntry.encrypted && localDirectory.encrypted && (!passThroughEncryption || checkPasswordOnly);
        const zipCrypto = encrypted && !extraFieldAES;
        if (!passThroughEncryption) {
          fileEntry.zipCrypto = zipCrypto;
        }
        if (encrypted && (localDirectory.rawBitFlag & BITFLAG_STRONG_ENCRYPTION) == BITFLAG_STRONG_ENCRYPTION) {
          throw new Error(ERR_UNSUPPORTED_ENCRYPTION);
        }
        const registeredCodec = passThroughCompression ? UNDEFINED_VALUE : getRegisteredCodec(compressionMethod);
        if (compressionMethod != COMPRESSION_METHOD_STORE && compressionMethod != COMPRESSION_METHOD_DEFLATE && compressionMethod != COMPRESSION_METHOD_DEFLATE_64 && !registeredCodec && !passThroughCompression) {
          throw new Error(ERR_UNSUPPORTED_COMPRESSION);
        }
        if (encrypted) {
          if (!zipCrypto && (extraFieldAES.strength < 1 || extraFieldAES.strength > 3)) {
            throw new Error(ERR_UNSUPPORTED_ENCRYPTION);
          } else if (!password && !rawPassword) {
            throw new Error(ERR_ENCRYPTED);
          }
        }
        if (dataOffset + compressedSize > reader.size) {
          throw new Error(ERR_ENTRY_DATA_OUT_OF_BOUNDS);
        }
        const size = compressedSize;
        const readable = toCompatibleReadable(reader.createReadable({ offset: dataOffset, size }));
        const signal = checkSignalOption(getOptionValue(zipEntry, options, OPTION_SIGNAL));
        throwIfAborted(signal);
        let checkOverlappingEntry = getOptionValue(zipEntry, options, OPTION_CHECK_OVERLAPPING_ENTRY);
        const checkOverlappingEntryOnly = getOptionValue(zipEntry, options, OPTION_CHECK_OVERLAPPING_ENTRY_ONLY);
        if (checkOverlappingEntryOnly) {
          checkOverlappingEntry = true;
        }
        const { onstart, onprogress, onend } = options;
        const compressed = compressionMethod != COMPRESSION_METHOD_STORE && !passThroughCompression;
        const outputSize = passThroughCompression ? compressedSize - getEncryptionOverhead(encrypted, zipCrypto, extraFieldAES && extraFieldAES.strength) : uncompressedSize;
        const deflate64 = compressionMethod == COMPRESSION_METHOD_DEFLATE_64;
        let useCompressionStream = getOptionValue(zipEntry, options, OPTION_USE_COMPRESSION_STREAM);
        if (deflate64) {
          useCompressionStream = false;
        }
        const checkCrc32Option = getOptionValue(zipEntry, options, OPTION_CHECK_CRC32);
        const checkCrc32 = (checkCrc32Option === UNDEFINED_VALUE ? getOptionValue(zipEntry, options, OPTION_CHECK_SIGNATURE) : checkCrc32Option) && !passThroughCompression && (!encrypted || zipCrypto || extraFieldAES && extraFieldAES.vendorVersion == VENDOR_VERSION_AE_1);
        const workerOptions = {
          options: {
            codecType: CODEC_INFLATE,
            password,
            rawPassword,
            zipCrypto,
            encryptionStrength: extraFieldAES && extraFieldAES.strength,
            checkCrc32,
            checkAuthenticationCode: getOptionValue(zipEntry, options, OPTION_CHECK_AUTHENTICATION_CODE),
            passwordVerification: zipCrypto && (dataDescriptor ? rawLastModDate >>> 8 & MAX_8_BITS : crc32 >>> 24 & MAX_8_BITS),
            outputSize,
            crc32,
            compressed,
            encrypted,
            useWebWorkers: getOptionValue(zipEntry, options, OPTION_USE_WEB_WORKERS),
            useCompressionStream,
            transferStreams: getOptionValue(zipEntry, options, OPTION_TRANSFER_STREAMS),
            deflate64,
            format: registeredCodec ? registeredCodec.format : UNDEFINED_VALUE,
            codecURI: registeredCodec ? registeredCodec.codecURI : UNDEFINED_VALUE,
            compressionMethod,
            rawBitFlag,
            checkPasswordOnly
          },
          config: config2,
          streamOptions: { signal, size, onstart, onprogress, onend }
        };
        if (checkOverlappingEntry) {
          await detectOverlappingEntry({
            reader,
            fileEntry,
            index,
            offset: localHeaderOffset,
            crc32,
            compressedSize,
            uncompressedSize,
            dataOffset,
            dataDescriptor: dataDescriptor || localDirectory.bitFlag.dataDescriptor,
            extraFieldZip64: extraFieldZip64 || localDirectory.extraFieldZip64,
            readRanges
          });
        }
        let writable, abortError, aborted;
        try {
          if (!checkOverlappingEntryOnly) {
            if (checkPasswordOnly) {
              writer = new WritableStream();
            }
            writer = new GenericWriter(writer);
            await initStream(writer, getDecodableOutputSize(outputSize, compressedSize, compressed));
            ({ writable } = writer);
            const { outputSize: writtenSize } = await runWorker2({ readable, writable }, workerOptions);
            if (writtenSize != outputSize) {
              throw Object.assign(new Error(ERR_INVALID_UNCOMPRESSED_SIZE), { outputSize: writtenSize });
            }
            writer.size += writtenSize;
          }
        } catch (error) {
          const { outputSize: failedOutputSize } = workerOptions;
          if (failedOutputSize !== UNDEFINED_VALUE) {
            writer.size += failedOutputSize;
          } else if (isErrorObject(error) && error.outputSize !== UNDEFINED_VALUE) {
            writer.size += error.outputSize;
          }
          if (!checkPasswordOnly || !isErrorObject(error) || error.message != ERR_ABORT_CHECK_PASSWORD) {
            abortError = error;
            aborted = true;
            throw error;
          }
        } finally {
          const preventClose = !ownsWritable(writer) && getOptionValue(zipEntry, options, OPTION_PREVENT_CLOSE);
          if (!preventClose && writable && !writable.locked) {
            const writableWriter = writable.getWriter();
            if (aborted) {
              try {
                await writableWriter.abort(abortError);
              } catch {
              }
            } else {
              await writableWriter.close();
            }
          }
        }
        return checkPasswordOnly || checkOverlappingEntryOnly ? UNDEFINED_VALUE : writer.getData ? writer.getData() : writable;
      }
    };
  }
});

// src/features/archive/compression-policy.ts
var INCOMPRESSIBLE_EXTENSIONS = /* @__PURE__ */ new Set([
  "7z",
  "aac",
  "avi",
  "avif",
  "br",
  "bz2",
  "docx",
  "flac",
  "gif",
  "gz",
  "heic",
  "jpeg",
  "jpg",
  "m4a",
  "m4v",
  "mkv",
  "mov",
  "mp3",
  "mp4",
  "ogg",
  "otf",
  "pdf",
  "png",
  "pptx",
  "rar",
  "tar",
  "tgz",
  "ttf",
  "wasm",
  "webm",
  "webp",
  "woff",
  "woff2",
  "xlsx",
  "xz",
  "zip",
  "zst"
]);
var INCOMPRESSIBLE_APPLICATION_TYPES = /* @__PURE__ */ new Set([
  "application/gzip",
  "application/octet-stream",
  "application/pdf",
  "application/wasm",
  "application/x-7z-compressed",
  "application/x-brotli",
  "application/x-rar-compressed",
  "application/x-xz",
  "application/zip",
  "application/zstd"
]);
function archiveCompressionLevel({
  path,
  mimeType,
  mode: mode2 = "balanced"
}) {
  const extension = path.slice(path.lastIndexOf("/") + 1).split(".").at(-1)?.toLowerCase();
  const normalizedMime = mimeType?.split(";", 1)[0]?.trim().toLowerCase();
  const mediaMime = normalizedMime?.startsWith("audio/") || normalizedMime?.startsWith("video/") || normalizedMime?.startsWith("image/") && normalizedMime !== "image/svg+xml" || normalizedMime?.startsWith("font/");
  if (extension && INCOMPRESSIBLE_EXTENSIONS.has(extension) || mediaMime || normalizedMime && INCOMPRESSIBLE_APPLICATION_TYPES.has(normalizedMime)) {
    return 0;
  }
  return mode2 === "speed" ? 1 : 6;
}

// node_modules/@zip.js/zip.js/lib/zip-core-base.js
init_configuration();

// node_modules/@zip.js/zip.js/lib/core/codec-worker-web.js
init_constants();
init_array();
init_error();
init_codec_stream();
init_codec_worker();
var MODULE_WORKER_OPTIONS = { type: "module" };
var ERROR_EVENT_TYPE = "error";
var MESSAGE_ERROR_EVENT_TYPE = "messageerror";
var webWorkerSource;
var webWorkerURI;
var webWorkerOptions;
var transferStreamsSupported = true;
try {
  transferStreamsSupported = typeof structuredClone == FUNCTION_TYPE && structuredClone(new DOMException("", "AbortError")).code !== UNDEFINED_VALUE;
} catch {
}
setWebWorkerBackend(createWebWorkerInterface);
function createWebWorkerInterface(workerData, config2) {
  const { baseURI, chunkSize, workerStartupTimeout } = config2;
  let { wasmURI } = config2;
  if (!workerData.interface) {
    if (typeof wasmURI == FUNCTION_TYPE) {
      wasmURI = wasmURI();
    }
    let worker;
    try {
      worker = getWebWorker(workerData.workerURI, baseURI, workerData);
    } catch {
      disableWebWorker(workerData);
      return createWorkerInterface(workerData, config2);
    }
    Object.assign(workerData, {
      worker,
      workerAlive: false,
      terminated: false,
      startupError: null,
      interface: {
        run: async () => {
          try {
            return await runWebWorker(workerData, { chunkSize, wasmURI, baseURI, workerStartupTimeout });
          } catch (error) {
            if (error && error.workerStartupFailed) {
              disableWebWorker(workerData);
              releaseWorkerStreams(workerData);
              return runWorker(workerData, config2);
            }
            if (error && error.codecImportFailed) {
              if (workerData.reader) {
                releaseWorkerStreams(workerData);
                return runWorker(workerData, config2);
              }
              workerData.onTaskFinished();
            }
            throw error;
          }
        }
      }
    });
  }
  return workerData.interface;
}
async function runWebWorker(workerData, config2) {
  if (!workerData.worker) {
    const { startupError } = workerData;
    workerData.startupError = null;
    const error = startupError || new Error(ERR_WORKER_STARTUP_TIMEOUT);
    error.workerStartupFailed = true;
    throw error;
  }
  let resolveResult, rejectResult;
  const result = new Promise((resolve, reject) => {
    resolveResult = resolve;
    rejectResult = (error) => {
      const { outputSize, workerOptions } = workerData;
      workerOptions.outputSize = outputSize;
      if (isErrorObject(error)) {
        try {
          error.outputSize = outputSize;
        } catch {
        }
      }
      reject(error);
    };
  });
  Object.assign(workerData, {
    reader: null,
    writer: null,
    outputSize: 0,
    destinationFailed: false,
    destinationError: null,
    resolveResult,
    rejectResult,
    result
  });
  const { readable, options } = workerData;
  const { writable, closed, abortPipe } = watchClosedStream(workerData.writable, workerData);
  let streamsTransferred;
  try {
    streamsTransferred = sendMessage({
      type: MESSAGE_START,
      options,
      config: config2,
      readable,
      writable
    }, workerData);
  } catch (error) {
    abortPipe();
    try {
      await closed;
    } catch {
    }
    workerData.onTaskFinished();
    throw error;
  }
  if (!streamsTransferred) {
    Object.assign(workerData, {
      reader: readable.getReader(),
      writer: writable.getWriter()
    });
  }
  const { workerStartupTimeout } = config2;
  if (!workerData.workerAlive && Number.isFinite(workerStartupTimeout) && workerStartupTimeout >= 0) {
    workerData.startupTimeout = setTimeout(() => onStartupTimeout(workerData), workerStartupTimeout);
  }
  try {
    const resultValue = await result;
    await closeWritable();
    await closed;
    return resultValue;
  } catch (error) {
    await closeWritable();
    abortPipe();
    try {
      await closed;
    } catch {
    }
    const { outputSize, workerOptions, destinationFailed, destinationError } = workerData;
    workerOptions.outputSize = outputSize;
    const workerFailed = isErrorObject(error) && (error.codecImportFailed || error.workerStartupFailed);
    const reportedError = destinationFailed && !workerFailed ? destinationError : error;
    if (isErrorObject(reportedError)) {
      try {
        reportedError.outputSize = outputSize;
      } catch {
      }
    }
    throw reportedError;
  }
  async function closeWritable() {
    if (!streamsTransferred && !writable.locked) {
      try {
        await writable.getWriter().close();
      } catch {
      }
    }
  }
}
function watchClosedStream(writableSource, workerData) {
  const abortController = new AbortController();
  let aborting;
  const { writable, readable } = new TransformStream({
    transform(chunk, controller) {
      workerData.outputSize += chunk.length;
      controller.enqueue(chunk);
    }
  });
  const closed = readable.pipeTo(writableSource, { preventClose: true, preventAbort: true, signal: abortController.signal });
  closed.catch((error) => {
    if (!aborting) {
      Object.assign(workerData, { destinationFailed: true, destinationError: error });
    }
  });
  return {
    writable,
    closed,
    abortPipe: () => {
      aborting = true;
      abortController.abort();
    }
  };
}
function releaseWorkerStreams(workerData) {
  const { reader } = workerData;
  if (reader) {
    reader.releaseLock();
  }
  workerData.reader = null;
  workerData.writer = null;
}
function terminateWorker(workerData) {
  const { worker } = workerData;
  if (worker) {
    try {
      worker.terminate();
    } catch {
    }
  }
  workerData.interface = null;
}
function getWebWorker(url, baseURI, workerData, isModuleType, useBlobURI = true) {
  const { createWorker } = workerData;
  let worker, resolvedURI, resolvedOptions;
  if (createWorker) {
    worker = createWorker();
  } else if (webWorkerURI === UNDEFINED_VALUE || webWorkerSource !== url) {
    const isFunctionURI = typeof url == FUNCTION_TYPE;
    if (isFunctionURI) {
      resolvedURI = url(useBlobURI);
    } else {
      resolvedURI = url;
    }
    const isDataURI = resolvedURI.startsWith("data:");
    const isBlobURI = resolvedURI.startsWith("blob:");
    if (isDataURI || isBlobURI) {
      if (isModuleType === UNDEFINED_VALUE) {
        isModuleType = false;
      }
      if (isModuleType) {
        resolvedOptions = MODULE_WORKER_OPTIONS;
      }
      try {
        worker = new Worker(resolvedURI, resolvedOptions);
      } catch (error) {
        if (isBlobURI) {
          try {
            URL.revokeObjectURL(resolvedURI);
          } catch {
          }
        }
        if (isFunctionURI && isBlobURI) {
          return getWebWorker(url, baseURI, workerData, isModuleType, false);
        } else if (!isModuleType) {
          return getWebWorker(url, baseURI, workerData, true, false);
        } else {
          throw error;
        }
      }
    } else {
      if (isModuleType === UNDEFINED_VALUE) {
        isModuleType = true;
      }
      if (isModuleType) {
        resolvedOptions = MODULE_WORKER_OPTIONS;
      }
      try {
        resolvedURI = new URL(resolvedURI, baseURI);
      } catch {
      }
      try {
        worker = new Worker(resolvedURI, resolvedOptions);
      } catch (error) {
        if (isModuleType) {
          return getWebWorker(url, baseURI, workerData, false, useBlobURI);
        } else {
          throw error;
        }
      }
    }
    webWorkerSource = url;
    webWorkerURI = resolvedURI;
    webWorkerOptions = resolvedOptions;
  } else {
    worker = new Worker(webWorkerURI, webWorkerOptions);
  }
  worker.addEventListener(MESSAGE_EVENT_TYPE, (event) => {
    workerData.workerAlive = true;
    clearStartupTimeout(workerData);
    onMessage(event, workerData);
  });
  worker.addEventListener(ERROR_EVENT_TYPE, (event) => onWorkerError(event, workerData));
  worker.addEventListener(MESSAGE_ERROR_EVENT_TYPE, (event) => onWorkerError(event, workerData));
  return worker;
}
function onStartupTimeout(workerData) {
  workerData.startupTimeout = null;
  if (workerData.workerAlive) {
    return;
  }
  const { rejectResult, writer } = workerData;
  terminateWorker(workerData);
  workerData.worker = null;
  if (rejectResult) {
    const error = new Error(ERR_WORKER_STARTUP_TIMEOUT);
    error.workerStartupFailed = true;
    rejectResult(error);
    if (writer) {
      writer.releaseLock();
    }
  }
}
function clearStartupTimeout(workerData) {
  const { startupTimeout } = workerData;
  if (startupTimeout) {
    clearTimeout(startupTimeout);
    workerData.startupTimeout = null;
  }
}
function onWorkerError(event, workerData) {
  if (event.preventDefault) {
    event.preventDefault();
  }
  clearStartupTimeout(workerData);
  const { workerAlive, rejectResult, writer, onTaskFinished } = workerData;
  terminateWorker(workerData);
  if (!workerAlive) {
    workerData.worker = null;
  }
  let error = event.error || new Error(event.message || ERROR_EVENT_TYPE);
  if (!workerAlive) {
    error = Object.assign(new Error(error.message || ERROR_EVENT_TYPE), { workerStartupFailed: true });
    workerData.startupError = error;
  }
  if (rejectResult) {
    rejectResult(error);
    if (writer) {
      writer.releaseLock();
    }
    if (workerAlive) {
      onTaskFinished();
    }
  }
}
function sendMessage(message, { worker, writer, transferStreams, workerAlive }) {
  try {
    const { value, readable, writable } = message;
    const transferables = [];
    if (value) {
      message.value = toExactUint8Array(value);
      transferables.push(message.value.buffer);
    }
    if (transferStreams && transferStreamsSupported && workerAlive) {
      if (readable) {
        transferables.push(readable);
      }
      if (writable) {
        transferables.push(writable);
      }
    } else {
      message.readable = message.writable = null;
    }
    if (transferables.length) {
      try {
        worker.postMessage(message, transferables);
        return true;
      } catch {
        transferStreamsSupported = false;
        message.readable = message.writable = null;
        worker.postMessage(message);
      }
    } else {
      worker.postMessage(message);
    }
  } catch (error) {
    if (writer) {
      writer.releaseLock();
    }
    throw error;
  }
}
async function onMessage({ data }, workerData) {
  const { type, value, messageId, result, error, errorValue } = data;
  const { reader, writer, resolveResult, rejectResult, onTaskFinished, generation } = workerData;
  const stale = () => workerData.generation != generation;
  try {
    if (error) {
      fail(getResponseError(error, errorValue));
    } else {
      if (type == MESSAGE_PULL) {
        const { value: value2, done } = await reader.read();
        if (!stale()) {
          sendMessage({ type: MESSAGE_DATA, value: value2, done, messageId }, workerData);
        }
      }
      if (type == MESSAGE_DATA) {
        const chunk = new Uint8Array(value);
        await writer.ready;
        await writer.write(chunk);
        if (!stale()) {
          sendMessage({ type: MESSAGE_ACK_DATA, messageId }, workerData);
        }
      }
      if (type == MESSAGE_CLOSE) {
        succeed(result);
      }
    }
  } catch (error2) {
    if (!stale()) {
      terminateWorker(workerData);
      fail(error2);
    }
  }
  function fail(error2) {
    if (!stale()) {
      rejectResult(error2);
      releaseWriter();
      if (!(isErrorObject(error2) && error2.codecImportFailed)) {
        onTaskFinished();
      }
    }
  }
  function succeed(result2) {
    if (!stale()) {
      resolveResult(result2);
      releaseWriter();
      onTaskFinished();
    }
  }
  function releaseWriter() {
    if (writer) {
      writer.releaseLock();
    }
  }
}
function getResponseError(errorData, errorValue) {
  const { message, stack, code, name, outputSize, cause, codecImportFailed } = errorData;
  let responseError;
  if (errorValue) {
    responseError = errorValue.value;
  } else {
    responseError = Object.assign(new Error(message), { stack, code, name });
    if (cause) {
      responseError.cause = Object.assign(new Error(cause.message), { name: cause.name });
    }
  }
  if (isErrorObject(responseError)) {
    try {
      if (outputSize !== UNDEFINED_VALUE) {
        responseError.outputSize = outputSize;
      }
      if (codecImportFailed) {
        responseError.codecImportFailed = true;
      }
      if (errorValue) {
        if (responseError.name !== name) {
          responseError.name = name;
        }
        if (responseError.code !== code) {
          responseError.code = code;
        }
      }
    } catch {
    }
  }
  return responseError;
}

// node_modules/@zip.js/zip.js/lib/zip-core-reader.js
init_zip_reader();

// node_modules/@zip.js/zip.js/lib/core/zip-writer.js
init_constants();
init_configuration();
init_codec_registry();
init_codec_worker();
init_codec_pool();
init_io();
init_encode_text();
init_array();
init_warnings();
init_compatible_streams();
init_error();
init_zip_entry();
init_options();
var ERR_DUPLICATED_NAME = "File already exists";
var ERR_INVALID_COMMENT = "Zip file comment exceeds 64KB";
var ERR_INVALID_COMMENT_TYPE = "Invalid zip file comment (must be a Uint8Array)";
var ERR_INVALID_ENTRY_COMMENT = "File entry comment exceeds 64KB";
var ERR_INVALID_ENTRY_COMMENT_TYPE = "Invalid file entry comment (must be a string)";
var ERR_INVALID_DATE = "Invalid date (must be a valid Date instance)";
var ERR_INVALID_ENTRY_NAME = "File entry name exceeds 64KB";
var ERR_INVALID_VERSION = "Version exceeds 65535";
var ERR_INVALID_ENCRYPTION_STRENGTH = "The strength must equal 1, 2, or 3";
var ERR_UNSUPPORTED_ENCRYPTION_USDZ = "Encryption is not supported in USDZ files";
var ERR_UNSUPPORTED_SPLIT_USDZ = "Split zip files are not supported in USDZ files";
var ERR_UNSUPPORTED_ENCRYPTION_PASS_THROUGH = "Encryption is not supported when the 'passThrough' option is set to true (use 'compressed' instead)";
var ERR_INVALID_EXTRAFIELD = "Invalid extra field (must be a Map)";
var ERR_INVALID_EXTRAFIELD_TYPE = "Invalid extra field type (must be integer 0..65535)";
var ERR_INVALID_EXTRAFIELD_DATA_TYPE = "Invalid extra field data (must be a Uint8Array)";
var ERR_INVALID_EXTRAFIELD_DATA = "Extra field data exceeds 64KB";
var MIN_UNIX_TIME = -2147483648;
var MAX_UNIX_TIME = 2147483647;
var MIN_NTFS_TIME = BigInt(0);
var MAX_NTFS_TIME = BigInt("0x7fffffffffffffff");
var ERR_UNSUPPORTED_FORMAT = "Zip64 is not supported (set the 'zip64' option to 'true')";
var ERR_UNDEFINED_UNCOMPRESSED_SIZE = "Undefined uncompressed size";
var ERR_UNDEFINED_COMPRESSION_METHOD = "Undefined compression method";
var ERR_UNDEFINED_CRC32 = "Undefined CRC32";
var ERR_UNDEFINED_READER = "Undefined reader";
var ERR_INVALID_READER = "Invalid reader (must be a Reader instance, a ReadableStream instance, or an object with a 'readable' property)";
var ERR_ZIP_NOT_EMPTY = "Zip file not empty";
var ERR_INVALID_UID = "Invalid uid (must be integer 0..2^32-1)";
var ERR_INVALID_GID = "Invalid gid (must be integer 0..2^32-1)";
var ERR_INVALID_UNIX_MODE = "Invalid UNIX mode (must be integer 0..65535)";
var ERR_INVALID_UNIX_EXTRA_FIELD_TYPE = "Invalid unixExtraFieldType (must be 'infozip' or 'unix')";
var ERR_INVALID_UNIX_ID_SIZE = "uid/gid must be 0..65535 for unixExtraFieldType 'unix' (use 'infozip' for larger ids)";
var ERR_INVALID_MSDOS_ATTRIBUTES = "Invalid msdosAttributesRaw (must be integer 0..255)";
var ERR_INVALID_MSDOS_DATA = "Invalid msdosAttributes (must be an object with boolean flags)";
var ERR_INVALID_LEVEL = "Invalid level (must be integer 0..9)";
var ERR_INVALID_SIGNATURE_DATA = "Signature data exceeds 64KB";
var ERR_INVALID_ENTRY = "Invalid entry option (must be an entry returned by ZipReader#getEntries())";
var ERR_ZIP_CRYPTO_LAST_MOD_DATE = "The last modification date of an entry encrypted with ZipCrypto cannot be changed when passThrough is set";
var WARNING_COMPRESSION_UNAVAILABLE = "compression unavailable";
var WARNING_CLAMPED_LAST_MODIFICATION_DATE = "clamped last modification date";
var EXTRAFIELD_DATA_AES = new Uint8Array([7, 0, 2, 0, 65, 69, 3, 0, 0]);
var EXTRAFIELD_OFFSET_AES_VENDOR_VERSION = 4;
var EXTRAFIELD_OFFSET_AES_COMPRESSION_METHOD = 9;
var EXTRAFIELD_USDZ_MAX_LENGTH = 67;
var MIN_PRINTABLE_ASCII_CHARACTER_CODE = 32;
var MAX_PRINTABLE_ASCII_CHARACTER_CODE = 126;
var VENDOR_VERSION_AE_12 = 1;
var INFOZIP_EXTRA_FIELD_TYPE = "infozip";
var UNIX_EXTRA_FIELD_TYPE = "unix";
var LEVEL_BY_BITFLAG_LEVEL = [8, 9, 5, 3];
var MAX_LEVEL = 9;
var workers = 0;
var pendingEntries = [];
var ZipWriter = class {
  constructor(writer, options = {}) {
    writer = new GenericWriter(writer);
    const { availableSize = INFINITY_VALUE, maxSize = INFINITY_VALUE } = writer;
    const addSplitZipSignature = availableSize > 0 && availableSize !== INFINITY_VALUE && maxSize > 0 && maxSize !== INFINITY_VALUE;
    if (addSplitZipSignature && options[OPTION_USDZ]) {
      throw new Error(ERR_UNSUPPORTED_SPLIT_USDZ);
    }
    Object.assign(this, {
      writer,
      addSplitZipSignature,
      options,
      fileEntries: /* @__PURE__ */ new Map(),
      filenames: /* @__PURE__ */ new Set(),
      offset: options[OPTION_OFFSET] === UNDEFINED_VALUE ? writer.size || writer.writable.size || 0 : options[OPTION_OFFSET],
      initialOffset: options[OPTION_OFFSET] === UNDEFINED_VALUE ? 0 : options[OPTION_OFFSET] - (writer.size || writer.writable.size || 0),
      pendingAddFileCalls: /* @__PURE__ */ new Set(),
      pendingErrors: [],
      warnings: [],
      bufferedWrites: 0,
      directWrites: 0,
      lastFileEntry: UNDEFINED_VALUE,
      archiveClosed: false
    });
  }
  prependZip(reader) {
    return watchPromiseError(this, prependZipEntries(this, reader));
  }
  appendZip(reader) {
    return watchPromiseError(this, this.appendZipEntries(reader));
  }
  async appendZipEntries(reader) {
    const zipWriter = this;
    const { pendingAddFileCalls, filenames, fileEntries } = zipWriter;
    while (pendingAddFileCalls.size) {
      await Promise.allSettled(Array.from(pendingAddFileCalls));
    }
    let resolveAppendZip;
    const promiseAppendZip = new Promise((resolve) => resolveAppendZip = resolve);
    pendingAddFileCalls.add(promiseAppendZip);
    const appendedFilenames = [];
    let releaseLockWriter;
    try {
      reader = new GenericReader(reader);
      await initStream(reader);
      if (reader.size === UNDEFINED_VALUE || !reader.readUint8Array) {
        reader = new BlobReader(await streamToBlob(reader.readable));
        await initStream(reader);
      }
      const { ZipReader: ZipReader2 } = await Promise.resolve().then(() => (init_zip_reader(), zip_reader_exports));
      const zipReader = new ZipReader2(reader);
      const entries = await zipReader.getEntries();
      await zipReader.close();
      await initStream(zipWriter.writer);
      const { directoryOffset } = zipReader;
      entries.forEach(({ filename }) => {
        if (filenames.has(filename)) {
          throw new Error(ERR_DUPLICATED_NAME);
        }
        filenames.add(filename);
        appendedFilenames.push(filename);
      });
      zipWriter.writerLocked = true;
      const { lockWriter } = zipWriter;
      zipWriter.lockWriter = new Promise((resolve) => releaseLockWriter = () => {
        zipWriter.writerLocked = false;
        resolve();
      });
      await lockWriter;
      if (zipWriter.addSplitZipSignature) {
        delete zipWriter.addSplitZipSignature;
        if (!await startsWithSplitZipSignature2(reader)) {
          await writeData(zipWriter.writer, getSplitZipSignatureArray());
          zipWriter.offset += SPLIT_ZIP_FILE_SIGNATURE_LENGTH;
        }
      }
      const entryPositions = await copyZipData(zipWriter, reader, entries, directoryOffset);
      entries.forEach((entry) => {
        const {
          version,
          rawLastModDate,
          rawFilename,
          bitFlag,
          encrypted,
          uncompressedSize,
          compressedSize,
          extraFieldZip64
        } = entry;
        let {
          compressionMethod,
          rawExtraField
        } = entry;
        const { level, languageEncodingFlag, dataDescriptor } = bitFlag;
        rawExtraField = removeExtraFieldZip64(rawExtraField || EMPTY_UINT8_ARRAY);
        if (entry.extraFieldAES) {
          compressionMethod = COMPRESSION_METHOD_AES;
        }
        const extraFieldLength = getLength(rawExtraField);
        const zip64UncompressedSize = Boolean(extraFieldZip64) && extraFieldZip64.uncompressedSize !== UNDEFINED_VALUE;
        const zip64CompressedSize = Boolean(extraFieldZip64) && extraFieldZip64.compressedSize !== UNDEFINED_VALUE;
        const bitFlagValue = getBitFlag(level, languageEncodingFlag, dataDescriptor, encrypted, compressionMethod) & ~BITFLAG_LEVEL | level << 1;
        const {
          headerArray,
          headerView
        } = getHeaderArrayData({
          version,
          bitFlag: bitFlagValue,
          compressionMethod,
          uncompressedSize,
          compressedSize,
          rawLastModDate,
          rawFilename,
          zip64CompressedSize,
          zip64UncompressedSize,
          extraFieldLength
        });
        const { crc32 } = entry;
        if (crc32 !== UNDEFINED_VALUE) {
          setUint32(headerView, HEADER_OFFSET_SIGNATURE, crc32);
        }
        const { offset, diskNumberStart } = entryPositions.get(entry);
        Object.assign(entry, {
          zip64Enabled: true,
          zip64UncompressedSize,
          zip64CompressedSize,
          offset,
          diskNumberStart,
          zip64DiskNumberStart: false,
          rawExtraFieldZip64: EMPTY_UINT8_ARRAY,
          rawExtraFieldAES: EMPTY_UINT8_ARRAY,
          rawExtraFieldExtendedTimestamp: EMPTY_UINT8_ARRAY,
          rawExtraFieldNTFS: EMPTY_UINT8_ARRAY,
          rawExtraFieldUnix: EMPTY_UINT8_ARRAY,
          rawExtraField,
          rawCentralExtraField: EMPTY_UINT8_ARRAY,
          extendedTimestamp: false,
          headerArray,
          headerView
        });
        fileEntries.set(entry.filename, entry);
      });
    } catch (error) {
      appendedFilenames.forEach((filename) => filenames.delete(filename));
      throw error;
    } finally {
      resolveAppendZip();
      pendingAddFileCalls.delete(promiseAppendZip);
      if (releaseLockWriter) {
        releaseLockWriter();
      }
    }
  }
  add(name = "", reader, options = {}) {
    const zipWriter = this;
    const { pendingAddFileCalls } = zipWriter;
    const promiseAddFile = addFileEntry(zipWriter, name, reader, options);
    pendingAddFileCalls.add(promiseAddFile);
    const deletePendingAddFileCall = () => pendingAddFileCalls.delete(promiseAddFile);
    Promise.prototype.then.call(promiseAddFile, deletePendingAddFileCall, deletePendingAddFileCall);
    return watchPromiseError(zipWriter, promiseAddFile);
  }
  remove(entry) {
    const { filenames, fileEntries } = this;
    if (typeof entry == STRING_TYPE) {
      entry = fileEntries.get(entry);
    }
    if (entry && entry.filename !== UNDEFINED_VALUE) {
      const { filename } = entry;
      if (filenames.has(filename) && fileEntries.has(filename)) {
        filenames.delete(filename);
        fileEntries.delete(filename);
        return true;
      }
    }
    return false;
  }
  async close(comment = EMPTY_UINT8_ARRAY, options = {}) {
    const zipWriter = this;
    const { pendingAddFileCalls, writer } = this;
    const { writable } = writer;
    if (zipWriter.archiveClosed) {
      return getWriterData(writer);
    }
    if (!(comment instanceof Uint8Array)) {
      throw new Error(ERR_INVALID_COMMENT_TYPE);
    }
    if (getLength(comment) > MAX_16_BITS) {
      throw new Error(ERR_INVALID_COMMENT);
    }
    while (pendingAddFileCalls.size) {
      await Promise.allSettled(Array.from(pendingAddFileCalls));
    }
    await Promise.allSettled(zipWriter.pendingErrors.map((watcher) => watcher.recorded));
    const unobservedWatchers = zipWriter.pendingErrors.filter((watcher) => watcher.failed && !watcher.observed);
    if (unobservedWatchers.length) {
      const unobservedErrors = unobservedWatchers.map((watcher) => watcher.error);
      unobservedWatchers.forEach((watcher) => watcher.observed = true);
      const [error] = unobservedErrors;
      try {
        error.entryErrors = unobservedErrors;
      } catch {
      }
      throw error;
    }
    await closeFile(zipWriter, comment, options);
    zipWriter.archiveClosed = true;
    const preventClose = !ownsWritable(writer) && getOptionValue2(zipWriter, options, OPTION_PREVENT_CLOSE);
    if (!preventClose) {
      await writable.getWriter().close();
    }
    return getWriterData(writer);
  }
  [SYMBOL_ASYNC_DISPOSE]() {
    return this.close();
  }
};
var WatchedPromise = class extends Promise {
  then(onFulfilled, onRejected) {
    const { watcher } = this;
    if (watcher) {
      watcher.observed = true;
    }
    return super.then(onFulfilled, onRejected);
  }
};
function getWriterData(writer) {
  return writer.getData ? writer.getData() : writer.writable;
}
function watchPromiseError(zipWriter, promise) {
  const watchedPromise = new WatchedPromise((resolve, reject) => Promise.prototype.then.call(promise, resolve, reject));
  const watcher = {};
  watchedPromise.watcher = watcher;
  watcher.recorded = Promise.prototype.then.call(
    watchedPromise,
    UNDEFINED_VALUE,
    (error) => Object.assign(watcher, { failed: true, error })
  );
  zipWriter.pendingErrors.push(watcher);
  return watchedPromise;
}
async function prependZipEntries(zipWriter, reader) {
  if (zipWriter.filenames.size) {
    throw new Error(ERR_ZIP_NOT_EMPTY);
  }
  await zipWriter.appendZipEntries(reader);
}
async function addFileEntry(zipWriter, name, reader, options) {
  options = Object.assign({}, options);
  const entry = options[OPTION_ENTRY];
  if (entry !== UNDEFINED_VALUE) {
    const { entryOptions, passThroughOptions } = getSourceEntryOptions(
      entry,
      checkPassThroughOption(getOptionValue2(zipWriter, options, OPTION_PASS_THROUGH)),
      getOptionValue2(zipWriter, options, PROPERTY_NAME_LAST_MODIFICATION_DATE)
    );
    delete options[OPTION_ENTRY];
    options = Object.assign(entryOptions, passThroughOptions, options);
  }
  if (getOptionValue2(zipWriter, options, PROPERTY_NAME_DIRECTORY) && !name.endsWith(DIRECTORY_SIGNATURE)) {
    name += DIRECTORY_SIGNATURE;
  }
  if (zipWriter.filenames.has(name)) {
    throw new Error(ERR_DUPLICATED_NAME);
  }
  zipWriter.filenames.add(name);
  if (workers < getConfiguration().maxWorkers) {
    workers++;
  } else {
    await new Promise((resolve) => pendingEntries.push(resolve));
  }
  try {
    return await addFile(zipWriter, name, reader, options);
  } catch (error) {
    zipWriter.filenames.delete(name);
    throw error;
  } finally {
    const pendingEntry = pendingEntries.shift();
    if (pendingEntry) {
      pendingEntry();
    } else {
      workers--;
    }
  }
}
async function addFile(zipWriter, name, reader, options) {
  const attributesInfo = resolveAttributes(zipWriter, name, options);
  ({ name } = attributesInfo);
  const metadataInfo = resolveMetadata(zipWriter, name, options);
  const { comment } = metadataInfo;
  const extraField = options[PROPERTY_NAME_EXTRA_FIELD];
  zipWriter.fileEntries.set(name, UNDEFINED_VALUE);
  const previousFileEntry = zipWriter.lastFileEntry;
  const pendingFileEntry = {};
  let releaseLockFileEntry;
  if (metadataInfo.resolvedOptions.keepOrder) {
    pendingFileEntry.lockFileEntry = new Promise((resolve) => releaseLockFileEntry = resolve);
  }
  zipWriter.lastFileEntry = pendingFileEntry;
  let fileEntry;
  try {
    const { resolvedOptions } = metadataInfo;
    if (resolvedOptions.level != 0 && resolvedOptions.compressionMethod === UNDEFINED_VALUE && !resolvedOptions.passThroughCompression && !await supportsDeflate(getConfiguration())) {
      resolvedOptions.level = 0;
      addWarning(zipWriter.warnings, WARNING_COMPRESSION_UNAVAILABLE, name);
    }
    const sizesInfo = await resolveSizes(zipWriter, reader, metadataInfo, options);
    ({ reader } = sizesInfo);
    const diskOffset = getDiskOffset2(zipWriter.writer);
    const diskNumber = getDiskNumber(zipWriter.writer);
    let crc32 = options.crc32 === UNDEFINED_VALUE ? options[PROPERTY_NAME_SIGNATURE] : options.crc32;
    const storesAE2 = sizesInfo.resolvedOptions.encrypted && !resolvedOptions.zipCrypto;
    if (resolvedOptions.passThroughCompression && !resolvedOptions.passThroughEncryption && storesAE2) {
      crc32 = UNDEFINED_VALUE;
    }
    if (resolvedOptions.passThroughCompression && reader && !storesAE2 && crc32 === UNDEFINED_VALUE) {
      throw new Error(ERR_UNDEFINED_CRC32);
    }
    options = Object.assign({}, options, attributesInfo.resolvedOptions, metadataInfo.resolvedOptions, sizesInfo.resolvedOptions, {
      signature: options[PROPERTY_NAME_SIGNATURE],
      crc32,
      offset: zipWriter.offset - diskOffset,
      diskNumberStart: diskNumber,
      [OPTION_USDZ]: zipWriter.options[OPTION_USDZ]
    });
    const headerInfo = getHeaderInfo(options);
    if (headerInfo.lastModDateClamped) {
      addWarning(zipWriter.warnings, WARNING_CLAMPED_LAST_MODIFICATION_DATE, name);
    }
    const dataDescriptorInfo = getDataDescriptorInfo(options);
    const metadataSize = getLength(headerInfo.localHeaderArray, dataDescriptorInfo.dataDescriptorArray);
    fileEntry = await getFileEntry(zipWriter, name, reader, {
      headerInfo,
      dataDescriptorInfo,
      metadataSize,
      fileEntry: pendingFileEntry,
      previousFileEntry,
      releaseLockFileEntry
    }, options);
  } catch (error) {
    zipWriter.fileEntries.delete(name);
    throw error;
  } finally {
    if (releaseLockFileEntry) {
      releaseLockFileEntry(previousFileEntry && previousFileEntry.lockFileEntry);
    }
  }
  Object.assign(fileEntry, {
    name,
    comment,
    extraField
  });
  return new Entry(fileEntry);
}
function getSourceEntryOptions(entry, passThrough, lastModDateOverride) {
  if (entry === null || typeof entry != OBJECT_TYPE || Array.isArray(entry)) {
    throw new Error(ERR_INVALID_ENTRY);
  }
  const {
    externalFileAttributes,
    versionMadeBy,
    comment,
    lastModDate,
    rawLastModDate,
    creationDate,
    lastAccessDate,
    uncompressedSize,
    encrypted,
    zipCrypto,
    crc32,
    compressionMethod,
    extraFieldAES,
    extraFieldUnix,
    internalFileAttributes,
    extraField,
    bitFlag,
    directory,
    uid,
    gid
  } = entry;
  const entryOptions = {
    externalFileAttributes,
    versionMadeBy,
    comment,
    lastModDate,
    creationDate,
    lastAccessDate,
    internalFileAttributes,
    directory
  };
  if (bitFlag && bitFlag.languageEncodingFlag) {
    entryOptions[OPTION_USE_UNICODE_FILE_NAMES] = true;
  }
  const userExtraField = getUserExtraField(extraField);
  if (userExtraField) {
    entryOptions[PROPERTY_NAME_EXTRA_FIELD] = userExtraField;
  }
  if (uid !== UNDEFINED_VALUE || gid !== UNDEFINED_VALUE) {
    Object.assign(entryOptions, {
      uid,
      gid,
      unixExtraFieldType: extraFieldUnix ? UNIX_EXTRA_FIELD_TYPE : INFOZIP_EXTRA_FIELD_TYPE
    });
  }
  const passThroughOptions = {};
  if (passThrough && !directory) {
    Object.assign(passThroughOptions, {
      uncompressedSize,
      crc32,
      compressionMethod
    });
    if (passThrough !== PASS_THROUGH_COMPRESSED) {
      Object.assign(passThroughOptions, {
        encrypted,
        zipCrypto,
        encryptionStrength: extraFieldAES ? extraFieldAES.strength : UNDEFINED_VALUE
      });
    }
    if (bitFlag) {
      passThroughOptions.dataDescriptor = bitFlag.dataDescriptor;
      passThroughOptions[OPTION_LEVEL] = LEVEL_BY_BITFLAG_LEVEL[bitFlag.level];
    }
    if (lastModDateOverride === UNDEFINED_VALUE) {
      passThroughOptions.rawLastModDate = rawLastModDate;
    } else if (passThrough !== PASS_THROUGH_COMPRESSED && zipCrypto && (!bitFlag || bitFlag.dataDescriptor) && lastModDateOverride instanceof Date && getDosTimeHighByte(lastModDateOverride) != (rawLastModDate >>> 8 & MAX_8_BITS)) {
      throw new Error(ERR_ZIP_CRYPTO_LAST_MOD_DATE);
    }
  }
  return { entryOptions, passThroughOptions };
}
function getDosTimeHighByte(lastModDate) {
  let dosLastModDate = new Date(Math.ceil(Math.floor(lastModDate.getTime() / 1e3) / 2) * 2e3);
  if (dosLastModDate < MIN_DATE) {
    dosLastModDate = MIN_DATE;
  } else if (dosLastModDate > MAX_DATE) {
    dosLastModDate = MAX_DATE;
  }
  return (dosLastModDate.getHours() << 3 | dosLastModDate.getMinutes() >> 3) & MAX_8_BITS;
}
function resolveAttributes(zipWriter, name, options) {
  let msDosCompatible = getOptionValue2(zipWriter, options, PROPERTY_NAME_MS_DOS_COMPATIBLE);
  let versionMadeBy = getOptionValue2(zipWriter, options, PROPERTY_NAME_VERSION_MADE_BY, msDosCompatible ? VERSION_MADE_BY_MSDOS : VERSION_MADE_BY_UNIX);
  const executable = getOptionValue2(zipWriter, options, PROPERTY_NAME_EXECUTABLE);
  const uid = getNumberOptionValue(zipWriter, options, PROPERTY_NAME_UID);
  const gid = getNumberOptionValue(zipWriter, options, PROPERTY_NAME_GID);
  let unixMode = getNumberOptionValue(zipWriter, options, PROPERTY_NAME_UNIX_MODE);
  let unixExtraFieldType = getOptionValue2(zipWriter, options, OPTION_UNIX_EXTRA_FIELD_TYPE);
  let setuid = getOptionValue2(zipWriter, options, PROPERTY_NAME_SETUID);
  let setgid = getOptionValue2(zipWriter, options, PROPERTY_NAME_SETGID);
  let sticky = getOptionValue2(zipWriter, options, PROPERTY_NAME_STICKY);
  checkIntegerOption(uid, MAX_32_BITS, ERR_INVALID_UID);
  checkIntegerOption(gid, MAX_32_BITS, ERR_INVALID_GID);
  checkIntegerOption(unixMode, MAX_16_BITS, ERR_INVALID_UNIX_MODE);
  if (unixExtraFieldType !== UNDEFINED_VALUE && unixExtraFieldType !== INFOZIP_EXTRA_FIELD_TYPE && unixExtraFieldType !== UNIX_EXTRA_FIELD_TYPE) {
    throw new Error(ERR_INVALID_UNIX_EXTRA_FIELD_TYPE);
  }
  if (unixExtraFieldType === UNIX_EXTRA_FIELD_TYPE && (uid !== UNDEFINED_VALUE && uid > MAX_16_BITS || gid !== UNDEFINED_VALUE && gid > MAX_16_BITS)) {
    throw new Error(ERR_INVALID_UNIX_ID_SIZE);
  }
  if (unixExtraFieldType === UNDEFINED_VALUE && (uid !== UNDEFINED_VALUE || gid !== UNDEFINED_VALUE)) {
    unixExtraFieldType = INFOZIP_EXTRA_FIELD_TYPE;
  }
  let msdosAttributesRaw = getNumberOptionValue(zipWriter, options, PROPERTY_NAME_MSDOS_ATTRIBUTES_RAW);
  let msdosAttributes = getOptionValue2(zipWriter, options, PROPERTY_NAME_MSDOS_ATTRIBUTES);
  const hasUnixMetadata = uid !== UNDEFINED_VALUE || gid !== UNDEFINED_VALUE || unixMode !== UNDEFINED_VALUE || unixExtraFieldType || executable;
  const hasMsDosProvided = msdosAttributesRaw !== UNDEFINED_VALUE || msdosAttributes !== UNDEFINED_VALUE;
  if (hasUnixMetadata) {
    msDosCompatible = false;
    versionMadeBy = versionMadeBy & MAX_8_BITS | VERSION_MADE_BY_UNIX;
  } else if (hasMsDosProvided) {
    msDosCompatible = true;
    versionMadeBy = versionMadeBy & MAX_8_BITS;
  }
  checkIntegerOption(msdosAttributesRaw, MAX_8_BITS, ERR_INVALID_MSDOS_ATTRIBUTES);
  if (msdosAttributes && (typeof msdosAttributes !== OBJECT_TYPE || Array.isArray(msdosAttributes))) {
    throw new Error(ERR_INVALID_MSDOS_DATA);
  }
  if (versionMadeBy > MAX_16_BITS) {
    throw new Error(ERR_INVALID_VERSION);
  }
  let externalFileAttributes = getOptionValue2(zipWriter, options, PROPERTY_NAME_EXTERNAL_FILE_ATTRIBUTES);
  const externalFileAttributesProvided = externalFileAttributes !== UNDEFINED_VALUE;
  if (!externalFileAttributesProvided) {
    externalFileAttributes = 0;
  }
  if (!options[PROPERTY_NAME_DIRECTORY] && name.endsWith(DIRECTORY_SIGNATURE)) {
    options[PROPERTY_NAME_DIRECTORY] = true;
  }
  const directory = getOptionValue2(zipWriter, options, PROPERTY_NAME_DIRECTORY);
  if (directory) {
    if (!name.endsWith(DIRECTORY_SIGNATURE)) {
      name += DIRECTORY_SIGNATURE;
    }
    if (!externalFileAttributesProvided) {
      externalFileAttributes = FILE_ATTR_MSDOS_DIR_MASK;
      if (!msDosCompatible) {
        externalFileAttributes |= (FILE_ATTR_UNIX_TYPE_DIR | FILE_ATTR_UNIX_EXECUTABLE_MASK | FILE_ATTR_UNIX_DEFAULT_MASK) << 16;
      }
    }
  } else if (!msDosCompatible && !externalFileAttributesProvided) {
    if (executable) {
      externalFileAttributes = (FILE_ATTR_UNIX_EXECUTABLE_MASK | FILE_ATTR_UNIX_DEFAULT_MASK) << 16;
    } else {
      externalFileAttributes = FILE_ATTR_UNIX_DEFAULT_MASK << 16;
    }
  }
  if (!msDosCompatible) {
    const unixModeProvided = unixMode !== UNDEFINED_VALUE || Boolean(setuid || setgid || sticky);
    const defaultUnixMode = externalFileAttributes >> 16 & MAX_16_BITS;
    unixMode = unixMode === UNDEFINED_VALUE ? defaultUnixMode : unixMode & MAX_16_BITS;
    if (setuid) {
      unixMode |= FILE_ATTR_UNIX_SETUID_MASK;
    } else {
      setuid = Boolean(unixMode & FILE_ATTR_UNIX_SETUID_MASK);
    }
    if (setgid) {
      unixMode |= FILE_ATTR_UNIX_SETGID_MASK;
    } else {
      setgid = Boolean(unixMode & FILE_ATTR_UNIX_SETGID_MASK);
    }
    if (sticky) {
      unixMode |= FILE_ATTR_UNIX_STICKY_MASK;
    } else {
      sticky = Boolean(unixMode & FILE_ATTR_UNIX_STICKY_MASK);
    }
    if (!externalFileAttributesProvided || unixModeProvided) {
      if (directory) {
        unixMode = unixMode & ~FILE_ATTR_UNIX_TYPE_MASK | FILE_ATTR_UNIX_TYPE_DIR;
      } else if (!(unixMode & FILE_ATTR_UNIX_TYPE_MASK)) {
        unixMode |= FILE_ATTR_UNIX_TYPE_FILE;
      }
      externalFileAttributes = (unixMode & MAX_16_BITS) << 16 | externalFileAttributes & MAX_16_BITS;
    }
  }
  ({ msdosAttributesRaw, msdosAttributes } = normalizeMsdosAttributes(msdosAttributesRaw, msdosAttributes));
  if (hasMsDosProvided) {
    externalFileAttributes = externalFileAttributes & MAX_32_BITS | msdosAttributesRaw & MAX_8_BITS;
  }
  const unixExternalUpper = externalFileAttributes >> 16 & MAX_16_BITS;
  const symlink = unixMode !== UNDEFINED_VALUE && (unixMode & FILE_ATTR_UNIX_TYPE_MASK) == FILE_ATTR_UNIX_TYPE_SYMLINK;
  return {
    name,
    resolvedOptions: {
      versionMadeBy,
      msDosCompatible: Boolean(msDosCompatible),
      externalFileAttributes,
      unixExternalUpper,
      uid,
      gid,
      unixMode,
      unixExtraFieldType,
      symlink,
      setuid,
      setgid,
      sticky,
      msdosAttributesRaw,
      msdosAttributes
    }
  };
}
function resolveMetadata(zipWriter, name, options) {
  const encode = getFunctionOptionValue2(zipWriter, options, OPTION_ENCODE_TEXT) || encodeText;
  let rawFilename = encode(name, TEXT_TYPE_FILENAME);
  if (rawFilename === UNDEFINED_VALUE) {
    rawFilename = encodeText(name);
  }
  if (getLength(rawFilename) > MAX_16_BITS) {
    throw new Error(ERR_INVALID_ENTRY_NAME);
  }
  const comment = options[PROPERTY_NAME_COMMENT] || "";
  if (typeof comment != STRING_TYPE) {
    throw new Error(ERR_INVALID_ENTRY_COMMENT_TYPE);
  }
  let rawComment = encode(comment, TEXT_TYPE_COMMENT);
  if (rawComment === UNDEFINED_VALUE) {
    rawComment = encodeText(comment);
  }
  if (getLength(rawComment) > MAX_16_BITS) {
    throw new Error(ERR_INVALID_ENTRY_COMMENT);
  }
  const version = getOptionValue2(zipWriter, options, PROPERTY_NAME_VERSION);
  if (version !== UNDEFINED_VALUE && version > MAX_16_BITS) {
    throw new Error(ERR_INVALID_VERSION);
  }
  const lastModDate = getDateOptionValue(zipWriter, options, PROPERTY_NAME_LAST_MODIFICATION_DATE, /* @__PURE__ */ new Date());
  const rawLastModDate = getOptionValue2(zipWriter, options, PROPERTY_NAME_RAW_LAST_MODIFICATION_DATE);
  const lastAccessDate = getDateOptionValue(zipWriter, options, PROPERTY_NAME_LAST_ACCESS_DATE);
  const creationDate = getDateOptionValue(zipWriter, options, PROPERTY_NAME_CREATION_DATE);
  const internalFileAttributes = getOptionValue2(zipWriter, options, PROPERTY_NAME_INTERNAL_FILE_ATTRIBUTES, 0);
  const passThrough = checkPassThroughOption(getOptionValue2(zipWriter, options, OPTION_PASS_THROUGH));
  const passThroughCompression = Boolean(passThrough);
  const passThroughEncryption = passThrough === true;
  const password = getOptionValue2(zipWriter, options, OPTION_PASSWORD);
  const rawPassword = getOptionValue2(zipWriter, options, OPTION_RAW_PASSWORD);
  checkPasswordOption(password, rawPassword);
  const encryptionStrength = getNumberOptionValue(zipWriter, options, OPTION_ENCRYPTION_STRENGTH, 3);
  const zipCrypto = getOptionValue2(zipWriter, options, PROPERTY_NAME_ZIPCRYPTO);
  const extendedTimestamp = getOptionValue2(zipWriter, options, OPTION_EXTENDED_TIMESTAMP, true);
  const ntfsTimestamp = getOptionValue2(zipWriter, options, OPTION_NTFS_TIMESTAMP);
  const keepOrder = getOptionValue2(zipWriter, options, OPTION_KEEP_ORDER, true);
  const useWebWorkers = getOptionValue2(zipWriter, options, OPTION_USE_WEB_WORKERS);
  const transferStreams = getOptionValue2(zipWriter, options, OPTION_TRANSFER_STREAMS);
  const bufferedWrite = getOptionValue2(zipWriter, options, OPTION_BUFFERED_WRITE);
  const createTempStream = getFunctionOptionValue2(zipWriter, options, OPTION_CREATE_TEMP_STREAM);
  const dataDescriptorSignature = getOptionValue2(zipWriter, options, OPTION_DATA_DESCRIPTOR_SIGNATURE, true);
  const signal = checkSignalOption(getOptionValue2(zipWriter, options, OPTION_SIGNAL));
  throwIfAborted(signal);
  const useUnicodeFileNames = getOptionValue2(
    zipWriter,
    options,
    OPTION_USE_UNICODE_FILE_NAMES,
    !isPrintableASCIIText(rawFilename) || !isPrintableASCIIText(rawComment)
  );
  const compressionMethod = getOptionValue2(zipWriter, options, PROPERTY_NAME_COMPRESSION_METHOD);
  const registeredCodec = passThroughCompression || compressionMethod === UNDEFINED_VALUE ? UNDEFINED_VALUE : getRegisteredCodec(compressionMethod);
  if (!passThroughCompression && compressionMethod !== UNDEFINED_VALUE && compressionMethod !== COMPRESSION_METHOD_STORE && compressionMethod !== COMPRESSION_METHOD_DEFLATE && !registeredCodec) {
    throw new Error(ERR_UNSUPPORTED_COMPRESSION);
  }
  let level = getNumberOptionValue(zipWriter, options, OPTION_LEVEL);
  checkIntegerOption(level, MAX_LEVEL, ERR_INVALID_LEVEL);
  if (zipWriter.options[OPTION_USDZ]) {
    if (password !== UNDEFINED_VALUE || rawPassword !== UNDEFINED_VALUE) {
      throw new Error(ERR_UNSUPPORTED_ENCRYPTION_USDZ);
    }
    if (level === UNDEFINED_VALUE && compressionMethod === UNDEFINED_VALUE) {
      level = 0;
    }
  }
  if (passThroughCompression) {
    level = toNumber(options[OPTION_LEVEL]);
  }
  let useCompressionStream = getOptionValue2(zipWriter, options, OPTION_USE_COMPRESSION_STREAM);
  let dataDescriptor = getOptionValue2(zipWriter, options, OPTION_DATA_DESCRIPTOR);
  if (bufferedWrite && dataDescriptor === UNDEFINED_VALUE) {
    dataDescriptor = false;
  }
  if (dataDescriptor === UNDEFINED_VALUE || zipCrypto && !passThroughEncryption) {
    dataDescriptor = true;
  }
  if (level !== UNDEFINED_VALUE && level != 6) {
    useCompressionStream = false;
  }
  const zip64 = getOptionValue2(zipWriter, options, PROPERTY_NAME_ZIP64);
  if (!zipCrypto && (password !== UNDEFINED_VALUE || rawPassword !== UNDEFINED_VALUE) && !(Number.isInteger(encryptionStrength) && encryptionStrength >= 1 && encryptionStrength <= 3)) {
    throw new Error(ERR_INVALID_ENCRYPTION_STRENGTH);
  }
  const rawExtraField = serializeExtraField(options[PROPERTY_NAME_EXTRA_FIELD]);
  const rawLocalExtraField = serializeExtraField(options[OPTION_LOCAL_EXTRA_FIELD]);
  const rawCentralExtraField = serializeExtraField(options[OPTION_CENTRAL_EXTRA_FIELD]);
  return {
    comment,
    resolvedOptions: {
      rawFilename,
      rawComment,
      version,
      lastModDate,
      rawLastModDate,
      lastAccessDate,
      creationDate,
      internalFileAttributes,
      passThroughCompression,
      passThroughEncryption,
      password,
      rawPassword,
      encryptionStrength,
      zipCrypto,
      extendedTimestamp,
      ntfsTimestamp,
      keepOrder,
      useWebWorkers,
      transferStreams,
      bufferedWrite,
      createTempStream,
      dataDescriptorSignature,
      signal,
      useUnicodeFileNames,
      compressionMethod,
      format: registeredCodec ? registeredCodec.format : UNDEFINED_VALUE,
      codecURI: registeredCodec ? registeredCodec.codecURI : UNDEFINED_VALUE,
      codecVersionNeeded: registeredCodec ? registeredCodec.versionNeeded : UNDEFINED_VALUE,
      level,
      useCompressionStream,
      dataDescriptor,
      zip64,
      rawExtraField,
      rawLocalExtraField,
      rawCentralExtraField
    }
  };
}
function serializeExtraField(extraField) {
  if (!extraField) {
    return EMPTY_UINT8_ARRAY;
  }
  if (!(extraField instanceof Map)) {
    throw new Error(ERR_INVALID_EXTRAFIELD);
  }
  let extraFieldSize = 0;
  let offset = 0;
  extraField.forEach((data, type) => {
    checkInteger(type, MAX_16_BITS, ERR_INVALID_EXTRAFIELD_TYPE);
    if (!(data instanceof Uint8Array)) {
      throw new Error(ERR_INVALID_EXTRAFIELD_DATA_TYPE);
    }
    if (getLength(data) > MAX_16_BITS) {
      throw new Error(ERR_INVALID_EXTRAFIELD_DATA);
    }
    extraFieldSize += 4 + getLength(data);
  });
  const rawExtraField = new Uint8Array(extraFieldSize);
  const rawExtraFieldView = getDataView(rawExtraField);
  extraField.forEach((data, type) => {
    setUint16(rawExtraFieldView, offset, type);
    setUint16(rawExtraFieldView, offset + 2, getLength(data));
    arraySet(rawExtraField, data, offset + 4);
    offset += 4 + getLength(data);
  });
  return rawExtraField;
}
async function resolveSizes(zipWriter, reader, { resolvedOptions: metadata }, options) {
  if (metadata.passThroughCompression && !reader && !getOptionValue2(zipWriter, options, PROPERTY_NAME_DIRECTORY)) {
    throw new Error(ERR_UNDEFINED_READER);
  }
  let contentSize;
  if (reader) {
    reader = new GenericReader(reader);
    await initStream(reader);
    if (!reader.readable && !reader.readUint8Array) {
      throw new Error(ERR_INVALID_READER);
    }
    ({ size: contentSize } = reader);
  }
  return Object.assign({ reader }, resolveEntrySizes(zipWriter, Boolean(reader), contentSize, metadata, options));
}
function resolveEntrySizes(zipWriter, hasContent, contentSize, metadata, options) {
  const { passThroughCompression, passThroughEncryption, zipCrypto, password, rawPassword, encryptionStrength } = metadata;
  let { dataDescriptor, zip64, level, compressionMethod } = metadata;
  let maximumCompressedSize = 0;
  let uncompressedSize = 0;
  let unknownSize = false;
  if (passThroughCompression && hasContent) {
    uncompressedSize = options[PROPERTY_NAME_UNCOMPRESSED_SIZE];
    if (uncompressedSize === UNDEFINED_VALUE) {
      throw new Error(ERR_UNDEFINED_UNCOMPRESSED_SIZE);
    }
    if (compressionMethod === UNDEFINED_VALUE) {
      throw new Error(ERR_UNDEFINED_COMPRESSION_METHOD);
    }
  }
  const zip64Enabled = zip64 === true;
  const encrypted = getOptionValue2(zipWriter, options, PROPERTY_NAME_ENCRYPTED);
  if (hasContent && passThroughEncryption && !encrypted && getLength(password, rawPassword)) {
    throw new Error(ERR_UNSUPPORTED_ENCRYPTION_PASS_THROUGH);
  }
  const encryptedEntry = hasContent && (Boolean(password && getLength(password) || rawPassword && getLength(rawPassword)) || passThroughEncryption && encrypted);
  if (!hasContent) {
    level = 0;
    compressionMethod = COMPRESSION_METHOD_STORE;
  }
  const encryptionOverhead = getEncryptionOverhead(encryptedEntry, zipCrypto, encryptionStrength);
  if (hasContent) {
    if (!passThroughCompression) {
      if (contentSize === UNDEFINED_VALUE) {
        dataDescriptor = true;
        if (zip64 || zip64 === UNDEFINED_VALUE) {
          zip64 = unknownSize = true;
          maximumCompressedSize = MAX_32_BITS + 1;
        }
      } else {
        options.uncompressedSize = uncompressedSize = contentSize;
        maximumCompressedSize = (isCompressed(compressionMethod, level) ? getMaximumCompressedSize(uncompressedSize) : uncompressedSize) + encryptionOverhead;
      }
    } else {
      options.uncompressedSize = uncompressedSize;
      maximumCompressedSize = contentSize === UNDEFINED_VALUE ? getMaximumCompressedSize(uncompressedSize) + encryptionOverhead : contentSize + (passThroughEncryption ? 0 : encryptionOverhead);
    }
  }
  const emptyEntry = !encryptedEntry && (!hasContent || contentSize === 0 && !passThroughCompression) && !isCompressed(compressionMethod, level);
  if (emptyEntry && !zipCrypto && getOptionValue2(zipWriter, options, OPTION_DATA_DESCRIPTOR) === UNDEFINED_VALUE) {
    dataDescriptor = false;
  }
  const zip64UncompressedSize = zip64Enabled || unknownSize || uncompressedSize >= MAX_32_BITS;
  const zip64CompressedSize = zip64Enabled || maximumCompressedSize >= MAX_32_BITS;
  if (zip64UncompressedSize || zip64CompressedSize) {
    if (zip64 === false) {
      throw new Error(ERR_UNSUPPORTED_FORMAT);
    } else {
      zip64 = true;
    }
  }
  zip64 = zip64 || false;
  return {
    maximumCompressedSize,
    resolvedOptions: {
      dataDescriptor,
      emptyEntry,
      zip64,
      zip64Enabled,
      unknownSize,
      zip64UncompressedSize,
      zip64CompressedSize,
      uncompressedSize,
      level,
      compressionMethod,
      encrypted: encryptedEntry
    }
  };
}
async function getFileEntry(zipWriter, name, reader, entryInfo, options) {
  const {
    fileEntries,
    writer
  } = zipWriter;
  const {
    keepOrder,
    dataDescriptor,
    emptyEntry,
    signal
  } = options;
  const {
    headerInfo,
    fileEntry: pendingFileEntry,
    previousFileEntry,
    releaseLockFileEntry
  } = entryInfo;
  const usdz = zipWriter.options[OPTION_USDZ];
  let fileEntry = pendingFileEntry;
  let bufferedWrite;
  let directWrite;
  let releaseLockWriter;
  let writingBufferedEntryData;
  let writingEntryData;
  let writerSizeBeforeEntry;
  let flushedBufferedSize = 0;
  let fileWriter;
  const lockPreviousFileEntry = keepOrder && previousFileEntry ? previousFileEntry.lockFileEntry : UNDEFINED_VALUE;
  fileEntries.set(name, fileEntry);
  try {
    if (options.bufferedWrite || !keepOrder || zipWriter.writerLocked || zipWriter.bufferedWrites || zipWriter.directWrites || !dataDescriptor && !emptyEntry) {
      bufferedWrite = true;
      zipWriter.bufferedWrites++;
      if (options.createTempStream) {
        fileWriter = await options.createTempStream();
      } else {
        fileWriter = new TransformStream(UNDEFINED_VALUE, UNDEFINED_VALUE, { highWaterMark: INFINITY_VALUE });
      }
      fileWriter.size = 0;
      await initStream(writer);
    } else {
      directWrite = true;
      zipWriter.directWrites++;
      fileWriter = writer;
      await lockPreviousFileEntry;
      await requestLockWriter();
    }
    await initStream(fileWriter);
    const diskOffset = getDiskOffset2(writer);
    if (zipWriter.addSplitZipSignature && !bufferedWrite) {
      await writeSplitZipSignature(zipWriter, writer);
    }
    if (usdz && !bufferedWrite) {
      appendExtraFieldUSDZ(entryInfo, zipWriter.offset - diskOffset);
    }
    const { localHeaderArray } = headerInfo;
    if (!bufferedWrite) {
      await skipDiskIfNeeded();
    }
    const diskNumberStart = getDiskNumber(writer);
    const entryOffset = getSegmentOffset(zipWriter, writer);
    fileEntry.diskNumberStart = diskNumberStart;
    if (!bufferedWrite) {
      writingEntryData = true;
      writerSizeBeforeEntry = writer.size;
      await writeData(fileWriter, localHeaderArray);
    }
    fileEntry = await createFileEntry(reader, fileWriter, fileEntry, entryInfo, getConfiguration(), options);
    if (!bufferedWrite) {
      writingEntryData = false;
    }
    fileEntries.set(name, fileEntry);
    fileEntry.filename = name;
    if (bufferedWrite) {
      await Promise.all([fileWriter.writable.getWriter().close(), lockPreviousFileEntry]);
      await requestLockWriter();
      if (zipWriter.addSplitZipSignature) {
        await writeSplitZipSignature(zipWriter, writer);
      }
      writingBufferedEntryData = true;
      writerSizeBeforeEntry = writer.size;
      await skipDiskIfNeeded();
      fileEntry.diskNumberStart = getDiskNumber(writer);
      fileEntry.offset = getSegmentOffset(zipWriter, writer);
      if (usdz) {
        const previousMetadataSize = entryInfo.metadataSize;
        appendExtraFieldUSDZ(entryInfo, zipWriter.offset - getDiskOffset2(writer));
        fileEntry.size += entryInfo.metadataSize - previousMetadataSize;
      }
      updateLocalHeader(fileEntry, headerInfo.localHeaderView, options);
      await writeData(writer, headerInfo.localHeaderArray);
      await flushBufferedData(fileWriter.readable, writer, signal, (chunkLength) => flushedBufferedSize += chunkLength);
      writer.size += fileWriter.size;
      writingBufferedEntryData = false;
    } else {
      fileEntry.diskNumberStart = diskNumberStart;
      fileEntry.offset = entryOffset;
    }
    zipWriter.offset += fileEntry.size;
    return fileEntry;
  } catch (error) {
    if (writingBufferedEntryData || writingEntryData) {
      zipWriter.hasCorruptedEntries = true;
      if (error) {
        try {
          error.corruptedEntry = true;
        } catch {
        }
      }
      zipWriter.offset += writer.size - writerSizeBeforeEntry;
      if (bufferedWrite) {
        zipWriter.offset += flushedBufferedSize;
      }
    }
    fileEntries.delete(name);
    throw error;
  } finally {
    if (bufferedWrite) {
      zipWriter.bufferedWrites--;
    }
    if (directWrite) {
      zipWriter.directWrites--;
    }
    if (releaseLockFileEntry) {
      releaseLockFileEntry(lockPreviousFileEntry);
    }
    if (releaseLockWriter) {
      releaseLockWriter();
    }
    if (bufferedWrite && fileWriter && fileWriter.dispose) {
      try {
        await fileWriter.dispose();
      } catch {
      }
    }
  }
  async function requestLockWriter() {
    zipWriter.writerLocked = true;
    const { lockWriter } = zipWriter;
    zipWriter.lockWriter = new Promise((resolve) => releaseLockWriter = () => {
      zipWriter.writerLocked = false;
      resolve();
    });
    await lockWriter;
  }
  async function skipDiskIfNeeded() {
    if (exceedsAvailableSize(writer, getLength(headerInfo.localHeaderArray))) {
      await writer.closeDisk();
    }
  }
}
async function createFileEntry(reader, writer, { diskNumberStart, lockFileEntry }, entryInfo, config2, options) {
  const {
    headerInfo,
    dataDescriptorInfo,
    metadataSize
  } = entryInfo;
  const {
    headerArray,
    headerView,
    lastModDate,
    rawLastModDate,
    encrypted,
    compressed,
    version,
    compressionMethod,
    rawExtraFieldZip64,
    localExtraFieldZip64Length,
    rawExtraFieldExtendedTimestamp,
    extraFieldExtendedTimestampFlag,
    extraFieldExtendedTimestampTime,
    rawExtraFieldNTFS,
    rawExtraFieldUnix,
    rawExtraFieldAES
  } = headerInfo;
  const { dataDescriptorArray } = dataDescriptorInfo;
  const {
    rawFilename,
    lastAccessDate,
    creationDate,
    password,
    rawPassword,
    level,
    useUnicodeFileNames,
    zip64,
    zip64Enabled,
    zip64UncompressedSize,
    zip64CompressedSize,
    zipCrypto,
    dataDescriptor,
    directory,
    executable,
    versionMadeBy,
    rawComment,
    rawExtraField,
    rawCentralExtraField,
    useWebWorkers,
    transferStreams,
    onstart,
    onprogress,
    onend,
    signal,
    encryptionStrength,
    extendedTimestamp,
    msDosCompatible,
    internalFileAttributes,
    externalFileAttributes,
    uid,
    gid,
    unixMode,
    symlink,
    setuid,
    setgid,
    sticky,
    unixExternalUpper,
    msdosAttributesRaw,
    msdosAttributes,
    useCompressionStream,
    passThroughCompression,
    passThroughEncryption,
    format,
    codecURI
  } = options;
  const fileEntry = {
    lockFileEntry,
    versionMadeBy,
    zip64,
    zip64Enabled,
    directory: Boolean(directory),
    executable: Boolean(executable),
    filenameUTF8: Boolean(useUnicodeFileNames),
    rawFilename,
    commentUTF8: Boolean(useUnicodeFileNames),
    rawComment,
    rawExtraFieldZip64,
    localExtraFieldZip64Length,
    rawExtraFieldExtendedTimestamp,
    rawExtraFieldNTFS,
    rawExtraFieldUnix,
    rawExtraFieldAES,
    rawExtraField,
    rawCentralExtraField,
    extendedTimestamp,
    msDosCompatible,
    internalFileAttributes,
    externalFileAttributes,
    diskNumberStart,
    uid,
    gid,
    unixMode,
    symlink: Boolean(symlink),
    setuid,
    setgid,
    sticky,
    unixExternalUpper,
    msdosAttributesRaw,
    msdosAttributes
  };
  let {
    crc32,
    uncompressedSize
  } = options;
  let compressedSize = 0;
  if (!passThroughCompression) {
    uncompressedSize = 0;
  }
  const { writable } = writer;
  if (reader) {
    const size = reader.size;
    const readable = toCompatibleReadable(createReadable(reader, { size }));
    const workerOptions = {
      options: {
        codecType: CODEC_DEFLATE,
        inputSize: size,
        level,
        rawPassword,
        password,
        encryptionStrength,
        zipCrypto: encrypted && zipCrypto,
        passwordVerification: encrypted && zipCrypto && rawLastModDate >> 8 & MAX_8_BITS,
        computeCrc32: !passThroughCompression,
        compressed: compressed && !passThroughCompression,
        encrypted: encrypted && !passThroughEncryption,
        useWebWorkers,
        useCompressionStream,
        transferStreams,
        format,
        codecURI,
        compressionMethod
      },
      config: config2,
      streamOptions: { signal, size, onstart, onprogress, onend }
    };
    try {
      const result = await runWorker2({ readable, writable }, workerOptions);
      compressedSize = result.outputSize;
      writer.size += compressedSize;
      if (!passThroughCompression) {
        uncompressedSize = result.inputSize;
        if (!encrypted || zipCrypto) {
          crc32 = result.crc32;
        }
      }
      if (!zip64CompressedSize && compressedSize >= MAX_32_BITS || !zip64UncompressedSize && uncompressedSize >= MAX_32_BITS) {
        throw new Error(ERR_UNSUPPORTED_FORMAT);
      }
    } catch (error) {
      const { outputSize: failedOutputSize } = workerOptions;
      if (failedOutputSize !== UNDEFINED_VALUE) {
        writer.size += failedOutputSize;
      } else if (isErrorObject(error) && error.outputSize !== UNDEFINED_VALUE) {
        writer.size += error.outputSize;
      }
      throw error;
    }
  }
  setEntryInfo({
    crc32,
    compressedSize,
    uncompressedSize,
    headerInfo,
    dataDescriptorInfo
  }, options);
  if (dataDescriptor) {
    await writeData(writer, dataDescriptorArray);
  }
  Object.assign(fileEntry, {
    uncompressedSize,
    compressedSize,
    lastModDate,
    rawLastModDate,
    creationDate,
    lastAccessDate,
    encrypted: Boolean(encrypted),
    zipCrypto: Boolean(zipCrypto),
    size: metadataSize + compressedSize,
    compressionMethod,
    version,
    headerArray,
    headerView,
    signature: crc32,
    crc32: encrypted && !zipCrypto && !passThroughCompression ? UNDEFINED_VALUE : crc32,
    extraFieldExtendedTimestampFlag,
    extraFieldExtendedTimestampTime,
    zip64UncompressedSize,
    zip64CompressedSize
  });
  return fileEntry;
}
function getHeaderInfo(options) {
  const {
    rawFilename,
    lastModDate,
    rawLastModDate: rawLastModDateOption,
    lastAccessDate,
    creationDate,
    level,
    zip64,
    zipCrypto,
    useUnicodeFileNames,
    dataDescriptor,
    directory,
    rawExtraField,
    rawLocalExtraField,
    encryptionStrength,
    extendedTimestamp,
    ntfsTimestamp,
    passThroughCompression,
    encrypted,
    zip64UncompressedSize,
    zip64CompressedSize,
    uncompressedSize,
    unknownSize,
    crc32
  } = options;
  let { version, compressionMethod } = options;
  const compressed = !directory && isCompressed(compressionMethod, level);
  let rawLocalExtraFieldZip64;
  const uncompressedFile = passThroughCompression || !compressed;
  const zip64ExtraFieldComplete = zip64 && (options.bufferedWrite || !dataDescriptor || (!zip64UncompressedSize && !zip64CompressedSize || uncompressedFile && !unknownSize));
  const writeLocalExtraFieldZip64 = zip64ExtraFieldComplete || zip64 && dataDescriptor && (zip64UncompressedSize || zip64CompressedSize);
  if (zip64 && (zip64UncompressedSize || zip64CompressedSize)) {
    const length = 4 + 16;
    const extraFieldZip64 = createRecordWriter(length);
    extraFieldZip64.writeUint16(EXTRAFIELD_TYPE_ZIP64);
    extraFieldZip64.writeUint16(length - 4);
    rawLocalExtraFieldZip64 = extraFieldZip64.array;
    if (zip64ExtraFieldComplete) {
      extraFieldZip64.writeUint64(uncompressedSize);
      if (uncompressedFile) {
        const encryptionOverhead = getEncryptionOverhead(encrypted, zipCrypto, encryptionStrength);
        extraFieldZip64.writeUint64(passThroughCompression ? 0 : uncompressedSize + encryptionOverhead);
      }
    }
  } else {
    rawLocalExtraFieldZip64 = EMPTY_UINT8_ARRAY;
  }
  let rawExtraFieldAES;
  if (encrypted && !zipCrypto) {
    const extraFieldAES = createRecordWriter(getLength(EXTRAFIELD_DATA_AES) + 2);
    extraFieldAES.writeUint16(EXTRAFIELD_TYPE_AES);
    extraFieldAES.writeBytes(EXTRAFIELD_DATA_AES);
    rawExtraFieldAES = extraFieldAES.array;
    rawExtraFieldAES[8] = encryptionStrength;
  } else {
    rawExtraFieldAES = EMPTY_UINT8_ARRAY;
  }
  let rawExtraFieldNTFS;
  let rawExtraFieldExtendedTimestamp;
  let extraFieldExtendedTimestampFlag;
  let extraFieldExtendedTimestampTime;
  if (extendedTimestamp) {
    const lastModTimeUnix = getTimeUnix(lastModDate);
    const lastModTimeUnixInRange = inUnixTimeRange(lastModTimeUnix);
    if (lastModTimeUnixInRange) {
      const extraFieldTimestampLength = 9 + (lastAccessDate ? 4 : 0) + (creationDate ? 4 : 0);
      const extraFieldTimestamp = createRecordWriter(extraFieldTimestampLength);
      extraFieldExtendedTimestampFlag = 1 + (lastAccessDate ? 2 : 0) + (creationDate ? 4 : 0);
      extraFieldExtendedTimestampTime = lastModTimeUnix;
      extraFieldTimestamp.writeUint16(EXTRAFIELD_TYPE_EXTENDED_TIMESTAMP);
      extraFieldTimestamp.writeUint16(extraFieldTimestampLength - 4);
      extraFieldTimestamp.writeUint8(extraFieldExtendedTimestampFlag);
      extraFieldTimestamp.writeUint32(lastModTimeUnix);
      if (lastAccessDate) {
        extraFieldTimestamp.writeUint32(clampUnixTime(getTimeUnix(lastAccessDate)));
      }
      if (creationDate) {
        extraFieldTimestamp.writeUint32(clampUnixTime(getTimeUnix(creationDate)));
      }
      rawExtraFieldExtendedTimestamp = extraFieldTimestamp.array;
    } else {
      rawExtraFieldExtendedTimestamp = EMPTY_UINT8_ARRAY;
    }
    const writeExtraFieldNTFS = ntfsTimestamp === UNDEFINED_VALUE ? !lastModTimeUnixInRange || Boolean(lastAccessDate || creationDate) : ntfsTimestamp;
    if (writeExtraFieldNTFS) {
      try {
        const lastModTimeNTFS = getTimeNTFS(lastModDate);
        const extraFieldNTFS = createRecordWriter(36);
        extraFieldNTFS.writeUint16(EXTRAFIELD_TYPE_NTFS);
        extraFieldNTFS.writeUint16(32);
        extraFieldNTFS.skip(4);
        extraFieldNTFS.writeUint16(EXTRAFIELD_TYPE_NTFS_TAG1);
        extraFieldNTFS.writeUint16(24);
        extraFieldNTFS.writeUint64(lastModTimeNTFS);
        extraFieldNTFS.writeUint64(lastAccessDate ? getTimeNTFS(lastAccessDate) : lastModTimeNTFS);
        extraFieldNTFS.writeUint64(creationDate ? getTimeNTFS(creationDate) : lastModTimeNTFS);
        rawExtraFieldNTFS = extraFieldNTFS.array;
      } catch {
        rawExtraFieldNTFS = EMPTY_UINT8_ARRAY;
      }
    } else {
      rawExtraFieldNTFS = EMPTY_UINT8_ARRAY;
    }
  } else {
    rawExtraFieldNTFS = rawExtraFieldExtendedTimestamp = EMPTY_UINT8_ARRAY;
  }
  let rawExtraFieldUnix;
  try {
    const { uid, gid, unixExtraFieldType } = options;
    if (unixExtraFieldType == INFOZIP_EXTRA_FIELD_TYPE && (uid !== UNDEFINED_VALUE || gid !== UNDEFINED_VALUE)) {
      const uidBytes = packUnixId(uid === UNDEFINED_VALUE ? 0 : uid);
      const gidBytes = packUnixId(gid === UNDEFINED_VALUE ? 0 : gid);
      const payloadLength = 3 + uidBytes.length + gidBytes.length;
      const extraFieldUnix = createRecordWriter(4 + payloadLength);
      extraFieldUnix.writeUint16(EXTRAFIELD_TYPE_INFOZIP);
      extraFieldUnix.writeUint16(payloadLength);
      extraFieldUnix.writeUint8(1);
      extraFieldUnix.writeUint8(uidBytes.length);
      extraFieldUnix.writeBytes(uidBytes);
      extraFieldUnix.writeUint8(gidBytes.length);
      extraFieldUnix.writeBytes(gidBytes);
      rawExtraFieldUnix = extraFieldUnix.array;
    } else if (unixExtraFieldType == UNIX_EXTRA_FIELD_TYPE && (uid !== UNDEFINED_VALUE || gid !== UNDEFINED_VALUE)) {
      const extraFieldUnix = createRecordWriter(8);
      extraFieldUnix.writeUint16(EXTRAFIELD_TYPE_UNIX);
      extraFieldUnix.writeUint16(4);
      extraFieldUnix.writeUint16((uid === UNDEFINED_VALUE ? 0 : uid) & MAX_16_BITS);
      extraFieldUnix.writeUint16((gid === UNDEFINED_VALUE ? 0 : gid) & MAX_16_BITS);
      rawExtraFieldUnix = extraFieldUnix.array;
    } else {
      rawExtraFieldUnix = EMPTY_UINT8_ARRAY;
    }
  } catch {
    rawExtraFieldUnix = EMPTY_UINT8_ARRAY;
  }
  if (compressionMethod === UNDEFINED_VALUE) {
    compressionMethod = compressed ? COMPRESSION_METHOD_DEFLATE : COMPRESSION_METHOD_STORE;
  }
  if (version === UNDEFINED_VALUE) {
    version = compressionMethod == COMPRESSION_METHOD_STORE && !directory && !encrypted ? VERSION_STORE : VERSION_DEFLATE;
  }
  const { codecVersionNeeded } = options;
  if (compressed && codecVersionNeeded !== UNDEFINED_VALUE) {
    version = version > codecVersionNeeded ? version : codecVersionNeeded;
  }
  if (zip64) {
    version = version > VERSION_ZIP64 ? version : VERSION_ZIP64;
  }
  if (encrypted && !zipCrypto) {
    version = version > VERSION_AES ? version : VERSION_AES;
    if (passThroughCompression && crc32 !== UNDEFINED_VALUE) {
      rawExtraFieldAES[EXTRAFIELD_OFFSET_AES_VENDOR_VERSION] = VENDOR_VERSION_AE_12;
    }
    setUint16(getDataView(rawExtraFieldAES), EXTRAFIELD_OFFSET_AES_COMPRESSION_METHOD, compressionMethod);
    compressionMethod = COMPRESSION_METHOD_AES;
  }
  const localExtraFieldZip64Length = writeLocalExtraFieldZip64 ? getLength(rawLocalExtraFieldZip64) : 0;
  const extraFieldLength = localExtraFieldZip64Length + getLength(rawExtraFieldAES, rawExtraFieldExtendedTimestamp, rawExtraFieldNTFS, rawExtraFieldUnix, rawExtraField, rawLocalExtraField);
  const maximumUsdzExtraFieldLength = options[OPTION_USDZ] ? EXTRAFIELD_USDZ_MAX_LENGTH : 0;
  if (extraFieldLength + maximumUsdzExtraFieldLength > MAX_16_BITS) {
    throw new Error(ERR_INVALID_EXTRAFIELD_DATA);
  }
  const dosLastModDate = new Date(Math.ceil(Math.floor(lastModDate.getTime() / 1e3) / 2) * 2e3);
  const clampedLastModDate = dosLastModDate < MIN_DATE ? MIN_DATE : dosLastModDate > MAX_DATE ? MAX_DATE : dosLastModDate;
  const storedLastModDate = getLength(rawExtraFieldExtendedTimestamp) ? new Date(getTimeUnix(lastModDate) * 1e3) : getLength(rawExtraFieldNTFS) ? lastModDate : clampedLastModDate;
  const {
    headerArray,
    headerView,
    rawLastModDate
  } = getHeaderArrayData({
    version,
    bitFlag: getBitFlag(level, useUnicodeFileNames, dataDescriptor, encrypted, compressionMethod),
    compressionMethod,
    uncompressedSize,
    lastModDate: clampedLastModDate,
    rawLastModDate: rawLastModDateOption,
    rawFilename,
    zip64CompressedSize,
    zip64UncompressedSize,
    extraFieldLength
  });
  const localHeader = createRecordWriter(HEADER_SIZE + getLength(rawFilename) + extraFieldLength);
  const localHeaderArray = localHeader.array;
  const localHeaderView = getDataView(localHeaderArray);
  localHeader.writeUint32(LOCAL_FILE_HEADER_SIGNATURE);
  localHeader.writeBytes(headerArray);
  localHeader.writeBytes(rawFilename);
  if (writeLocalExtraFieldZip64) {
    localHeader.writeBytes(rawLocalExtraFieldZip64);
  }
  localHeader.writeBytes(rawExtraFieldAES);
  localHeader.writeBytes(rawExtraFieldExtendedTimestamp);
  localHeader.writeBytes(rawExtraFieldNTFS);
  localHeader.writeBytes(rawExtraFieldUnix);
  localHeader.writeBytes(rawExtraField);
  localHeader.writeBytes(rawLocalExtraField);
  if (dataDescriptor) {
    if (!zip64CompressedSize) {
      setUint32(localHeaderView, HEADER_OFFSET_COMPRESSED_SIZE + LOCAL_HEADER_COMMON_OFFSET, 0);
    }
    if (!zip64UncompressedSize) {
      setUint32(localHeaderView, HEADER_OFFSET_UNCOMPRESSED_SIZE + LOCAL_HEADER_COMMON_OFFSET, 0);
    }
  }
  return {
    localHeaderArray,
    localHeaderView,
    headerArray,
    headerView,
    lastModDate: storedLastModDate,
    lastModDateClamped: storedLastModDate === clampedLastModDate && dosLastModDate.getTime() != clampedLastModDate.getTime(),
    rawLastModDate,
    encrypted,
    compressed,
    version,
    compressionMethod,
    extraFieldExtendedTimestampFlag,
    extraFieldExtendedTimestampTime,
    rawExtraFieldZip64: EMPTY_UINT8_ARRAY,
    localExtraFieldZip64Length,
    rawExtraFieldExtendedTimestamp,
    rawExtraFieldNTFS,
    rawExtraFieldUnix,
    rawExtraFieldAES,
    extraFieldLength
  };
}
function appendExtraFieldUSDZ(entryInfo, zipWriterOffset) {
  const { headerInfo } = entryInfo;
  let { localHeaderArray, extraFieldLength } = headerInfo;
  let extraBytesLength = 64 - (zipWriterOffset + getLength(localHeaderArray)) % 64;
  if (extraBytesLength < 4) {
    extraBytesLength += 64;
  }
  const rawExtraFieldUSDZ = new Uint8Array(extraBytesLength);
  const extraFieldUSDZView = getDataView(rawExtraFieldUSDZ);
  setUint16(extraFieldUSDZView, 0, EXTRAFIELD_TYPE_USDZ);
  setUint16(extraFieldUSDZView, 2, extraBytesLength - 4);
  const previousLocalHeaderArray = localHeaderArray;
  headerInfo.localHeaderArray = localHeaderArray = new Uint8Array(getLength(previousLocalHeaderArray) + extraBytesLength);
  arraySet(localHeaderArray, previousLocalHeaderArray);
  arraySet(localHeaderArray, rawExtraFieldUSDZ, getLength(previousLocalHeaderArray));
  const localHeaderArrayView = getDataView(localHeaderArray);
  setUint16(localHeaderArrayView, 28, extraFieldLength + extraBytesLength);
  headerInfo.localHeaderView = localHeaderArrayView;
  entryInfo.metadataSize += extraBytesLength;
}
function packUnixId(id) {
  const dataArray = new Uint8Array(4);
  const dataView = getDataView(dataArray);
  dataView.setUint32(0, id, true);
  let length = 4;
  while (length > 1 && dataArray[length - 1] === 0) {
    length--;
  }
  return dataArray.subarray(0, length);
}
function normalizeMsdosAttributes(msdosAttributesRaw, msdosAttributes) {
  if (msdosAttributesRaw !== UNDEFINED_VALUE) {
    msdosAttributesRaw = msdosAttributesRaw & MAX_8_BITS;
  } else if (msdosAttributes !== UNDEFINED_VALUE) {
    const { readOnly, hidden, system, directory: msdDir, archive } = msdosAttributes;
    let raw = 0;
    if (readOnly) raw |= FILE_ATTR_MSDOS_READONLY_MASK;
    if (hidden) raw |= FILE_ATTR_MSDOS_HIDDEN_MASK;
    if (system) raw |= FILE_ATTR_MSDOS_SYSTEM_MASK;
    if (msdDir) raw |= FILE_ATTR_MSDOS_DIR_MASK;
    if (archive) raw |= FILE_ATTR_MSDOS_ARCHIVE_MASK;
    msdosAttributesRaw = raw & MAX_8_BITS;
  }
  if (msdosAttributes === UNDEFINED_VALUE) {
    msdosAttributes = {
      readOnly: Boolean(msdosAttributesRaw & FILE_ATTR_MSDOS_READONLY_MASK),
      hidden: Boolean(msdosAttributesRaw & FILE_ATTR_MSDOS_HIDDEN_MASK),
      system: Boolean(msdosAttributesRaw & FILE_ATTR_MSDOS_SYSTEM_MASK),
      directory: Boolean(msdosAttributesRaw & FILE_ATTR_MSDOS_DIR_MASK),
      archive: Boolean(msdosAttributesRaw & FILE_ATTR_MSDOS_ARCHIVE_MASK)
    };
  }
  return { msdosAttributesRaw, msdosAttributes };
}
function getDataDescriptorInfo({
  zip64,
  dataDescriptor,
  dataDescriptorSignature
}) {
  let dataDescriptorArray = EMPTY_UINT8_ARRAY;
  let dataDescriptorView, dataDescriptorOffset = 0;
  let dataDescriptorLength = zip64 ? DATA_DESCRIPTOR_RECORD_ZIP_64_LENGTH : DATA_DESCRIPTOR_RECORD_LENGTH;
  if (dataDescriptorSignature) {
    dataDescriptorLength += DATA_DESCRIPTOR_RECORD_SIGNATURE_LENGTH;
  }
  if (dataDescriptor) {
    dataDescriptorArray = new Uint8Array(dataDescriptorLength);
    dataDescriptorView = getDataView(dataDescriptorArray);
    if (dataDescriptorSignature) {
      dataDescriptorOffset = DATA_DESCRIPTOR_RECORD_SIGNATURE_LENGTH;
      setUint32(dataDescriptorView, 0, DATA_DESCRIPTOR_RECORD_SIGNATURE);
    }
  }
  return {
    dataDescriptorArray,
    dataDescriptorView,
    dataDescriptorOffset
  };
}
function setEntryInfo({
  crc32,
  compressedSize,
  uncompressedSize,
  headerInfo,
  dataDescriptorInfo
}, {
  zip64,
  zipCrypto,
  passThroughCompression,
  dataDescriptor
}) {
  const {
    headerView,
    encrypted
  } = headerInfo;
  const {
    dataDescriptorView,
    dataDescriptorOffset
  } = dataDescriptorInfo;
  if ((!encrypted || zipCrypto || passThroughCompression) && crc32 !== UNDEFINED_VALUE) {
    setUint32(headerView, HEADER_OFFSET_SIGNATURE, crc32);
    if (dataDescriptor) {
      setUint32(dataDescriptorView, dataDescriptorOffset, crc32);
    }
  }
  if (zip64) {
    if (dataDescriptor) {
      setBigUint64(dataDescriptorView, dataDescriptorOffset + 4, BigInt(compressedSize));
      setBigUint64(dataDescriptorView, dataDescriptorOffset + 12, BigInt(uncompressedSize));
    }
  } else {
    setUint32(headerView, HEADER_OFFSET_COMPRESSED_SIZE, compressedSize);
    setUint32(headerView, HEADER_OFFSET_UNCOMPRESSED_SIZE, uncompressedSize);
    if (dataDescriptor) {
      setUint32(dataDescriptorView, dataDescriptorOffset + 4, compressedSize);
      setUint32(dataDescriptorView, dataDescriptorOffset + 8, uncompressedSize);
    }
  }
}
function updateLocalHeader({
  rawFilename,
  encrypted,
  zip64,
  localExtraFieldZip64Length,
  crc32,
  compressedSize,
  uncompressedSize,
  zip64UncompressedSize,
  zip64CompressedSize
}, localHeaderView, { dataDescriptor, passThroughCompression }) {
  if (!dataDescriptor) {
    if (!encrypted || passThroughCompression && crc32 !== UNDEFINED_VALUE) {
      setUint32(localHeaderView, HEADER_OFFSET_SIGNATURE + LOCAL_HEADER_COMMON_OFFSET, crc32);
    }
    if (!zip64CompressedSize) {
      setUint32(localHeaderView, HEADER_OFFSET_COMPRESSED_SIZE + LOCAL_HEADER_COMMON_OFFSET, compressedSize);
    }
    if (!zip64UncompressedSize) {
      setUint32(localHeaderView, HEADER_OFFSET_UNCOMPRESSED_SIZE + LOCAL_HEADER_COMMON_OFFSET, uncompressedSize);
    }
  }
  if (zip64 && localExtraFieldZip64Length) {
    const localHeaderOffset = HEADER_SIZE + getLength(rawFilename) + 4;
    setBigUint64(localHeaderView, localHeaderOffset, BigInt(uncompressedSize));
    setBigUint64(localHeaderView, localHeaderOffset + 8, BigInt(compressedSize));
  }
}
async function closeFile(zipWriter, comment, options) {
  const { directoryDataLength, zip64Entries } = createDirectoryRecords(zipWriter.fileEntries);
  const { directoryStart, directoryEnd, directoryArray } = await writeDirectoryRecords(zipWriter, directoryDataLength, options);
  const signatureLength = await writeDigitalSignatureRecord(zipWriter, directoryArray, options);
  await writeEndOfDirectoryRecord(zipWriter, comment, options, { directoryStart, directoryEnd, directoryDataLength, signatureLength, zip64Entries });
}
function createDirectoryRecords(files) {
  let directoryDataLength = 0;
  let zip64Entries = false;
  for (const [, fileEntry] of files) {
    const {
      rawFilename,
      rawExtraFieldAES,
      rawComment,
      rawExtraFieldNTFS,
      rawExtraFieldUnix,
      rawExtraField,
      rawCentralExtraField,
      extraFieldExtendedTimestampFlag,
      extraFieldExtendedTimestampTime,
      zip64Enabled,
      uncompressedSize,
      compressedSize
    } = fileEntry;
    let { zip64UncompressedSize, zip64CompressedSize } = fileEntry;
    if (!zip64Enabled) {
      if (zip64UncompressedSize && uncompressedSize < MAX_32_BITS) {
        zip64UncompressedSize = fileEntry.zip64UncompressedSize = false;
      }
      if (zip64CompressedSize && compressedSize < MAX_32_BITS) {
        zip64CompressedSize = fileEntry.zip64CompressedSize = false;
      }
    }
    zip64Entries = zip64Entries || zip64UncompressedSize || zip64CompressedSize;
    const zip64Offset = fileEntry.offset >= MAX_32_BITS;
    const zip64DiskNumberStart = fileEntry.diskNumberStart >= MAX_16_BITS;
    let rawExtraFieldZip64;
    if (zip64Offset || zip64DiskNumberStart || zip64UncompressedSize || zip64CompressedSize) {
      const length = 4 + (zip64UncompressedSize ? 8 : 0) + (zip64CompressedSize ? 8 : 0) + (zip64Offset ? 8 : 0) + (zip64DiskNumberStart ? 4 : 0);
      const extraFieldZip64 = createRecordWriter(length);
      extraFieldZip64.writeUint16(EXTRAFIELD_TYPE_ZIP64);
      extraFieldZip64.writeUint16(length - 4);
      if (zip64UncompressedSize) {
        extraFieldZip64.writeUint64(uncompressedSize);
      }
      if (zip64CompressedSize) {
        extraFieldZip64.writeUint64(compressedSize);
      }
      if (zip64Offset) {
        extraFieldZip64.writeUint64(fileEntry.offset);
      }
      if (zip64DiskNumberStart) {
        extraFieldZip64.writeUint32(fileEntry.diskNumberStart);
      }
      rawExtraFieldZip64 = extraFieldZip64.array;
    } else {
      rawExtraFieldZip64 = EMPTY_UINT8_ARRAY;
    }
    fileEntry.rawExtraFieldZip64 = rawExtraFieldZip64;
    fileEntry.zip64Offset = zip64Offset;
    fileEntry.zip64DiskNumberStart = zip64DiskNumberStart;
    let rawExtraFieldTimestamp;
    if (extraFieldExtendedTimestampTime === UNDEFINED_VALUE) {
      rawExtraFieldTimestamp = EMPTY_UINT8_ARRAY;
    } else {
      const extraFieldTimestamp = createRecordWriter(9);
      extraFieldTimestamp.writeUint16(EXTRAFIELD_TYPE_EXTENDED_TIMESTAMP);
      extraFieldTimestamp.writeUint16(5);
      extraFieldTimestamp.writeUint8(extraFieldExtendedTimestampFlag);
      extraFieldTimestamp.writeUint32(extraFieldExtendedTimestampTime);
      rawExtraFieldTimestamp = extraFieldTimestamp.array;
    }
    fileEntry.rawExtraFieldExtendedTimestamp = rawExtraFieldTimestamp;
    const extraFieldLength = getLength(
      rawExtraFieldZip64,
      rawExtraFieldAES,
      rawExtraFieldNTFS,
      rawExtraFieldUnix,
      rawExtraFieldTimestamp,
      rawExtraField,
      rawCentralExtraField
    );
    if (extraFieldLength > MAX_16_BITS) {
      throw new Error(ERR_INVALID_EXTRAFIELD_DATA);
    }
    directoryDataLength += CENTRAL_FILE_HEADER_LENGTH + getLength(rawFilename, rawComment) + extraFieldLength;
  }
  return { directoryDataLength, zip64Entries };
}
async function writeDirectoryRecords(zipWriter, directoryDataLength, options) {
  const { fileEntries, writer } = zipWriter;
  const directoryArray = new Uint8Array(directoryDataLength);
  await initStream(writer);
  let offset = 0;
  let directoryDiskOffset = 0;
  let directoryStartDiskNumber = getDiskNumber(writer);
  let directoryStartDiskOffset = getDiskOffset2(writer);
  let directoryEndDiskEntriesLength = 0;
  for (const [indexFileEntry, fileEntry] of Array.from(fileEntries.values()).entries()) {
    const {
      offset: fileEntryOffset,
      rawFilename,
      rawExtraFieldZip64,
      rawExtraFieldAES,
      rawExtraFieldExtendedTimestamp,
      rawExtraFieldNTFS,
      rawExtraFieldUnix,
      rawExtraField,
      rawCentralExtraField,
      rawComment,
      versionMadeBy,
      headerArray,
      headerView,
      zip64UncompressedSize,
      zip64CompressedSize,
      zip64DiskNumberStart,
      zip64Offset,
      internalFileAttributes,
      externalFileAttributes,
      diskNumberStart,
      uncompressedSize,
      compressedSize
    } = fileEntry;
    const extraFieldLength = getLength(rawExtraFieldZip64, rawExtraFieldAES, rawExtraFieldExtendedTimestamp, rawExtraFieldNTFS, rawExtraFieldUnix, rawExtraField, rawCentralExtraField);
    const directoryRecordLength = CENTRAL_FILE_HEADER_LENGTH + getLength(rawFilename, rawComment) + extraFieldLength;
    if (exceedsAvailableSize(writer, offset + directoryRecordLength - directoryDiskOffset)) {
      await writeData(writer, directoryArray.slice(directoryDiskOffset, offset));
      directoryDiskOffset = offset;
      directoryEndDiskEntriesLength = 0;
      await writer.closeDisk();
    }
    if (indexFileEntry == 0) {
      directoryStartDiskNumber = getDiskNumber(writer);
      directoryStartDiskOffset = getDiskOffset2(writer);
    }
    if (!zip64UncompressedSize) {
      setUint32(headerView, HEADER_OFFSET_UNCOMPRESSED_SIZE, uncompressedSize);
    }
    if (!zip64CompressedSize) {
      setUint32(headerView, HEADER_OFFSET_COMPRESSED_SIZE, compressedSize);
    }
    if ((zip64Offset || zip64DiskNumberStart) && fileEntry.version < VERSION_ZIP64) {
      setUint16(headerView, HEADER_OFFSET_VERSION, VERSION_ZIP64);
    }
    const directoryRecord = createRecordWriter(directoryRecordLength);
    directoryRecord.writeUint32(CENTRAL_FILE_HEADER_SIGNATURE);
    directoryRecord.writeUint16(versionMadeBy);
    directoryRecord.writeBytes(headerArray.subarray(0, HEADER_SIZE - 4 - 2));
    directoryRecord.writeUint16(extraFieldLength);
    directoryRecord.writeUint16(getLength(rawComment));
    directoryRecord.writeUint16(zip64DiskNumberStart ? MAX_16_BITS : diskNumberStart);
    directoryRecord.writeUint16(internalFileAttributes);
    directoryRecord.writeUint32(externalFileAttributes);
    directoryRecord.writeUint32(zip64Offset ? MAX_32_BITS : fileEntryOffset);
    directoryRecord.writeBytes(rawFilename);
    directoryRecord.writeBytes(rawExtraFieldZip64);
    directoryRecord.writeBytes(rawExtraFieldAES);
    directoryRecord.writeBytes(rawExtraFieldExtendedTimestamp);
    directoryRecord.writeBytes(rawExtraFieldNTFS);
    directoryRecord.writeBytes(rawExtraFieldUnix);
    directoryRecord.writeBytes(rawExtraField);
    directoryRecord.writeBytes(rawCentralExtraField);
    directoryRecord.writeBytes(rawComment);
    arraySet(directoryArray, directoryRecord.array, offset);
    offset += directoryRecordLength;
    directoryEndDiskEntriesLength++;
    if (options.onprogress) {
      try {
        await options.onprogress(indexFileEntry + 1, fileEntries.size, new Entry(fileEntry));
      } catch {
      }
    }
  }
  await writeData(writer, directoryDiskOffset ? directoryArray.slice(directoryDiskOffset) : directoryArray);
  return {
    directoryStart: { diskNumber: directoryStartDiskNumber, diskOffset: directoryStartDiskOffset },
    directoryEnd: { diskNumber: getDiskNumber(writer), entriesLength: directoryEndDiskEntriesLength },
    directoryArray
  };
}
async function writeDigitalSignatureRecord(zipWriter, directoryArray, options) {
  const signCentralDirectory = getFunctionOptionValue2(zipWriter, options, OPTION_SIGN_CENTRAL_DIRECTORY);
  if (signCentralDirectory) {
    const signatureData = await signCentralDirectory(directoryArray);
    const signatureDataLength = getLength(signatureData);
    if (signatureDataLength > MAX_16_BITS) {
      throw new Error(ERR_INVALID_SIGNATURE_DATA);
    }
    const signatureRecord = createRecordWriter(6 + signatureDataLength);
    signatureRecord.writeUint32(DIGITAL_SIGNATURE_RECORD_SIGNATURE);
    signatureRecord.writeUint16(signatureDataLength);
    signatureRecord.writeBytes(signatureData);
    const { writer } = zipWriter;
    if (exceedsAvailableSize(writer, getLength(signatureRecord.array))) {
      await writer.closeDisk();
    }
    await writeData(writer, signatureRecord.array);
    return 6 + signatureDataLength;
  }
  return 0;
}
async function writeEndOfDirectoryRecord(zipWriter, comment, options, cdInfo) {
  const { writer } = zipWriter;
  const { directoryStart, directoryEnd, signatureLength, zip64Entries } = cdInfo;
  let { directoryDataLength } = cdInfo;
  let fileEntriesLength = zipWriter.fileEntries.size;
  let diskNumber = directoryStart.diskNumber;
  let directoryOffset = getSegmentOffset(zipWriter, directoryStart);
  const commentLength = getLength(comment);
  if (commentLength > MAX_16_BITS) {
    throw new Error(ERR_INVALID_COMMENT);
  }
  let zip64 = getOptionValue2(zipWriter, options, PROPERTY_NAME_ZIP64);
  let lastDiskNumber = getDiskNumber(writer);
  if (exceedsAvailableSize(writer, (zip64 ? ZIP64_END_OF_CENTRAL_DIR_TOTAL_LENGTH : END_OF_CENTRAL_DIR_LENGTH) + commentLength)) {
    lastDiskNumber++;
  }
  if (directoryOffset >= MAX_32_BITS || directoryDataLength >= MAX_32_BITS || fileEntriesLength >= MAX_16_BITS || lastDiskNumber >= MAX_16_BITS) {
    if (zip64 === false) {
      throw new Error(ERR_UNSUPPORTED_FORMAT);
    } else {
      zip64 = true;
    }
  } else if (zip64 === UNDEFINED_VALUE && zip64Entries) {
    zip64 = true;
  }
  const endOfdirectoryRecord = createRecordWriter(zip64 ? ZIP64_END_OF_CENTRAL_DIR_TOTAL_LENGTH : END_OF_CENTRAL_DIR_LENGTH);
  if (exceedsAvailableSize(writer, getLength(endOfdirectoryRecord.array) + commentLength)) {
    await writer.closeDisk();
  }
  lastDiskNumber = getDiskNumber(writer);
  let diskFileEntriesLength = lastDiskNumber == directoryEnd.diskNumber ? directoryEnd.entriesLength : 0;
  if (zip64) {
    endOfdirectoryRecord.writeUint32(ZIP64_END_OF_CENTRAL_DIR_SIGNATURE);
    endOfdirectoryRecord.writeUint64(44);
    endOfdirectoryRecord.writeUint16(45);
    endOfdirectoryRecord.writeUint16(45);
    endOfdirectoryRecord.writeUint32(lastDiskNumber);
    endOfdirectoryRecord.writeUint32(diskNumber);
    endOfdirectoryRecord.writeUint64(diskFileEntriesLength);
    endOfdirectoryRecord.writeUint64(fileEntriesLength);
    endOfdirectoryRecord.writeUint64(directoryDataLength);
    endOfdirectoryRecord.writeUint64(directoryOffset);
    endOfdirectoryRecord.writeUint32(ZIP64_END_OF_CENTRAL_DIR_LOCATOR_SIGNATURE);
    endOfdirectoryRecord.writeUint32(lastDiskNumber);
    endOfdirectoryRecord.writeUint64(BigInt(getSegmentOffset(zipWriter, writer)) + BigInt(directoryDataLength) + BigInt(signatureLength));
    endOfdirectoryRecord.writeUint32(lastDiskNumber + 1);
    const supportZip64SplitFile = getOptionValue2(zipWriter, options, OPTION_SUPPORT_ZIP64_SPLIT_FILE, true);
    if (supportZip64SplitFile) {
      lastDiskNumber = MAX_16_BITS;
      diskNumber = MAX_16_BITS;
    }
    diskFileEntriesLength = MAX_16_BITS;
    fileEntriesLength = MAX_16_BITS;
    directoryOffset = MAX_32_BITS;
    directoryDataLength = MAX_32_BITS;
  }
  endOfdirectoryRecord.writeUint32(END_OF_CENTRAL_DIR_SIGNATURE);
  endOfdirectoryRecord.writeUint16(lastDiskNumber);
  endOfdirectoryRecord.writeUint16(diskNumber);
  endOfdirectoryRecord.writeUint16(diskFileEntriesLength);
  endOfdirectoryRecord.writeUint16(fileEntriesLength);
  endOfdirectoryRecord.writeUint32(directoryDataLength);
  endOfdirectoryRecord.writeUint32(directoryOffset);
  endOfdirectoryRecord.writeUint16(commentLength);
  await writeData(writer, endOfdirectoryRecord.array);
  if (commentLength) {
    await writeData(writer, comment);
  }
}
function createRecordWriter(length) {
  const array = new Uint8Array(length);
  const view = getDataView(array);
  let offset = 0;
  return {
    array,
    writeUint8: (value) => {
      setUint8(view, offset, value);
      offset += 1;
    },
    writeUint16: (value) => {
      setUint16(view, offset, value);
      offset += 2;
    },
    writeUint32: (value) => {
      setUint32(view, offset, value);
      offset += 4;
    },
    writeUint64: (value) => {
      setBigUint64(view, offset, BigInt(value));
      offset += 8;
    },
    writeBytes: (value) => {
      arraySet(array, value, offset);
      offset += getLength(value);
    },
    skip: (count) => offset += count
  };
}
function getDiskNumber(writer) {
  const { diskNumber = 0 } = writer;
  return diskNumber;
}
function getDiskOffset2(writer) {
  const { diskOffset = 0 } = writer;
  return diskOffset;
}
function exceedsAvailableSize(writer, length) {
  const { availableSize = INFINITY_VALUE } = writer;
  return length > availableSize;
}
function getSegmentOffset(zipWriter, { diskNumber = 0, diskOffset = 0 }) {
  return zipWriter.offset - diskOffset - (diskNumber ? zipWriter.initialOffset : 0);
}
async function startsWithSplitZipSignature2(reader) {
  const signatureArray = await readUint8Array(reader, 0, SPLIT_ZIP_FILE_SIGNATURE_LENGTH);
  return getUint322(getDataView(signatureArray), 0) == SPLIT_ZIP_FILE_SIGNATURE;
}
function removeExtraFieldZip64(rawExtraField) {
  const rawExtraFieldView = getDataView(rawExtraField);
  let offsetExtraField = 0;
  while (offsetExtraField + 4 <= getLength(rawExtraField)) {
    const size = 4 + getUint162(rawExtraFieldView, offsetExtraField + 2);
    if (getUint162(rawExtraFieldView, offsetExtraField) == EXTRAFIELD_TYPE_ZIP64) {
      return removeExtraFieldZip64(concat(
        rawExtraField.subarray(0, offsetExtraField),
        rawExtraField.subarray(Math.min(offsetExtraField + size, getLength(rawExtraField)))
      ));
    }
    offsetExtraField += size;
  }
  return rawExtraField;
}
async function copyZipData(zipWriter, reader, entries, directoryOffset) {
  const { writer } = zipWriter;
  const entryPositions = /* @__PURE__ */ new Map();
  if (writer.closeDisk) {
    const sortedEntries = Array.from(entries).sort((firstEntry, secondEntry) => getSourceOffset(reader, firstEntry) - getSourceOffset(reader, secondEntry));
    let copiedLength = 0;
    for (const entry of sortedEntries) {
      const sourceOffset = getSourceOffset(reader, entry);
      await copyData(zipWriter, reader, copiedLength, sourceOffset - copiedLength);
      if (exceedsAvailableSize(writer, await getLocalHeaderLength(reader, sourceOffset))) {
        await writer.closeDisk();
      }
      entryPositions.set(entry, {
        offset: getSegmentOffset(zipWriter, writer),
        diskNumberStart: getDiskNumber(writer)
      });
      copiedLength = sourceOffset;
    }
    await copyData(zipWriter, reader, copiedLength, directoryOffset - copiedLength);
  } else {
    const baseOffset = zipWriter.offset;
    await copyData(zipWriter, reader, 0, directoryOffset);
    entries.forEach((entry) => entryPositions.set(entry, {
      offset: baseOffset + getSourceOffset(reader, entry),
      diskNumberStart: 0
    }));
  }
  return entryPositions;
}
async function copyData(zipWriter, reader, offset, size) {
  if (size > 0) {
    const { writer } = zipWriter;
    let copiedLength = 0;
    try {
      await flushBufferedData(createReadable(reader, { offset, size }), writer, UNDEFINED_VALUE, (chunkLength) => copiedLength += chunkLength);
    } catch (error) {
      zipWriter.hasCorruptedEntries = true;
      try {
        error.corruptedEntry = true;
      } catch {
      }
      throw error;
    } finally {
      writer.size += copiedLength;
      zipWriter.offset += copiedLength;
    }
  }
}
async function getLocalHeaderLength(reader, offset) {
  const headerArray = await readUint8Array(reader, offset, HEADER_SIZE);
  if (getLength(headerArray) < HEADER_SIZE) {
    return HEADER_SIZE;
  }
  const headerView = getDataView(headerArray);
  return HEADER_SIZE + getUint162(headerView, HEADER_OFFSET_FILENAME_LENGTH + LOCAL_HEADER_COMMON_OFFSET) + getUint162(headerView, HEADER_OFFSET_EXTRAFIELD_LENGTH + LOCAL_HEADER_COMMON_OFFSET);
}
function getSourceOffset(reader, { offset, diskNumberStart }) {
  return offset + (reader.getDiskOffset ? reader.getDiskOffset(diskNumberStart) : 0);
}
function getSplitZipSignatureArray() {
  const signatureArray = new Uint8Array(SPLIT_ZIP_FILE_SIGNATURE_LENGTH);
  setUint32(getDataView(signatureArray), 0, SPLIT_ZIP_FILE_SIGNATURE);
  return signatureArray;
}
async function writeSplitZipSignature(zipWriter, writer) {
  delete zipWriter.addSplitZipSignature;
  await writeData(writer, getSplitZipSignatureArray());
  zipWriter.offset += SPLIT_ZIP_FILE_SIGNATURE_LENGTH;
}
async function writeData(writer, array) {
  const { writable } = writer;
  const streamWriter = writable.getWriter();
  try {
    await streamWriter.ready;
    writer.size += getLength(array);
    await streamWriter.write(array);
  } finally {
    streamWriter.releaseLock();
  }
}
async function flushBufferedData(readable, writer, signal, onChunkWritten) {
  const streamWriter = writer.writable.getWriter();
  try {
    await readable.pipeTo(new WritableStream({
      async write(chunk) {
        await streamWriter.ready;
        await streamWriter.write(chunk);
        onChunkWritten(getLength(chunk));
      }
    }), { preventClose: true, preventAbort: true, signal });
  } finally {
    streamWriter.releaseLock();
  }
}
function getTimeNTFS(date) {
  if (date) {
    const timeNTFS = (BigInt(date.getTime()) + BigInt(116444736e5)) * BigInt(1e4);
    return timeNTFS < MIN_NTFS_TIME ? MIN_NTFS_TIME : timeNTFS > MAX_NTFS_TIME ? MAX_NTFS_TIME : timeNTFS;
  }
}
function getTimeUnix(date) {
  return Math.floor(date.getTime() / 1e3);
}
function inUnixTimeRange(timeUnix) {
  return timeUnix >= MIN_UNIX_TIME && timeUnix <= MAX_UNIX_TIME;
}
function clampUnixTime(timeUnix) {
  return Math.min(MAX_UNIX_TIME, Math.max(MIN_UNIX_TIME, timeUnix));
}
function getOptionValue2(zipWriter, options, name, defaultValue) {
  const result = options[name] === UNDEFINED_VALUE ? zipWriter.options[name] : options[name];
  return result === UNDEFINED_VALUE ? defaultValue : result;
}
function getDateOptionValue(zipWriter, options, name, defaultValue) {
  const date = getOptionValue2(zipWriter, options, name, defaultValue);
  if (date === null) {
    return defaultValue;
  }
  if (date !== UNDEFINED_VALUE && (typeof date.getTime != FUNCTION_TYPE || Number.isNaN(date.getTime()))) {
    throw new Error(ERR_INVALID_DATE);
  }
  return date;
}
function getFunctionOptionValue2(zipWriter, options, name) {
  return checkFunctionOption(getOptionValue2(zipWriter, options, name));
}
function getNumberOptionValue(zipWriter, options, name, defaultValue) {
  return toNumber(getOptionValue2(zipWriter, options, name, defaultValue));
}
function getMaximumCompressedSize(uncompressedSize) {
  return uncompressedSize + 5 * (Math.floor(uncompressedSize / 16383) + 1);
}
function isCompressed(compressionMethod, level) {
  return compressionMethod === UNDEFINED_VALUE ? level === UNDEFINED_VALUE || level > 0 : compressionMethod !== COMPRESSION_METHOD_STORE;
}
function getUint162(view, offset) {
  return view.getUint16(offset, true);
}
function getUint322(view, offset) {
  return view.getUint32(offset, true);
}
function setUint8(view, offset, value) {
  view.setUint8(offset, value);
}
function setUint16(view, offset, value) {
  view.setUint16(offset, value, true);
}
function setUint32(view, offset, value) {
  view.setUint32(offset, value, true);
}
function setBigUint64(view, offset, value) {
  view.setBigUint64(offset, value, true);
}
function arraySet(array, typedArray, offset) {
  array.set(typedArray, offset);
}
function getLength(...arrayLikes) {
  let result = 0;
  arrayLikes.forEach((arrayLike) => arrayLike && (result += arrayLike.length));
  return result;
}
function getHeaderArrayData({
  version,
  bitFlag,
  compressionMethod,
  uncompressedSize,
  compressedSize,
  lastModDate,
  rawLastModDate,
  rawFilename,
  zip64CompressedSize,
  zip64UncompressedSize,
  extraFieldLength
}) {
  const headerRecord = createRecordWriter(HEADER_SIZE - 4);
  const headerArray = headerRecord.array;
  const headerView = getDataView(headerArray);
  headerRecord.writeUint16(version);
  headerRecord.writeUint16(bitFlag);
  headerRecord.writeUint16(compressionMethod);
  if (rawLastModDate === UNDEFINED_VALUE) {
    const dateArray = new Uint32Array(1);
    const dateView = getDataView(dateArray);
    setUint16(dateView, 0, (lastModDate.getHours() << 6 | lastModDate.getMinutes()) << 5 | lastModDate.getSeconds() / 2);
    setUint16(dateView, 2, (lastModDate.getFullYear() - 1980 << 4 | lastModDate.getMonth() + 1) << 5 | lastModDate.getDate());
    rawLastModDate = dateArray[0];
  }
  headerRecord.writeUint32(rawLastModDate);
  headerRecord.skip(4);
  if (zip64CompressedSize || compressedSize !== UNDEFINED_VALUE) {
    headerRecord.writeUint32(zip64CompressedSize ? MAX_32_BITS : compressedSize);
  } else {
    headerRecord.skip(4);
  }
  if (zip64UncompressedSize || uncompressedSize !== UNDEFINED_VALUE) {
    headerRecord.writeUint32(zip64UncompressedSize ? MAX_32_BITS : uncompressedSize);
  } else {
    headerRecord.skip(4);
  }
  headerRecord.writeUint16(getLength(rawFilename));
  headerRecord.writeUint16(extraFieldLength);
  return {
    headerArray,
    headerView,
    rawLastModDate
  };
}
function isPrintableASCIIText(rawText) {
  return rawText.every((characterCode) => characterCode >= MIN_PRINTABLE_ASCII_CHARACTER_CODE && characterCode <= MAX_PRINTABLE_ASCII_CHARACTER_CODE);
}
function getBitFlag(level, useUnicodeFileNames, dataDescriptor, encrypted, compressionMethod) {
  let bitFlag = 0;
  if (useUnicodeFileNames) {
    bitFlag = bitFlag | BITFLAG_LANG_ENCODING_FLAG;
  }
  if (dataDescriptor) {
    bitFlag = bitFlag | BITFLAG_DATA_DESCRIPTOR;
  }
  if (compressionMethod == COMPRESSION_METHOD_DEFLATE || compressionMethod == COMPRESSION_METHOD_DEFLATE_64) {
    if (level >= 0 && level <= 3) {
      bitFlag = bitFlag | BITFLAG_LEVEL_SUPER_FAST_MASK;
    }
    if (level > 3 && level <= 5) {
      bitFlag = bitFlag | BITFLAG_LEVEL_FAST_MASK;
    }
    if (level == 9) {
      bitFlag = bitFlag | BITFLAG_LEVEL_MAX_MASK;
    }
  }
  if (encrypted) {
    bitFlag = bitFlag | BITFLAG_ENCRYPTED;
  }
  return bitFlag;
}

// node_modules/@zip.js/zip.js/lib/zip-core-base.js
init_io();
init_options();
init_configuration();
init_codec_registry();

// node_modules/@zip.js/zip.js/lib/core/compression-methods.js
init_constants();
init_configuration();
init_codec_registry();
init_zip_entry_stream();

// node_modules/@zip.js/zip.js/lib/core/util/opfs-temp-stream.js
var DEFAULT_THRESHOLD = 1024 * 1024;

// node_modules/@zip.js/zip.js/lib/core/util/blob-temp-stream.js
init_compatible_streams();
var DEFAULT_THRESHOLD2 = 1024 * 1024;

// node_modules/@zip.js/zip.js/lib/core/util/sync-access-handle-temp-stream.js
var DEFAULT_THRESHOLD3 = 1024 * 1024;
var READ_CHUNK_SIZE = 512 * 1024;

// node_modules/@zip.js/zip.js/lib/zip-core-base.js
try {
  setDefaultConfiguration({ baseURI: import.meta.url });
} catch {
}

// node_modules/@zip.js/zip.js/lib/zip-module-wasm.js
init_configuration();

// node_modules/@zip.js/zip.js/lib/core/zlib-streams-inline.js
var t = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
var e = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
var n = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
var o = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
var r = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
var V = new Uint8Array(288);
V.fill(8, 0, 144), V.fill(9, 144, 256), V.fill(7, 256, 280), V.fill(8, 280, 288);
var l = new Uint8Array(30).fill(5);
function a(t2) {
  const e2 = new Uint16Array(16);
  for (const n3 of t2) e2[n3]++;
  e2[0] = 0;
  const n2 = new Uint16Array(17);
  for (let t3 = 1; t3 <= 15; t3++) n2[t3 + 1] = n2[t3] + e2[t3];
  const o2 = new Uint16Array(t2.length);
  for (let e3 = 0; e3 < t2.length; e3++) t2[e3] && (o2[n2[t2[e3]]++] = e3);
  return { o: e2, symbols: o2 };
}
var f = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function s(s2) {
  let m;
  s2({ wasmURI: () => (m || (m = "data:application/wasm;base64," + (function(t2) {
    let e2 = "";
    const n2 = t2.length;
    let o2 = 0;
    for (; o2 + 2 < n2; o2 += 3) {
      const n3 = t2[o2] << 16 | t2[o2 + 1] << 8 | t2[o2 + 2];
      e2 += f[n3 >> 18 & 63] + f[n3 >> 12 & 63] + f[n3 >> 6 & 63] + f[63 & n3];
    }
    const r2 = n2 - o2;
    if (1 === r2) {
      const n3 = t2[o2] << 16;
      e2 += f[n3 >> 18 & 63] + f[n3 >> 12 & 63] + "==";
    } else if (2 === r2) {
      const n3 = t2[o2] << 16 | t2[o2 + 1] << 8;
      e2 += f[n3 >> 18 & 63] + f[n3 >> 12 & 63] + f[n3 >> 6 & 63] + "=";
    }
    return e2;
  })((function(f2) {
    let s3 = 0, m2 = 0, q = 0, i = new Uint8Array(1024), K = 0, y = 0;
    for (; !y; ) {
      y = W(1);
      const t2 = W(2);
      if (0 == t2) Y();
      else if (1 == t2) c(a(V), a(l));
      else {
        if (2 != t2) throw new Error("invalid deflate block type");
        c(...p());
      }
    }
    return i.subarray(0, K);
    function z() {
      if (s3 >= f2.length) throw new Error("unexpected end of deflate data");
      return f2[s3++];
    }
    function W(t2) {
      for (; q < t2; ) m2 |= z() << q, q += 8;
      const e2 = m2 & (1 << t2) - 1;
      return m2 >>>= t2, q -= t2, e2;
    }
    function Y() {
      m2 = 0, q = 0;
      const t2 = z() | z() << 8;
      s3 += 2, Z(K + t2);
      for (let e2 = 0; e2 < t2; e2++) i[K++] = z();
    }
    function c(r2, V2) {
      let l2 = u(r2);
      for (; 256 != l2; ) {
        if (l2 < 256) Z(K + 1), i[K++] = l2;
        else {
          const r3 = l2 - 257, a2 = t[r3] + W(e[r3]), f3 = u(V2), s4 = n[f3] + W(o[f3]);
          Z(K + a2);
          const m3 = K - s4;
          for (let t2 = 0; t2 < a2; t2++) i[K++] = i[m3 + t2];
        }
        l2 = u(r2);
      }
    }
    function p() {
      const t2 = W(5) + 257, e2 = W(5) + 1, n2 = W(4) + 4, o2 = new Uint8Array(19);
      for (let t3 = 0; t3 < n2; t3++) o2[r[t3]] = W(3);
      const V2 = a(o2), l2 = new Uint8Array(t2 + e2);
      let f3 = 0;
      for (; f3 < l2.length; ) {
        const t3 = u(V2);
        if (t3 < 16) l2[f3++] = t3;
        else if (16 == t3) {
          const t4 = l2[f3 - 1];
          let e3 = W(2) + 3;
          for (; e3--; ) l2[f3++] = t4;
        } else f3 += 17 == t3 ? W(3) + 3 : W(7) + 11;
      }
      return [a(l2.subarray(0, t2)), a(l2.subarray(t2))];
    }
    function u(t2) {
      const { o: e2, symbols: n2 } = t2;
      let o2 = 0, r2 = 0, V2 = 0;
      for (let t3 = 1; t3 <= 15; t3++) {
        o2 |= W(1);
        const l2 = e2[t3];
        if (o2 - r2 < l2) return n2[V2 + (o2 - r2)];
        V2 += l2, r2 = r2 + l2 << 1, o2 <<= 1;
      }
      throw new Error("invalid huffman code");
    }
    function Z(t2) {
      if (i.length < t2) {
        let e2 = 2 * i.length;
        for (; e2 < t2; ) e2 *= 2;
        const n2 = new Uint8Array(e2);
        n2.set(i.subarray(0, K)), i = n2;
      }
    }
  })((function(t2) {
    const e2 = (t2 = String(t2).replace(/[^A-Za-z0-9+/=]/g, "")).length, n2 = [];
    for (let o2 = 0; o2 < e2; o2 += 4) {
      const e3 = f.indexOf(t2[o2]) << 18 | f.indexOf(t2[o2 + 1]) << 12 | (63 & f.indexOf(t2[o2 + 2])) << 6 | 63 & f.indexOf(t2[o2 + 3]);
      n2.push(e3 >> 16 & 255), "=" !== t2[o2 + 2] && n2.push(e3 >> 8 & 255), "=" !== t2[o2 + 3] && n2.push(255 & e3);
    }
    return new Uint8Array(n2);
  })("zb19jF3HdSdYX/fjvftuv9tkk2zyUeK5l4zdstWk5DhN2dImXYybrRZFy5v1H/kjgERTLZvvUaS62aZlj6LX+gyTyB7CIwRar7DhZIx1EEhYAauZdXaVMWeibDyzyoxm1wNoYGNhzBo7XsCLURbCQFhoxdXvnLrvo7tJUbKTrBrUu/fWvVWnTp06dep8lTpx7kGtlNK/kd9n+n3dv8/2+cf0++o+jSvdV/xQ3afUfUr374v7/J/u35f0B5euz6+4cKsf1X3760di64x1SWKVTVXD4j+lVKqsNdpq3YgyrbUxqhUp13SuaaIoiqxyWjmllHGxdpF+SDebUaz14+ZxE6e6r/2lP4iy5Pfc3vjB5QfPrn7VqNapMw+cPrG2/Kl7zyx/RSWTg9tTZ06t3bt64isqzceeqWYxuH9o9ezJ5XPnVDasZfnM/Wpi5+D29Ilza/eePHvm3JcfXL5ftbNQII3VX0m9RTF6y01PTo49+uLXTj2ktrXrZ4PWB7Vy4zvqu41t37882nZ9x21vL0Zvue2pybFH3PaOdv2sbnvnoFa0Pe0eWF1eVmZH/XADCPGDJ06fPntS6YwrPXXi9KmvLSu1+957T525/9Tq8sm1ex/48pmTa6fOnrl37cQXTi9rtfve5QfPnVw99dDa8pl7z62dONm7d3X53NrZ1WUV7d1U9MXltXtPfnl1dfnMmoqre+89+fCJe0+dObm6/ODymbV7lx8+ufwQV766/MDJs18+s6Z+rdHWyuusofZ0Wrvm5z71nzVf+ytzxKjsex/VWX+/8kWvah5QZn7zHyn/lj7u5v2TO2aMqqwvSPms69+2K7hY6lSxt+crdb7S3q44fKF9/5zXK6S6lfF2rdL+hR3dSpGeMS/vqPSMSavoKNdI1j9K5isrc0a1dEYRqTnTIkXRnEkz0j7tloo0cS3G29U543DbrTQqc17jSSvLKPbPMHjp8VyTBhTekMJHikxvlTSptZUvAcS1SjE4hhSDozaCo7+yUtkBQAYAmQCQojgAoSjuVo64Pk1xr4oEFlKku3hbUermKfUPr6C1UvvnAF9pTJ+s15R6e36tSlYWQruUrOIbjUaBoKy06OicScnWMGj5sQIK48Y/t4PcnFH+mR3caCvL/AVGRLaQa8q+5M3ajHl5V2WArYdXKO6VjkypLY/TjCkqteD4aqpSC7nOgJXwZqUJ2HZLle6U6Jkh3SkNqRJgZmRmzHTZIIOLVqUW3Tyu0krXo6jnTNpq8otTlXZ9Mn6qG+G2qPRCbsn4opuVkZ2nqExIV8pPdcsIIExVOlekfBHuC9xnlHiFXjYy3y9jUv57/WP8WtattH94pYxD75OFXPl9ZeqV9Fj5t65cSY67eYr9R0BX579Yqd55JlKv13r+V7tlmgWCT2ukaYyOKkEJ+KHY76bU6/M9ryj1+xY7a6WpEVnjzJK7J1eky4hs5XLlVelIl6plQT6MZ0s8tv6G896tdLlvRzukyHZKRcbrtdIQeosPolWBIfKGUpCuItVbpWQFo2VJ1QNcqox4/Oz86AgackulJoOBlDGMcFGj1PVJC7qzSnGL0UKuyMlkoriHrkQY5pQiXIRhjjYPc5rhqQxzxMMcDYY54mE2dp4MyFqG2WwYZjMyzFaGORnO6wgcSKaQMvMUMXn64h43L1PRkB5MwKgLkNRwtmJSKYoGUzca5x9elcarUmeYRfgSs8pwDTzJWg3AcZHhMEtu3l/cQYYBwLvP7/DPc5HAgc9GgRkwjLqqQEmHupUzff+j6Rmj3Lz/CX5BZz+dPtI/bJT/8fSR9Uvr6+vrDnc/mqamb3X9Qyv+jT/5t38SnUPLb04zmvzl8LtOWaW7lfWKdK9KVsCYjuepf2WaMejm/ct8lZLuVg1Kj1NEjaXVvJGZeX95elYp78CQas4f+oUPX50ulVAWPsdgUEQpU1p3KbfMNVIhIa8KVxnfP5pb0qX1P+Y2lde9KiKzAmZDpgeW2mViXumWNiMLUG0AVQ1Ajch2q4Si46QoWVrNXUa2cJUis5jrVoTvTA+zAU+ZgpQAdTTXZHhSABJNsb+lSxZwq9K0XCYIx/wg2+vyIrFSmcLJ24Zst7T8qs3I+P5ibjLg+TK+8g68OiMdOso9Rjur4JHHV/MIv2AFsZ/pHs+jzL88LR1Cd3isvst3CtT03WlMJJUNEO6GCJcuYarNGFdF3aO5GaIa3XhWSA+YJHO8A2bxrBAvE5r//jTWC+VfneaH/ts7fB+/f7xDSA/Xrwv9YHxlOZP1OpozL+8gjXXluzvAJruV8rSYqwwTwPqZXqX8w2R6HqTWw/uYDWF95tWMhqui6foZzLVLO/zPQsMtl4EzHccac2xVetby6QquyFLUxfvP7yDnHybHrSip2F/cIdMR6DSkeoxTrPGhOUNui+Yso6QVy0+NPDLHRpAmQx8x/s08FqYwAmB7AfO6ZcCbZxWAXchtFkbLzNej5UBoWDuZFqtoKSysKa8lV8FfsgX+kmvhjxxF/qMUoYKuP9SrQATOF92lTqV9h2Ul/9r0TUYdNgVp/6pcpv61aRat0N5G+gi0QNpPd2XK+6RmX6S8gzwWLYFHa3JHsdAJI310BW+xuNCrTICaBRhlsO5fgQhJphaHlOkHeVJ7Fu/Or1WmFoY0GRaGWAJTLAxp9AzCkMZPy7dK41Owy328ZF4Ji7vxHyGz5eKuMnKYZnvJHWF0KG/W/Mu7uqVmVidiQ+QhJ1aWIbkAsSwSsYyFLIBj/G5UyiKAEhGAV3UlUkxVSwKGZ6q/4TzWWizpMhvcSreyWOYiXuZQbQHI9JyZ9mlpyFW6VL5Vi4EVd7slAKTShZQn9nRpfCsjF9Y6ULywkbBQKTBUzBSsQR9qqXKZX9/hb8GHqpZfZFVksibb5alWk3C3Sgc1aP8waXloKaa0W7lemdQMjiyk7eeD5DqYy4mwRnQyyPU6kyVfPhiKukE82fQBiESwAPxZsEzl7YrXRzF5IR828LRVGt7WCE1akWWM7ACEKv2jYIXnZV9iMiHkIIKnoe7pMjZg0HaxrkTVbyl5y/DzqUo5yPwQiawI3LkmyyKRtvMsKaoKknGpRSRSuWLJGIIbfwBaiXzoF6SVjOKFXEn9eyuQMgjv5V2MKNKgaxkqk2t/YYdQNzpV9wifUjxjCrwf490C3eKrqYwM7wQMxXNmOgDt5qVjhVDBdBb6BnmRC6YGBQk1umVClhpM7K5kUlcDHlEzNUdJl8D1KAljkWzNH5IPyh9korRkYgU+YdBK4BOJ/wglW/IJg9loRviEqfmEGuETzLTWqqjmEzrwCTXgE4nfDVGe+YQJWwVeHWTMq1pGT8AnsBXAYIvoD+YLPhENxOFowCcUBsTVfXSBGpWQsBNxXDiFD6+O4CGjVGY2j38qFBSBgjQoyDAFYSdMhimIJ5diCqIkbIyTAf1ElAb6SZkuAAhfTYWdCClKAYP0gwV1DfrhfcN0vV0A/XDBVF1g5sn5toiYDoxKjQruwnwGDAI7gVAc4V1LoQzMtcvDQS5Ql9uautx1UZcV6rJApxWs2hHq4lYCdTn/EXJXW4WsrEJ2q1UIM4OVFjVdmVotwIu0NDgNuNxVlyEhr3q77wbLkK6XIRPIKxluqlF7IXoGzOu6kzaQlxHmZofqB9mgTdeqCe4TNoBCXsz5GkJeZkBeEZMX2CxFm8grE/IaEJehRiCuxoC4GhuIqwEIzFWIy7wvcZmNxGU2E5cZEJfBu9GAuBw2mW6TlkeFLao2/aGOh+xGLc8Iadmwf5axbVHYVGvR8mDNi4J6x4l4yijOqOmL7gFFKvvfMp32sZxxX32KbYfyrifU/TBk5jJinZxegbjmzQqvP2DfCmKnFTF4KdesuyqDErBeecPq1oJOopbiZLlzi7kZXTH1YMWM6gVybHkcX0RdWED0+OLI+gJZHJ2dJ8dqIV4cXRjTenF0YexH1EKWmYpjRaS3i7kF3pjMItJh+bEDYYGVjaodGD4AY35qtlhhmYDdcIV1V11h9YdeYTVjNhDxyAqrZYUNRFxP0ShoZtBZvcKgBu0Vj7CrRa0oiFp2TNRSQXIaIsPKeC/mULiIOuE5+W0HIQz7/iCG2TExbHNl2JfVyAUNkuJtwzgVsQ7JbZK7xqhofGRcJrookFU0ooYaJSt7VTWUCWqoD05WJtuSfga9lI3lkGSiDSQTXT/JRNdLMtFVSCa6OslsgpsspYu5qidJOxvIxGqgth6slA5LEzM0VbMzRW6j0josVSmpehHRwwWiLWKYGiyUyn8ELOv8FystC6UeEcOsiGF2gxjmTN/Mm/64IJYMBTHhsE5odDpsE0ltJY45sGomh8G2TQ3EMTfQxJIbrpduuF6ictKl89xtWw2wUDnpu2DCT5cKOzuvsjJh7YKsGwEzPBhJ0Mx8mylCQy/QJ9UBw8+eyXTSF84cmaBigNqJubkJ3FyJLksHOQJvQQEVlqOgumiVdrARtyIzbmThZnTyKZlrYQ3g9009qibMR96vONcnxXONNbiOFdMjKt+EXGVF5csczeWKWbzc10gdZ+FmlIVrYeEmTEE12LNGXMQsPAA2ZOF2MB8V5qMZzkc1nI8iVo3PRzMyH9XIfLSD+Wh5Plqej1bmI/fcMGYxb0VOmg4IMpiPXDBVFwzYdejtVjxbjfFsHZRCw96rD8Kz1RjP3qIy2K0CNqGmYWISnj0km8Cz7QaebcZ59uhQDHm2HeHZ43RU82w3zrPdkGd/cDpinr2ZYAa9FJ5tx3m22ZJnvx+NRNdLI9FVaCS6Co1sBTc2VYFn63qBlbHRNc82A54NQ6Nmnq2HuxvLDNLUgn3G5iElu5tg0DFDuw7zbItGAs/WA/uZEZ5tap7NCiILnq2EZ9uaZ5uRrTPWETvCsV3g2CbsB3i5Ylbqd8NSyizbCsu2gFgJNWCcmGVrsGwLlo0fjbfAuwcs2wjLDqoLFxAbeirLElaCgT1LdGykZIej6l01b6CzJSyIP50KOnmfdCFhGxaaybASXrMSntSvKV+sHc/1UInWb2f+p1PSTZ3FitQBlTm1X2Ve676Z96+qQldBjnc9mGPsitwp/6p6J4M1g1mtmTMHsBjPGSIVeZVlk4pgx/WP8iL+UNHI/iur477/GhYN/2yKym4F3TwKbVOoNPAtqiw/mDEHwu+M1/5Hh8lOalUZVPtIOyj/9qKXc+a2eriM1/Lw5XfVnHHgmMVeEUZJe3WnCCj+oaNVPGfeOCyWKe0L36a4c6xMRKWqUIZt6XkfdUvY40Bx7RUIMkwJKXYnurSUiAhk58yMSIUtaVAq+SQZUN7No89IepoKUU6R472i83plztySyQd3yKsH3ruDxe0hFjiOvPyuOoyd35HH5Nlrh2Hq9i83Wd596L1v1tedX183FHd4KwqUfF5+PudZnJphMIHZSRNQvjejiAe/SLNtTDDoD6vyXZFnf3qnKfvm0f3KU6+aOIABm66xyot41QiDpKp4QdZlF6wLe3nbX1n/vXeVaHEu86jgB7NT+6hX7iPjf6S6JZHxb0XdcgcZ/4bqlh0y/k3VLfdIF8udKFfdchJzbh6iy4y5QwzHrtpbprLi5eW2UV8R2ED8b5duKz+Sv4k/siC83sS+KE7SxsFDt9zazFr5RLuYtGZqh67Ugc4e96lP334H87q7y6xVDa46fHW6bLUKuara+LmPzfPtpU6ZtSa4oFW61qxcVXZhBK+tg7C2J6JOSBfyT8A5oFemFM8qRckaRXBeiL3uljHUjV2md1i3zcoCRf4P/8Asri6I18SMVNyeMzNYmLB2Ydqr4oaKWeoE3r5dY/8x4V3Xm+IGXpf/MUMiU2KvV2XSOsigHoAVkRyMfbewYmbNr79rV3B1vuv3PbQAXrmywhTk/2GT6df/m7pbFPn2ik9Z7vP/Mdtc6s5XFhO0iV45avrkOPeiylyfskjm5gy5jNw9K/l2SjwMAKT8H4xVRraMWrPjWLz1OrHIPjlTFPkr+mqgzgLU9cvwSiLl30g3FjKeLC/IwAvzBMVLul93zHoNjHxyOeHTTytHE/zqp1Ukfi97B8PBU9v4fyJTDh4bqkyka/tC12653q6NwDVnHCvEZtUOFvbHYeLyMUjcAJL/fgtIaiQf+hCQ+PS8CG2MciyH14ILtLo1hr47Dpfsv61fTzFMEW/IakBZtzYGpwO5jcNpUE9Kroxat2aKKcPNmc8I7E03T03cT8m0sjKy+4fQ7qcJcltD29pfYwCvsc6zaO0fH9PZ6ydXP70GynrXrvh0bVVILkzK6fOrqzLRWYS6hYz/p5vRVPB0pVxEmYYIJmkw3okQlcyx9jSaM3d4U063bs0GnOTGDQ18jxvIaJ83S/nHRBrMU8C8WjYpLi2lYTAMa7UXcuidNdyp7GhfLfpqqTnSUSYP/8/eVWU6wqwjr8+zOa43YZU2NhP98BuHqyYE79j/bKpbZTOGPdJi/850F9IerIpvyWUs5q/YzvuLmgsusl1+Evhe6/r0dq0C6gGKnffrpowp9etGXkv5tQZeS/FaGl57znBtz5nR2pKNtVHqL41VlI5XRBPU9OuTp/3F3V3IO3sJ/QLwMjoTvgG0aJr0lwxN+L1dMJUu7aBmsW8PiJjboNEmog1NcI3vTHdpAut9KtXCOdGb96qlTbVSxvuhoDf6HJkjv7u+vv66Omx+kwxo5/Nk/F8KM9Y+XswtrG3g1ZG3MF7bMiZXpq3ZzL+K8RRtyp+A0YKTlmkm9bjsKh/+UsZmvRK79cQnK+fZUu7CBNoww934/HG8vAxneNL6OM/wyF+5YlcqsKL+OV+cF+7/F42xtQWv/xLI/5+PrJGfqSeU9Fa1ZvDGn4epYGbMZwK7g0Y+XepUlnKylONqIf8oNbC1K0iYxWfI9sBpYOksG3ixV+LtGLCnuEuZhYSp1qqEdeSBdXzkA7COfSvv7eYeM905cz/fR+fxyHndnTNf4ifN81izXbfK5sx9lPgJGYuJ86z+t/6G4y5MN3L+xqVVFhr9PxzDGYtH/i9qztMWufh0xr4tGbWx799OGWV++/GOqM4oY5UZZfAPsnPmNE3ieu2QvthiClagYFtmLZXx9vyq3CW9Pu7SRkOxNNQeaYgin6ygrXEyjMv2gBSlgp0ipe8UGT6Z45mwk2X2suUVTfrttIc6tEOwVeyrdjF5fW9cfiiBqv8pkBajyatyF9PQ/VWBny91y7adpxa14ebVx6PfXPP9c+V2XH6unKK4bFKKbQ2jYooi2r7izVq32j2rdJWROwZaBGosUGOpOTpJmkBNs54kOgM/3X1ImyqtLVytEVwJkphlOcoYQ5QJhuBuYvqsWBX/16I3YZQ2GGjTBb+FrWxJYKHrg2WsEUctkTR/Z3yKNqEXCmv3R0EcBp84bwCXYxVgt0wZdJrsetM7pFlFmOH5OFj7PgBYgUAoO8++6zzpErQF5pb5ZGPdN36QupORuhOp+4pa8Vk3gztyVsbUppRa3aVrIESEjJTXARm3GOOG4SxbgWsEam5hfg6+42eH9FtO0P3O+OwmkGxjSPBhFmBFomJLmv9H6eYK4jnzW8L/Hpozn8e6wzTPYILqaQ/Rpor+eouK/rLmM7sCM4avdOsjKPr+kCG/cbjaTqlvL61S7p80S6t5fP0yEDUo71aFf8L0yt24oW29blmyTxI45A1QtGMlbQ3nZmvGfJI3ga0Zc3N1I35uqSq6cakDD21+/FtlGz+fL5v4+VyZ42ceZP4r5o5yP+5u49Xc+dtWQQLsZNAz85RTfBNo6MWnaf+T1f7v1BM+mVVKxF8xdSezynxaQeudgBWwE3tO+yl+8cLmrxqgi8boh5oamLkNqNeu/n2ZCLHzrG+ZPinTZ8LnbyJ8s5+iFy+U+/FEVdECG+Rr2EKzUPH6AsJ7ckibUjaPVcIekAnX8R3fpwTYXaGsW2b0XnWoNKN2mVBT5AGKRt/j3kWAQmqQDygCFAk3ZvrYJaxUU8HZskwoFs+I21ZxPcRyub/Gv0+6mH8TFB3SRpqb4ubY2XUvJTQlrU1xaw0qe3A+XuKglogS3FXHc4Xxfe0wQgx+0mzFYupN7mFPGEtJr1tG4gxzI0xFvYqfUELZPbw1ylBRBpVUA5VSUZTwSysTSssIqspsidEcysIXeH8g3BVV2YAEmJYJC4JlRAU1ev7Q3QgWoKjHOE0W8ibX0+jOKjUcMbiZ9MpEFmRup9hfNuDBj5tMAILzPd9yWZz5fwf+fFmt5HYPNRmDTEKRVBOhCOSRMxWgSBAcDcZTVnDIQhR5Wsn1Hv9nWS1HZsHjIqYbgKUG7YbPbDac4mEIq1i0xLvR3SdMtwqM4AaKe36iWzEnaJGDT60FH2gJGJbBAEcYV2exo8z33lWL+Q3w854zrx9u3QAO9K+EIQ9kVhFik9bejJlHGbdurK8ogasHd/CGjGVLlgemoCE01FwTzrf1JuzP3lUBI+uX1Uon7Phau8PeqFU5if8Acsb2nTdep/CoaBvl7BQyY6a6Yl0wM4bYfZPYtlk1F8AYj67K9La9khnv3rItQEy5eWoTPO9vEBV8q8JnZRMDJgU3Qr9oaKRv6ECT1QLYVEfvu/vlhjpHWTP9r8f0UZSX21p7soHgnpfbMED/WlaSXRnlC3mDGiyQg8jr1YNyICiv2dSuoGl+/fCoKFaIKNbeIIq1KaJCuFBrXBRz1ykLtMALCxAgeFbL6x4rqiZQTVa2vSozQV/Bc2PK9ymjVpeBajFDhDjYWqHsPINRAIw2Zd2lDwYHi2GulvWKWaXKFhUMHEasYE0JZPsuUEOO2iK/tPF6CzCLntn4vxKETyAYhlb40fdq8VcmDhddVqJu+7NxXRx0qf5f1O/v823a3qF4BYzw7lp8ySiDzW9kKNgF3wlHtAts6LmeTjOJv36YMulU2KxFwHHg9230e1wOrmUot8W8nt7i2a4tnu2UPWTJRtR/We8723PmB4czIbvfkhHG5ee3JLvWynC8P/AOQEa2ZeZ5pKtCIqQYGWJsaVOL6W0701sh9FYwkrczzdf01tpAb+mHord6GMqE50FZyLxoUbvkYUrqIRofimJARf8u21I+ngR+/+cavwUEASYklofvHNLTCHopc+PEFP8cxHTnKDGhxXH4sadpljGAfC1IsnnOuqu8NRlY+52VC6z5GMsXCESq2PvoluPCNlnEIAgZYzOpnRmmJAipbkmG9zb87+ZQR68bjLu3wbDU62ZiEoVuo0mOmkudCsKgg1ajbFLu23dDS+pZAdsge5NSh1lYSCEsWPxYaJ5cKJ9Rao7LnZS7UG5C+SGlbudyI+UmlMNPzeCFMWkEpvoGWWoWB0SGFSVMrXZhAINc43i0RO8Qqtok24gOQYQS59vH0OF7eGVrgge3V1ifMKKVxAcTqdLOOOesAzANr3u3KnXkscefvHDx0uV1/Wi1/7CCvLYfiGliiXRB6yOwxFI2eMX5Aq804J3QEGAgt1V4ZHqHlCp+iSZusilLmRM32WLk26BNstQ8msPTdPhFaBjvl/vl+wN2ftj0ARm2QvBQ9NgjAvxs0LbrzShVfOS62rY0+sWHa9sKOtPeTUqN4XC0IVNXHl4s949WvH/LiploHCSVZmktBHB3nMebhzrjWqiBi3SsVSYhJ407eAvIHG9wbWRrGgz3TJOBA4Amm6zuy6kper7mYt4aiBut1hbrwcQWz/ItnrWGW/g0Y2Vnk3VWCQK6Rf3v/3S4J56qmsFewoA5QmgQayuZlbDNIgPzyGCkbYWrafDzGdjAe5UDj3HU6hL0Eei6OMy3j3Wg3ZwxU2WTRbgtLGHBUAJFaLDp1MrQig0vovkMetCMXA4U+v9hRFX2mYHpCJ3gEOl0IU9F6YIJjRkaDDhosYktejtIk5+pMjygexiUjFWgn2EJhuynlUQPY2xB8elSJ1dXt1MNelJbzVytu3Xcg4VcI/i3tgEpsQGxFet/3LI7xUh3kmt158DG7sz8LXUn3dSdA+jOK6PE5TDovFoOLYbJ9e03BLYaoAjKqL0i1D8+Lg/abMy0FayMcCe5BZToG2KOvTnbaAnfYL/iPf9CzqLG1EIejW2SouvcJDmGVxPXQogAVv67Y6suA+lKy1vYALj4GaYZ7YKNAoC+Lu96XcI38nqVVGEhwgqeK96J5Rz55aoYNR6D74t3izmsUX/F98Hdw86Y20Q6t8FtB45wM2u+6Hp2CiV48MTw14kXcsMO5TdXKX8Av5dbOBUFf4KN880YPRZJmpTew/5sDUp7lBYklPJJCRu4ec7cEpzcIIUkXWpQs0cp9BoxNSmm5lKVdqq4INZhAky8gjjEuEd4zB5xG6rjm08izgJpG1IBtrnY4Rehg0upeQ87yYF9sl8DfFDKnH1SSk7PAS9V2ktprytOyNybeNPeN+a9b02ow80vHGyQMMLK/rdJRkStKbYiW4qLGwCpXN6YiZGPh/QWdpCaQSA9grFhS+10/bqWa8QhwikHj6AU4Kidf44HpKAGPdrpzkF883+PXEfCeBmoDtg67T3aAQEc7ZTTQmb/SyCzR8pprO2ESJDp7FsN3eqLGxgclsT/6LZyAj93EBIXmD5N8F6u0OJ4NX8PXq6DPNkK4OFrnXU5hhXZXUqWHnpVA71oQweSm3lqew5qocyvG/hmZd51ie1aDezQoQfnAHuv144jdF7Jgp13eW+Syat4rUp9gQoa4Hher6x6ww6PDcoQ+J+G8JsWVG518E1CaYGJGNxlW0c5JQMu826VU3acRcMt6kulyRB/iNjYOuY6DbGVzw1rfKauMaVsKUfEaCof85Zqy/rzQWhjitjHVIIbUwTKhQhpkS3wIaX1p/xuQsloPooEWwUO/8lD+E8SAguBhyr1ZiXXHHcECCcBIZT4Wa/chjdaZZPtOOIZ2oJ3Y0LNDV676WiEa0JNcKkm2klDO9Osv2hSa3GkkrG3DD+fqhLXpxZ77rYgcCTgpS323M3tPOVlSknVhOdujm5OVQkWQYh0OZa+AvcIThxGuDYzKsQxt8V2bvgHJOyYi7GhhB1zm8Buc9wxNx1xzG1RERxzC7zLjrl8NZVBNcUTuQCTF6B5jidg2dzN6Sz0jVdsFEwNCrbJshhGcnJIBJPjIynDvSUlbguUvekbSmlbAbkZK2OSMVxYqhgxmLrsAbjHP+Ifhq8KB3ol3q50WEOJumCOTY51+MsGTVDyThNyxERhqJFVE4FB3Ff7dN5BiibmzG0ZwTd5Ag6J8gH7vhZ1KAe/64TH3iZK2IjiSaU4PJK9HF1vjjeyYMs99hhGSMf02mp2v4Z1wfX9o3i72BuY7V4EXtzGPtEbfSXBf3VwodQbXCg5WQvDURhShSEd+UezrAhOsMH1cn6DV2y7aGx4srLpyb6ikTXFLb5d+PpyZXi5r/Ab3TajIs/+z1/SucSlPEqq+BW4Wh5bzdWeOmKjFZw290oUsENSFXbiDA6u7qgsE85/K1oMpvn/COOdwAXXH5EJZrA2wRl5ZrCBDeuTKg7zi7IpcLVI0p8zM3UEkzu6yiE2/iueg4yPdbrsMs331ru7Ot27VnN48V/D5dL5jy2ya+G3okUJPYFnUGub5IMSVeFfs2QmmZ/WtW+t+fU3dY+lJhecfrTXd4kA/ANdWW/uzJW/DMnZ+ngpV1g6LyNMPj7aKSVPCEWrlfW0Srw6v6I7lfX7HiK76vedK35VnkmU+iH9CTzAxS3Fr2bsQM3KdxEcGTrGF1AXZC004vynwCODuBnczYO4WbupaZYjuCjt+n2scN667Pf1NQrTT6tBeKw4lW79nrpGHX9TZd5IFBwPTGPxvVXDeSeCDA9bBzqdO8OwbFULuWu0YEVHPz4ITN1Cq20WUw+UHBC6t2QhE2p/iIMlS4UFzwGuvCGVM8SN0Hji1aKHiJV2Vhlu21n1nAmss+oLmMc6qwzDjNnLMn1dWRQgjUJF9vreYndQefGQjq+julmVvP9bPy/yGezWdUDD+UgQhIs9//XgYur6cBGRzWbMzeyxqGYwhSCb4zNsTm9hR6PhFpo40ZLMQ2Yyf6F6E5FpNBqWFXk/VKyQ8v9BLeasohdqYV4/7MU82UN6imX8HsJEAazYEMR7mzfE98iMT6HukB6xEYi6rB6qBt5drYodjOWVmxfAgESRONof10WWgl7dpVHT2oC2JTKoV8bBjjdgy63sKoDENQxTnNNgDAxourYCw46AwRhlg8tg77p3xuyVpWGqTAQhewOKROvMglUceppsbiLpsj0/NDHgnlGoKQitMJ5AByGYCARCFIkWBGw8kMwAbNCLDVqN0EdZF5AoLzmeq41Q2CEUw47+UNWO0lzHgbqOv/m+HvgQff0wPf0Po0N5swxlq9bXGHEnqgF1Ah0quzogg9JrTuV67azB2Mi3bU3MyYCs48FVNLgSaDhSxcyYVxFuzTHZbH//VnQ017XM0a+5n6yKuphr1WWBCZraO834nyAs1g4KuV5TfHq0jVio5MmDokTR0uEXwF7VZx23dkGT7SKOSoQIsj2vi0Py4it6zrzADEMVh731/BByVkd6p+bMSzpUwq8PRt/MmDdng4vmm7Nigfnp7Ojy+yGKZegijq1DthN7CIldu/AOM9Jrr3tz5lVdQ8+Kwzn0imvE/9+afT80wI7k1ZYoqLvP6fcyqZTVb9eD1WtXuZBbwekb2+HmJqPLvqfimij9q2L/hGGr5hD3r2jxm8LQ64WR95ZW8oTizS9T7M2xPIwba/JGqeRoLY/9IqgkGSCp8YtBUhJU0gCcRtxDOJ9SBSsXTL8pmzWhNOQrPbgyi7z5ftx0y9ybUVOYRHDBriG+V5RKdp+IPzJyhZhsuXKLuZOraBGaVlzFi3ksV8kiVMZQlcH2FHWrBoMDM/L/o5coKi0ro+E5xFbAGFcwGIIEIvh3Bs8yGBk5RBixgWwtjHwc3N0iuK+xgaZBeQ994nxjlmLYQuoBf3MWeSS9Xcr1HglPkDnFMwppKPXolBsUR1vOyE3FqLlXCWuHu8SsunQRyR8o6/on0w1ztOUvfVMjGHPz7J0xL2kO6QqEKlTMHuavymZT2IvMZqZYACTG3YS5DmahHe+d3QD+oNhu2btNxRShmMfmA/KbbJzhqJ+b4YjVDwkZrG+d9m9vR0zIpFJZZf2jK95IyOO3OGKKrP/tFba48544j/eMCozW68XBgoMdcW8iUki0rtl79sJBmb/PHKzs2iqnebN+4rPMFOLb9YWDV5O846tve6Bs/t2DQTZGxT7vlc4bX5DtnecIExBSN+x158wzB/0fPaMPaVlLYn+Jb5CCaG21ClCwttb2yN053EDWS73bAqaNZUOY4MEZIIt657l2JOD0RU80866bASQyxcEQsstCwc0IL18UIeZ51ixw2tP3GntWV1Ht+88ZnxRZjmBm+n7+4HC1DmyXfzHo+AX11PoMfodlCNGUwE+YaWMalHQ33BFZkgFZmMHCtnkA9EDmufortcxzSH+ifJ+KZtUvl+/bVvrzvTIEp/n+4GTXfoWNVW2eP744P64ekUk2jTSyd7kQyN4bpNFayFg19u9ZHfX3sr1a90dUZsXuEUVc9k+1tn1owKDqiwYqPmyfOTXKNTR9monm2i9cfL8XLugPrkz8bVZ+/bU62skQmK0LkzVYv3e60NkCp/JCWpUQNj9jaEO0/F7J3cC6IhUmg/M/eFf1/H1LDFf2fMMk/eRR0kE9iZj8J5CuDRk6n+AF4eITmtchr2FCllLJKboAzgfvTzYsRwiVRBQae5dz3CuyJFQNf+npf/9/PXoOTjFer8BRHdM9bDjBvqHIuni7rLcR2zE5vXRp/aUntFzD1qDFv8bTUW4jO5L+hps/8oah7Ih9+rfLJr/5cGm95M5pfo59a47oJ/jC+X0rnJL80hOabPFReP4IHHjnAvuMZpR9xzfXKk5pefHX3+M9F/8cWcoGTUu4HiJA4Ebs4Dlqi49KKr9Bl7Ij+hH2ocyALRiOlXwBQ2LxUSz/gGH4BeeCPiemeH9oKef8ygukfbKyIGHYsBUbwnCQPcfumujJxdt5M3SOkxIgK8qIDRi8aeZM1QDgwZeIA6/1TZYofvGpKv/OsJ5fL2MUTJN68alqYqxAoaCg5MWnqvZYQYKC9wSqF5+qirGCCAWK7ItPVdlYgT2iyyYG5kj6n8O1BqhmBLP5q3nEPl21LtRfdDnN+zn2EZigDc/VuRIyY3vj8+QcfNWp2Pg8OldCDMw2PrdAXRPD1RRXKIYc/SonuN9lm/FSFoy3Emx+BtlnGv43T5Ph/C4vPlXMvAjP/Ref4qs2cMVXBdDJVxkw/lQxU1rO2cp1cIMWGYjTJYfgBrCH9x3hQAohWr9/LrrqJxXyV6FUkxotHRaYqxXYqxW4qxVEVyuIr1aQbCjgHqbSwzT0MPuziJk2x1SWnLoppL86yp4F6DryJP71FduDhsK/ecUeg5Xa4dCFAmdsrK/f0eWVhYtIrSIvDZ/3ADtZwHqYXnWFVmK5h1OKHJp4yBdrYMdoDJkAucbVNtjfDw3nRXjp49j9ac5ObbHyhcrkBlGI4dIML+3w0g0vo+FlPLxMhpfp8LIxvGwOL7PhZWt4mQ8vJ4aXbVzyWRQFp8PjjPi5qvvNpg++wBi99HEZpJc+XtOhcX2m42JIx9eJ0UHN0XA0OVEy0223UuHSDC/t8NINL6PhZTy8TIaX6fCyMbxsDi+z4WVreJkPLyeGlzW+dEiFDJdKRgU0y3AFXFuNvM6yf9HQO3GEzTw7F4RNbOJh+BXVL/Eq2fLUJS1h1byJWWO763A/MxJlzZnhEt+GGR2stP68GT4GXwXuZTWL4Uos+TSRIV0Ojrhs5iD7bvnY63ICm9sEdmX445aJ1+xK2mArPTVlo8ttNuo2de0wC5YWSWEyDLFNUCjuTAmCtKhxrFNOeM11S2R5sSjh1mtlFnrLFZC0hEbg36A+m+uWQzWIWkXWjgX0dnE1F38naqFBg5rFQ2wDooc4Zgt0S4AMuIbzBWM7kscckJqN4N5PlZMUVdvLqTqT3YQxCmmU2n49p7hTTvnLE/5yC5fb/WOmnIRlfL3w6xOhtO0v51Kqykk4YyHxiD7q/9fY/yCmuFNNe00Ta1V7aSXHdDRH/b9x/nWHot0kT9sY3j1ie9pGE6zzNb4PdZTXFK+VOy2svYomKaIddX9zr7vHcrWHcppcYsVM7n/Mbhvb8ajn9VoV480yp5imsGnPysT3qUFFr9q1VnZoG/zZ2QW/3Es7eeD2UkqdLjtBdKuY8tu1oZh2IcovpgTif4pDGZg+emsyKlXs9XlOOBivgMcMSWlA9L2qznDQI7NCcZdNZKVBd5AXKOEFQWKC2B1Yj3Q1/IjyZc8KnGSOwtng+GrOQWUIPGse61BBE1R0qgLmmG20k/u1DaCiw8ka/EPYxySholtlx9griGHNQgu9KvPqrlxTUsYjY4kxoHa3atP0sRUeQ2rT7mMrq3kiUy4jwVdCE0BUIhvhhLbBN8mcBw7TkjUKaKnM6/mDyYXplcg0YertVkKrw3nCsTqHtAIpB+4M1zmOe8M2CtUrGSKYtcWPkwGjNt7hlAwObhdKXCCTdub72ccVKrLzwgCV6N81n4E1lEs4o1mW/QONkxUsqZ747xvx34dgJf77YaFXIWOwEf99pIkW/30N1ZoOhzpknEtSyoP/voY6DuWGyznZF7wk92yAjv1INJniQJY9aGxfPyoHHakKTt1W0jS1j0l6uxmj4MPn4KCNOF4XHLQVxYdrRUX4OupJ6mstfmR8JhfnAJdDNEhl33XGDpJlWRxfBr+NYwBGLHWcZHNvyGzNyAsBACMZqkT/MxoAwN3aGAAQj0HpepyoHQjkXUQekyZ+RYdXeLUKa5dIvaIIBT6DO7+FBMwJNoMTfqhe6kUrCACA40b9RWgY78Mwju8x2wdNJzLug/WSSYVTLddt1+7819O2FaeR8MWHa9sKOiUAIL5KQ6auXIcAgHi04njLig1nG0RArPXT3aJir0l4DPQ493RxgEUgYledHoizZA0b+0rq7KsGBzDyVJEU3AMytDJ62Md5dz7kf2WiqWS6AG5VbySu8n2ANkh6I5sJlVVas/gGOY7TtHZJ385NYqPD8vhWr8zxK65+5R5t+2EjLieQqfpoJd5soUVSK8G5SJ+vXK0dYPFwpSOs5Hy9xclulSZ1SKRVb99+BfscdSS98NSABUk3vpO9oLXry8xzBxj8Hu/gjUB+lDNeaE4C2GGNgw+JGyUNqAq8Mka+Ci2n5fDqJCpmVmHx6oQ5XHyMhQSDekwQbDGQEUmW3iqGiI38/2DJzCtYQT14P/uktn05TgmeeJUNqX29PsZp9KV3vTIcPnaFXdeyP9HstcZmKMPY+a+NnCQCAxUfGcZPb5SHr+0Yfbh9MeQ+NLWANoo/r2/XP2mIBmr9oOQmfHtW7t+cja724VULsv/WMKzQ6bHuVrEuF7riiLW5WCucKLFVyNo7UAYrVhKyov8qZapWFHPC1VC5rRXFPu9J5L0NWmJVzNY1DVWRUpMZaWVTWa3vvFrxlSv2nFhargLnwP8kJCwWx29enCi4h08RkuhMZd/RnHQz9EX7xghqdKhWD7t/4eBIs1uUM3pEQ63uztX71cQ+aTIwaJ95hRLcMSUiHQm+vHgw+29qQE1/ACw7tf6cwNYQ+AB2eiefAPC+deLzIeQ+7fGYZ9m7TZ1AVZoMDw6FHV9UypyvsjljboaK3oY51fBX1q/8YZ+VfrGkvXKs/kSWJVA5dj3slqfPD7K+8R5BY+k6pC+YnLXYz4Tf50xuPA2UiFhYWCEYFJANVLhQ25E41aiEocTwBI452ARo+enObnELX701uPqJ7qITP9tZ3Mr3b2zn+7fr+/Vd/Kb/VzvA6rZhBTPolcU2wIh9J0IYyuvb656J6C09EsS/PYsvTneryE9255ghzJh3Zn2zixNW4Wva4avouGie34CtmtOmJMgcAvcXWL/hi++OBacWNh0WN/NaCN4ghww9c7B02N/xC9ab1WBYMldhFhsJwlwXgbFVKdBsYBZ6M7Pwl57U/tLXdfEJJkQ4ogZw+JymASABtp8HoDB9co5Q9gXpniyBDI7E7DgBCkNdNZCgIBxA+vZObD0YMa0AD43h7OeAS9KZjeKKF6esJ2eQBFyQ81E3Q97uZ2SI9BCShPQvBJLk2pBwM/xkCEns/98rgiQGKR8i5xcD0lboqdJATK2eCHl1c/Vz180qF8DjeO56ZopsGVNThJB0w6TEgZCDat5/GqTX1wGzJewjE2EU1gE/AM+pDDWKX645TqUp4Tu4RX0CxrePs3VVFbNZ9i8berIvZwClwdjGORMlha19T8aAvPj6X6rD5tJNHFRovbqLD4X1f3wTD6B/YRe4cr9sDoQ1J1YgNWMu3YRTB+4Ospvm8+Mu3QSvW7bSNFlC9nAtMXdWSUeOl0u5tGp1IfCocOjnAGlvz7LzwNtwb2pSgljveKFehd6ZpZg32aY3Z96ZZfGHg3BEcIQOox6YSzeh8WaAp8nwhNPt6vaMZCtJeGs+JkpqxHS4IA6z8KrudqHH/EAEeK5czZiXdvG2KXSbD2J8aRex9rD4pIDz7Zt4+zBnvl1/Af8UMWbFgwP0Rt+qSwPO2Llr0FMHfUMqKyJ3mwVjmOdZ5IWzD5+IwlfYSsVLkLjRa0cWmohEftiVfQTYkFpvMLZ35Sobhc0E2GSAuSeixHxmF+In2a7bEopLBhRXyKl1aRnceQvJ2Z4jqTcU9qKE5NwLg+SADEewqjnWXgoMguBa3jX+FScF6KV/xd3dKSd5mTXSEUOTCDVN2AQq31YwfFbbuhXCWhKaCKmJsOnAR1gd765Mp2oDP0b057YEN2lB5xRzhsFxvxfOTh5R9lmOK4pYncRtSQJ8WcYnxFfDUrt7WlbyfJSwkd1gG6DoUoRyIW/DqQSw5+GtEHSNJBuqmEzF9gLD4OSofQKSDOU04XVPdkoRFxq4sEBpczurqTLR9XHaP2/uwv96JULoUfkC91HXyjwj21rWQyM3RjVEI/DBefTFEQjpn3D8+WI9Bd+eRUooPimzF3ocka7nWr39lU2WqEPgGxYXN0XMhU3xyZH3sn9idKNPGqlC+BRRJoErV+ztOvbOW3LQmCf+9zSu0rD3EsbV5yTtYdOZBT7m2FwdyYGufH5QdpQPwdKBldVE4Y5iScCj6Bj0pqYPRbXk47JB/xqjn5FMQvaOYUUTLyj1SxEjQ+glk13ZMzv59pmd/BHLho3jgr1D+qIUXtwZVBaH9LPy5NmdGXIGNn3scaCiO1rZTt1tb70j2wnoYLz9INWNsKl5c5blPxb5oiDy2VZ9PvhPZxGF5maV4eygvNIdUiGlvK69vQT/g00lqC6uN3/1ztIXnD3gzuEiuXHfFl1jTzeySMajG8uwa4VFCz5IRnyQRD6M2MOuamBmpwzl0+k4mE+mVTPUlaytQhkgq7nAmozAmgR4knoDeX2wNgewJr3zoX444QV/KVzWa3rD7+350/e4cGDipW8gDioAk86Y9ckqDQ5czNNZ/HCjQtNGMNz17NM3iEyud57dBNOhR5cIlfKwhlURd0XOvdO9KqXUJ+f9uum+d/+YWerMqkvfDJhPhAmIDpHJHcllRvUNvqB40LWfR+XQHO1HqB+BHANsx90M2mHGtkMkbIp4ykt/H5lgfIHr9W2IPA9UCrWRHdKFtD/0f/9AlOA2IXozgMMWa6oeACypTKtMZizOVc7A9h5PWb0c4XodJ5PYIVVIiPa1p5y7PsTqAdwqbM/4nOkiSPthh5b9d5lu9oXdgiVXSad0zIaTDrsLBOY7znj7nKZbYQvHh/dE1BSmq0VUbNYsN6XkqOjxupURpstHDArTTdhiZAMjc4GRwS/K1tTnhDO1KNqApLhH0QiSNo7wKJI2lo0gqTVAUtQ7H+qPhoMb8WBG4h1ZW2dgrBruuG2940bOSk7QElPC3qqSKDL0knWhpZx9HguvdTWVmnkZ9GvNpuuiWFPz2K5kKIqDA6qVIXeju2A+NA4rl0ACzyng4pD+xs5qCMvYLPoFwGS2gMmEUOVnDlJUbzeNb392wDXNxq1mHBqLt9hqmjoa5n23miZMC4NcsYaSYHWQBkMJ+yclnDuBIlnTrazpG9H2zb9TtL1bo23ibxFteW8rlEmiZStyzkYs/cHfKZb+U42l5t8ilhphmRjHEpLVGskYHeDLWAxMKD1aGRYDU3BiiIEGYmDa4azqIgpe0Trry9YeQhu29lU02LRWDShFOEvwWoixEUtKvR10d8npp+Q+m/PR9dgQrFau/j6pFSZpKAzPW/XzXPLh5ou8xeD4BN7PzypJYOOwXcrYI2S8BjeoeYk3cxyEIin6ZLeLQ7UodCWcpRi2F/XDBszrT2hx3TXXdN3lozJ17boLBapka/mhwjlVO497OJvrNf/YpXWz0pHjBCU2VRtjWLr3HztKCjFsq5zn6FOLeX1Iu8neafAozJiWj3oV08QjcJAnu9QpeZvLuWvYzroo3kai3GbzOR9fFvTsH2PNb8K5UkBHePyKFsnhBV21IK3hsHWkiTLIxMP7WWSBEKXePZ3KHIN6uEnJwgrKFldXVzjTkZJsAEdZ3bNSxcXNI8YT73qBvoePbG9oqxk+NXjarw00w+e6NwwmlIiOTFKKSO9b+L2gpR+s9YAj0bEOB+IyHhz8sVocVcunniNOFmExhdxMccmUTMAXNN+9wGrvHg9CbX5g/4sWmeK2PeMPuuG4a46/7clR2HZoKeIjAjM5vN2ytUCOBXaVkWMCeSSYBDlNtEEaRx5oDlPj49rWD4ZesgsIMIXOhbc4/oGn+CtaKsGQ6zDCiO84xhYli6otx/JxZZjP0AIFRK0fBPM5PlDQodWsrgS/Tx68R+pBg1kNUDeMA9IrkqvBekXDvdNIY8JxH5E6KtuDdp4i5EPvhqoA/AvMUN8b82cPHhMg5syzB3mr6yR+T09EWimlAzYRDwpfOCufvYCT/Ia9NyFpMV67Jw+DW0WCM3cn9wRuAwMgEYfNI18jhw/pNu+DnEfIBiXYK1omW40mI32zgQg5awdYtKTZE5wg6BMDAJIKaLNDtNlRtLle/Tm5gLYtsFWjoop7VVTP89YoDwBabJjRrmYoFlNdPM4sJnmYzvHi6sJqbgbYloNRBdQLmmIOXgeejnUqw+5sEmCzR+KmZIT2cOR7VmnwhTDHTLfGNOYz9EjeRN7yeeY+Zbsl2ez3JRqEQySKgyFVSaXl6DgoX+xSJxzSHmKZC9I1BbZId+VgZ3nelVw0bMLVwwkPI44cpsmVK75FmR7EnL0HT5FlX9ccuMIn5DGPgROzCYs8pj0jcy/SHllR4iOUmNh7yRwdBojDmHxDSFkWPvDc1kj5jSEhmFTSHeh8U75BCr7sv0z5XF92JUiCQTSWE/Rq4+mr2j/Fh6MohLXKk8r4p8W5SaJ5JAAboY1BcfSKLm6XgBSQhn/a9AJdmt6SAEmmuAMk+pIOXXhJlyaTAFtv76l7Oh4NqCQaUKpSM+ay7o1Y4scjlVUdFzlizt/yDYPISSP5QEYjJ2OJnAyaTHEESVgjKef+YKMZ9BLIprbUQVRltw6rHPtMCdqkm5XpYacmt2/NyrR/c5aNgXZJpt7ruracitb/JW3n67kdrB48t9kbYaW4PUz8l3TQmCN0c6BHH/3EklvMI3aICiGeNccwg1pnzHMHazUxs5aKTzxI58xz4em3Wf8FDYeaMX+s15DT/rlQOWf8GSymIRLdXH00RywxH6JYpII4GCm2QnodGboZexwYqiQw1IYIw8Ux7vSChjEJcaLSIReCpMlJnGioc5QLqUFgumEXGzNg6sabezqjwd11E3q0CV03oSWwe3MTHNgdmum0g9ImMN33rfLaUMNVC0sh2Oafx7rZF86eYAKLoPiqmALC4hj65rrQJnL5I105CUNWP84B1oW+vlcz1Muaj5G4PCS8pBdSA9RsPZEF1MmSJd5nbiAtPMtAP6/FCiGz5xF2d7IS9xk0xNAcwpeY0ns6wQ8rqEUUQviCdcMG28Z1f4sQr+ehe0m6ZRTkBMVHni4EYWAw1ZlguhQVt8kzJjwpggCDmCItFTx3kM80Zq1hWL970iVkp1B88PHINH/yIJtFAi2xS25gy4i0hpySiTeNXapXhAtBaOGqK81ad07KOZzSVUpulr25eVJX8dq5FYzMc1pi4iOBR7O3Btv5sBdaO0dp/ZogFgBq0ivsrCwD5tgm1Dyk2dLWJC3z027qBnfAHGMNpPFPmWP5UAQQ2xRTnshkzx6sDPugiE/SqzXDqTSZY27eP85BKbwH8Y8bbD0WsNoPkmzy1EBSIw4JBqMTrCGAX5M5zmpC04PiU+TAICq4PulBDQY1aDkWGSBFhKgv6CyfPZhl9/JqH1hm3SRHY80EhDH3BGFcC39icFPsGiCoE0N29kNj2n3zKF57LfCY87j5fkDRjzTCOsI0Fam1558Gq/dslz4e9n8/DlInElaI7bZsBrLJKGLTlCTD0L0qJ9s9pJQcvvukltSeFzXOacPjIiRCwZY86wpJangOsyR0SCkq+IpJik2tNpz30+rCPXeSJWZcbfsNPnpq21Nf+46352GEMV0sLs6/rZdCbnyEHDxussp8lildM2cxxHoTIyF4hvIAryk5E3ibNE2s1NESGnJ2woEIfNbLIHVD9m+bQ+EoHQpHQTzqbxaOFkako6UVpCNZyBnRkvVhRDbKSlev2Bj77+uaOc6ZlzXyYciG7SWNk6JZE81CwT2bBSo3EKhccUfINmF9dGzgm6UlONcu5trbeo8RhCf/GEFmG20wE/LhPauII3ZpmJlodAmWKTculFVMay9r3z/XHZfMRjJWXEUy2/zGB5HM0p9DMvs+5/7rjY7Eq5JZpcsMO4GyQdT+b83KdHpzdlwgs4PNljuOhVc2R8Ky0QDYQpDNvl/LZmGEWRD77piAIuthsgjqqWWnYc4KtWXOimvIIoblvRnz3SHbEk4pWVr+bqSzofQ1KguZ0S4a6WK9c7hKN0el3KEcMSL4DbDgIlm/x5C9xSctw+d7/v8NY0Ino0Il9uAfQKi0H0aoNO9f5XUJlWAobfgR/NpgTdysp9bjztebiuG0nCpSbl5lmVUqeybX0TARxNDZv7QSFRDz4fVI96nCHh9YnGY1bKWC2hWKWM/Rk75/tFNaZP/y6k4HVYTpRSEGwmusV8hgIRHARQ+acc5Dkh6tkhWO7ibrG8dWV3PlH4HTCKdD95cOkkIOdFEAeyS49M8dfCeDIKU4ebdHViZxV1tnLRLD6D8muW61ODxpMmt44xFSR65ceYzPz4VYcWR9/fH1N/Vh87webBif1BL+NAOoVr3BNfKwzzEpSwmvJCMlF/Xg+fN6WAAKANKeDepBCOB+fV3PmZ/Nhqpw6139AWBMZQh/NuvN2pxp1coEiKFBK3CxVrk8yxdG0s1y4pz3hnCdT2rUxe49A13kI7AMGF905VD5kM/F1aKXFHOwiRk0MZDuuAdvaNE7/oDj0T6tDtRAVoHA5uCSwuv1aQ/d7luzIB7Sxa/kHImG9OgaNaWkESwxhS7vrawctMb62pQ1t8hjwiQ0zz6OsrZMI6rjU/5jmNxHK9XhnnJG4kG2V06vLFliMz6DwD/K6YJK45/7BsLdQqIt9i3fK77qZq3icbn0DS359tcn1xD9hz7f1cEuQ4n/IMeC+EsXdZ2dczSShX3Tldz6P/ym9ntDDtaQY8LYeV9wwDjc/jlS/8ajmCEcS7YGRadP1ubg78Dgaorg8OCTHqfYwFjd1eE9RIi9cf7Ss3BnH0IymldDAg5xWcfyiMOeGTrsDcFnLhUf0oWERPmLmpOxa3m6jdEFQYDzLZLzb8J5cRuO5eYXJsILzw1emO7eridwHre0fSmgzqzhsO0/elKPog5mrefAoQt2If9DA3+y2nPV31h/WSmcov1HX5cpGiGY6NLXRyvCAHPuFbEf4eDv8ZbC88ZVnqebn0dD2vj7NW1suyZtfFMHf5iRDkqqlpo2Mjm04ZmDIrqH+BHrf1rMmQu7yPofFHPmnZ1k/eVizry5k7nqazug6t7F129s786Zt+T5T8Def7qTbPFxmUmqnslzwfQwyOekhVVUpo46CimC9HB6P39QfmHHYDdjOszrP+D9rh4+eyHIXPXW9wfat05X2r+1HRuCOfNj5pD+zXD7I7n9v8Pt63L7n8Lta5pPokNAn8uy/yNLlF9Ps3/sTp059+UHHjh18tTymTV6cPnBs6tfVbce/OWDtx68dfbBs2unl7+qTp05f+L0qfvp9Km15dUTpw+dXj7zxbUvnaNzy2uDspNn71+m0YIvn+mdOfuVM/Sl5RP3L6/SA6dPfHH8i/tPnVs7cebk8vjTL5xaC9XQ6vJDyyfW1NrZs/TgiTNfrR+fXR18Sue++uAXzp4+N/j63NrZ1eX76Qunz57s1dCoL3z5gQeWV2l5dfXsqjq3trp84sFwMwb87Cw9eOrcuVNnvkjLZ+6fPfvALFejTp05eXZ1dfnkWt2Vk19aHnsc4Nr4+P4TaycGD8e7TOjTAydW6QsnTvZUXe3qSQDw4Im1k18afPGVU2fuP/sVOnfqa8tDFHHv1r760PJVRob7s7lRfloPy8mzDz60unzu3KmzZ+jB5bUvnb1fyX+FmlTblFKpSlRDxaqpIpUpp1rKqlwZNaG0ait/uZX9qbPKqUjFKlGpaqimylSu2mpSbVe7VEftU/vVx9Uvq9vVr6v/Qp1U59QT6h+pP1f/uzK6bmv8bzL8bQt/28PfVPjbEf4KtaS+z6YxowQGwJqrSbVblepW5dUJ9Zj6Z0rrx5CmzmqnY53qli70tCZ9i57X9422X7dZt4U2dqqdapfapabVtNqtdqs9ao/qqI7aq/aqG9QNal7Nqw/bfxtwvb7h77Hw93j4eyL8PRn+ngp/F38B/dfr+vJou3V7dTtPq6fV76jfURfUBfW76nfV76nfU7+vfl89o55RX1dfV99Q31B0RKn1VCmtlbpRK9VWSl06qpRqSP9uVPKM+xqebVdKJcpfmsyOi3Vz+M9s+Gc3/HMb/kVj//zFbdnyxqo2flq/Hod/SfiXhn+N8K8Z/mXhXyv8y/mfv7w9219Xn9QTZ3KbSpNG3Iwy17K5mdBt5d/enj2YcNtOpfxP8XgVKg3XMW8i0vAOqLHBsBT8vL7GKMk1vXetNK5xZbRycm200apoKP/TqaxBx7Rg9f8D")))), m) });
}

// node_modules/@zip.js/zip.js/lib/zip-module-wasm-base.js
init_constants();
init_configuration();
init_codec_worker();
init_codec_pool();

// node_modules/@zip.js/zip.js/lib/core/streams/zlib-wasm/zlib-streams.js
var FORMAT_DEFLATE = "deflate";
var FORMAT_DEFLATE_RAW2 = "deflate-raw";
var FORMAT_DEFLATE64_RAW2 = "deflate64-raw";
var FORMAT_GZIP2 = "gzip";
var wasm;
var malloc;
var free;
var memory;
var initError;
function setWasmExports(wasmAPI) {
  wasm = wasmAPI;
  ({ malloc, free, memory } = wasm);
  if (typeof malloc !== "function" || typeof free !== "function" || !memory) {
    wasm = malloc = free = memory = null;
    throw new Error("Invalid WASM module");
  }
}
function setInitError(error) {
  initError = error;
}
function _make(isCompress, type, options = {}) {
  if (!wasm) {
    const error = new Error("WASM module not loaded");
    error.cause = initError;
    throw error;
  }
  const level = typeof options.level === "number" ? options.level : -1;
  const outBufferSize = typeof options.outBuffer === "number" ? options.outBuffer : 64 * 1024;
  const inBufferSize = typeof options.inBufferSize === "number" ? options.inBufferSize : 64 * 1024;
  return new TransformStream({
    start() {
      try {
        let result;
        this.out = malloc(outBufferSize);
        this.in = malloc(inBufferSize);
        this.inBufferSize = inBufferSize;
        if (!this.out || !this.in) {
          throw new Error("allocation failed");
        }
        this._scratch = new Uint8Array(outBufferSize);
        if (isCompress) {
          this._process = wasm.deflate_process;
          this._last_consumed = wasm.deflate_last_consumed;
          this._end = wasm.deflate_end;
          this.streamHandle = wasm.deflate_new();
          if (type === FORMAT_GZIP2) {
            result = wasm.deflate_init_gzip(this.streamHandle, level);
          } else if (type === FORMAT_DEFLATE_RAW2) {
            result = wasm.deflate_init_raw(this.streamHandle, level);
          } else {
            result = wasm.deflate_init(this.streamHandle, level);
          }
        } else {
          if (type === FORMAT_DEFLATE64_RAW2) {
            this._process = wasm.inflate9_process;
            this._last_consumed = wasm.inflate9_last_consumed;
            this._end = wasm.inflate9_end;
            this.streamHandle = wasm.inflate9_new();
            result = wasm.inflate9_init_raw(this.streamHandle);
          } else {
            this._process = wasm.inflate_process;
            this._last_consumed = wasm.inflate_last_consumed;
            this._end = wasm.inflate_end;
            this.streamHandle = wasm.inflate_new();
            if (type === FORMAT_DEFLATE_RAW2) {
              result = wasm.inflate_init_raw(this.streamHandle);
            } else if (type === FORMAT_GZIP2) {
              result = wasm.inflate_init_gzip(this.streamHandle);
            } else {
              result = wasm.inflate_init(this.streamHandle);
            }
          }
        }
        if (result !== 0) {
          throw new Error("init failed:" + result);
        }
      } catch (error) {
        disposeStream(this);
        throw error;
      }
    },
    transform(chunk, controller) {
      try {
        const buffer = chunk;
        const heap = new Uint8Array(memory.buffer);
        const process = this._process;
        const last_consumed = this._last_consumed;
        const out = this.out;
        const scratch = this._scratch;
        let offset = 0;
        while (offset < buffer.length) {
          const toRead = Math.min(buffer.length - offset, 32 * 1024);
          if (!this.in || this.inBufferSize < toRead) {
            if (this.in && free) {
              free(this.in);
              this.in = 0;
            }
            this.in = malloc(toRead);
            this.inBufferSize = toRead;
            if (!this.in) {
              throw new Error("allocation failed");
            }
          }
          heap.set(buffer.subarray(offset, offset + toRead), this.in);
          const result = process(this.streamHandle, this.in, toRead, out, outBufferSize, 0);
          const code = result >> 24 & 255;
          const signedCode = code & 128 ? code - 256 : code;
          if (signedCode < 0) {
            throw new Error("process error:" + signedCode);
          }
          const prod = result & 16777215;
          if (prod) {
            scratch.set(heap.subarray(out, out + prod), 0);
            controller.enqueue(scratch.slice(0, prod));
          }
          const consumed = last_consumed(this.streamHandle);
          if (consumed === 0 && prod === 0) {
            break;
          }
          offset += consumed;
        }
      } catch (error) {
        disposeStream(this);
        controller.error(error);
      }
    },
    flush(controller) {
      try {
        const heap = new Uint8Array(memory.buffer);
        const process = this._process;
        const out = this.out;
        const scratch = this._scratch;
        while (true) {
          const result = process(this.streamHandle, 0, 0, out, outBufferSize, 4);
          const code = result >> 24 & 255;
          const signedCode = code & 128 ? code - 256 : code;
          if (signedCode < 0) {
            throw new Error("process error:" + signedCode);
          }
          const produced = result & 16777215;
          if (produced) {
            scratch.set(heap.subarray(out, out + produced), 0);
            controller.enqueue(scratch.slice(0, produced));
          }
          if (code === 1 || produced === 0) {
            break;
          }
        }
      } catch (error) {
        controller.error(error);
      } finally {
        const result = disposeStream(this);
        if (result !== 0) {
          controller.error(new Error("end error:" + result));
        }
      }
    },
    cancel() {
      disposeStream(this);
    }
  });
  function disposeStream(state) {
    let endResult = 0;
    if (state.streamHandle && state._end) {
      endResult = state._end(state.streamHandle);
    }
    state.streamHandle = 0;
    if (state.in && free) {
      free(state.in);
    }
    state.in = 0;
    if (state.out && free) {
      free(state.out);
    }
    state.out = 0;
    return endResult;
  }
}
var CompressionStreamZlib = class {
  constructor(type = FORMAT_DEFLATE, options) {
    return _make(true, type, options);
  }
};
var DecompressionStreamZlib = class {
  constructor(type = FORMAT_DEFLATE, options) {
    return _make(false, type, options);
  }
};
CompressionStreamZlib.requiresModule = true;
DecompressionStreamZlib.requiresModule = true;
CompressionStreamZlib.supportedFormats = [FORMAT_DEFLATE, FORMAT_DEFLATE_RAW2, FORMAT_GZIP2];
DecompressionStreamZlib.supportedFormats = [FORMAT_DEFLATE, FORMAT_DEFLATE_RAW2, FORMAT_GZIP2, FORMAT_DEFLATE64_RAW2];

// node_modules/@zip.js/zip.js/lib/core/streams/zlib-wasm/zlib-streams-loader.js
var initializedModule = false;
async function initModule2(wasmURI, { baseURI }) {
  if (!initializedModule) {
    try {
      await instantiateModule(wasmURI, baseURI);
      initializedModule = true;
    } catch (error) {
      setInitError(error);
      throw error;
    }
  }
}
async function instantiateModule(wasmURI, baseURI) {
  let arrayBuffer, uri;
  try {
    try {
      uri = new URL(wasmURI, baseURI);
    } catch {
    }
    const response = await fetch(uri);
    arrayBuffer = await response.arrayBuffer();
  } catch (error) {
    if (wasmURI.startsWith("data:application/wasm;base64,")) {
      arrayBuffer = arrayBufferFromDataURI(wasmURI);
    } else {
      throw error;
    }
  }
  const wasmInstance = await WebAssembly.instantiate(arrayBuffer);
  setWasmExports(wasmInstance.instance.exports);
}
function arrayBufferFromDataURI(dataURI) {
  const base64 = dataURI.split(",")[1];
  const binary = atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; ++i) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

// node_modules/@zip.js/zip.js/lib/zip-module-wasm-base.js
var modulePromise;
configureWorker({
  initModule: (config2) => {
    if (!modulePromise) {
      let { wasmURI } = config2;
      if (typeof wasmURI == FUNCTION_TYPE) {
        wasmURI = wasmURI();
      }
      modulePromise = initModule2(wasmURI, config2).catch((error) => {
        modulePromise = null;
        throw error;
      });
    }
    return modulePromise;
  }
});
setDefaultConfiguration({
  CompressionStreamFallback: CompressionStreamZlib,
  DecompressionStreamFallback: DecompressionStreamZlib
});

// node_modules/@zip.js/zip.js/lib/zip-module-wasm.js
s(setDefaultConfiguration);

// src/generated/zip-assets.ts
var ZIP_CODEC_WORKER_URL = "/workers/zip-codec.3f6dd95b34eca13b9cf0636f2e28cdc494dfe0a76973510e40f35ba651abb345.worker.js";
var ZIP_WASM_URL = "/workers/zip-module.46f729acd6190568922be4b5be49c5fec73027b3064921908fe587536d8b91c8.wasm";

// src/features/archive/zip.ts
if (typeof location !== "undefined") {
  configure({
    baseURI: location.href,
    workerURI: ZIP_CODEC_WORKER_URL,
    wasmURI: ZIP_WASM_URL
  });
}

// src/features/dashboard/bounded-blob-writer.ts
var ZIP_ARCHIVE_SAFETY_LIMIT_ERROR = "The ZIP archive exceeds the browser safety limit.";
var BoundedBlobWriter = class extends Writer {
  constructor(maxBytes) {
    super();
    this.maxBytes = maxBytes;
  }
  maxBytes;
  chunks = [];
  writtenBytes = 0;
  async writeUint8Array(array) {
    if (this.writtenBytes + array.byteLength > this.maxBytes) {
      throw new Error(ZIP_ARCHIVE_SAFETY_LIMIT_ERROR);
    }
    this.writtenBytes += array.byteLength;
    const copy = new Uint8Array(array.byteLength);
    copy.set(array);
    this.chunks.push(copy.buffer);
  }
  async getData() {
    return new Blob(this.chunks, { type: "application/zip" });
  }
};

// src/features/uploads/progress-coalescer.ts
function createIntervalProgressCoalescer(emit, intervalMilliseconds = 100, now = performance.now.bind(performance)) {
  let lastEmission = Number.NEGATIVE_INFINITY;
  let pending;
  let hasPending = false;
  const deliver = (timestamp) => {
    if (!hasPending) return;
    const value = pending;
    pending = void 0;
    hasPending = false;
    lastEmission = timestamp;
    emit(value);
  };
  return {
    publish(value, immediate = false) {
      pending = value;
      hasPending = true;
      const timestamp = now();
      if (immediate || timestamp - lastEmission >= intervalMilliseconds) {
        deliver(timestamp);
      }
    },
    flush() {
      deliver(now());
    }
  };
}

// src/features/dashboard/folder-zip.worker.ts
var workerScope = self;
var activeController = null;
workerScope.onmessage = (event) => {
  if (event.data.type === "cancel") {
    activeController?.abort();
    return;
  }
  if (activeController) {
    return;
  }
  void createArchive(event.data);
};
async function createArchive(request) {
  const { sources, compressionMode = "balanced", maxOutputBytes } = request;
  const controller = new AbortController();
  activeController = controller;
  const totalBytes = sources.reduce(
    (total, source) => total + (source.directory ? 0 : source.file.size),
    0
  );
  let completedBytes = 0;
  let currentPath = "";
  const progressReporter = createIntervalProgressCoalescer(
    (message) => workerScope.postMessage(message)
  );
  try {
    progressReporter.publish(
      {
        type: "progress",
        processedBytes: 0,
        totalBytes,
        currentPath
      },
      true
    );
    if (maxOutputBytes !== void 0 && (!Number.isSafeInteger(maxOutputBytes) || maxOutputBytes <= 0)) {
      throw new Error("The ZIP archive output limit is invalid.");
    }
    const blobWriter = maxOutputBytes === void 0 ? new BlobWriter("application/zip") : new BoundedBlobWriter(maxOutputBytes);
    const zipWriter = new ZipWriter(blobWriter, {
      signal: controller.signal,
      useWebWorkers: false
    });
    for (const source of sources) {
      const path = normalizeArchivePath(source.path);
      if (!path) {
        continue;
      }
      if (source.directory) {
        const directoryPath = path.endsWith("/") ? path : `${path}/`;
        currentPath = directoryPath;
        await zipWriter.add(directoryPath, void 0, {
          directory: true,
          lastModDate: new Date(source.lastModified),
          signal: controller.signal
        });
        progressReporter.publish({
          type: "progress",
          processedBytes: completedBytes,
          totalBytes,
          currentPath
        });
        continue;
      }
      currentPath = path;
      await zipWriter.add(path, new BlobReader(source.file), {
        level: archiveCompressionLevel({
          path,
          mimeType: source.file.type,
          mode: compressionMode
        }),
        lastModDate: new Date(source.file.lastModified),
        signal: controller.signal,
        onprogress(progress) {
          progressReporter.publish({
            type: "progress",
            processedBytes: completedBytes + progress,
            totalBytes,
            currentPath: path
          });
        }
      });
      completedBytes += source.file.size;
      progressReporter.publish({
        type: "progress",
        processedBytes: completedBytes,
        totalBytes,
        currentPath
      });
    }
    const archive = await zipWriter.close();
    if (controller.signal.aborted) {
      workerScope.postMessage({ type: "canceled" });
      return;
    }
    progressReporter.publish(
      {
        type: "progress",
        processedBytes: totalBytes,
        totalBytes,
        currentPath
      },
      true
    );
    workerScope.postMessage({ type: "complete", archive });
  } catch (error) {
    if (controller.signal.aborted) {
      workerScope.postMessage({ type: "canceled" });
      return;
    }
    workerScope.postMessage({
      type: "error",
      message: error instanceof Error ? error.message : "The ZIP archive could not be created."
    });
  } finally {
    activeController = null;
  }
}
function normalizeArchivePath(value) {
  return value.replaceAll("\\", "/").split("/").flatMap((segment) => {
    if (!segment || segment === "." || segment === "..") return [];
    const normalized = Array.from(segment).filter((character) => {
      const code = character.charCodeAt(0);
      return code > 31 && code !== 127;
    }).join("").trim();
    return normalized ? [normalized] : [];
  }).join("/");
}
